export declare const DELAYED_EVENTS_ROUTES_ENTRY_COUNT: 7;
export declare const DELAYED_EVENTS_ROUTES_STATUS_SCENARIOS: readonly [];
export type DelayedEventsStatusScenario = (typeof DELAYED_EVENTS_ROUTES_STATUS_SCENARIOS)[number];
export declare const DELAYED_EVENTS_ROUTES_ERROR_SCENARIOS: readonly [];
export type DelayedEventsErrorScenario = (typeof DELAYED_EVENTS_ROUTES_ERROR_SCENARIOS)[number];
export declare const DELAYED_EVENTS_ROUTES_ERRCODES: readonly [];
export type DelayedEventsErrcode = (typeof DELAYED_EVENTS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map