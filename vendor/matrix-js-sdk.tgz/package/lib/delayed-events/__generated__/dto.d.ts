/**
 * DTO snippets extracted from the contract doc for `delayed-events`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
import type { IContent } from "../../models/event.ts";
export interface DelayedEventInfo {
    delay_id: number;
    room_id: string;
    type: string;
    state_key?: string;
    delay_ms: number;
    delayed_since_ts: number;
    content: IContent;
}
export interface ListDelayedEventsResponse {
    delayed_events: DelayedEventInfo[];
}
export interface UpdateDelayedEventRequest {
    action: "send" | "cancel" | "restart";
}
export interface ScheduleDelayedEventRequest {
    delay_ms: number;
    content: IContent;
    state_key?: string | null;
}
export interface ScheduleDelayedEventResponse {
    delay_id: number;
}
//# sourceMappingURL=dto.d.ts.map