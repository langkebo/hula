/**
 * External Service Manager - 外部服务管理
 *
 * 提供外部服务的 CRUD、健康检查、Webhook 触发等功能
 * 支持三种 API 前缀: synapse_admin (/_synapse/admin/v1)、matrix_admin (/_matrix/admin/v1)、client (/_matrix/client/v1)
 * 以及 Webhook 路由前缀: /_synapse/external
 * 对应后端: synapse-rust/src/web/routes/external_service.rs
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export type ExternalServiceApiPrefix = "synapse_admin" | "matrix_admin" | "client";
/**
 * Arbitrary configuration values for an external service.
 * Shape varies by service type (e.g. webhook, openclaw, trendradar).
 */
export type ExternalServiceConfig = Record<string, unknown>;
/**
 * Arbitrary JSON payload sent to an external service webhook endpoint.
 */
export type WebhookPayload = Record<string, unknown>;
export interface ExternalServiceItem {
    id: string;
    type: string;
    url: string;
    enabled: boolean;
}
export interface ExternalServiceListResponse {
    services: ExternalServiceItem[];
    total?: number;
}
export interface ExternalServiceCreateRequest {
    type: string;
    url: string;
    config?: ExternalServiceConfig;
    enabled?: boolean;
}
export interface ExternalServiceCreateResponse {
    id: string;
}
export interface ExternalServiceUpdateRequest {
    type?: string;
    url?: string;
    config?: ExternalServiceConfig;
    enabled?: boolean;
}
export interface ExternalServiceUpdateResponse {
    id: string;
}
export interface ExternalServiceDeleteResponse {
    id: string;
}
export interface ExternalServiceHealthResponse {
    status: string;
    services?: Array<{
        id: string;
        type: string;
        status: string;
        last_check?: number;
    }>;
}
export interface ExternalServiceSingleHealthResponse {
    id: string;
    type: string;
    status: string;
    last_check?: number;
    error?: string;
}
export interface ExternalServiceHealthCheckResponse {
    id: string;
    status: string;
    checked_at: number;
    healthy: boolean;
    error?: string;
}
export interface ExternalServiceWebhookResponse {
    success: boolean;
    message?: string;
}
export declare class ExternalServiceManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    private resolvePrefix;
    private resolveListPath;
    private resolveServiceIdPath;
    private resolveHealthPath;
    listServices(prefix?: ExternalServiceApiPrefix): Promise<ExternalServiceListResponse>;
    createService(data: ExternalServiceCreateRequest, prefix?: ExternalServiceApiPrefix): Promise<ExternalServiceCreateResponse>;
    updateService(serviceId: string, data: ExternalServiceUpdateRequest, prefix?: ExternalServiceApiPrefix): Promise<ExternalServiceUpdateResponse>;
    deleteService(serviceId: string, prefix?: ExternalServiceApiPrefix): Promise<ExternalServiceDeleteResponse>;
    getHealth(prefix?: ExternalServiceApiPrefix): Promise<ExternalServiceHealthResponse>;
    getServiceHealth(serviceId: string): Promise<ExternalServiceSingleHealthResponse>;
    checkServiceHealth(serviceId: string): Promise<ExternalServiceHealthCheckResponse>;
    triggerWebhook(serviceId: string, data?: WebhookPayload): Promise<ExternalServiceWebhookResponse>;
    triggerOpenclawWebhook(serviceId: string, data?: WebhookPayload): Promise<ExternalServiceWebhookResponse>;
    triggerTrendradarWebhook(serviceId: string, data?: WebhookPayload): Promise<ExternalServiceWebhookResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map