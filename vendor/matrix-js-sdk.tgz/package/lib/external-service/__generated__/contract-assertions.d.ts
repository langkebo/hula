export declare const EXTERNAL_SERVICE_ROUTES_ENTRY_COUNT: 11;
export declare const EXTERNAL_SERVICE_ROUTES_STATUS_SCENARIOS: readonly [];
export type ExternalServiceStatusScenario = (typeof EXTERNAL_SERVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const EXTERNAL_SERVICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type ExternalServiceErrorScenario = (typeof EXTERNAL_SERVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const EXTERNAL_SERVICE_ROUTES_ERRCODES: readonly [];
export type ExternalServiceErrcode = (typeof EXTERNAL_SERVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map