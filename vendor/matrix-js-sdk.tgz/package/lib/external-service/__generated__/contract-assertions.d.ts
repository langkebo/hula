export declare const EXTERNAL_SERVICE_ROUTES_ENTRY_COUNT: 10;
export declare const EXTERNAL_SERVICE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "查询、健康检查或 Webhook 处理成功";
}, {
    readonly status: 201;
    readonly note: "外部服务创建成功";
}, {
    readonly status: 204;
    readonly note: "外部服务删除成功";
}, {
    readonly status: 400;
    readonly note: "服务类型、Webhook 配置或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "管理员凭据缺失，或 Webhook 服务签名/凭据无效";
}, {
    readonly status: 403;
    readonly note: "当前账号或服务无权访问目标端点";
}, {
    readonly status: 404;
    readonly note: "服务实例不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "按 synapse-rust 路由与 SDK 实现修正端点清单、覆盖率和已知差异 | 覆盖率从 0% 修正为 85.7%，明确 Webhook 不纳入 SDK 统计";
}];
export type ExternalServiceStatusScenario = (typeof EXTERNAL_SERVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const EXTERNAL_SERVICE_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "管理员或服务凭据无效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "检查管理员登录态或服务侧签名配置";
}, {
    readonly scenario: "服务配置不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 type、url、config 或 webhook 请求体";
}, {
    readonly scenario: "权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "确认管理员权限或服务绑定关系";
}, {
    readonly scenario: "服务不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新服务列表并核对 as_id/service_id";
}];
export type ExternalServiceErrorScenario = (typeof EXTERNAL_SERVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const EXTERNAL_SERVICE_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "管理员凭据或服务签名无效";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "外部服务请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "as_id、service_id 或服务配置参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "当前账号或服务无权访问目标端点";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "目标外部服务不存在";
}];
export type ExternalServiceErrcode = (typeof EXTERNAL_SERVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map