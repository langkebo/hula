export declare const EXTERNAL_SERVICE_ROUTES_ENTRY_COUNT: 18;
export declare const EXTERNAL_SERVICE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type ExternalServiceStatusScenario = (typeof EXTERNAL_SERVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const EXTERNAL_SERVICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type ExternalServiceErrorScenario = (typeof EXTERNAL_SERVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const EXTERNAL_SERVICE_ROUTES_ERRCODES: readonly [];
export type ExternalServiceErrcode = (typeof EXTERNAL_SERVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map