/** Routes served by the synapse-rust `external-service` module (mirrored from the backend contract). */
export declare const EXTERNAL_SERVICE_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/admin/v1/external_services";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/admin/v1/external_services";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/admin/v1/external_services/health";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/admin/v1/external_services/{as_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/admin/v1/external_services/{as_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/external_services/health";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/external_services/{service_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/external_services/{service_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/external_services";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/external_services";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/external_services/health";
}, {
    readonly method: "DELETE";
    readonly path: "/_synapse/admin/v1/external_services/{as_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/admin/v1/external_services/{as_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/external_services/{as_id}/health";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/external_services/{as_id}/health/check";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/external/trendradar/{service_id}/webhook";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/external/webhook/{service_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/vendor/v1/external_services/health";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/vendor/v1/external_services/{service_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/vendor/v1/external_services/{service_id}";
}];
/** Union of every (method, path) tuple in `EXTERNAL_SERVICE_ROUTES`. */
export type ExternalServiceRoute = (typeof EXTERNAL_SERVICE_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type ExternalServiceMethod = ExternalServiceRoute["method"];
/** Path templates referenced by this module. */
export type ExternalServicePath = ExternalServiceRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type ExternalServiceReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${ExternalServiceReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type ExternalServicePathPattern = ExternalServiceReplaceBraces<ExternalServicePath>;
//# sourceMappingURL=route-table.d.ts.map