/**
 * DTO snippets extracted from the contract doc for `external-service`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ExternalServicesResponse {
    services: Array<{
        id: string;
        type: string;
        url: string;
        enabled: boolean;
    }>;
}
export interface ExternalServiceAdminRequestDto {
    type: string;
    url: string;
    config: Record<string, never>;
}
export interface ExternalServiceAdminResponseDto {
    id: string;
}
//# sourceMappingURL=dto.d.ts.map