/**
 * DTO snippets extracted from the contract doc for `external_service`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ExternalServicesResponse {
    services: Array<{
        id: string;
        type: string;
        url: string;
        enabled: boolean;
    }>;
}
export interface ExternalServiceHealthResponse {
    service_id: string;
    service_type: string;
    is_healthy: boolean;
    last_check_ts: number;
    last_success_ts?: number;
    last_error?: string;
    consecutive_failures: number;
}
export interface ExternalServiceAdminRequestDto {
    type: string;
    url: string;
    config: Record<string, never>;
}
export interface ExternalServiceAdminResponseDto {
    id: string;
}
//# sourceMappingURL=dto.d.ts.map