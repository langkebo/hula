/**
 * ThreePids Manager - 三方身份管理
 *
 * 提供三方身份（邮箱、手机号）的绑定、解绑、查询功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IThreepid } from "../@types/three-pids";
import type { IdServerUnbindResult } from "../@types/partials";
import type { EmptyObject } from "../@types/common";
export type ThreePidsManagerEvents = Record<"threepid_bound" | "threepid_unbound" | "threepid_deleted", (data: {
    medium: string;
    address: string;
}) => void>;
export declare class ThreePidsManager extends BaseManager<keyof ThreePidsManagerEvents, ThreePidsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getThreePids(): Promise<{
        threepids: IThreepid[];
    }>;
    addThreePidOnly(clientSecret: string, sid: string): Promise<EmptyObject>;
    bindThreePid(clientSecret: string, sid: string, idServer: string, idAccessToken: string | null): Promise<EmptyObject>;
    unbindThreePid(medium: string, address: string, idServer?: string): Promise<{
        id_server_unbind_result: IdServerUnbindResult;
    }>;
    deleteThreePid(medium: string, address: string, idServer?: string): Promise<{
        id_server_unbind_result: IdServerUnbindResult;
    }>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map