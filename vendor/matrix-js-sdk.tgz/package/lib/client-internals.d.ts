import type { SendDelayedEventRequestOpts } from "./@types/requests";
import type { QueryDict } from "./utils";
export declare function getLegacyClientPrefix(version?: "v1" | "r0"): string;
export declare function buildUnstableDelayQueryOpts(delayOpts: SendDelayedEventRequestOpts, unstableFeatureName: string): QueryDict;
//# sourceMappingURL=client-internals.d.ts.map