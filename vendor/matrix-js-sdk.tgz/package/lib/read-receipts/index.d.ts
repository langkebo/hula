import { MatrixClient } from "../client";
import { Receipt, ReceiptType } from "../@types/read_receipts";
import type { EmptyObject } from "../@types/common";
import type { MatrixEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type ReceiptBody } from "../client-receipt-requests";
export interface IReadReceipt {
    eventId: string;
    ts: number;
    userId: string;
    data?: Receipt;
}
export interface IReadMarkers {
    m_read?: string;
    m_fully_read?: string;
}
export interface ReadReceiptsManagerEvents {
    receipt_sent: {
        roomId: string;
        eventId: string;
    };
    markers_updated: {
        roomId: string;
        markers: IReadMarkers;
    };
}
export declare class ReadReceiptsManager extends BaseManager<keyof ReadReceiptsManagerEvents, ReadReceiptsManagerEvents> {
    private pendingReceiptTimers;
    private pendingReceiptData;
    private pendingReceiptResolvers;
    private readonly RECEIPT_DEBOUNCE_MS;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Send a receipt.
     * @param event - The event being acknowledged
     * @param receiptType - The kind of receipt e.g. "m.read". Other than
     * ReceiptType.Read are experimental!
     * @param body - Additional content to send alongside the receipt.
     * @param unthreaded - An unthreaded receipt will clear room+thread notifications
     * @returns Promise which resolves: to an empty object `{}`
     * @returns Rejects: with an error response.
     */
    sendReceipt(event: MatrixEvent, receiptType: ReceiptType, body?: ReceiptBody, unthreaded?: boolean): Promise<EmptyObject>;
    /**
     * Send a read receipt.
     * @param event - The event that has been read.
     * @param receiptType - other than ReceiptType.Read are experimental! Optional.
     * @returns Promise which resolves: to an empty object `{}`
     * @returns Rejects: with an error response.
     */
    sendReadReceipt(event: MatrixEvent | null, receiptType?: ReceiptType, unthreaded?: boolean): Promise<EmptyObject | undefined>;
    /**
     * Set a marker to indicate the point in a room before which the user has read every
     * event. This can be retrieved from room account data (the event type is `m.fully_read`)
     * and displayed as a horizontal line in the timeline that is visually distinct to the
     * position of the user's own read receipt.
     * @param roomId - ID of the room that has been read
     * @param rmEventId - ID of the event that has been read
     * @param rrEvent - the event tracked by the read receipt. This is here for
     * convenience because the RR and the RM are commonly updated at the same time as each
     * other. The local echo of this receipt will be done if set. Optional.
     * @param rpEvent - the m.read.private read receipt event for when we don't
     * want other users to see the read receipts. This is experimental. Optional.
     * @returns Promise which resolves: the empty object, `{}`.
     */
    setRoomReadMarkers(roomId: string, rmEventId: string, rrEvent?: MatrixEvent, rpEvent?: MatrixEvent): Promise<EmptyObject>;
    /**
     * Send an HTTP request to set room read markers.
     * @param roomId - ID of the room
     * @param rmEventId - ID of the event that has been read (fully read marker)
     * @param rrEventId - ID of the event tracked by the read receipt. Optional.
     * @param rpEventId - ID of the m.read.private read receipt event. Optional.
     * @returns Promise which resolves: the empty object, `{}`.
     */
    setRoomReadMarkersHttpRequest(roomId: string, rmEventId: string, rrEventId?: string, rpEventId?: string): Promise<EmptyObject>;
    sendReadReceiptByEventId(roomId: string, eventId: string): Promise<void>;
    /**
     * Send a read receipt by room ID and event ID, bypassing the room store lookup.
     * Unlike sendReadReceiptByEventId, this always sends the HTTP request even if
     * the event is not loaded in the local room store.
     *
     * @param roomId - The room ID
     * @param receiptType - The receipt type (e.g. "m.read")
     * @param eventId - The event ID to acknowledge
     */
    sendReceiptForce(roomId: string, receiptType: string, eventId: string): Promise<void>;
    setReadMarkers(roomId: string, eventId: string, fullyReadEventId?: string): Promise<void>;
    setReadMarker(roomId: string, eventId: string): Promise<void>;
    getReceipt(roomId: string, eventId: string): IReadReceipt[];
    getReadMarkers(roomId: string): IReadMarkers;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map