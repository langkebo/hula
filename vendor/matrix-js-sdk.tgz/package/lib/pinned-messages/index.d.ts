import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export declare enum PinnedEvent {
    Pinned = "Pinned",
    Unpinned = "Unpinned",
    PinnedUpdated = "PinnedUpdated",
    PinnedError = "PinnedError"
}
export interface IPinnedEventInfo {
    eventId: string;
    roomId: string;
    pinnedBy?: string;
    pinnedAt?: number;
}
export interface IServerPinnedEventsResponse {
    pinned_events: string[];
}
interface PinnedMessagesManagerEventMap {
    [PinnedEvent.Pinned]: (roomId: string, eventId: string) => void;
    [PinnedEvent.Unpinned]: (roomId: string, eventId: string) => void;
    [PinnedEvent.PinnedUpdated]: (roomId: string, events: IPinnedEventInfo[]) => void;
    [PinnedEvent.PinnedError]: (roomId: string, error: Error) => void;
}
export declare class PinnedMessagesManager extends BaseManager<PinnedEvent, PinnedMessagesManagerEventMap> {
    private pinnedEventsCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
    pinMessage(roomId: string, eventId: string): Promise<void>;
    unpinMessage(roomId: string, eventId: string): Promise<void>;
    getPinnedMessages(roomId: string): string[];
    hasPinnedMessages(roomId: string): boolean;
    getPinnedEventsFromServer(roomId: string): Promise<IPinnedEventInfo[]>;
    pinEventToServer(roomId: string, eventId: string): Promise<void>;
    unpinEventFromServer(roomId: string, eventId: string): Promise<void>;
    getCachedPinnedEvents(roomId: string): IPinnedEventInfo[];
    clearCache(): void;
    stop(): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map