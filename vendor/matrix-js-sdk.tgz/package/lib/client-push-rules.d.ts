import { type IPushRule, type IPushRules, PushRuleActionName, PushRuleKind } from "./@types/PushRules.ts";
type Scope = "global" | "device";
interface PushManagerLike {
    deletePushRule(scope: Scope, kind: PushRuleKind, ruleId: string): Promise<unknown>;
    createPushRule(scope: Scope, kind: PushRuleKind, ruleId: string, body: {
        actions: PushRuleActionName[];
    }): Promise<unknown>;
    getPushRules(): Promise<IPushRules>;
}
export declare function getRoomPushRuleRequest(pushRules: IPushRules | undefined, scope: Scope, roomId: string): IPushRule | undefined;
export declare function setRoomMutePushRuleRequest(scope: Scope, roomId: string, mute: boolean, roomPushRule: IPushRule | undefined, getPushManager: () => PushManagerLike, setPushRules: (rules: IPushRules) => void): Promise<void> | undefined;
export {};
//# sourceMappingURL=client-push-rules.d.ts.map