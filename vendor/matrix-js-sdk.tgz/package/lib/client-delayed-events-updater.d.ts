import { Method, type IRequestOpts } from "./http-api/index.ts";
import type { EmptyObject } from "./@types/common.ts";
import type { UpdateDelayedEventAction } from "./@types/requests.ts";
export interface DelayedEventsHttpClient {
    request<T>(method: Method, path: string, queryParams?: Record<string, unknown>, body?: Record<string, unknown>, opts?: IRequestOpts): Promise<T>;
    authedRequest<T>(method: Method, path: string, queryParams?: Record<string, unknown>, body?: Record<string, unknown>, opts?: IRequestOpts): Promise<T>;
}
export declare function updateScheduledDelayedEventWithActionInBody(http: DelayedEventsHttpClient, delayId: string, action: UpdateDelayedEventAction, unstableFeatureName: string, requestOptions?: IRequestOpts): Promise<EmptyObject>;
export declare function updateScheduledDelayedEventWithFallback(http: DelayedEventsHttpClient, delayId: string, action: UpdateDelayedEventAction, unstableFeatureName: string, requestOptions?: IRequestOpts): Promise<EmptyObject>;
//# sourceMappingURL=client-delayed-events-updater.d.ts.map