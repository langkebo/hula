import { Method, type IRequestOpts } from "./http-api/index";
import type { EmptyObject } from "./@types/common";
import type { UpdateDelayedEventAction } from "./@types/requests";
export interface DelayedEventsHttpClient {
    request<T>(method: Method, path: string, queryParams?: Record<string, unknown>, // Dynamic: HTTP query parameters
    body?: Record<string, unknown>, // Dynamic: HTTP request body
    opts?: IRequestOpts): Promise<T>;
    authedRequest<T>(method: Method, path: string, queryParams?: Record<string, unknown>, // Dynamic: HTTP query parameters
    body?: Record<string, unknown>, // Dynamic: HTTP request body
    opts?: IRequestOpts): Promise<T>;
}
export declare function updateScheduledDelayedEventWithActionInBody(http: DelayedEventsHttpClient, delayId: string, action: UpdateDelayedEventAction, unstableFeatureName: string, requestOptions?: IRequestOpts): Promise<EmptyObject>;
export declare function updateScheduledDelayedEventWithFallback(http: DelayedEventsHttpClient, delayId: string, action: UpdateDelayedEventAction, unstableFeatureName: string, requestOptions?: IRequestOpts): Promise<EmptyObject>;
//# sourceMappingURL=client-delayed-events-updater.d.ts.map