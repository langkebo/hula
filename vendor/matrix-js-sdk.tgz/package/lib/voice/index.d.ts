/**
 * Voice Manager - 语音消息管理 API 封装
 *
 * 提供语音消息统计查询、配置获取、上传/获取/删除语音消息等功能
 * 对接后端: synapse-rust/synapse-web/src/routes/voice.rs
 * API 前缀: /_matrix/client/v3/voice（v3）和 /_matrix/vendor/v1/voice（vendor v1）
 *
 * 注意：MSC3245 协议规定语音转码/转录/优化在客户端完成
 *
 * 路径契约（勿凭直觉补后缀）：`/voice/{media_id}/convert|optimize|transcription`
 * 带 `{media_id}`，而 `/voice/room/{room_id}` 与 `/voice/user/{user_id}` **不带任何后缀**
 * （列表与内容共用同一路由，仅响应体不同）。
 *
 * 使用方式:
 * ```typescript
 * const manager = client.getVoiceManager();
 * // 获取语音统计
 * const stats = await manager.getVoiceStats();
 * // 上传语音消息
 * const result = await manager.uploadVoiceMessage({ content_type: "audio/ogg", body: "..." });
 * ```
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export interface IVoiceStats {
    total_messages: number;
    total_duration_ms: number;
    average_duration_ms: number;
    storage_used_bytes: number;
}
export interface IVoiceRoomStats {
    room_id: string;
    message_count: number;
    total_duration_ms: number;
}
export interface IVoiceUserStats {
    user_id: string;
    message_count: number;
    total_duration_ms: number;
}
export interface IVoiceConfig {
    max_upload_size_bytes: number;
    allowed_content_types: string[];
    auto_transcribe: boolean;
    retention_days: number;
}
export interface IVoiceUploadRequest {
    /** @deprecated Use uploadVoiceMessage(formData) with FormData instead. */
    content: string;
    content_type: string;
    room_id?: string;
    filename?: string;
}
/**
 * Upload a voice message using multipart/form-data (raw binary, no base64 overhead).
 *
 * This is the recommended upload path for P0-2: it sends the raw audio bytes
 * in a multipart form, avoiding the ~33% size inflation of base64 JSON encoding.
 *
 * The FormData fields are:
 *   - `file`: the audio file (File or Blob)
 *   - `room_id` (optional): target room ID
 *   - `duration_ms` (optional): audio duration in milliseconds
 *   - `waveform` (optional): comma-separated uint16 waveform samples
 *   - `content_type` (optional): MIME type; default "audio/ogg"
 */
export interface IVoiceUploadRequestMultipart {
    formData: FormData;
    prefix?: string;
}
/**
 * Response of `POST /voice/upload`.
 *
 * Contract source: `synapse-services/src/voice_service.rs::upload_voice_message`
 * → `json!({ "content_uri", "content", "content_type", "duration_ms", "size" })`.
 *
 * The stored media URI is exposed as `content_uri` (there is no `url`/`mxc_url`
 * alias) and the byte count is `size` (not `size_bytes`); the endpoint does not
 * return a `message_id` — callers derive it from `content_uri` via
 * `MediaLocator::parse`.
 */
export interface IVoiceUploadResponse {
    content_uri: string;
    content: Record<string, unknown>;
    content_type: string;
    duration_ms: number;
    size: number;
}
export interface IVoiceTranscriptionResponse {
    message_id: string;
    text: string;
    language: string;
    confidence: number;
}
/**
 * A stored voice message record.
 *
 * Contract source: `synapse-services/src/voice_service.rs::record_to_message_json`
 * → `{ media_id, user_id, room_id, content_uri, content_type, duration_ms,
 *      size_bytes, created_ts }`.
 *
 * Returned by both the list endpoints and `GET /voice/{media_id}`. The previous
 * shape (`message_id` / `url` / `mxc_url`) never existed on the wire; the mxc
 * URI is `content_uri` and the identifier is `media_id`.
 */
export interface IVoiceMessage {
    media_id: string;
    user_id: string;
    room_id: string | null;
    content_uri: string;
    content_type: string;
    duration_ms: number;
    size_bytes: number;
    created_ts: number;
}
export interface IVoiceDeleteResponse {
    message_id: string;
    deleted: boolean;
}
export interface IVoiceRoomInfo {
    room_id: string;
    [key: string]: unknown;
}
export interface IVoiceUserInfo {
    user_id: string;
    [key: string]: unknown;
}
/**
 * @deprecated The backend never returned `event_id` / `sender` / `duration` /
 * `timestamp` for voice list rows. Alias of {@link IVoiceMessage}.
 */
export type IVoiceMessageItem = IVoiceMessage;
/**
 * Response of `GET /voice/room/{room_id}` and `GET /voice/user/{user_id}`.
 *
 * Contract source: `synapse-services/src/voice_service.rs`
 * (`get_room_voice_messages` / `get_user_voice_messages`) →
 * `{ room_id|user_id, messages: [...], next_batch: <i64|null> }`.
 *
 * `next_batch` is a **keyset cursor carrying the `created_ts` (ms) of the last
 * row**, or `null` when the page is empty. It is a number, not an opaque
 * string, and the backend does **not** return `has_more` — termination is
 * signalled by `messages.length < limit` or `next_batch === null`.
 */
export interface IVoiceMessageList {
    room_id?: string;
    user_id?: string;
    messages: IVoiceMessage[];
    next_batch: number | null;
}
/**
 * Query parameters for the voice list endpoints.
 *
 * Backend `VoiceListQuery` is `#[serde(deny_unknown_fields)]` and only accepts
 * `limit` + `from`; `from` is the millisecond `created_ts` cursor echoed back
 * as `next_batch` by the previous page.
 */
export interface IVoiceListQueryParams {
    limit?: number;
    from?: number;
}
export interface IVoiceConvertOptions {
    format?: string;
    [key: string]: unknown;
}
export interface IVoiceConvertResponse {
    media_id: string;
    [key: string]: unknown;
}
export interface IVoiceOptimizeOptions {
    bitrate?: number;
    [key: string]: unknown;
}
export interface IVoiceOptimizeResponse {
    media_id: string;
    [key: string]: unknown;
}
export interface IVoiceTranscribeOptions {
    language?: string;
    [key: string]: unknown;
}
export interface IVoiceTranscribeResponse {
    media_id: string;
    text: string;
    language?: string;
    confidence?: number;
    [key: string]: unknown;
}
/**
 * Request body for `POST /voice/register` - registering an encrypted voice attachment.
 *
 * Used after uploading via standard media service (`uploadEncryptedFile`) in encrypted
 * rooms: the encrypted file is stored in the `media` table, but we need to register it
 * in `voice_usage_stats` so it appears in the voice lists.
 */
export interface IVoiceRegisterRequest {
    /** The room_id the voice belongs to */
    room_id: string;
    /** The media_id extracted from mxc:// URL */
    media_id: string;
    /** The content type (e.g., "audio/webm") */
    content_type: string;
    /** Duration in milliseconds */
    duration_ms: number;
    /** File size in bytes */
    size_bytes: number;
}
/**
 * Response of `POST /voice/register`.
 */
export interface IVoiceRegisterResponse {
    content_uri: string;
    exists: boolean;
}
export declare enum VoiceEvent {
    StatsUpdated = "StatsUpdated",
    ConfigUpdated = "ConfigUpdated",
    MessageUploaded = "MessageUploaded",
    MessageDeleted = "MessageDeleted",
    Error = "Error"
}
interface VoiceManagerEventMap {
    [VoiceEvent.StatsUpdated]: (stats: IVoiceStats) => void;
    [VoiceEvent.ConfigUpdated]: (config: IVoiceConfig) => void;
    [VoiceEvent.MessageUploaded]: (response: IVoiceUploadResponse) => void;
    [VoiceEvent.MessageDeleted]: (messageId: string) => void;
    [VoiceEvent.Error]: (error: Error) => void;
}
export declare class VoiceManager extends BaseManager<VoiceEvent, VoiceManagerEventMap> {
    private cachedConfig;
    private configPromise;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    isSupported(): Promise<boolean>;
    getVoiceStats(prefix?: string): Promise<IVoiceStats>;
    getRoomVoiceStats(roomId: string, prefix?: string): Promise<IVoiceRoomStats>;
    getUserVoiceStats(userId: string, prefix?: string): Promise<IVoiceUserStats>;
    getVoiceConfig(prefix?: string): Promise<IVoiceConfig>;
    private fetchVoiceConfig;
    uploadVoiceMessage(request: IVoiceUploadRequest, prefix?: string): Promise<IVoiceUploadResponse>;
    /**
     * Upload a voice message using multipart/form-data (P0-2 fix).
     *
     * Avoids the ~33% base64 expansion of the JSON upload path by sending
     * raw audio bytes in a multipart form. Backend must accept multipart
     * (synapse-web `voice.rs` extractor switched to `Multipart`).
     */
    uploadVoiceMessageMultipart(request: IVoiceUploadRequestMultipart): Promise<IVoiceUploadResponse>;
    getVoiceMessage(messageId: string, prefix?: string): Promise<IVoiceMessage>;
    deleteVoiceMessage(messageId: string, prefix?: string): Promise<IVoiceDeleteResponse>;
    /**
     * @deprecated The backend exposes a single route for this path; it returns a
     * **voice-message page**, not a room-info object. Use
     * {@link listRoomVoiceMessages} for the correctly-typed result. Kept as a
     * thin delegate so existing callers keep the same request.
     */
    getRoomVoice(roomId: string, prefix?: string): Promise<IVoiceRoomInfo>;
    /**
     * List voice messages in a room with keyset pagination.
     * GET /_matrix/vendor/v1/voice/room/{room_id}
     *
     * NOTE: the route has **no `/messages` suffix** — it is the same path as
     * `getRoomVoice`, distinguished only by the way the handler renders the
     * body. `synapse-web/src/routes/voice.rs` registers exactly
     * `/voice/room/{room_id}` for both v3 and vendor/v1; appending `/messages`
     * would produce a 404.
     *
     * Backend returns `{ room_id, messages: [...], next_batch: <ms>|null }`.
     *
     * @param roomId - The room ID to list messages for
     * @param params - Optional pagination parameters (`limit`, `from`)
     * @param prefix - API prefix (default: VendorPrefix)
     */
    listRoomVoiceMessages(roomId: string, params?: IVoiceListQueryParams, prefix?: string): Promise<IVoiceMessageList>;
    /**
     * List voice messages for a user with keyset pagination.
     * GET /_matrix/vendor/v1/voice/user/{user_id}
     *
     * NOTE: see {@link listRoomVoiceMessages} — no `/messages` suffix exists on
     * the server side, and the caller must be the user themselves
     * (`voice.rs::get_user_voice_messages` rejects cross-user reads with 403).
     *
     * Backend returns `{ user_id, messages: [...], next_batch: <ms>|null }`.
     *
     * @param userId - The user ID to list messages for (must be the caller)
     * @param params - Optional pagination parameters (`limit`, `from`)
     * @param prefix - API prefix (default: VendorPrefix)
     */
    listUserVoiceMessages(userId: string, params?: IVoiceListQueryParams, prefix?: string): Promise<IVoiceMessageList>;
    /**
     * @deprecated Same route as {@link listUserVoiceMessages}, which returns the
     * correctly-typed voice-message page. Kept as a thin delegate.
     */
    getUserVoice(userId: string, prefix?: string): Promise<IVoiceUserInfo>;
    convertVoiceMessage(mediaId: string, options?: IVoiceConvertOptions, prefix?: string): Promise<IVoiceConvertResponse>;
    optimizeVoiceMessage(mediaId: string, options?: IVoiceOptimizeOptions, prefix?: string): Promise<IVoiceOptimizeResponse>;
    transcribeVoiceMessage(mediaId: string, options?: IVoiceTranscribeOptions, prefix?: string): Promise<IVoiceTranscribeResponse>;
    /**
     * Register an encrypted voice attachment to the voice_usage_stats table.
     *
     * Phase 2.3 - After uploading encrypted voice via standard media service
     * (e.g., `matrixMediaService.uploadEncryptedFile`), call this method to
     * register the voice so it appears in lists.
     *
     * @param roomId - The room the voice belongs to
     * @param mediaId - The media_id from the mxc:// URL
     * @param durationMs - Duration in milliseconds
     * @param sizeBytes - File size in bytes
     * @param contentType - Content type (e.g., "audio/webm")
     * @param prefix - API prefix (default: VendorPrefix)
     */
    registerEncryptedVoice(roomId: string, mediaId: string, durationMs: number, sizeBytes: number, contentType?: string, prefix?: string): Promise<IVoiceRegisterResponse>;
    getCachedConfig(): IVoiceConfig | null;
    /**
     * 获取 RTC 传输协议信息（MSC4143 unstable 端点）。
     *
     * 对应后端 GET /_matrix/client/unstable/org.matrix.msc4143/rtc/transports。
     * 失败时抛出错误，调用方按无 RTC 能力处理。
     */
    getRtcTransports(): Promise<Record<string, unknown>>;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map