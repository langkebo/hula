/**
 * DTO snippets extracted from the contract doc for `voice`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type VoiceContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map