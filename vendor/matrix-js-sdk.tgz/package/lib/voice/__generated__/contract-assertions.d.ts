export declare const VOICE_ROUTES_ENTRY_COUNT: 18;
export declare const VOICE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "base64 无效、音频 MIME 非法、duration_ms 不合法、参数缺失，或 convert / optimize 当前未启用";
}, {
    readonly status: 401;
    readonly note: "需认证接口缺少或使用无效令牌";
}, {
    readonly status: 403;
    readonly note: "跨用户读取用户级语音数据、非成员向他人房间上传语音、无权读取房间/消息级语音内容，或非所有者删除语音时被拒绝";
}, {
    readonly status: 404;
    readonly note: "语音消息不存在";
}, {
    readonly status: 500;
    readonly note: "service 层或存储层内部错误";
}];
export type VoiceStatusScenario = (typeof VOICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const VOICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type VoiceErrorScenario = (typeof VOICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const VOICE_ROUTES_ERRCODES: readonly [];
export type VoiceErrcode = (typeof VOICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map