import { type ICreateClientOpts } from "./client";
import { type MatrixEvent } from "./models/event";
/**
 * Simplified HuLa client for 3-line integration.
 *
 * ISSUE-14: A 30-minute quickstart requires a dead-simple API that hides the
 * full {@link MatrixClient} surface behind the handful of methods most
 * applications need: log in, receive messages, send text, and manage the
 * sync lifecycle.
 *
 * @example
 * ```typescript
 * const hula = new HuLaClient("https://matrix.example.com");
 * await hula.login("alice", "password123");
 * hula.onMessage((roomId, event) => {
 *     console.log(`New message in ${roomId}: ${event.getContent().body}`);
 * });
 * await hula.start();
 * await hula.sendText("!room:example.com", "Hello world!");
 * ```
 */
export declare class HuLaClient {
    private client;
    /**
     * @param homeserverUrl - Base URL of the Matrix homeserver.
     * @param opts - Additional {@link ICreateClientOpts} passed through to the
     *   underlying {@link MatrixClient} (e.g. `accessToken`, `deviceId`).
     */
    constructor(homeserverUrl: string, opts?: Partial<ICreateClientOpts>);
    /**
     * Login with a username and password.
     *
     * On success the underlying client's access token and user id are populated,
     * so {@link HuLaClient.start} / {@link HuLaClient.sendText} can be used
     * immediately afterwards.
     *
     * @param username - The localpart or full user id to log in as.
     * @param password - The account password.
     */
    login(username: string, password: string): Promise<void>;
    /**
     * Register a callback for incoming timeline messages.
     *
     * The callback is invoked for each non-removed event emitted on
     * {@link RoomEvent.Timeline}. Removals (e.g. redactions of local echo) are
     * filtered out so the callback only fires for newly arrived events.
     *
     * @param callback - Invoked with the room id and the received event.
     */
    onMessage(callback: (roomId: string, event: MatrixEvent) => void): void;
    /**
     * Send a text message to a room.
     *
     * @param roomId - The id of the target room.
     * @param text - The plaintext body to send.
     * @returns The id of the newly created event.
     */
    sendText(roomId: string, text: string): Promise<string>;
    /**
     * Start syncing with the homeserver.
     *
     * Resolves once the client has begun syncing. Incoming messages registered
     * via {@link HuLaClient.onMessage} will be delivered after this resolves.
     */
    start(): Promise<void>;
    /**
     * Stop syncing and clean up the underlying client.
     */
    stop(): void;
}
//# sourceMappingURL=hula-client.d.ts.map