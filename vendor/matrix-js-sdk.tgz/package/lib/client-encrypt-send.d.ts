import { type ISendEventResponse, type SendDelayedEventRequestOpts, type SendDelayedEventResponse } from "./@types/requests.ts";
import { EventStatus, type MatrixEvent } from "./models/event.ts";
import type { Room } from "./models/room.ts";
import type { MatrixScheduler } from "./scheduler.ts";
import type { QueryDict } from "./utils.ts";
interface LoggerLike {
    error(...args: unknown[]): void;
}
interface EncryptAndSendEventArgs {
    room: Room | null;
    event: MatrixEvent;
    delayOptsOrQuery?: SendDelayedEventRequestOpts | QueryDict;
    queryDict?: QueryDict;
    scheduler?: MatrixScheduler<ISendEventResponse>;
    eventsBeingEncrypted: Set<string>;
    encryptEventIfNeeded: (event: MatrixEvent, room?: Room) => Promise<void>;
    sendEventHttpRequest: (event: MatrixEvent, queryOrDelayOpts?: SendDelayedEventRequestOpts | QueryDict, queryDict?: QueryDict) => Promise<ISendEventResponse | SendDelayedEventResponse>;
    updatePendingEventStatus: (room: Room | null, event: MatrixEvent, newStatus: EventStatus) => void;
    logger: LoggerLike;
}
export declare function encryptAndSendEventWorkflow({ room, event, delayOptsOrQuery, queryDict, scheduler, eventsBeingEncrypted, encryptEventIfNeeded, sendEventHttpRequest, updatePendingEventStatus, logger, }: EncryptAndSendEventArgs): Promise<ISendEventResponse | SendDelayedEventResponse>;
export {};
//# sourceMappingURL=client-encrypt-send.d.ts.map