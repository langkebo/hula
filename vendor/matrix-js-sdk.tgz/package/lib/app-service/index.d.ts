/**
 * Application Service Manager - 应用服务管理
 *
 * 提供应用服务的注册、查询、管理功能
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export declare enum AppServiceEvent {
    ServiceRegistered = "ServiceRegistered",
    ServiceUpdated = "ServiceUpdated",
    ServiceUnregistered = "ServiceUnregistered",
    ServiceError = "ServiceError"
}
/**
 * 后端响应类型（`synapse-rust/src/web/routes/app_service.rs:127-154` 对应的 `AppServiceResponse`）。
 * - `id` 是 DB 行 id（i64）
 * - `as_id` 是业务 ID（和请求体 `id` 对应），**应该作为 Manager 的主键**
 * - `sender` 是后端从 `sender_localpart` 重命名后的字段
 */
export interface ApplicationServiceResponse {
    id: number;
    as_id: string;
    url: string;
    sender: string;
    description?: string;
    rate_limited: boolean;
    protocols: string[];
    is_enabled: boolean;
    created_ts: number;
}
export interface ApplicationService {
    /** 业务 ID（对应后端 as_id），作为 Manager 主键 */
    as_id: string;
    /** DB 行 id；仅调试/关联用，不作为主键 */
    db_id?: number;
    url: string;
    as_token?: string;
    hs_token?: string;
    sender_localpart: string;
    sender?: string;
    description?: string;
    rate_limited?: boolean;
    is_enabled?: boolean;
    created_ts?: number;
    protocols?: string[];
    namespaces?: {
        users?: ApplicationServiceNamespace[];
        rooms?: ApplicationServiceNamespace[];
        aliases?: ApplicationServiceNamespace[];
    };
}
export interface ApplicationServiceNamespace {
    exclusive: boolean;
    regex: string;
    group_id?: string;
}
export interface ApplicationServiceUser {
    user_id: string;
    displayname?: string;
    avatar_url?: string;
}
export interface ApplicationServiceProtocol {
    instances: ApplicationServiceProtocolInstance[];
}
export interface ApplicationServiceProtocolInstance {
    network_id: string;
    desc: string;
    icon?: string;
    field?: string;
}
export interface UserAppservicesResponse {
    user_id: string;
    appservices: Array<{
        id?: string;
        as_id?: string;
        url?: string;
        sender_localpart?: string;
        namespaces?: object;
        [key: string]: unknown;
    }>;
}
export interface ApplicationServiceQueryUserResult {
    user_id: string;
    application_service: string | null;
    exists: boolean;
}
export interface ApplicationServiceQueryAliasResult {
    alias: string;
    application_service: string | null;
    exists: boolean;
}
export interface ApplicationServiceStateEntry {
    as_id: string;
    state_key: string;
    state_value: string;
    updated_ts: number;
}
export interface PingResult {
    duration: number;
}
export interface RegisterApplicationServiceRequest {
    /** 业务 ID（对应后端 RegisterAppServiceBody.id） */
    id: string;
    url: string;
    as_token: string;
    hs_token: string;
    /** 发送者（本地部分），后端将其映射为 sender_localpart 存储 */
    sender_localpart: string;
    description?: string;
    rate_limited?: boolean;
    protocols?: string[];
    namespaces?: ApplicationService["namespaces"];
}
export interface UpdateApplicationServiceRequest extends Partial<ApplicationService> {
}
interface ApplicationServiceManagerEventMap {
    [AppServiceEvent.ServiceRegistered]: (serviceId: string, service: ApplicationService) => void;
    [AppServiceEvent.ServiceUpdated]: (serviceId: string, service: ApplicationService) => void;
    [AppServiceEvent.ServiceUnregistered]: (serviceId: string) => void;
    [AppServiceEvent.ServiceError]: (error: Error) => void;
}
export declare class ApplicationServiceManager extends BaseManager<AppServiceEvent, ApplicationServiceManagerEventMap> {
    private services;
    private initialized;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 将后端 AppServiceResponse 规范化为 SDK ApplicationService。
     * 后端 sender 字段实际是 sender_localpart 重命名后的结果。
     */
    private fromResponse;
    registerAppService(request: RegisterApplicationServiceRequest): Promise<ApplicationService>;
    getApplicationService(asId: string): Promise<ApplicationService | null>;
    updateApplicationService(asId: string, request: UpdateApplicationServiceRequest): Promise<ApplicationService>;
    unregisterApplicationService(asId: string): Promise<void>;
    listApplicationServices(): Promise<ApplicationService[]>;
    /**
     * 查询某 userId 是否落在已注册 AS 的命名空间内。
     *
     * @remarks
     * 对应后端 `GET /_matrix/client/v3/appservice/user`，handler 使用 `AdminUser` 提取器，
     * 因此必须以**服务器管理员**身份调用；使用普通用户 access token 会直接 401/403。
     * 同一逻辑也挂在 `GET /_synapse/admin/v1/application_services/query/user`，推荐管理面板走该路径。
     */
    checkUserId(userId: string): Promise<boolean>;
    /**
     * 查询某 room alias 是否落在已注册 AS 的命名空间内。
     *
     * @remarks
     * 对应后端 `GET /_matrix/client/v3/appservice/alias`，同样需要管理员权限。见 {@link checkUserId}。
     */
    checkAlias(alias: string): Promise<boolean>;
    getUserAppservices(userId: string): Promise<UserAppservicesResponse | null>;
    pingApplicationService(serviceId: string): Promise<PingResult>;
    getProtocol(protocol: string): Promise<ApplicationServiceProtocol | null>;
    getProtocols(): Promise<string[]>;
    queryUsers(protocol: string, fields: Record<string, string>): Promise<ApplicationServiceUser[]>;
    queryLocations(protocol: string, fields: Record<string, string>): Promise<unknown[]>;
    getCachedService(serviceId: string): ApplicationService | null;
    getApplicationServiceState(asId: string): Promise<ApplicationServiceStateEntry[]>;
    setApplicationServiceState(asId: string, stateKey: string, value: unknown): Promise<void>;
    listApplicationServiceUsers(asId: string): Promise<{
        users: ApplicationServiceUser[];
    }>;
    getApplicationServiceNamespaces(asId: string): Promise<Record<string, unknown>>;
    listApplicationServiceEvents(asId: string, params?: {
        limit?: number;
        from?: string;
    }): Promise<{
        events: unknown[];
        next_token?: string;
    }>;
    getApplicationServiceStatistics(asId: string): Promise<Record<string, unknown>>;
    queryApplicationServiceUser(asId: string, userId: string): Promise<ApplicationServiceQueryUserResult>;
    queryApplicationServiceAlias(asId: string, alias: string): Promise<ApplicationServiceQueryAliasResult>;
    getCachedServices(): ApplicationService[];
    clearCache(): void;
    start(): Promise<void>;
    stop(): void;
}
/**
 * 将 `getAppServiceManager` 挂到 `MatrixClient.prototype` 上，使前端可经 SDK 调用
 * 应用服务管理端点（对应 `synapse-rust/src/web/routes/app_service.rs` 的 25 条路由）。
 *
 * 遵循本 fork 的 `extendMatrixClient` 约定：由 `extendMatrixClientWithManagers()`
 * 统一动态调用（见 `src/manager-extensions/index.ts`，已登记 `includeAppService`）。
 */
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map