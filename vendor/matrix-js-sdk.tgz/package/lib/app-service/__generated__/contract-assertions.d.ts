export declare const APP_SERVICE_ROUTES_ENTRY_COUNT: 41;
export declare const APP_SERVICE_ROUTES_STATUS_SCENARIOS: readonly [];
export type AppServiceStatusScenario = (typeof APP_SERVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const APP_SERVICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type AppServiceErrorScenario = (typeof APP_SERVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const APP_SERVICE_ROUTES_ERRCODES: readonly [];
export type AppServiceErrcode = (typeof APP_SERVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map