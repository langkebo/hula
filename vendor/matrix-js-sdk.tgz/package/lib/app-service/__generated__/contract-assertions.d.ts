export declare const APP_SERVICE_ROUTES_ENTRY_COUNT: 25;
export declare const APP_SERVICE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type AppServiceStatusScenario = (typeof APP_SERVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const APP_SERVICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type AppServiceErrorScenario = (typeof APP_SERVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const APP_SERVICE_ROUTES_ERRCODES: readonly [];
export type AppServiceErrcode = (typeof APP_SERVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map