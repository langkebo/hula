/**
 * DTO snippets extracted from the contract doc for `app-service`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ASUser {
    user_id: string;
    displayname?: string;
    avatar_url?: string;
}
export interface ASRoom {
    room_id: string;
    alias: string;
}
export interface AppServicesResponse {
    appservices: Array<{
        id: string;
        url: string;
        sender_localpart: string;
        namespaces: object;
    }>;
}
export type AppServiceASPingResponseDto = Record<string, never>;
export interface AppServiceASRequestDto {
    events: unknown[];
}
export type AppServiceASResponseDto = Record<string, never>;
//# sourceMappingURL=dto.d.ts.map