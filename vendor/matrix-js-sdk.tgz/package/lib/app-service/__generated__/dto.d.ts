/**
 * DTO snippets extracted from the contract doc for `app_service`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ASUser {
    user_id: string;
    displayname?: string;
    avatar_url?: string;
}
export interface ASRoom {
    room_id: string;
    alias: string;
}
export interface AppServiceNamespace {
    exclusive: boolean;
    regex: string;
    group_id?: string;
}
export interface AppServiceNamespaces {
    users?: AppServiceNamespace[];
    rooms?: AppServiceNamespace[];
    aliases?: AppServiceNamespace[];
}
export interface AppServiceEntry {
    id: string;
    url: string;
    sender_localpart: string;
    namespaces: AppServiceNamespaces;
}
export interface AppServicesResponse {
    appservices: AppServiceEntry[];
}
export interface AppServiceASPingResponseDto {
}
export interface AppServiceEvent {
    type: string;
    content: Record<string, unknown>;
    sender?: string;
    event_id?: string;
    origin_server_ts?: number;
    room_id?: string;
    state_key?: string;
}
export interface AppServiceASRequestDto {
    events: AppServiceEvent[];
}
export interface AppServiceASResponseDto {
}
//# sourceMappingURL=dto.d.ts.map