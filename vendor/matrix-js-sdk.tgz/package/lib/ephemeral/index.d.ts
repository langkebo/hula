import { MatrixClient } from "../client";
import { type IContent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export declare enum EphemeralEvent {
    EphemeralReceived = "EphemeralReceived",
    EphemeralCleared = "EphemeralCleared",
    EphemeralError = "EphemeralError"
}
export interface IEphemeralEventData {
    type: string;
    sender: string;
    content: IContent;
}
export interface IEphemeralEventInfo {
    roomId: string;
    type: string;
    sender: string;
    content: IContent;
    timestamp: number;
}
export interface IServerEphemeralEvent {
    type: string;
    sender: string;
    content: IContent;
    origin_server_ts?: number;
    stream_id?: number;
    event_id?: string;
}
export interface IServerEphemeralEventsResponse {
    chunk: IServerEphemeralEvent[];
    start?: string;
    end?: string;
}
export interface EphemeralManagerMetrics {
    cache: {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
    requests: {
        total: number;
        successful: number;
        failed: number;
        retried: number;
    };
}
interface EphemeralManagerEventMap {
    [EphemeralEvent.EphemeralReceived]: (roomId: string, events: IEphemeralEventInfo[]) => void;
    [EphemeralEvent.EphemeralCleared]: (roomId: string) => void;
    [EphemeralEvent.EphemeralError]: (roomId: string, error: Error) => void;
}
/**
 * EphemeralManager handles room ephemeral events like typing and receipts.
 * Aligned with synapse-rust /room_keys/ephemeral logic.
 */
export declare class EphemeralManager extends BaseManager<EphemeralEvent, EphemeralManagerEventMap> {
    private ephemeralEventsCache;
    private defaultLimit;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getMetrics(): EphemeralManagerMetrics;
    sendEphemeralEvent(roomId: string, type: string, content: IContent): Promise<void>;
    getEphemeralEvents(roomId: string): IEphemeralEventInfo[];
    hasEphemeralEvents(roomId: string): boolean;
    clearEphemeralEvents(roomId: string): void;
    getEphemeralEventsFromServer(roomId: string, limit?: number): Promise<IEphemeralEventInfo[]>;
    getTypingEvents(roomId: string): Promise<string[]>;
    getReceiptEvents(roomId: string): Promise<Map<string, string>>;
    getCachedEphemeralEvents(roomId: string): IEphemeralEventInfo[];
    clearCache(): void;
    setDefaultLimit(limit: number): void;
    getDefaultLimit(): number;
    stop(): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map