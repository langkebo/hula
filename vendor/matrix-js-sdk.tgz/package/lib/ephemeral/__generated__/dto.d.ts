/**
 * DTO snippets extracted from the contract doc for `ephemeral`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface EphemeralEventsResponse {
    chunk: Array<{
        type: string;
        sender: string;
        content: Record<string, unknown>;
        origin_server_ts: number;
        stream_id: number;
        event_id: string;
    }>;
    start?: string;
    end?: string;
}
//# sourceMappingURL=dto.d.ts.map