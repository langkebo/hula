/**
 * DTO snippets extracted from the contract doc for `ephemeral`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface EphemeralEventsResponse {
    events: Array<{
        type: string;
        content: object;
    }>;
}
//# sourceMappingURL=dto.d.ts.map