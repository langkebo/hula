/** Routes served by the synapse-rust `ephemeral` module (mirrored from the backend contract). */
export declare const EPHEMERAL_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/ephemeral";
}];
/** Union of every (method, path) tuple in `EPHEMERAL_ROUTES`. */
export type EphemeralRoute = (typeof EPHEMERAL_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type EphemeralMethod = EphemeralRoute["method"];
/** Path templates referenced by this module. */
export type EphemeralPath = EphemeralRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type EphemeralReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${EphemeralReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type EphemeralPathPattern = EphemeralReplaceBraces<EphemeralPath>;
//# sourceMappingURL=route-table.d.ts.map