export declare const EPHEMERAL_ROUTES_ENTRY_COUNT: 1;
export declare const EPHEMERAL_ROUTES_STATUS_SCENARIOS: readonly [];
export type EphemeralStatusScenario = (typeof EPHEMERAL_ROUTES_STATUS_SCENARIOS)[number];
export declare const EPHEMERAL_ROUTES_ERROR_SCENARIOS: readonly [];
export type EphemeralErrorScenario = (typeof EPHEMERAL_ROUTES_ERROR_SCENARIOS)[number];
export declare const EPHEMERAL_ROUTES_ERRCODES: readonly [];
export type EphemeralErrcode = (typeof EPHEMERAL_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map