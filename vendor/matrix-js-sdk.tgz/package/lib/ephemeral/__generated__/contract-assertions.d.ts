export declare const EPHEMERAL_ROUTES_ENTRY_COUNT: 1;
export declare const EPHEMERAL_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "修正 chunk 返回体、事件字段、SDK 覆盖率与路径绑定说明，并同步时间戳语义 | 修复文档与实现漂移";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type EphemeralStatusScenario = (typeof EPHEMERAL_ROUTES_STATUS_SCENARIOS)[number];
export declare const EPHEMERAL_ROUTES_ERROR_SCENARIOS: readonly [];
export type EphemeralErrorScenario = (typeof EPHEMERAL_ROUTES_ERROR_SCENARIOS)[number];
export declare const EPHEMERAL_ROUTES_ERRCODES: readonly [];
export type EphemeralErrcode = (typeof EPHEMERAL_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map