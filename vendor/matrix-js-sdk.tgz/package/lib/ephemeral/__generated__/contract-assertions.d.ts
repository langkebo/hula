export declare const EPHEMERAL_ROUTES_ENTRY_COUNT: 1;
export declare const EPHEMERAL_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "非房间成员，或无权查看目标房间的临时事件";
}, {
    readonly status: 404;
    readonly note: "房间不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type EphemeralStatusScenario = (typeof EPHEMERAL_ROUTES_STATUS_SCENARIOS)[number];
export declare const EPHEMERAL_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录";
}, {
    readonly scenario: "房间访问越权";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户需要先加入对应房间";
}, {
    readonly scenario: "房间不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新房间列表并确认房间 ID";
}];
export type EphemeralErrorScenario = (typeof EPHEMERAL_ROUTES_ERROR_SCENARIOS)[number];
export declare const EPHEMERAL_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权读取该房间的临时事件";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "房间不存在或已不可访问";
}];
export type EphemeralErrcode = (typeof EPHEMERAL_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map