/**
 * Key Backup Manager - 密钥备份管理
 *
 * 提供密钥备份、恢复、导入导出等功能
 * 对应后端: synapse-rust/src/web/routes/key_backup.rs
 *
 * 遵循 D7 契约驱动开发标准，100% 覆盖后端端点并保持类型对齐。
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { Aes256AuthData } from "../crypto-api/keybackup";
import type { AESEncryptedSecretStoragePayload } from "../@types/AESEncryptedSecretStoragePayload";
export interface EncryptedData {
    ciphertext: string;
    ephemeral: string;
    mac: string;
}
export interface AuthData {
    public_key: string;
    signatures?: Record<string, Record<string, string>>;
}
export interface SessionData {
    first_message_index: number;
    forwarded_count: number;
    is_verified: boolean;
    session_data: EncryptedData | AESEncryptedSecretStoragePayload;
}
export interface BackupVersionInfo {
    version: string;
    algorithm: string;
    auth_data: AuthData | Aes256AuthData;
    count?: number;
    etag?: string;
}
export interface BackupVersion {
    version: string;
    algorithm: string;
    auth_data: AuthData | Aes256AuthData;
    count?: number;
    etag?: string;
}
export interface RoomSessions {
    sessions: Record<string, SessionData>;
}
export interface RoomKeyBackup {
    rooms: Record<string, RoomSessions>;
    etag?: string;
}
export interface RecoveryProgress {
    user_id: string;
    version: string;
    total_keys: number;
    recovered_keys: number;
    status: string;
    started_ts: number;
    updated_ts: number;
}
export interface BatchRecoverResult {
    rooms: Record<string, RoomSessions>;
    total_sessions: number;
    has_more: boolean;
    next_batch?: string;
}
export interface ExportResult {
    room_keys: Array<{
        room_id: string;
        session_id: string;
        session_data: EncryptedData | AESEncryptedSecretStoragePayload;
        first_message_index: number;
        forwarded_count: number;
        is_verified: boolean;
    }>;
    version: string;
}
export interface ImportResult {
    count: number;
    failed: number;
    total: number;
}
export interface VerifyResult {
    valid: boolean;
    algorithm: string;
    auth_data: AuthData | Aes256AuthData;
    key_count: number;
    signatures?: Record<string, Record<string, string>>;
}
export interface PutRoomKeysBody {
    rooms: Record<string, RoomSessions>;
}
export interface PutRoomSessionsBody {
    sessions: Record<string, SessionData>;
}
export interface UploadKeysResult {
    count: number;
    etag: string;
}
export interface RecoverKeysResult {
    rooms: Record<string, RoomSessions>;
    total_keys: number;
    recovered_keys: number;
}
export interface RecoverRoomKeysResult {
    room_id: string;
    sessions: SessionData[];
}
export interface RecoverSessionKeyResult {
    room_id: string;
    session_id: string;
    session_data: EncryptedData | AESEncryptedSecretStoragePayload;
}
export declare class KeyBackupManager extends BaseManager {
    private currentVersion;
    private versionCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取最新备份版本
     * 对应 GET /room_keys/version
     */
    getLatestBackupVersion(forceRefresh?: boolean): Promise<BackupVersionInfo>;
    /**
     * 检查是否存在密钥备份（兼容方法）
     *
     * 这是 {@link getLatestBackupVersion} 的兼容别名，对齐标准 SDK 的
     * `CryptoApi.checkKeyBackupAndEnable` 命名风格。当服务器不存在备份版本
     * （HTTP 404 / M_NOT_FOUND）时返回 `null`，而非抛出错误，便于调用方
     * 用 `if (info)` 的方式判断是否已启用备份。
     *
     * 注意：与 `RustBackupManager.checkKeyBackupAndEnable` 不同，本方法仅做
     * 只读检查，不会自动启用备份。
     *
     * 对应 GET /room_keys/version
     */
    checkKeyBackup(forceRefresh?: boolean): Promise<BackupVersionInfo | null>;
    /**
     * 获取所有备份版本信息 (兼容旧版)
     */
    getBackupVersions(forceRefresh?: boolean): Promise<{
        versions: BackupVersionInfo[];
    }>;
    createBackupVersion(algorithm?: string, authData?: AuthData | Aes256AuthData): Promise<{
        version: string;
    }>;
    getBackupVersion(version: string, forceRefresh?: boolean): Promise<BackupVersionInfo>;
    updateBackupVersion(version: string, authData: AuthData | Aes256AuthData): Promise<{
        version: string;
    }>;
    deleteBackupVersion(version: string): Promise<{
        deleted: boolean;
        version: string;
    }>;
    getAllRoomKeys(version: string): Promise<RoomKeyBackup>;
    putAllRoomKeys(version: string, body: PutRoomKeysBody): Promise<UploadKeysResult>;
    getRoomKeys(version: string, roomId: string): Promise<{
        sessions: Record<string, SessionData>;
    }>;
    putRoomKeys(version: string, roomId: string, body: PutRoomSessionsBody): Promise<UploadKeysResult>;
    deleteAllRoomKeys(version: string): Promise<UploadKeysResult>;
    deleteRoomKeys(version: string, roomId: string): Promise<UploadKeysResult>;
    getSessionKey(version: string, roomId: string, sessionId: string): Promise<EncryptedData | AESEncryptedSecretStoragePayload>;
    putSessionKey(version: string, roomId: string, sessionId: string, sessionData: SessionData): Promise<UploadKeysResult>;
    deleteSessionKey(version: string, roomId: string, sessionId: string): Promise<UploadKeysResult>;
    recoverKeys(version: string, rooms?: string[]): Promise<RecoverKeysResult>;
    getRecoveryProgress(version: string): Promise<RecoveryProgress>;
    verifyBackup(version: string): Promise<VerifyResult>;
    batchRecover(version: string, roomIds: string[], sessionLimit?: number): Promise<BatchRecoverResult>;
    recoverRoomKeys(version: string, roomId: string): Promise<RecoverRoomKeysResult>;
    recoverSessionKey(version: string, roomId: string, sessionId: string): Promise<RecoverSessionKeyResult>;
    exportKeys(version?: string): Promise<ExportResult>;
    importKeys(roomKeys: ExportResult["room_keys"], version?: string): Promise<ImportResult>;
    getCurrentVersion(): string | null;
    setCurrentVersion(version: string | null): void;
    ensureBackupVersion(_algorithm?: string): Promise<string>;
    clearCache(): void;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map