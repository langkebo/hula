/**
 * DTO snippets extracted from the contract doc for `key_backup`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface BackupVersionInfo {
    version: string;
    algorithm: string;
    auth_data: any;
}
export interface BackupVersion {
    version: string;
    algorithm: string;
    auth_data: any;
    count?: number;
    etag?: string;
}
export interface RecoveryProgress {
    user_id: string;
    version: string;
    total_keys: number;
    recovered_keys: number;
    status: string;
    started_ts: number;
    updated_ts: number;
}
export interface BatchRecoverResult {
    rooms: Record<string, any>;
    total_sessions: number;
    has_more: boolean;
    next_batch?: string;
}
export interface ExportResult {
    room_keys: Array<{
        room_id: string;
        session_id: string;
        session_data: any;
    }>;
    version: string;
}
export interface ImportResult {
    count: number;
    failed: number;
    total: number;
}
export interface VerifyResult {
    valid: boolean;
    algorithm: string;
    auth_data: any;
    key_count: number;
    signatures?: any;
}
export interface SecureBackupInfo {
    backup_id: string;
    version: string;
    algorithm: string;
    auth_data: any;
    key_count: number;
}
//# sourceMappingURL=dto.d.ts.map