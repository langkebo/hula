export declare const KEY_BACKUP_ROUTES_ENTRY_COUNT: 99;
export declare const KEY_BACKUP_ROUTES_STATUS_SCENARIOS: readonly [];
export type KeyBackupStatusScenario = (typeof KEY_BACKUP_ROUTES_STATUS_SCENARIOS)[number];
export declare const KEY_BACKUP_ROUTES_ERROR_SCENARIOS: readonly [];
export type KeyBackupErrorScenario = (typeof KEY_BACKUP_ROUTES_ERROR_SCENARIOS)[number];
export declare const KEY_BACKUP_ROUTES_ERRCODES: readonly [];
export type KeyBackupErrcode = (typeof KEY_BACKUP_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map