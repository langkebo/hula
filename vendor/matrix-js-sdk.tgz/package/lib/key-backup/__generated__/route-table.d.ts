/** Routes served by the synapse-rust `key-backup` module (mirrored from the backend contract). */
export declare const KEY_BACKUP_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/room_keys/batch_recover";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/export";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/export/{version}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/room_keys/import";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/room_keys/import/{version}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/keys";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/keys";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/keys";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/keys/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/keys/{room_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/keys/{room_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/keys/{room_id}/{session_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/keys/{room_id}/{session_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/keys/{room_id}/{session_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/room_keys/recover";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/recover/{version}/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/recover/{version}/{room_id}/{session_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/recovery/{version}/progress";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/verify/{version}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/version";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/room_keys/version";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/version/{version}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/version/{version}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/version/{version}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys/{room_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys/{room_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys/{room_id}/{session_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys/{room_id}/{session_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/room_keys/{version}/keys/{room_id}/{session_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/room_keys/batch_recover";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/export";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/export/{version}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/room_keys/import";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/room_keys/import/{version}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/keys";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/keys";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/keys";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/keys/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/keys/{room_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/keys/{room_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/keys/{room_id}/{session_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/keys/{room_id}/{session_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/keys/{room_id}/{session_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/room_keys/recover";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/recover/{version}/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/recover/{version}/{room_id}/{session_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/recovery/{version}/progress";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/verify/{version}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/version";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/room_keys/version";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/version/{version}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/version/{version}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/version/{version}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys/{room_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys/{room_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys/{room_id}/{session_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys/{room_id}/{session_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/room_keys/{version}/keys/{room_id}/{session_id}";
}];
/** Union of every (method, path) tuple in `KEY_BACKUP_ROUTES`. */
export type KeyBackupRoute = (typeof KEY_BACKUP_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type KeyBackupMethod = KeyBackupRoute["method"];
/** Path templates referenced by this module. */
export type KeyBackupPath = KeyBackupRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type KeyBackupReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${KeyBackupReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type KeyBackupPathPattern = KeyBackupReplaceBraces<KeyBackupPath>;
//# sourceMappingURL=route-table.d.ts.map