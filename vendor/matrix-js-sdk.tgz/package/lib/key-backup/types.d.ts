/**
 * Key Backup Types - Extended types with index signatures
 *
 * This module provides extended versions of key-backup related types
 * that include index signatures for flexible property access.
 */
import type { RoomSessions, RecoverKeysResult, RecoverRoomKeysResult, RecoverSessionKeyResult } from "./index";
/**
 * Key-backup types extended with an index signature (`[key: string]: unknown`).
 *
 * These variants are useful when you need to pass recovery results through
 * generic pipelines (e.g. JSON schema validators, dynamic property access)
 * that require an open-ended index signature on the object.
 */
/**
 * Extended {@link RecoverKeysResult} with an index signature.
 */
export interface RecoverKeysResultWithIndex extends RecoverKeysResult {
    [key: string]: unknown;
}
/**
 * Extended {@link RecoverRoomKeysResult} with an index signature.
 */
export interface RecoverRoomKeysResultWithIndex extends RecoverRoomKeysResult {
    [key: string]: unknown;
}
/**
 * Extended {@link RecoverSessionKeyResult} with an index signature.
 */
export interface RecoverSessionKeyResultWithIndex extends RecoverSessionKeyResult {
    [key: string]: unknown;
}
/**
 * Base recovery result with an index signature.
 */
export interface RecoveryResultBase {
    [key: string]: unknown;
}
/**
 * Extended {@link RoomSessions} with an index signature.
 */
export interface RoomSessionsWithIndex extends RoomSessions {
    [key: string]: unknown;
}
/**
 * Extended {@link SessionData} with an index signature.
 * Note: SessionData must be imported with an alias due to naming conflict.
 */
import type { SessionData as SessionDataType } from "./index";
/**
 * Extended SessionData with an index signature.
 */
export interface SessionDataWithIndex extends SessionDataType {
    [key: string]: unknown;
}
//# sourceMappingURL=types.d.ts.map