import type { MatrixClient } from "../client";
import { type IRoomEventFilter } from "../filter";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { QueryDict } from "../http-api/utils";
import { ISendEventResponse, SendDelayedEventRequestOpts, SendDelayedEventResponse } from "../@types/requests";
import { type IMessagesResponse } from "../client-internal-types";
import { EventStatus, type IContent, type IUnsigned, MatrixEvent } from "../models/event";
import { Room } from "../models/room";
import { Direction } from "../models/event-timeline";
import { type MatrixScheduler } from "../scheduler";
import { ThreadFilterType } from "../models/thread";
import { type NormalizedContextResponse } from "../client-timeline-core";
export declare enum EventManagerEvent {
    EventSent = "EventSent",
    EventRedacted = "EventRedacted",
    StateChanged = "StateChanged",
    Error = "Error"
}
export interface IRoomEvent {
    content: IContent;
    type: string;
    event_id: string;
    sender: string;
    origin_server_ts: number;
    room_id?: string;
    unsigned?: IUnsigned;
}
export interface IStateEvent extends IRoomEvent {
    state_key: string;
}
export interface IGetMessagesResponse {
    chunk: IRoomEvent[];
    start: string;
    end?: string;
    state?: IStateEvent[];
}
export interface IEventContextResponse {
    event: IRoomEvent;
    events_before: IRoomEvent[];
    events_after: IRoomEvent[];
    start: string;
    end: string;
    state: IStateEvent[];
}
interface SendEventWorkflowContext {
    threadId: string | null;
    userId: string;
    makeTxnId: () => string;
    getRoom: (roomId: string) => Room | null;
    reEmitter: {
        reEmit(target: MatrixEvent, events: string[]): void;
    };
    scheduler?: MatrixScheduler<ISendEventResponse>;
    eventsBeingEncrypted: Set<string>;
    encryptEventIfNeeded: (event: MatrixEvent, room?: Room) => Promise<void>;
    sendEventHttpRequest: (event: MatrixEvent, queryOrDelayOpts?: SendDelayedEventRequestOpts | QueryDict, queryDict?: QueryDict) => Promise<ISendEventResponse | SendDelayedEventResponse>;
    updatePendingEventStatus: (room: Room | null, event: MatrixEvent, newStatus: EventStatus) => void;
    logger: {
        debug(message: string): void;
        error(...args: unknown[]): void;
    };
}
interface EventManagerEventMap {
    [EventManagerEvent.EventSent]: (roomId: string, eventId: string) => void;
    [EventManagerEvent.EventRedacted]: (roomId: string, eventId: string) => void;
    [EventManagerEvent.StateChanged]: (roomId: string, eventType: string, stateKey: string) => void;
    [EventManagerEvent.Error]: (error: Error) => void;
}
export declare function setEventManagerRetryOptions(client: MatrixClient, options: import("../managers/base-manager").RetryOptions): void;
export declare class EventManager extends BaseManager<EventManagerEvent, EventManagerEventMap> {
    private stateCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    private validateEventId;
    getMessages(roomId: string, params: {
        from: string;
        dir: "f" | "b";
        to?: string;
        limit?: number;
        filter?: IRoomEventFilter;
    }): Promise<IGetMessagesResponse>;
    createMessagesRequest(roomId: string, fromToken: string | null, limit: number | undefined, dir: Direction, timelineFilter?: IRoomEventFilter, lazyLoadMembers?: boolean): Promise<IMessagesResponse>;
    createThreadListMessagesRequest(roomId: string, fromToken: string | null, limit?: number, dir?: Direction, threadListType?: ThreadFilterType | null, timelineFilter?: IRoomEventFilter, lazyLoadMembers?: boolean): Promise<IMessagesResponse>;
    sendEvent(roomId: string, eventType: string, content: IContent, txnId?: string, workflowContext?: SendEventWorkflowContext): Promise<ISendEventResponse>;
    getState(roomId: string, forceRefresh?: boolean): Promise<IStateEvent[]>;
    getStateEvent(roomId: string, eventType: string, stateKey?: string): Promise<IContent>;
    sendStateEvent(roomId: string, eventType: string, content: IContent, stateKey?: string): Promise<ISendEventResponse>;
    getEvent(roomId: string, eventId: string): Promise<IRoomEvent>;
    getEventContext(roomId: string, eventId: string, params?: {
        limit?: number;
        filter?: IRoomEventFilter;
        lazyLoadMembers?: boolean;
    }): Promise<NormalizedContextResponse>;
    redactEvent(roomId: string, eventId: string, reasonOrContent?: string | IContent, txnId?: string): Promise<ISendEventResponse>;
    /**
     * Resend an event.
     * @param event - The event to resend
     * @param room - The room the event belongs to
     * @param deps - Dependencies from the client
     */
    resendEvent(event: MatrixEvent, room: Room, deps: {
        toDeviceMessageQueueSendQueue: () => void;
        updatePendingEventStatus: (room: Room | null, event: MatrixEvent, status: EventStatus) => void;
        encryptAndSendEvent: (room: Room | null, event: MatrixEvent) => Promise<ISendEventResponse>;
    }): Promise<ISendEventResponse>;
    /**
     * Cancel a queued or unsent event.
     * @param event - The event to cancel
     * @param deps - Dependencies from the client
     * @throws Error if the event is not in QUEUED, NOT_SENT or ENCRYPTING state
     */
    cancelPendingEvent(event: MatrixEvent, deps: {
        eventsBeingEncrypted: Set<string>;
        scheduler?: {
            removeEventFromQueue(event: MatrixEvent): void;
        };
        getRoom: (roomId: string) => Room | null;
        updatePendingEventStatus: (room: Room | null, event: MatrixEvent, status: EventStatus) => void;
    }): void;
    /**
     * Decrypt an event if needed.
     * @param event - The event to decrypt
     * @param deps - Dependencies from the client
     */
    decryptEventIfNeeded(event: MatrixEvent, deps: {
        enableEncryptedStateEvents: boolean;
        getCrypto: () => unknown;
        cryptoBackend: unknown;
    }, options?: import("../models/event").IDecryptOptions): Promise<void>;
    /**
     * Send a state event with encryption support.
     * @param roomId - The room ID
     * @param eventType - The event type
     * @param content - The event content
     * @param stateKey - The state key
     * @param deps - Dependencies from the client
     */
    sendStateEventWithEncryption(roomId: string, eventType: string, content: IContent, stateKey?: string, deps?: {
        getRoom: (roomId: string) => Room | null;
        encryptStateEventIfNeeded: (event: MatrixEvent, room?: Room) => Promise<void>;
        dispatchStateEventRequest: (params: {
            roomId: string;
            eventType: string;
            content: unknown;
            stateKey: string;
            http: unknown;
            requestOpts: unknown;
        }) => Promise<ISendEventResponse>;
        http: unknown;
        requestOpts: unknown;
    }): Promise<ISendEventResponse>;
}
export {};
//# sourceMappingURL=EventManager.d.ts.map