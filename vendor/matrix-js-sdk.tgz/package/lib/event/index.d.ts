import { MatrixClient } from "../client";
import type { RetryOptions } from "../managers/base-manager";
export * from "./EventManager";
export declare function extendMatrixClient(): void;
export declare function setEventManagerRetryOptions(client: MatrixClient, options: RetryOptions): void;
//# sourceMappingURL=index.d.ts.map