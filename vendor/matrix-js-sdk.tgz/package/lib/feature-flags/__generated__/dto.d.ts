/**
 * DTO snippets extracted from the contract doc for `feature_flags`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface FeatureFlagsResponse {
    flags: Array<{
        name: string;
        enabled: boolean;
        description: string;
        created_ts: number;
        updated_ts: number;
    }>;
}
export interface FeatureFlag {
    name: string;
    enabled: boolean;
    description: string;
    created_ts: number;
    updated_ts: number;
}
export interface FeatureFlagsRequestDto {
    enabled: boolean;
}
export type FeatureFlagsResponseDto = Record<string, never>;
//# sourceMappingURL=dto.d.ts.map