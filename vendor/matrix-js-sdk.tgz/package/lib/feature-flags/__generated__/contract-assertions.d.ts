export declare const FEATURE_FLAGS_ROUTES_ENTRY_COUNT: 5;
export declare const FEATURE_FLAGS_ROUTES_STATUS_SCENARIOS: readonly [];
export type FeatureFlagsStatusScenario = (typeof FEATURE_FLAGS_ROUTES_STATUS_SCENARIOS)[number];
export declare const FEATURE_FLAGS_ROUTES_ERROR_SCENARIOS: readonly [];
export type FeatureFlagsErrorScenario = (typeof FEATURE_FLAGS_ROUTES_ERROR_SCENARIOS)[number];
export declare const FEATURE_FLAGS_ROUTES_ERRCODES: readonly [];
export type FeatureFlagsErrcode = (typeof FEATURE_FLAGS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map