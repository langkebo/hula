/**
 * Feature Flag Manager - 功能开关管理
 *
 * 提供功能开关的创建、更新、获取及列表查询功能（Admin API）。
 * 对应后端: synapse-rust/src/web/routes/feature_flags.rs
 *
 * 遵循 D7 契约驱动开发标准，100% 覆盖后端端点并保持类型对齐。
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface FeatureFlag {
    key: string;
    target_scope: string;
    status: string;
    description?: string;
    created_ts: number;
    updated_ts: number;
}
export interface CreateFeatureFlagRequest {
    key: string;
    target_scope: string;
    status: string;
    description?: string;
}
export interface UpdateFeatureFlagRequest {
    status?: string;
    description?: string;
}
export interface FeatureFlagListQuery {
    target_scope?: string;
    status?: string;
    limit?: number;
    offset?: number;
    [key: string]: string | number | boolean | string[] | undefined;
}
export interface FeatureFlagListResponse {
    flags: FeatureFlag[];
    total: number;
}
/**
 * FeatureFlagManager 处理功能开关的后台管理。
 */
export declare class FeatureFlagManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 创建功能开关
     * 对应 POST /_synapse/admin/v1/feature-flags
     */
    createFlag(body: CreateFeatureFlagRequest): Promise<FeatureFlag>;
    /**
     * 更新功能开关
     * 对应 PATCH /_synapse/admin/v1/feature-flags/{flag_key}
     */
    updateFlag(key: string, body: UpdateFeatureFlagRequest): Promise<FeatureFlag>;
    /**
     * 获取功能开关详情
     * 对应 GET /_synapse/admin/v1/feature-flags/{flag_key}
     */
    getFlag(key: string): Promise<FeatureFlag>;
    /**
     * 获取功能开关列表
     * 对应 GET /_synapse/admin/v1/feature-flags
     */
    listFlags(query?: FeatureFlagListQuery): Promise<FeatureFlagListResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map