import * as RustSdkCryptoJs from "@matrix-org/matrix-sdk-crypto-wasm";
import { type OutgoingRequestProcessor } from "./OutgoingRequestProcessor";
import { type IHttpOpts, type MatrixHttpApi } from "../http-api/index";
import { type ServerSideSecretStorage } from "../secret-storage";
import { type Logger } from "../logger";
import { CryptoEvent, type CryptoEventHandlerMap, type StartDehydrationOpts } from "../crypto-api/index";
import { TypedEventEmitter } from "../models/typed-event-emitter";
/**
 * The unstable URL prefix for dehydrated device endpoints
 */
export declare const UnstablePrefix = "/_matrix/client/unstable/org.matrix.msc3814.v1";
/**
 * Manages dehydrated devices
 *
 * We have one of these per `RustCrypto`.  It's responsible for
 *
 * * determining server support for dehydrated devices
 * * creating new dehydrated devices when requested, including periodically
 *   replacing the dehydrated device with a new one
 * * rehydrating a device when requested, and when present
 *
 * @internal
 */
export declare class DehydratedDeviceManager extends TypedEventEmitter<DehydratedDevicesEvents, DehydratedDevicesEventMap> {
    private readonly logger;
    private readonly olmMachine;
    private readonly http;
    private readonly outgoingRequestProcessor;
    private readonly secretStorage;
    /** the ID of the interval for periodically replacing the dehydrated device */
    private intervalId?;
    constructor(logger: Logger, olmMachine: RustSdkCryptoJs.OlmMachine, http: MatrixHttpApi<IHttpOpts & {
        onlyData: true;
    }>, outgoingRequestProcessor: OutgoingRequestProcessor, secretStorage: ServerSideSecretStorage);
    private cacheKey;
    /**
     * Return whether the server supports dehydrated devices.
     *
     * @returns 服务器支持 dehydrated device 时返回 `true`。
     * @throws {MatrixError} 当探测请求返回 `M_UNRECOGNIZED` 与 `M_NOT_FOUND` 之外的错误码时原样抛出。
     * @example
     * ```ts
     * // 内部类：实例由 RustCrypto 在 initRustCrypto() 之后持有（this.dehydratedDeviceManager）。
     * // 对外 CryptoApi 通过 isDehydrationSupported() 转发到此方法。
     * await client.initRustCrypto();
     * const supported = await client.getCrypto()!.isDehydrationSupported();
     * ```
     */
    isSupported(): Promise<boolean>;
    /**
     * Start using device dehydration.
     *
     * - Rehydrates a dehydrated device, if one is available and `opts.rehydrate`
     *   is `true`.
     * - Creates a new dehydration key, if necessary, and stores it in Secret
     *   Storage.
     *   - If `opts.createNewKey` is set to true, always creates a new key.
     *   - If a dehydration key is not available, creates a new one.
     * - Creates a new dehydrated device, and schedules periodically creating
     *   new dehydrated devices.
     *
     * @param opts - options for device dehydration. For backwards compatibility
     *     with old code, a boolean can be given here, which will be treated as
     *     the `createNewKey` option. However, this is deprecated.
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 在 initRustCrypto() 之后通过 startDehydration() 调用。
     * await client.initRustCrypto();
     * await client.getCrypto()!.startDehydration({ createNewKey: false });
     * ```
     */
    start(opts?: StartDehydrationOpts | boolean): Promise<void>;
    /**
     * Return whether the dehydration key is stored in Secret Storage.
     *
     * @returns Secret Storage 中已存储脱水密钥时返回 `true`。
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 在 initRustCrypto() 之后持有，仅供其内部调用，无公开访问器。
     * const stored = await this.dehydratedDeviceManager.isKeyStored();
     * ```
     */
    isKeyStored(): Promise<boolean>;
    /**
     * Reset the dehydration key.
     *
     * Creates a new key and stores it in secret storage.
     *
     * @returns The newly-generated key.
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 持有；start({ createNewKey: true }) 会经此重建并缓存密钥。
     * const key = await this.dehydratedDeviceManager.resetKey();
     * ```
     */
    resetKey(): Promise<RustSdkCryptoJs.DehydratedDeviceKey>;
    /**
     * Get and cache the encryption key from secret storage.
     *
     * If `create` is `true`, creates a new key if no existing key is present.
     *
     * @returns the key, if available, or `null` if no key is available
     */
    private getKey;
    /**
     * Rehydrate the dehydrated device stored on the server.
     *
     * Checks if there is a dehydrated device on the server.  If so, rehydrates
     * the device and processes the to-device events.
     *
     * Returns whether or not a dehydrated device was found.
     *
     * @returns 找到并成功重水化了服务器上的 dehydrated device 时返回 `true`，否则 `false`。
     * @throws {MatrixError} 查询 dehydrated device 返回 `M_NOT_FOUND` / `M_UNRECOGNIZED` 之外的错误时原样抛出。
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 持有；start({ rehydrate: true }) 内部会调用此方法。
     * const found = await this.dehydratedDeviceManager.rehydrateDeviceIfAvailable();
     * ```
     */
    rehydrateDeviceIfAvailable(): Promise<boolean>;
    /**
     * Creates and uploads a new dehydrated device.
     *
     * Creates and stores a new key in secret storage if none is available.
     *
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 持有；scheduleDeviceDehydration() 首次执行即调用此方法。
     * await this.dehydratedDeviceManager.createAndUploadDehydratedDevice();
     * ```
     */
    createAndUploadDehydratedDevice(): Promise<void>;
    /**
     * Schedule periodic creation of dehydrated devices.
     *
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 持有；start() 末尾会调用此方法启动周期任务。
     * await this.dehydratedDeviceManager.scheduleDeviceDehydration();
     * ```
     */
    scheduleDeviceDehydration(): Promise<void>;
    /**
     * Stop the dehydrated device manager.
     *
     * Cancels any scheduled dehydration tasks.
     *
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 在 dispose 时调用，用于清理周期定时器。
     * this.dehydratedDeviceManager.stop();
     * ```
     */
    stop(): void;
    /**
     * Delete the current dehydrated device and stop the dehydrated device manager.
     *
     * @throws {MatrixError} 删除请求返回 `M_UNRECOGNIZED` / `M_NOT_FOUND` 之外的错误时原样抛出（这两者视为成功）。
     * @example
     * ```ts
     * // 内部类：由 RustCrypto 持有；deleteDehydration() 路径会调用此方法。
     * await this.dehydratedDeviceManager.delete();
     * ```
     */
    delete(): Promise<void>;
}
/**
 * The events fired by the DehydratedDeviceManager
 * @internal
 */
type DehydratedDevicesEvents = CryptoEvent.DehydratedDeviceCreated | CryptoEvent.DehydratedDeviceUploaded | CryptoEvent.RehydrationStarted | CryptoEvent.RehydrationProgress | CryptoEvent.RehydrationCompleted | CryptoEvent.RehydrationError | CryptoEvent.DehydrationKeyCached | CryptoEvent.DehydratedDeviceRotationError;
/**
 * A map of the {@link DehydratedDeviceEvents} fired by the {@link DehydratedDeviceManager} and their payloads.
 * @internal
 */
type DehydratedDevicesEventMap = Pick<CryptoEventHandlerMap, DehydratedDevicesEvents>;
export {};
//# sourceMappingURL=DehydratedDeviceManager.d.ts.map