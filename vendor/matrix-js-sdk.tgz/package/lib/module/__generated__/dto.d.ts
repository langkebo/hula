/**
 * DTO snippets extracted from the contract doc for `module`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface CreateModuleBody {
    module_name: string;
    module_type: string;
    version: string;
    description?: string;
    is_enabled?: boolean;
    priority?: number;
    config?: Record<string, unknown>;
}
export interface UpdateModuleConfigBody {
    config: Record<string, unknown>;
}
export interface EnableModuleBody {
    is_enabled: boolean;
}
export interface ListModulesResponse {
    modules: Array<Record<string, unknown>>;
    next_batch: string | null;
}
//# sourceMappingURL=dto.d.ts.map