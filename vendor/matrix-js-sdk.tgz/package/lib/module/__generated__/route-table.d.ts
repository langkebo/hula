/** Routes served by the synapse-rust `module` module (mirrored from the backend contract). */
export declare const MODULE_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/account_data_callbacks";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/account_data_callbacks";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/account_validity";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/account_validity/{user_id}";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/account_validity/{user_id}/renew";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/media_callbacks";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/media_callbacks";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/media_callbacks/{callback_type}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/modules";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/modules/check_spam";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/modules/check_third_party_rule";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules/logs/{module_name}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules/spam_check/sender/{sender}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules/spam_check/{event_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules/third_party_rule/{event_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules/type/{module_type}";
}, {
    readonly method: "DELETE";
    readonly path: "/_synapse/admin/v1/modules/{module_name}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/modules/{module_name}";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/admin/v1/modules/{module_name}/config";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/modules/{module_name}/enable";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/password_auth_providers";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/password_auth_providers";
}];
/** Union of every (method, path) tuple in `MODULE_ROUTES`. */
export type ModuleRoute = (typeof MODULE_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type ModuleMethod = ModuleRoute["method"];
/** Path templates referenced by this module. */
export type ModulePath = ModuleRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type ModuleReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${ModuleReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type ModulePathPattern = ModuleReplaceBraces<ModulePath>;
//# sourceMappingURL=route-table.d.ts.map