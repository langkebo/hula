export declare const MODULE_ROUTES_ENTRY_COUNT: 27;
export declare const MODULE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 201;
    readonly note: "模块创建成功";
}, {
    readonly status: 400;
    readonly note: "参数不合法或配置格式错误";
}, {
    readonly status: 401;
    readonly note: "管理员凭据无效或缺失";
}, {
    readonly status: 403;
    readonly note: "当前账号无权访问管理员模块接口";
}, {
    readonly status: 404;
    readonly note: "指定模块不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "补齐错误语义与 SDK 映射 | 交付验收通过";
}];
export type ModuleStatusScenario = (typeof MODULE_ROUTES_STATUS_SCENARIOS)[number];
export declare const MODULE_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "管理员凭据无效或缺失";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "重新获取管理员登录态";
}, {
    readonly scenario: "模块参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正模块名称或配置结构";
}, {
    readonly scenario: "管理权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "仅允许管理员账号访问";
}, {
    readonly scenario: "模块不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "提示目标模块已被卸载或不存在";
}];
export type ModuleErrorScenario = (typeof MODULE_ROUTES_ERROR_SCENARIOS)[number];
export declare const MODULE_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "管理员凭据无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "模块请求参数结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "module_name 或查询参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "当前账号无权访问管理员模块接口";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "目标模块不存在";
}];
export type ModuleErrcode = (typeof MODULE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map