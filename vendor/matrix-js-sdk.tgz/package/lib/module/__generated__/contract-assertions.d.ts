export declare const MODULE_ROUTES_ENTRY_COUNT: 23;
export declare const MODULE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "按后端 ledger 重写为 27 条 admin 路由口径，补充 AdminManager 实际封装映射，并修正配置更新/启用请求体语义 | 修复长期文档与 SDK 漂移";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type ModuleStatusScenario = (typeof MODULE_ROUTES_STATUS_SCENARIOS)[number];
export declare const MODULE_ROUTES_ERROR_SCENARIOS: readonly [];
export type ModuleErrorScenario = (typeof MODULE_ROUTES_ERROR_SCENARIOS)[number];
export declare const MODULE_ROUTES_ERRCODES: readonly [];
export type ModuleErrcode = (typeof MODULE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map