export declare const MODULE_ROUTES_ENTRY_COUNT: 23;
export declare const MODULE_ROUTES_STATUS_SCENARIOS: readonly [];
export type ModuleStatusScenario = (typeof MODULE_ROUTES_STATUS_SCENARIOS)[number];
export declare const MODULE_ROUTES_ERROR_SCENARIOS: readonly [];
export type ModuleErrorScenario = (typeof MODULE_ROUTES_ERROR_SCENARIOS)[number];
export declare const MODULE_ROUTES_ERRCODES: readonly [];
export type ModuleErrcode = (typeof MODULE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map