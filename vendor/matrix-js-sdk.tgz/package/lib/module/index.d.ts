/**
 * Module Manager - 模块系统管理
 *
 * 提供服务器端模块管理功能，包括：
 * - 模块列表与详情查询
 * - 模块安装、配置、启用/禁用
 * - Spam 检查与第三方规则
 * - 回调管理（账户数据、媒体、限速、在线状态）
 * - 密码认证提供商管理
 *
 * 对接后端 API: /_synapse/admin/v1/modules/*
 *                 /_synapse/admin/v1/account_data_callbacks
 *                 /_synapse/admin/v1/password_auth_providers
 *                 ...
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { Method } from "../http-api/method";
import { MatrixClient } from "../client";
import type { IContent } from "../models/event";
export declare enum ModuleEvent {
    ModulesListed = "ModulesListed",
    ModuleCreated = "ModuleCreated",
    ModuleDeleted = "ModuleDeleted",
    ModuleConfigUpdated = "ModuleConfigUpdated",
    ModuleEnabled = "ModuleEnabled",
    ModuleDisabled = "ModuleDisabled",
    ModuleLogsReceived = "ModuleLogsReceived",
    SpamCheckCompleted = "SpamCheckCompleted",
    ThirdPartyRuleChecked = "ThirdPartyRuleChecked",
    AccountDataCallbackRegistered = "AccountDataCallbackRegistered",
    MediaCallbackRegistered = "MediaCallbackRegistered",
    PasswordAuthProviderRegistered = "PasswordAuthProviderRegistered",
    AccountValidityChecked = "AccountValidityChecked",
    AccountValidityRenewed = "AccountValidityRenewed",
    ModuleError = "ModuleError"
}
export interface ModuleInfo {
    name: string;
    type: string;
    enabled: boolean;
    config?: IContent;
    version?: string;
    description?: string;
}
export interface CreateModuleRequest {
    name: string;
    type: string;
    config?: IContent;
    enabled?: boolean;
    [key: string]: unknown;
}
export interface ModuleListResponse {
    modules: ModuleInfo[];
    total: number;
}
export interface SpamCheckRequest {
    event_id: string;
    user_id: string;
    content: IContent;
    room_id?: string;
}
export interface SpamCheckResponse {
    is_spam: boolean;
    reason?: string;
    score?: number;
}
export interface ThirdPartyRuleRequest {
    rule_type: string;
    event_id: string;
    user_id: string;
    content?: IContent;
}
export interface ThirdPartyRuleResponse {
    allowed: boolean;
    reason?: string;
}
export interface CallbackInfo {
    id: string;
    module_name: string;
    callback_type: string;
    config?: IContent;
    enabled: boolean;
}
export interface PasswordAuthProviderInfo {
    id: string;
    name: string;
    type: string;
    enabled: boolean;
    config?: IContent;
}
export interface AccountValidityInfo {
    user_id: string;
    valid: boolean;
    expires_at?: number;
    reason?: string;
}
export interface ModuleLogEntry {
    timestamp: number;
    level: string;
    message: string;
    module_name: string;
}
export interface ModuleLogResponse {
    logs: ModuleLogEntry[];
    total: number;
}
interface ModuleManagerEventMap {
    [ModuleEvent.ModulesListed]: (modules: ModuleListResponse) => void;
    [ModuleEvent.ModuleCreated]: (module: ModuleInfo) => void;
    [ModuleEvent.ModuleDeleted]: (moduleName: string) => void;
    [ModuleEvent.ModuleConfigUpdated]: (moduleName: string, config: IContent) => void;
    [ModuleEvent.ModuleEnabled]: (moduleName: string) => void;
    [ModuleEvent.ModuleDisabled]: (moduleName: string) => void;
    [ModuleEvent.ModuleLogsReceived]: (logs: ModuleLogResponse) => void;
    [ModuleEvent.SpamCheckCompleted]: (result: SpamCheckResponse) => void;
    [ModuleEvent.ThirdPartyRuleChecked]: (result: ThirdPartyRuleResponse) => void;
    [ModuleEvent.AccountDataCallbackRegistered]: (callback: CallbackInfo) => void;
    [ModuleEvent.MediaCallbackRegistered]: (callback: CallbackInfo) => void;
    [ModuleEvent.PasswordAuthProviderRegistered]: (provider: PasswordAuthProviderInfo) => void;
    [ModuleEvent.AccountValidityChecked]: (info: AccountValidityInfo) => void;
    [ModuleEvent.AccountValidityRenewed]: (userId: string) => void;
    [ModuleEvent.ModuleError]: (error: Error) => void;
}
export declare class ModuleManager extends BaseManager<ModuleEvent, ModuleManagerEventMap> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    protected adminRequest<T>(method: Method, path: string, queryParams?: Record<string, string | string[]>, body?: object, label?: string): Promise<T>;
    listModules(options?: {
        limit?: number;
        from?: string;
    }): Promise<ModuleListResponse>;
    listModulesByType(moduleType: string): Promise<ModuleInfo[]>;
    getModule(moduleName: string): Promise<ModuleInfo>;
    createModule(moduleConfig: CreateModuleRequest): Promise<ModuleInfo>;
    deleteModule(moduleName: string): Promise<void>;
    updateModuleConfig(moduleName: string, config: IContent): Promise<ModuleInfo>;
    setModuleEnabled(moduleName: string, enabled: boolean): Promise<void>;
    getModuleLogs(moduleName: string, options?: {
        limit?: number;
        from?: string;
    }): Promise<ModuleLogResponse>;
    checkSpam(payload: SpamCheckRequest): Promise<SpamCheckResponse>;
    getSpamCheckResult(eventId: string): Promise<SpamCheckResponse>;
    getSpamCheckBySender(sender: string, options?: {
        limit?: number;
        from?: string;
    }): Promise<SpamCheckResponse[]>;
    checkThirdPartyRule(payload: ThirdPartyRuleRequest): Promise<ThirdPartyRuleResponse>;
    getThirdPartyRuleResult(eventId: string): Promise<ThirdPartyRuleResponse>;
    getAccountDataCallbacks(): Promise<CallbackInfo[]>;
    registerAccountDataCallback(callback: {
        module_name: string;
        callback_type: string;
    }): Promise<CallbackInfo>;
    getMediaCallbacks(): Promise<CallbackInfo[]>;
    registerMediaCallback(callback: {
        module_name: string;
        callback_type: string;
    }): Promise<CallbackInfo>;
    getMediaCallbacksByType(callbackType: string): Promise<CallbackInfo[]>;
    getPasswordAuthProviders(): Promise<PasswordAuthProviderInfo[]>;
    registerPasswordAuthProvider(provider: {
        name: string;
        type: string;
        config?: IContent;
    }): Promise<PasswordAuthProviderInfo>;
    /**
     * 创建/检查账户有效性记录。
     *
     * SDK-BL-002: 后端 `create_account_validity` 处理器要求 body 含必填字段
     * `user_id` 与 `expiration_ts`，此前 SDK 未传 body 导致 400 Bad Request。
     *
     * @param userId       目标用户 ID
     * @param expirationTs 过期时间戳（毫秒）
     */
    checkAccountValidity(userId: string, expirationTs: number): Promise<void>;
    getAccountValidity(userId: string): Promise<AccountValidityInfo>;
    /**
     * 续期账户有效性。
     *
     * SDK-BL-003: 后端 `renew_account` 处理器要求 body 含必填字段
     * `renewal_token` 与 `new_expiration_ts`，此前 SDK 仅传路径参数导致 400 Bad Request。
     *
     * @param userId           目标用户 ID
     * @param renewalToken     续期令牌
     * @param newExpirationTs 新过期时间戳（毫秒）
     */
    renewAccountValidity(userId: string, renewalToken: string, newExpirationTs: number): Promise<void>;
}
export {};
//# sourceMappingURL=index.d.ts.map