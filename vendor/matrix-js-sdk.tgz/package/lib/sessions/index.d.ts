/**
 * Sessions Manager - 会话管理
 *
 * 提供会话管理相关功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ISessionInfo {
    deviceId: string;
    userId: string;
    accessToken: string;
    refreshToken?: string;
    lastActiveTs?: number;
    isActive?: boolean;
}
export interface ISessionDetail {
    device_id: string;
    display_name?: string;
    last_seen_ip?: string;
    last_seen_ts?: number;
    user_id: string;
}
export interface SessionsManagerEvents {
    session_created: {
        deviceId: string;
    };
    session_revoked: {
        deviceId: string;
    };
    session_refreshed: {
        deviceId: string;
    };
}
export declare class SessionsManager extends BaseManager<keyof SessionsManagerEvents, SessionsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getActiveSessions(): ISessionInfo[];
    getSessionInfo(): ISessionInfo | null;
    refreshSession(): Promise<ISessionInfo>;
    revokeSession(deviceId: string): Promise<void>;
    getLastActiveSession(): ISessionDetail | null;
    setLastActiveSession(sessionId: string): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map