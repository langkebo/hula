/**
 * Device Trust Manager - 设备信任管理
 *
 * 提供设备验证、信任状态查询、安全摘要等功能
 * 对应后端: synapse-rust/src/web/routes/e2ee_routes.rs
 *
 * 后端端点:
 * - POST /v3/device_verification/request
 * - POST /v3/device_verification/respond
 * - GET /v3/device_verification/status/{token}
 * - GET /v3/device_trust
 * - GET /v3/device_trust/{device_id}
 * - GET /v3/security/summary
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export declare enum DeviceTrustEvent {
    VerificationRequested = "VerificationRequested",
    VerificationResponded = "VerificationResponded",
    TrustChanged = "TrustChanged",
    SecuritySummaryUpdated = "SecuritySummaryUpdated"
}
/**
 * Device trust levels, mirroring `synapse-e2ee/src/device_trust/models.rs`
 * `DeviceTrustLevel` (`Display` impl at `models.rs:26-29`).
 *
 * Only these three values ever appear on the wire: `verified`, `unverified`,
 * `blocked`. The previous union included `cross_signed` and `blacklisted`,
 * which the backend cannot emit — `isDeviceBlocked()` therefore never matched
 * and always reported `false`.
 */
export type TrustLevel = "verified" | "unverified" | "blocked";
export type VerificationStatus = "pending" | "approved" | "rejected" | "expired" | "not_found";
export type VerificationMethod = "sas" | "qr" | "emoji";
export interface IDeviceVerificationRequest {
    new_device_id?: string;
    device_id?: string;
    method?: VerificationMethod;
}
/**
 * Response of `POST /device_verification/request`.
 *
 * Contract source: `synapse-web/src/routes/e2ee/devices.rs::request_device_verification`
 * → `{ request_token, token, status, expires_at, methods_available }`
 * (`token` is an alias of `request_token`).
 */
export interface IDeviceVerificationResponse {
    request_token: string;
    token: string;
    status: VerificationStatus;
    expires_at: number;
    methods_available: VerificationMethod[];
}
/**
 * Response of `GET /device_verification/status/{token}`.
 *
 * Contract source: `devices.rs::get_verification_status` — returns the same
 * fields as the request response, **or** `{ "status": "not_found" }` with HTTP
 * 200 when the token is unknown (it never 404s). Hence every field except
 * `status` is optional here.
 */
export interface IVerificationStatusResponse {
    request_token?: string;
    token?: string;
    status: VerificationStatus;
    expires_at?: number;
    methods_available?: VerificationMethod[];
}
/**
 * Response of `POST /device_verification/respond`.
 *
 * Contract source: `devices.rs::respond_device_verification` →
 * `{ success, trust_level }`. The request body must carry
 * `request_token` (or its `token` alias) **and `approved: boolean`** —
 * `approved` defaults to `false`, so omitting it silently turns an "accept"
 * into a "reject".
 */
export interface IVerificationRespondResult {
    success: boolean;
    trust_level: TrustLevel;
}
/**
 * One device's trust record.
 *
 * Contract source: `synapse-web/src/routes/e2ee/devices.rs::get_device_trust_list`
 * and `::get_device_trust` → `{ device_id, trust_level, verified_at, verified_by }`.
 *
 * The backend does **not** return `user_id`, `display_name`, `last_seen_ts` or
 * `last_seen_ip` here — those live on `GET /devices` and `POST /keys/query`.
 * Filtering this list by `user_id` (as `CryptoDeviceAdapter.getDevices` used to)
 * therefore always yields an empty result.
 */
export interface IDeviceTrustInfo {
    device_id: string;
    trust_level: TrustLevel;
    verified_at?: number;
    verified_by?: string;
}
export interface IDeviceTrustListResponse {
    devices: IDeviceTrustInfo[];
}
/**
 * Response of `GET /security/summary`.
 *
 * Contract source: `devices.rs::get_security_summary` →
 * `{ verified_devices, unverified_devices, blocked_devices,
 *    has_cross_signing_master, security_score, recommendations }`.
 *
 * NOTE: the field names are *not* the `devices_total` / `devices_verified` /
 * `devices_unverified` / `cross_signing_ready` set that used to be declared
 * here and in `device-keys`/`e2ee`; those names never existed on the wire.
 */
export interface ISecuritySummary {
    verified_devices: number;
    unverified_devices: number;
    blocked_devices: number;
    has_cross_signing_master: boolean;
    security_score: number;
    recommendations: string[];
}
interface DeviceTrustManagerEventMap {
    [DeviceTrustEvent.VerificationRequested]: (response: IDeviceVerificationResponse) => void;
    [DeviceTrustEvent.VerificationResponded]: (result: IVerificationRespondResult) => void;
    [DeviceTrustEvent.TrustChanged]: (deviceId: string, trustLevel: TrustLevel) => void;
    [DeviceTrustEvent.SecuritySummaryUpdated]: (summary: ISecuritySummary) => void;
}
export declare class DeviceTrustManager extends BaseManager<DeviceTrustEvent, DeviceTrustManagerEventMap> {
    private deviceTrustCache;
    private deviceTrustListCache;
    private deviceTrustListCacheAt;
    private readonly cacheTTL;
    private securitySummaryCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    requestVerification(request: IDeviceVerificationRequest): Promise<IDeviceVerificationResponse>;
    respondToVerification(token: string, approved: boolean): Promise<IVerificationRespondResult>;
    getVerificationStatus(token: string): Promise<IVerificationStatusResponse>;
    getDeviceTrustList(forceRefresh?: boolean): Promise<IDeviceTrustInfo[]>;
    getDeviceTrust(deviceId: string, forceRefresh?: boolean): Promise<IDeviceTrustInfo | null>;
    getSecuritySummary(forceRefresh?: boolean): Promise<ISecuritySummary>;
    isDeviceTrusted(deviceId: string): Promise<boolean>;
    isDeviceBlocked(deviceId: string): Promise<boolean>;
    clearCache(): void;
    getCacheStats(): {
        deviceTrust: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        securitySummary: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map