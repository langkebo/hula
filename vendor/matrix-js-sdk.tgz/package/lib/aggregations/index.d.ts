import { MatrixClient } from "../client";
import { MatrixEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IAggregation {
    relationType: string;
    events: MatrixEvent[];
    count: number;
}
export interface AggregationsManagerEvents {
    aggregation_updated: {
        roomId: string;
        eventId: string;
        relationType: string;
    };
}
export declare class AggregationsManager extends BaseManager<keyof AggregationsManagerEvents, AggregationsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getAggregations(roomId: string, eventId: string): IAggregation[];
    getAggregation(roomId: string, eventId: string, relationType: string): IAggregation | null;
    hasAggregation(roomId: string, eventId: string, relationType: string): boolean;
    addAggregation(roomId: string, _eventId: string, _aggregation: IAggregation): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map