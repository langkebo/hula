import { UnstableValue } from "../NamespacedValue";
import { type IClientWellKnown } from "../client";
/**
 * Represents a response to the CSAPI `/refresh` endpoint.
 *
 * 后端实现: synapse-rust/src/web/routes/auth_compat.rs:371-376
 * 注意: 后端返回 expires_in (秒)，SDK使用 expires_in_ms (毫秒) 进行转换
 */
export interface IRefreshTokenResponse {
    access_token: string;
    /**
     * The lifetime of the access token, in milliseconds.
     *
     * 注意: 后端返回字段名为 expires_in (秒)，SDK自动转换为 expires_in_ms (毫秒)
     */
    expires_in_ms: number;
    refresh_token: string;
    /**
     * ID of the device.
     *
     * 注意: 后端此字段为必填，但SDK保持可选以兼容旧版本
     */
    device_id?: string;
}
/**
 * Response to GET login flows as per https://spec.matrix.org/v1.3/client-server-api/#get_matrixclientv3login
 */
export interface ILoginFlowsResponse {
    flows: LoginFlow[];
}
export type LoginFlow = ISSOFlow | IPasswordFlow | ILoginFlow;
export interface ILoginFlow {
    type: string;
}
export interface IPasswordFlow extends ILoginFlow {
    type: "m.login.password";
}
export declare const OAUTH_AWARE_PREFERRED_FLOW_FIELD: UnstableValue<"oauth_aware_preferred", "org.matrix.msc3824.delegated_oidc_compatibility">;
/**
 * Representation of SSO flow as per https://spec.matrix.org/v1.3/client-server-api/#client-login-via-sso
 */
export interface ISSOFlow extends ILoginFlow {
    type: "m.login.sso" | "m.login.cas";
    identity_providers?: IIdentityProvider[];
    [OAUTH_AWARE_PREFERRED_FLOW_FIELD.name]?: boolean;
    [OAUTH_AWARE_PREFERRED_FLOW_FIELD.altName]?: boolean;
}
export declare enum IdentityProviderBrand {
    Gitlab = "gitlab",
    Github = "github",
    Apple = "apple",
    Google = "google",
    Facebook = "facebook",
    Twitter = "twitter"
}
export interface IIdentityProvider {
    id: string;
    name: string;
    icon?: string;
    brand?: IdentityProviderBrand | string;
}
export declare enum SSOAction {
    /** The user intends to login to an existing account */
    LOGIN = "login",
    /** The user intends to register for a new account */
    REGISTER = "register"
}
/**
 * A client can identify a user using their Matrix ID.
 * This can either be the fully qualified Matrix user ID, or just the localpart of the user ID.
 * @see https://spec.matrix.org/v1.7/client-server-api/#matrix-user-id
 */
type UserLoginIdentifier = {
    type: "m.id.user";
    user: string;
};
/**
 * A client can identify a user using a 3PID associated with the user’s account on the homeserver,
 * where the 3PID was previously associated using the /account/3pid API.
 * See the 3PID Types Appendix for a list of Third-party ID media.
 * @see https://spec.matrix.org/v1.7/client-server-api/#third-party-id
 */
type ThirdPartyLoginIdentifier = {
    type: "m.id.thirdparty";
    medium: string;
    address: string;
};
/**
 * A client can identify a user using a phone number associated with the user’s account,
 * where the phone number was previously associated using the /account/3pid API.
 * The phone number can be passed in as entered by the user; the homeserver will be responsible for canonicalising it.
 * If the client wishes to canonicalise the phone number,
 * then it can use the m.id.thirdparty identifier type with a medium of msisdn instead.
 *
 * The country is the two-letter uppercase ISO-3166-1 alpha-2 country code that the number in phone should be parsed as if it were dialled from.
 *
 * @see https://spec.matrix.org/v1.7/client-server-api/#phone-number
 */
type PhoneLoginIdentifier = {
    type: "m.id.phone";
    country: string;
    phone: string;
};
type SpecUserIdentifier = UserLoginIdentifier | ThirdPartyLoginIdentifier | PhoneLoginIdentifier;
/**
 * User Identifiers usable for login & user-interactive authentication.
 *
 * Extensibly allows more than Matrix specified identifiers.
 */
export type UserIdentifier = SpecUserIdentifier | {
    type: Exclude<string, SpecUserIdentifier["type"]>;
    [key: string]: unknown;
};
/**
 * Request body for POST /login request
 * @see https://spec.matrix.org/v1.7/client-server-api/#post_matrixclientv3login
 */
export interface LoginRequest {
    /**
     * The login type being used.
     */
    type: "m.login.password" | "m.login.token" | string;
    /**
     * ID of the client device.
     * If this does not correspond to a known client device, a new device will be created.
     * The given device ID must not be the same as a cross-signing key ID.
     * The server will auto-generate a device_id if this is not specified.
     */
    device_id?: string;
    /**
     * Identification information for a user
     */
    identifier?: UserIdentifier;
    /**
     * A display name to assign to the newly-created device.
     * Ignored if device_id corresponds to a known device.
     */
    initial_device_display_name?: string;
    /**
     * Required when type is `m.login.password`. The user’s password.
     */
    password?: string;
    /**
     * If true, the client supports refresh tokens.
     */
    refresh_token?: boolean;
    /**
     * Required when type is `m.login.token`. Part of Token-based login.
     */
    token?: string;
    /**
     * The fully qualified user ID or just local part of the user ID, to log in.
     * @deprecated in favour of identifier.
     */
    user?: string;
    [key: string]: unknown;
}
export type ILoginParams = LoginRequest;
/**
 * Response body for POST /login request
 * @see https://spec.matrix.org/v1.7/client-server-api/#post_matrixclientv3login
 *
 * 后端实现: synapse-rust/src/web/routes/auth_compat.rs:312-327
 * 注意: 后端返回 expires_in (秒)，SDK使用 expires_in_ms (毫秒) 进行转换
 */
export interface LoginResponse {
    /**
     * An access token for the account.
     * This access token can then be used to authorize other requests.
     */
    access_token: string;
    /**
     * ID of the logged-in device.
     * Will be the same as the corresponding parameter in the request, if one was specified.
     */
    device_id: string;
    /**
     * The fully-qualified Matrix ID for the account.
     */
    user_id: string;
    /**
     * The lifetime of the access token, in milliseconds.
     * Once the access token has expired a new access token can be obtained by using the provided refresh token.
     * If no refresh token is provided, the client will need to re-log in to obtain a new access token.
     * If not given, the client can assume that the access token will not expire.
     *
     * 注意: 后端返回字段名为 expires_in (秒)，SDK自动转换为 expires_in_ms (毫秒)
     */
    expires_in_ms?: number;
    /**
     * A refresh token for the account.
     * This token can be used to obtain a new access token when it expires by calling the /refresh endpoint.
     *
     * 注意: 后端此字段为必填，但SDK保持可选以兼容旧版本
     */
    refresh_token?: string;
    /**
     * Optional client configuration provided by the server.
     * If present, clients SHOULD use the provided object to reconfigure themselves, optionally validating the URLs within.
     * This object takes the same form as the one returned from .well-known autodiscovery.
     */
    well_known?: IClientWellKnown;
}
/**
 * The result of a successful `m.login.token` issuance request as per https://spec.matrix.org/v1.7/client-server-api/#post_matrixclientv1loginget_token
 */
export interface LoginTokenPostResponse {
    /**
     * The token to use with `m.login.token` to authenticate.
     */
    login_token: string;
    /**
     * Expiration in milliseconds.
     */
    expires_in_ms: number;
}
export {};
//# sourceMappingURL=auth.d.ts.map