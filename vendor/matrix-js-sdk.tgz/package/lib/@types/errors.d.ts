/**
 * Matrix 标准错误码常量定义（与后端 synapse-rust src/common/error.rs MatrixErrorCode 枚举对齐）。
 *
 * - `M_UNRECOGNIZED` 在 Matrix Spec v1.11+ 中使用 HTTP 404 状态码（不再使用 400）。
 *   Element 客户端依赖此行为来区分"端点未实现"和"请求参数错误"。
 *
 * @see https://spec.matrix.org/v1.13/client-server-api/#standard-error-response
 */
export declare const MatrixErrorCode: {
    /** 请求被禁止 */
    readonly M_FORBIDDEN: "M_FORBIDDEN";
    /** 未提供访问令牌或令牌无效 */
    readonly M_UNKNOWN_TOKEN: "M_UNKNOWN_TOKEN";
    /** 请求未携带访问令牌 */
    readonly M_MISSING_TOKEN: "M_MISSING_TOKEN";
    /** 请求体非有效 JSON（语法错误） */
    readonly M_BAD_JSON: "M_BAD_JSON";
    /** 请求 Content-Type 非 application/json */
    readonly M_NOT_JSON: "M_NOT_JSON";
    /** 资源不存在 */
    readonly M_NOT_FOUND: "M_NOT_FOUND";
    /** 请求过于频繁，触发速率限制 */
    readonly M_LIMIT_EXCEEDED: "M_LIMIT_EXCEEDED";
    /** 未知内部错误 */
    readonly M_UNKNOWN: "M_UNKNOWN";
    /** [v1.11+] 端点未实现（HTTP 404） */
    readonly M_UNRECOGNIZED: "M_UNRECOGNIZED";
    /** 认证失败 */
    readonly M_UNAUTHORIZED: "M_UNAUTHORIZED";
    /** 用户已被停用 */
    readonly M_USER_DEACTIVATED: "M_USER_DEACTIVATED";
    /** 用户名已被使用 */
    readonly M_USER_IN_USE: "M_USER_IN_USE";
    /** 无效用户名 */
    readonly M_INVALID_USERNAME: "M_INVALID_USERNAME";
    /** 房间别名已被使用 */
    readonly M_ROOM_IN_USE: "M_ROOM_IN_USE";
    /** 房间状态无效 */
    readonly M_INVALID_ROOM_STATE: "M_INVALID_ROOM_STATE";
    /** 第三方标识符已被使用 */
    readonly M_THREEPID_IN_USE: "M_THREEPID_IN_USE";
    /** 第三方标识符未找到 */
    readonly M_THREEPID_NOT_FOUND: "M_THREEPID_NOT_FOUND";
    /** 第三方认证失败 */
    readonly M_THREEPID_AUTH_FAILED: "M_THREEPID_AUTH_FAILED";
    /** 第三方认证被拒绝 */
    readonly M_THREEPID_DENIED: "M_THREEPID_DENIED";
    /** 联邦：服务器不受信任 */
    readonly M_SERVER_NOT_TRUSTED: "M_SERVER_NOT_TRUSTED";
    /** 不支持的房间版本 */
    readonly M_UNSUPPORTED_ROOM_VERSION: "M_UNSUPPORTED_ROOM_VERSION";
    /** 不兼容的房间版本 */
    readonly M_INCOMPATIBLE_ROOM_VERSION: "M_INCOMPATIBLE_ROOM_VERSION";
    /** 状态不合法 */
    readonly M_BAD_STATE: "M_BAD_STATE";
    /** 访客访问被禁止 */
    readonly M_GUEST_ACCESS_FORBIDDEN: "M_GUEST_ACCESS_FORBIDDEN";
    /** 需要 CAPTCHA 验证 */
    readonly M_CAPTCHA_NEEDED: "M_CAPTCHA_NEEDED";
    /** CAPTCHA 验证失败 */
    readonly M_CAPTCHA_INVALID: "M_CAPTCHA_INVALID";
    /** 缺少必需参数 */
    readonly M_MISSING_PARAM: "M_MISSING_PARAM";
    /** 参数值无效 */
    readonly M_INVALID_PARAM: "M_INVALID_PARAM";
    /** 请求体过大 */
    readonly M_TOO_LARGE: "M_TOO_LARGE";
    /** 资源独占冲突 */
    readonly M_EXCLUSIVE: "M_EXCLUSIVE";
    /** 资源限制超出 */
    readonly M_RESOURCE_LIMIT_EXCEEDED: "M_RESOURCE_LIMIT_EXCEEDED";
    /** 用户无法离开系统通知房间 */
    readonly M_CANNOT_LEAVE_SERVER_NOTICE_ROOM: "M_CANNOT_LEAVE_SERVER_NOTICE_ROOM";
    /** 请求超时 */
    readonly M_REQUEST_TIMEOUT: "M_REQUEST_TIMEOUT";
};
export type MatrixErrorCodeType = (typeof MatrixErrorCode)[keyof typeof MatrixErrorCode];
/**
 * Matrix 错误码及其对应的 HTTP 状态码（与后端 http_status() 方法对齐）。
 *
 * 用于客户端根据 errcode 判断预期的 HTTP 响应行为。
 *
 * @see synapse-rust src/common/error.rs
 */
export declare const MATRIX_ERROR_HTTP_STATUS: Record<string, number>;
/**
 * 根据 HTTP 状态码返回对应的 Matrix 错误码（推测值）。
 * 在无法从响应 body 解析 errcode 时使用。
 */
export declare function httpStatusToErrorCode(httpStatus: number): string;
//# sourceMappingURL=errors.d.ts.map