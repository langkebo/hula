/**
 * Uploads Manager - 上传管理
 *
 * 提供文件上传管理功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IUploadOptions {
    name?: string;
    type?: string;
    includeFilename?: boolean;
    progress?: (progress: {
        loaded: number;
        total: number;
    }) => void;
}
export interface IUploadProgress {
    loaded: number;
    total: number;
}
export interface IUploadResponse {
    content_uri: string;
}
export interface UploadsManagerEvents {
    upload_started: {
        uploadId: string;
        filename: string;
    };
    upload_progress: {
        uploadId: string;
        progress: IUploadProgress;
    };
    upload_completed: {
        uploadId: string;
        contentUri: string;
    };
    upload_failed: {
        uploadId: string;
        error: Error;
    };
}
export declare class UploadsManager extends BaseManager<keyof UploadsManagerEvents, UploadsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    uploadContent(file: File | Blob | string, opts?: IUploadOptions): Promise<IUploadResponse>;
    uploadFile(file: File | Blob, opts?: IUploadOptions): Promise<IUploadResponse>;
    cancelUpload(upload: Promise<unknown>): boolean;
    getUploadProgress(uploadId: string): IUploadProgress | null;
    abortAllUploads(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map