import type { IContent, IEvent, MatrixEvent } from "./models/event.ts";
interface ThreadLike {
    lastReply: (predicate: (event: MatrixEvent) => boolean) => MatrixEvent | null | undefined;
}
export interface PrepareSendEventParamsArgs {
    roomId: string;
    threadIdOrEventType: string | null;
    eventTypeOrContent?: string | IContent;
    contentOrTxnId?: IContent | string;
    txnIdOrVoid?: string;
    eventIdPrefix: string;
    threadRelationTypeName: string;
    getThread: (roomId: string, threadId: string) => ThreadLike | undefined;
}
export interface PreparedSendEventParams {
    threadId: string | null;
    eventObject: Partial<IEvent>;
    txnId?: string;
}
export declare function prepareSendEventParams({ roomId, threadIdOrEventType, eventTypeOrContent, contentOrTxnId, txnIdOrVoid, eventIdPrefix, threadRelationTypeName, getThread, }: PrepareSendEventParamsArgs): PreparedSendEventParams;
export {};
//# sourceMappingURL=client-send-event.d.ts.map