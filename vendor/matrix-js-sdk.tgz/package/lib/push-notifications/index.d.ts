/**
 * Push Notifications Manager - 推送通知管理
 *
 * 提供推送通知相关功能
 */
import { MatrixClient } from "../client";
export interface IPusher {
    pushkey: string;
    kind: string;
    app_id: string;
    app_display_name: string;
    device_display_name: string;
    profile_tag?: string;
    lang: string;
    data: Record<string, unknown>;
}
export interface IPushersResponse {
    pushers: IPusher[];
}
export interface IPusherData {
    url?: string;
    format?: string;
    default_payload?: Record<string, unknown>;
}
export declare class PushNotificationsManager {
    private client;
    constructor(client: MatrixClient);
    getPushers(): Promise<IPushersResponse>;
    setPushers(pushers: IPusher[]): Promise<void>;
    removePusher(pusherData: IPusher): Promise<void>;
    getPusherData(roomId: string, userId: string): IPusherData | null;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map