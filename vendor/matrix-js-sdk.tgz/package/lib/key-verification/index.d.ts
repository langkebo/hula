import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type IDeviceSigningVerificationAcceptRequest, type IDeviceSigningVerificationAcceptResponse, type IDeviceSigningVerificationCancelRequest, type IDeviceSigningVerificationCancelResponse, type IDeviceSigningVerificationDoneResponse, type IDeviceSigningVerificationDoneRequest, type IDeviceSigningVerificationKeyAgreementResponse, type IDeviceSigningVerificationKeyAgreementRequest, type IDeviceSigningVerificationMacResponse, type IDeviceSigningVerificationMacRequest, type IDeviceSigningVerificationStartResponse, type IDeviceSigningVerificationStartRequest, type IScanQrCodeRequest, type IScanQrCodeResponse, type IShowQrCodeResponse, type IVerificationRequestsResponse, MatrixClient } from "../client";
type VerificationApiVersion = "v1" | "v3";
export interface IVerificationStatusResponse {
    transaction_id: string;
    state: string;
    from_device?: string;
    method?: string;
    created_ts?: number;
    updated_ts?: number;
}
export declare class KeyVerificationManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Request verification
     */
    requestVerification(userId: string, methods?: string[], version?: VerificationApiVersion): Promise<IDeviceSigningVerificationStartResponse>;
    /**
     * Request room key verification
     */
    requestRoomKeyVerification(_roomId: string, userId: string, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationStartResponse>;
    /**
     * Begin key verification
     */
    beginKeyVerification(method: string, targetUserId: string, targetDeviceId: string, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationStartResponse>;
    /**
     * Accept device signing verification
     */
    acceptKeyVerification(request: IDeviceSigningVerificationAcceptRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationAcceptResponse>;
    /**
     * Send key agreement step
     */
    sendKeyAgreement(request: IDeviceSigningVerificationKeyAgreementRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationKeyAgreementResponse>;
    /**
     * Send MAC confirmation
     */
    confirmVerificationMac(request: IDeviceSigningVerificationMacRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationMacResponse>;
    /**
     * Complete key verification
     */
    completeKeyVerification(txnId: string, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationDoneResponse>;
    /**
     * Cancel key verification
     */
    cancelKeyVerification(txnId: string, reason?: string, code?: string, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationCancelResponse>;
    /**
     * Get verification requests
     */
    getVerificationRequests(_userIdOrVersion?: string, version?: VerificationApiVersion): Promise<IVerificationRequestsResponse>;
    showQrCode(transactionId: string, version?: VerificationApiVersion): Promise<IShowQrCodeResponse>;
    /**
     * 扫描二维码便捷方法
     *
     * 发送后端 ScanQrBody 所需的全部必填字段，请求体与 scanQrCodeHttp 保持一致，
     * 避免 422/校验失败。
     *
     * @param request 扫码请求体，需包含后端所需的 6 个必填字段
     * @param version 验证 API 版本
     */
    scanQrCode(request: IScanQrCodeRequest, version?: VerificationApiVersion): Promise<{
        transaction_id: string;
        verified: boolean;
    }>;
    private getAuthedRequestProxy;
    startDeviceSigningVerification(request: IDeviceSigningVerificationStartRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationStartResponse>;
    acceptDeviceSigningVerification(request: IDeviceSigningVerificationAcceptRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationAcceptResponse>;
    sendDeviceSigningVerificationKeyAgreement(request: IDeviceSigningVerificationKeyAgreementRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationKeyAgreementResponse>;
    confirmDeviceSigningVerificationMac(request: IDeviceSigningVerificationMacRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationMacResponse>;
    completeDeviceSigningVerification(request: IDeviceSigningVerificationDoneRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationDoneResponse>;
    cancelDeviceSigningVerification(request: IDeviceSigningVerificationCancelRequest, version?: VerificationApiVersion): Promise<IDeviceSigningVerificationCancelResponse>;
    getVerificationRequestsHttp(version?: VerificationApiVersion): Promise<IVerificationRequestsResponse>;
    showQrCodeHttp(version?: VerificationApiVersion): Promise<IShowQrCodeResponse>;
    scanQrCodeHttp(request: IScanQrCodeRequest, version?: VerificationApiVersion): Promise<IScanQrCodeResponse>;
    getVerificationStatus(transactionId: string, version?: VerificationApiVersion): Promise<IVerificationStatusResponse>;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map