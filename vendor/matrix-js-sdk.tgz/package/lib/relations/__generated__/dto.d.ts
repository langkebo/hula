/**
 * DTO snippets extracted from the contract doc for `relations`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
import type { MatrixEvent } from "../../models/event.ts";
export interface RelationsResponse {
    chunk: MatrixEvent[];
    next_batch?: string;
    prev_batch?: string;
}
export interface AggregationsResponse {
    chunk: Array<{
        type: string;
        key: string;
        count: number;
    }>;
}
export interface RelationsRequestDto {
    content: {
        body: string;
        msgtype: string;
    };
    "m.new_content": {
        body: string;
        msgtype: string;
    };
    key: string;
}
export interface RelationsResponseDto {
    event_id: string;
    room_id: string;
    relates_to: {
        event_id: string;
        rel_type: string;
    };
}
//# sourceMappingURL=dto.d.ts.map