export declare const RELATIONS_ROUTES_ENTRY_COUNT: 11;
export declare const RELATIONS_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 400;
    readonly note: "M_INVALID_PARAM | 参数无效";
}, {
    readonly status: 401;
    readonly note: "M_UNAUTHORIZED | 未认证";
}, {
    readonly status: 403;
    readonly note: "M_FORBIDDEN | 非房间成员";
}, {
    readonly status: 404;
    readonly note: "M_NOT_FOUND | 事件或房间不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "补齐 RelationsManager 的聚合查询与关系发送专用封装 | 覆盖率更新为 100%";
}];
export type RelationsStatusScenario = (typeof RELATIONS_ROUTES_STATUS_SCENARIOS)[number];
export declare const RELATIONS_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "参数无效";
    readonly httpOrErrcode: "400 / M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "参数无效";
}, {
    readonly scenario: "未认证";
    readonly httpOrErrcode: "401 / M_UNAUTHORIZED";
    readonly sdkErrorType: "AuthError";
    readonly handling: "未认证";
}, {
    readonly scenario: "非房间成员";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "非房间成员";
}, {
    readonly scenario: "事件或房间不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "事件或房间不存在";
}];
export type RelationsErrorScenario = (typeof RELATIONS_ROUTES_ERROR_SCENARIOS)[number];
export declare const RELATIONS_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "参数无效";
}, {
    readonly errcode: "M_UNAUTHORIZED";
    readonly httpStatus: "401";
    readonly note: "未认证";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "非房间成员";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "事件或房间不存在";
}];
export type RelationsErrcode = (typeof RELATIONS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map