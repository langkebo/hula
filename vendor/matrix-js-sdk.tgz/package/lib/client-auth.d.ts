import { type Body, type IRequestOpts, Method } from "./http-api/index";
import { type QueryDict } from "./utils";
import { type OidcClientConfig } from "./oidc/index";
export declare function buildEmailTokenRequestParams(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): QueryDict;
export declare function buildMsisdnTokenRequestParams(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink?: string): QueryDict;
type RequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, data?: Body, opts?: IRequestOpts) => Promise<T>;
export declare function fetchAuthMetadataWithFallback(request: RequestFn, isVersionSupported: (version: string) => Promise<boolean>): Promise<OidcClientConfig>;
export declare function requestTokenFromEndpoint<T extends {
    sid?: string;
}>(endpoint: string, params: QueryDict, request: RequestFn): Promise<T>;
export {};
//# sourceMappingURL=client-auth.d.ts.map