/**
 * `MatrixClient` 的未读汇总类只读帮助函数。
 *
 * 这些方法只依赖「房间列表 + 按 ID 取房间」两件事，与 client 的网络层、store、
 * crypto 都无关，故从 `src/client.ts` 抽出为自由函数：实现可单测，`MatrixClient`
 * 上保留同签名的一行委托。
 */
import { type Room } from "./models/room";
/** 帮助函数所需的最小只读视图（`MatrixClient` 天然满足）。 */
export interface RoomsReader {
    getRooms(): Room[];
    getRoom(roomId: string | undefined): Room | null;
}
/**
 * 取未读通知数最高的房间。
 *
 * ⚠️ 2026-10-18 修正：此前恒返回 `null`（未读角标/红点无处可指）。
 * 现在按 `Room.getUnreadNotificationCount(Total)` 取最大者；全部为 0 时返回 `null`。
 *
 * @param client - 提供房间列表的只读视图。
 * @returns 未读数最高的房间；没有任何未读时为 `null`。
 *
 * @example
 * ```typescript
 * const room = selectRoomWithHighestUnread(client);
 * ```
 */
export declare function selectRoomWithHighestUnread(client: RoomsReader): Room | null;
/**
 * 按 alias 在**本地已知房间**里查（同步）。
 *
 * ⚠️ 2026-10-18 修正：此前恒返回 `null`。
 * 匹配的是房间的 `m.room.canonical_alias` 状态；要查服务端（含未加入的房间）
 * 请用异步的 `getRoomIdForAlias`。
 *
 * @param client - 提供房间列表的只读视图。
 * @param alias - 房间 alias（如 `#foo:example.org`）。
 * @returns 匹配的房间；本地没有则 `null`。
 *
 * @example
 * ```typescript
 * const room = findRoomByCanonicalAlias(client, "#example:matrix.org");
 * ```
 */
export declare function findRoomByCanonicalAlias(client: RoomsReader, alias: string): Room | null;
/**
 * 排序房间列表 —— 本构建**不实现**。
 *
 * 房间顺序由 store 拥有（Map 插入顺序），SDK 没有"设置顺序"的入口。
 * 此前是空方法（调用方以为排好了），现在**显式抛错并给出替代做法**。
 *
 * @throws 总是抛出。
 *
 * @example
 * ```typescript
 * throwSortRoomsByLastMessageUnsupported();
 * ```
 */
export declare function throwSortRoomsByLastMessageUnsupported(): never;
/**
 * 全部房间的未读通知总数（桌面端 badge 用）。
 *
 * ⚠️ 2026-10-18 修正：此前恒返回 `0`。现在对 `getRooms()` 求和。
 *
 * @param client - 提供房间列表的只读视图。
 * @returns 所有房间未读数之和。
 *
 * @example
 * ```typescript
 * const total = countTotalNotifications(client);
 * ```
 */
export declare function countTotalNotifications(client: RoomsReader): number;
/**
 * 全部房间的 highlight 通知总数。
 *
 * ⚠️ 2026-10-18 修正：此前恒返回 `0`。现在对 `getRooms()` 求和。
 *
 * @param client - 提供房间列表的只读视图。
 * @returns 所有房间 highlight 数之和。
 *
 * @example
 * ```typescript
 * const total = countTotalHighlights(client);
 * ```
 */
export declare function countTotalHighlights(client: RoomsReader): number;
//# sourceMappingURL=client-notification-helpers.d.ts.map