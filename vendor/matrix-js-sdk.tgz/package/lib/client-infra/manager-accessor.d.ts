import { type ManagerName, type ManagerTypeMap } from "./manager-registry";
declare module "../client" {
    interface MatrixClient {
        manager<K extends ManagerName>(name: K): ManagerTypeMap[K];
    }
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=manager-accessor.d.ts.map