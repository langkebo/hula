/**
 * DTO snippets extracted from the contract doc for `search`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type SearchContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map