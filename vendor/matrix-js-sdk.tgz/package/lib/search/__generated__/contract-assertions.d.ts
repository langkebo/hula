export declare const SEARCH_ROUTES_ENTRY_COUNT: 11;
export declare const SEARCH_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "搜索词为空、过滤器超限或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "无权搜索目标房间或查看用户资料";
}, {
    readonly status: 404;
    readonly note: "房间或事件不存在";
}, {
    readonly status: 429;
    readonly note: "触发限流";
}];
export type SearchStatusScenario = (typeof SEARCH_ROUTES_STATUS_SCENARIOS)[number];
export declare const SEARCH_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录或刷新凭据";
}, {
    readonly scenario: "搜索条件不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 term、limit、filter 后重试";
}, {
    readonly scenario: "无权访问目标房间或资料";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户缺少对应房间成员资格或资料可见性";
}, {
    readonly scenario: "上下文房间/事件不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "提示目标房间或事件已不存在";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底处理";
}];
export type SearchErrorScenario = (typeof SEARCH_ROUTES_ERROR_SCENARIOS)[number];
export declare const SEARCH_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "请求体结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "搜索词、过滤器或分页参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权搜索目标房间或查看受限资料";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "请求中的房间或事件不存在";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "搜索请求触发限流";
}];
export type SearchErrcode = (typeof SEARCH_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map