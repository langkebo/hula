/** Routes served by the synapse-rust `search` module (mirrored from the backend contract). */
export declare const SEARCH_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/context/{event_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/hierarchy";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/timestamp_to_event";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/context/{event_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/hierarchy";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/search";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/search_recipients";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/search_rooms";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/vendor/v1/search_recipients";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/vendor/v1/search_rooms";
}];
/** Union of every (method, path) tuple in `SEARCH_ROUTES`. */
export type SearchRoute = (typeof SEARCH_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type SearchMethod = SearchRoute["method"];
/** Path templates referenced by this module. */
export type SearchPath = SearchRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type SearchReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${SearchReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type SearchPathPattern = SearchReplaceBraces<SearchPath>;
//# sourceMappingURL=route-table.d.ts.map