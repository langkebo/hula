/**
 * Search Manager - 搜索管理
 *
 * 提供消息、用户搜索功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type ISearchRequestBody, type ISearchResponse, type ISearchResults, type SearchKey } from "../@types/search";
import type { IEventSearchOpts } from "../@types/requests";
import type { IUserDirectoryResponse } from "../client-internal-types";
export interface ISearchOptions {
    term: string;
    keys?: SearchKey[];
    room_id?: string;
    limit?: number;
    before_limit?: number;
    after_limit?: number;
    order_by_recency?: boolean;
    include_state?: boolean;
    filter?: {
        rooms?: string[];
        senders?: string[];
        types?: string[];
    };
}
export interface SearchManagerEvents {
    search_completed: {
        term: string;
        count: number;
    };
    search_failed: {
        term: string;
        error: Error;
    };
}
export declare class SearchManager extends BaseManager<keyof SearchManagerEvents, SearchManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 搜索消息文本
     *
     * @param opts - 搜索选项
     * @param opts.term - 搜索关键词
     * @param opts.room_id - 房间 ID（可选）
     * @param opts.limit - 结果数量限制（可选）
     * @param opts.order_by_recency - 是否按时间排序（可选）
     *
     * @example
     * ```typescript
     * // 搜索所有房间的消息
     * const results = await searchManager.searchMessageText({
     *     term: "hello"
     * });
     * console.log(`Found ${results.search_categories.room_events?.count} results`);
     *
     * // 在特定房间搜索
     * const roomResults = await searchManager.searchMessageText({
     *     term: "meeting",
     *     room_id: "!abc:example.com",
     *     limit: 20
     * });
     *
     * // 按时间排序
     * const recentResults = await searchManager.searchMessageText({
     *     term: "update",
     *     order_by_recency: true
     * });
     * ```
     *
     * @throws {ValidationError} 如果搜索关键词为空或房间 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    searchMessageText(opts: ISearchOptions): Promise<ISearchResponse>;
    searchRoomEvents(opts: ISearchOptions): Promise<ISearchResponse>;
    /**
     * 搜索用户目录
     *
     * @param opts - 搜索选项
     * @param opts.term - 搜索关键词
     * @param opts.limit - 结果数量限制（可选）
     *
     * @example
     * ```typescript
     * // 搜索用户
     * const users = await searchManager.searchUserDirectory({
     *     term: "alice"
     * });
     * users.results.forEach(user => {
     *     console.log(`${user.display_name} (${user.user_id})`);
     * });
     *
     * // 限制结果数量
     * const limitedUsers = await searchManager.searchUserDirectory({
     *     term: "bob",
     *     limit: 10
     * });
     * ```
     *
     * @throws {ValidationError} 如果搜索关键词为空或 limit 超出范围
     * @throws {ApiError} 如果 API 调用失败
     */
    searchUserDirectory(opts: {
        term: string;
        limit?: number;
    }): Promise<IUserDirectoryResponse>;
    searchRecipients(opts: {
        term: string;
        limit?: number;
    }): Promise<{
        results: unknown[];
        count: number;
        next_batch: string | null;
    }>;
    search({ body, next_batch, abortSignal, }: {
        body: ISearchRequestBody;
        next_batch?: string;
        abortSignal?: AbortSignal;
    }): Promise<ISearchResponse>;
    /**
     * Perform a server-side search for room events, returning processed search results.
     *
     * The returned promise resolves to an ISearchResults object containing the fields:
     * count, next_batch, highlights, results
     *
     * @param opts - search options including term and optional filter
     * @returns Promise which resolves: ISearchResults object
     */
    searchRoomEventsProcessed(opts: IEventSearchOpts): Promise<ISearchResults>;
    /**
     * Take a result from an earlier searchRoomEvents call, and backfill results.
     *
     * @param searchResults - the results object to be updated
     * @returns Promise which resolves: updated result object
     */
    backPaginateRoomEventsSearch<T extends ISearchResults>(searchResults: T): Promise<T>;
    /**
     * Helper for searchRoomEvents and backPaginateRoomEventsSearch. Processes the
     * response from the API call and updates the searchResults.
     *
     * @returns searchResults
     * @internal
     */
    processRoomEventsSearch<T extends ISearchResults>(searchResults: T, response: ISearchResponse): T;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map