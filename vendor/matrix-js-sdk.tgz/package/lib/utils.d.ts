/**
 * This is an internal module. Backward-compatible re-export barrel.
 * New code should import directly from the domain-specific modules:
 *   - src/common/async.ts       (sleep, logDuration, etc.)
 *   - src/common/strings.ts     (internaliseString, normalize, etc.)
 *   - src/common/collections.ts (deepCopy, MapWithDefault, etc.)
 *   - src/common/safety.ts      (safeSet, isNullOrUndefined, etc.)
 *   - src/http-api/utils.ts     (encodeParams, encodeUri, QueryDict, etc.)
 */
export { sleep, logDuration, logDurationSync, promiseMapSeries, promiseTry, simpleRetryOperation, } from "./common/async";
export { internaliseString, removeHiddenChars, removeDirectionOverrideChars, normalize, escapeRegExp, globToRegexp, DEFAULT_ALPHABET, alphabetPad, baseToString, stringToBase, averageBetweenStrings, nextString, prevString, lexicographicCompare, } from "./common/strings";
export { removeElement, deepCopy, deepCompare, deepSortedObjectEntries, mapsEqual, recursiveMapToObject, MapWithDefault, } from "./common/collections";
export { checkObjectHasKeys, isNumber, isNullOrUndefined, recursivelyAssign, sortEventsByLatestContentTimestamp, isSupportedReceiptType, unsafeProp, safeSet, noUnsafeEventProps, } from "./common/safety";
export { encodeParams, encodeUri, replaceParam, ensureNoTrailingSlash } from "./http-api/utils";
export type { QueryDict } from "./http-api/utils";
//# sourceMappingURL=utils.d.ts.map