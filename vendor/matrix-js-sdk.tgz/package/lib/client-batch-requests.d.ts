import { Method } from "./http-api/index.ts";
import type { Body, IRequestOpts } from "./http-api/index.ts";
import type { QueryDict } from "./utils.ts";
import type { IEvent } from "./models/event.ts";
import type { IRoomDirectoryOptions, ISearchOpts } from "./@types/requests.ts";
import type { IJoinedMembersResponse, IJoinedRoomsResponse, IRoomInitialSyncResponse, IPublicRoomsResponse, IOpenIDToken } from "./client.ts";
import type { IStateEventWithRoomId, ISearchRequestBody, ISearchResponse } from "./@types/search.ts";
import type { EmptyObject } from "./@types/common.ts";
import type { Visibility } from "./@types/partials.ts";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function buildRoomStatePath(roomId: string): string;
export declare function buildStateEventPath(roomId: string, eventType: string, stateKey?: string): string;
export declare function roomStateRequest(roomId: string, authedRequest: AuthedRequestFn): Promise<IStateEventWithRoomId[]>;
export declare function fetchRoomEventRequest(roomId: string, eventId: string, authedRequest: AuthedRequestFn): Promise<Partial<IEvent>>;
export declare function membersRequest(roomId: string, includeMembership: string | undefined, excludeMembership: string | undefined, atEventId: string | undefined, authedRequest: AuthedRequestFn): Promise<{
    [userId: string]: IStateEventWithRoomId[];
}>;
export declare function getJoinedRoomMembersRequest(roomId: string, authedRequest: AuthedRequestFn): Promise<IJoinedMembersResponse>;
export declare function setRoomReadMarkersRequest(roomId: string, rmEventId: string, rrEventId: string | undefined, rpEventId: string | undefined, supportsPrivateReadReceipt: () => Promise<boolean>, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function roomInitialSyncRequest(roomId: string, limit: number, authedRequest: AuthedRequestFn): Promise<IRoomInitialSyncResponse>;
export declare function getJoinedRoomsRequest(authedRequest: AuthedRequestFn): Promise<IJoinedRoomsResponse>;
export declare function publicRoomsRequest(roomDirectoryOptions: IRoomDirectoryOptions, authedRequest: AuthedRequestFn): Promise<IPublicRoomsResponse>;
export declare function createAliasRequest(alias: string, roomId: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function deleteAliasRequest(alias: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function getLocalAliasesRequest(roomId: string, authedRequest: AuthedRequestFn): Promise<{
    aliases: string[];
}>;
export declare function getRoomIdForAliasRequest(alias: string, authedRequest: AuthedRequestFn): Promise<{
    room_id: string;
    servers: string[];
}>;
export declare function getRoomDirectoryVisibilityRequest(roomId: string, authedRequest: AuthedRequestFn): Promise<{
    visibility: Visibility;
}>;
export declare function setRoomDirectoryVisibilityRequest(roomId: string, visibility: Visibility, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function buildSearchMessageRequestBody(opts: ISearchOpts): ISearchRequestBody;
export declare function searchMessageTextRequest(opts: ISearchOpts, search: (opts: {
    body: ISearchRequestBody;
}) => Promise<ISearchResponse>): Promise<ISearchResponse>;
export declare function getOpenIdTokenRequest(userId: string, authedRequest: AuthedRequestFn): Promise<IOpenIDToken>;
export {};
//# sourceMappingURL=client-batch-requests.d.ts.map