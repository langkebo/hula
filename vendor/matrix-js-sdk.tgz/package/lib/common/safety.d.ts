import { type IEvent, type MatrixEvent } from "../models/event";
/**
 * Checks that the given object has the specified keys.
 * @param obj - The object to check.
 * @param keys - The list of keys that 'obj' must have.
 * @throws If the object is missing keys.
 */
export declare function checkObjectHasKeys(obj: object, keys: string[]): void;
/**
 * Returns whether the given value is a finite number without type-coercion
 *
 * @param value - the value to test
 * @returns whether or not value is a finite number without type-coercion
 */
export declare function isNumber(value: unknown): value is number;
export declare function isNullOrUndefined(val: unknown): boolean;
/**
 * This function is similar to Object.assign() but it assigns recursively and
 * allows you to ignore nullish values from the source
 *
 * @returns the target object
 */
export declare function recursivelyAssign<T1 extends T2, T2 extends Record<string, any>>(target: T1, source: T2, ignoreNullish?: boolean): T1 & T2;
/**
 * Sort events by their content m.ts property
 * Latest timestamp first
 */
export declare function sortEventsByLatestContentTimestamp(left: MatrixEvent, right: MatrixEvent): number;
export declare function isSupportedReceiptType(receiptType: string): boolean;
export declare function unsafeProp<K extends keyof any | undefined>(prop: K): boolean;
export declare function safeSet<O extends Record<any, any>, K extends keyof O>(obj: O, prop: K, value: O[K]): void;
export declare function noUnsafeEventProps(event: Partial<IEvent>): boolean;
//# sourceMappingURL=safety.d.ts.map