/**
 * Backward-compatible re-export barrel.
 * New code should import directly from "../errors".
 */
export { InvalidParamError } from "../errors";
//# sourceMappingURL=errors.d.ts.map