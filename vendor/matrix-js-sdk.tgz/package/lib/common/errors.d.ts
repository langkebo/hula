import { ValidationError } from "../errors";
/**
 * Invalid parameter error.
 *
 * Kept as a distinct class for API ergonomics, but extends {@link ValidationError}
 * so generic validation callers and `instanceof ValidationError` checks continue
 * to work after the 2026 validator unification.
 */
export declare class InvalidParamError extends ValidationError {
    constructor(message: string, cause?: unknown);
}
//# sourceMappingURL=errors.d.ts.map