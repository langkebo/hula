import { type BaseLogger } from "../logger";
/**
 * Returns a promise which resolves with a given value after the given number of ms
 */
export declare function sleep<T>(ms: number, value?: T): Promise<T>;
/**
 * Utility to log the duration of a promise.
 *
 * @param logger - The logger to log to.
 * @param name - The name of the operation.
 * @param block - The block to execute.
 */
export declare function logDuration<T>(logger: BaseLogger, name: string, block: () => Promise<T>): Promise<T>;
/**
 * Utility to log the duration of a synchronous block.
 *
 * @param logger - The logger to log to.
 * @param name - The name of the operation.
 * @param block - The block to execute.
 */
export declare function logDurationSync<T>(logger: BaseLogger, name: string, block: () => T): T;
export declare function promiseMapSeries<T>(promises: Array<T | Promise<T>>, fn: (t: T) => Promise<unknown> | undefined): Promise<void>;
export declare function promiseTry<T>(fn: () => T | Promise<T>): Promise<T>;
/**
 * Retries the function until it succeeds or is interrupted. The given function must return
 * a promise which throws/rejects on error, otherwise the retry will assume the request
 * succeeded. The promise chain returned will contain the successful promise. The given function
 * should always return a new promise.
 * @param promiseFn - The function to call to get a fresh promise instance. Takes an
 * attempt count as an argument, for logging/debugging purposes.
 * @param shouldRetry - Optional function which is called with the error the latest rejection from promiseFn,
 * retrying will ba aborted if this return false.
 * @returns The promise for the retried operation.
 */
export declare function simpleRetryOperation<T>(promiseFn: (attempt: number) => Promise<T>, shouldRetry?: (e: unknown) => boolean): Promise<T>;
//# sourceMappingURL=async.d.ts.map