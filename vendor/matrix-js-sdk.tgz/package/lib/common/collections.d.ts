/**
 * The removeElement() method removes the first element in the array that
 * satisfies (returns true) the provided testing function.
 * @param array - The array.
 * @param fn - Function to execute on each value in the array, with the
 * function signature `fn(element, index, array)`. Return true to
 * remove this element and break.
 * @param reverse - True to search in reverse order.
 * @returns True if an element was removed.
 */
export declare function removeElement<T>(array: T[], fn: (t: T, i?: number, a?: T[]) => boolean, reverse?: boolean): boolean;
/**
 * Deep copy the given object. The object MUST NOT have circular references and
 * MUST NOT have functions.
 * @param obj - The object to deep copy.
 * @returns A copy of the object without any references to the original.
 */
export declare function deepCopy<T>(obj: T): T;
/**
 * Compare two objects for equality. The objects MUST NOT have circular references.
 *
 * @param x - The first object to compare.
 * @param y - The second object to compare.
 *
 * @returns true if the two objects are equal
 */
export declare function deepCompare(x: unknown, y: unknown): boolean;
/**
 * Creates an array of object properties/values (entries) then
 * sorts the result by key, recursively. The input object must
 * ensure it does not have loops. If the input is not an object
 * then it will be returned as-is.
 * @param obj - The object to get entries of
 * @returns The entries, sorted by key.
 */
export declare function deepSortedObjectEntries(obj: unknown): unknown;
/**
 * Determines whether two maps are equal.
 * @param eq - The equivalence relation to compare values by. Defaults to strict equality.
 */
export declare function mapsEqual<K, V>(x: Map<K, V>, y: Map<K, V>, eq?: (v1: V, v2: V) => boolean): boolean;
/**
 * Recursively converts Maps to plain objects.
 * Also supports sub-lists of Maps.
 */
export declare function recursiveMapToObject(map: Map<unknown, unknown>): Record<string, unknown>;
export declare class MapWithDefault<K, V> extends Map<K, V> {
    private createDefault;
    constructor(createDefault: () => V);
    /**
     * Returns the value if the key already exists.
     * If not, it creates a new value under that key using the ctor callback and returns it.
     */
    getOrCreate(key: K): V;
}
//# sourceMappingURL=collections.d.ts.map