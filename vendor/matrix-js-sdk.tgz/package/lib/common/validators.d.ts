export declare function validateUserId(userId: string): void;
export declare function validateRoomId(roomId: string, opts?: {
    allowAlias?: boolean;
}): void;
export declare function validateEventType(eventType: string): void;
export declare function validateLimit(limit: number): void;
//# sourceMappingURL=validators.d.ts.map