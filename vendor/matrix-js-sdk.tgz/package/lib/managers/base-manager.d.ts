/**
 * Base Manager - 管理器基类
 *
 * 提供所有 Manager 类的通用功能：
 * - 统一的错误处理和规范化
 * - 重试逻辑
 * - 请求统计
 * - 日志记录
 */
import { TypedEventEmitter } from "../models/typed-event-emitter";
import { SdkError } from "../errors";
import { MatrixClient } from "../client";
export interface RetryOptions {
    maxRetries?: number;
    retryDelay?: number;
    backoffMultiplier?: number;
    idempotent?: boolean;
    retryNonIdempotent?: boolean;
    label?: string;
}
export interface RequestStats {
    total: number;
    successful: number;
    failed: number;
    retried: number;
}
/**
 * Base class for all Manager classes
 *
 * Provides common functionality like error handling, retry logic, and request statistics.
 */
export declare abstract class BaseManager<Events extends string = string, EventMap extends Record<Events, any> = Record<Events, any>> extends TypedEventEmitter<Events, EventMap> {
    protected readonly client: MatrixClient;
    protected retryOptions: RetryOptions;
    protected requestStats: RequestStats;
    constructor(client: MatrixClient, retryOptions?: RetryOptions);
    /**
     * Set retry options for this manager.
     * This is intended for internal use by the SDK to configure retry behavior.
     * @param options - The retry options to set.
     * @internal
     */
    setRetryOptions(options: RetryOptions): void;
    /**
     * Normalize an error into a standard SdkError
     *
     * @param error - The error to normalize
     * @param method - The method name where the error occurred
     * @returns A normalized SdkError
     */
    protected normalizeError(error: unknown, method: string): SdkError;
    /**
     * Execute a function with retry logic
     *
     * @param fn - The function to execute
     * @param optionsOrLabel - Retry options or a label for logging
     * @returns The result of the function
     */
    protected withRetry<T>(fn: () => Promise<T>, optionsOrLabel?: RetryOptions | string): Promise<T>;
    /**
     * Get request statistics
     *
     * @returns Request statistics
     */
    getRequestStats(): RequestStats;
    /**
     * Reset request statistics
     */
    resetRequestStats(): void;
    /**
     * Sleep for a specified duration
     *
     * @param ms - Duration in milliseconds
     */
    protected sleep(ms: number): Promise<void>;
}
//# sourceMappingURL=base-manager.d.ts.map