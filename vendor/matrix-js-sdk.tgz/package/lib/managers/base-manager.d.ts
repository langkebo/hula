/**
 * Base Manager - 管理器基类
 *
 * 提供所有 Manager 类的通用功能：
 * - 统一的 HTTP 请求通道 (`request()`) 含可注入的 Transport seam
 * - 重试逻辑（幂等方法默认开启，非幂等方法需显式声明）
 * - 错误归一化（MatrixError/HTTPError → SdkError 子类）
 * - 请求统计
 * - 日志记录
 */
import { TypedEventEmitter } from "../models/typed-event-emitter";
import type { QueryDict } from "../http-api/utils";
import type { Body, IRequestOpts } from "../http-api/interface";
import { Method } from "../http-api/method";
import { SdkError } from "../errors";
import { MatrixClient } from "../client";
import type { MatrixClientInternalMethods } from "../matrix-client-extensions";
export interface RetryOptions {
    maxRetries?: number;
    retryDelay?: number;
    backoffMultiplier?: number;
    /**
     * 是否允许重试。
     *
     * 显式指定时优先采用；未指定时按本次调用**实际发出的 HTTP 方法**推断：
     * 仅 GET / HEAD 视为幂等可重试，POST / PUT / DELETE 等写方法默认不重试，
     * 避免"服务端已成功但响应丢失"时写操作被重复提交（S-8）。
     * 确需重试写请求时传 `retryNonIdempotent: true` 显式开启。
     */
    idempotent?: boolean;
    retryNonIdempotent?: boolean;
    label?: string;
    /** 抖动比例（0~1），用于避免重试风暴。0 = 无抖动。 */
    jitterRatio?: number;
    /**
     * 单次重试允许的**最长等待**（毫秒，默认 `DEFAULT_MAX_RETRY_DELAY_MS`，30s）。
     *
     * 服务端 `retry_after_ms` / `Retry-After` 超过该值时**不再重试**，直接把错误抛给调用方
     * （错误对象上 `getRetryAfterMs()` 仍可读到服务端建议值）。
     *
     * 为什么需要这道闸：`retry_after_ms=300000`（登录锁定）时，按服务端值睡觉等于让
     * `client.loginRequest()` **阻塞 5 分钟 ×3 次**，调用方既拿不到错误也看不到进度，
     * 表现为"整个应用卡住"。失败 + 可读的 `retry_after` 对客户端更可用
     * （联调里它正是 `Hook timed out in 30000ms` 的成因）。
     */
    maxRetryDelayMs?: number;
}
/**
 * 单次重试默认最长等待（30s）。
 *
 * 超过它的服务端 `retry_after` 一律**不重试**：等 5 分钟再重试 3 次，比直接失败更糟
 * （调用方拿不到错误、界面表现为卡死）。
 */
export declare const DEFAULT_MAX_RETRY_DELAY_MS = 30000;
export interface RequestStats {
    total: number;
    successful: number;
    failed: number;
    retried: number;
}
/**
 * `request()` 方法的参数对象。
 */
export interface RequestSpec {
    method: Method;
    path: string;
    prefix?: string;
    queryParams?: QueryDict;
    body?: unknown;
    retry?: RetryOptions;
    /** 用于日志和错误消息的标签，默认使用 `path` */
    label?: string;
    /**
     * 是否携带用户 access token。
     *
     * - `true`（默认）：走 `client.http.authedRequest`（经 transport）。
     * - `false`：走 `client.http.request`（不带 token），用于 federation
     *   查询等无需用户鉴权的端点。
     */
    authenticated?: boolean;
    /**
     * 透传至 `IRequestOpts.json = false`：响应按 **UTF-8 文本**解析而不是 JSON。
     *
     * 用于返回 `text/plain` / `application/xml` 的端点（如 CAS 的
     * `serviceValidate` ⇒ `yes\n<user>`、`proxyValidate`/`p3/serviceValidate`/`proxy` ⇒ CAS XML）。
     */
    textResponse?: boolean;
    /** 透传至 IRequestOpts.localTimeoutMs，用于长轮询请求（如 sliding sync） */
    localTimeoutMs?: number;
    /** 透传至 IRequestOpts.headers，用于自定义请求头（如媒体上传的 Content-Type） */
    headers?: Record<string, string>;
    /** 透传至 IRequestOpts.abortSignal，用于取消请求（如 sliding sync 重发） */
    abortSignal?: AbortSignal;
    /**
     * 调用方在**闭包之外**算好的幂等键（Matrix 事务 ID），仅用于写方法。
     *
     * 声明它等于承诺两件事：(1) `path` 的最后一跳就是该键（`/send/{eventType}/{txnId}`）；
     * (2) 同一个键在重试时会被复用而不是重新生成。满足这两条时，一次 5xx 重放不会产生
     * 重复事件 —— 服务端按 txnId 去重 —— 于是 `withRetry()` 允许重试这类写请求，而不必
     * 让每个调用点自己传 `retryNonIdempotent: true`（那会连没有幂等键的写也一起放开）。
     *
     * @example
     * const txnId = `m${Date.now()}`; // 必须在闭包外：闭包内的 Date.now() 每次重试都不同
     * await this.withRetry(() =>
     *     this.request({
     *         method: Method.Put,
     *         path: `/rooms/${roomId}/send/m.room.message/${txnId}`,
     *         body: content,
     *         idempotencyKey: txnId,
     *     }),
     * );
     */
    idempotencyKey?: string;
}
/**
 * Transport 请求选项：在 `IRequestOpts` 基础上扩展 `authenticated` 字段。
 *
 * `authenticated` 决定是否携带用户 access token：
 * - `true`（默认）：走 `client.http.authedRequest`（带 token）。
 * - `false`：走 `client.http.request`（不带 token），用于公共端点。
 */
export type TransportOpts = IRequestOpts & {
    authenticated?: boolean;
};
/**
 * HTTP 传输层接口。
 *
 * 生产环境默认适配 `client.http.authedRequest`，测试可注入 in-memory fake。
 *
 * `opts.authenticated`（默认 `true`）决定是否携带用户 access token。
 * 自定义 Transport 实现可忽略该字段；测试用的 FakeTransport 通常直接走单一通道。
 */
export interface Transport {
    request<T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, opts?: TransportOpts): Promise<T>;
}
/**
 * Manager 构造选项，向后兼容 `RetryOptions`。
 */
export interface ManagerOpts extends RetryOptions {
    transport?: Transport;
    /** 默认 API 前缀，不传时 fallback 为 `ClientPrefix.V3` */
    defaultPrefix?: string;
    /**
     * 管理员敏感操作 MFA 验证码（TOTP）提供者。
     *
     * 当后端开启 `admin_mfa_required` 时，所有敏感 admin 请求（全部 POST/PUT/PATCH/DELETE，
     * 以及 `/_synapse/admin/v1/{security,server,media/quarantine}` 下的 GET）都必须携带
     * `x-admin-mfa-code` 头，否则会被 403 拒绝（`"Sensitive admin operation requires MFA code"`）。
     *
     * 仅在 admin 域（`AdminBaseManager` 及其子 Manager）生效：每次发送 admin 请求时调用该
     * 回调取当前 6 位 TOTP 并注入请求头。未配置时行为与之前完全一致（不注入该头）。
     *
     * @example
     * ```typescript
     * extendMatrixClient({ adminMfaCodeProvider: () => generateTotp(secret) });
     * ```
     */
    adminMfaCodeProvider?: () => string;
}
export declare abstract class BaseManager<Events extends string = string, EventMap extends Record<Events, any> = Record<Events, any>> extends TypedEventEmitter<Events, EventMap> {
    protected readonly client: MatrixClient;
    protected readonly transport: Transport;
    protected readonly defaultPrefix: string;
    protected retryOptions: RetryOptions;
    protected requestStats: RequestStats;
    /**
     * 当前处于 `withRetry()` 调用链中的深度（并发安全计数器）。
     *
     * Managers 通常是单例，多个并发 `withRetry()` 调用会共享同一实例。使用布尔标志
     * 会在某个调用先结束时被重置为 `false`，导致其它在途调用中的 `request()` 误判
     * 为「未处于 withRetry」从而自行重试并写入统计，造成双重计数与嵌套重试
     * （见 FT-115）。改为深度计数器后，只要仍有任一 `withRetry()` 在途，
     * `request()` 就保持单次调用模式，全部退出后才恢复独立重试+统计。
     *
     * - `> 0`：`request()` 被外层 `withRetry()` 包装，只做单次调用，不重试、不写统计
     *   （由 `withRetry()` 统一负责），避免双重计数与嵌套重试。
     * - `0`：`request()` 被直接调用，自行负责重试与统计。
     */
    private _withRetryDepth;
    /**
     * 所有在途 `withRetry()` 的观测帧（方法与成败，S-8）。
     *
     * `withRetry()` 接收的是闭包，自身无法得知内部会发什么请求，因此进入时压入一个
     * 空帧，`request()` 在被包装（`_withRetryDepth > 0`）时把 `{ method, ok }` 回填到
     * 本次调用所属的帧，`withRetry()` 退出时按身份移除自己的帧。
     *
     * 归属规则见 {@link _retryFrameStack}；只在无法确定归属时才写入全部帧。
     *
     * 之所以连 `ok` 一起记录：限流（429 / `M_LIMIT_EXCEEDED`）重试会**重跑整个闭包**，
     * 若闭包中已有写请求成功返回，重放会造成重复提交 —— 此时必须放弃重试。
     */
    private readonly _retryObserved;
    /**
     * 当前同步执行栈上的观测帧（用于把请求精确归属到发起它的 `withRetry()`）。
     *
     * `withRetry()` 在调用闭包前压入自己的帧、在闭包同步前奏结束后立即出栈。
     * `request()` 在入口处同步复制这组「外层帧」，请求完成后回填到其中**每一个**帧
     * （嵌套 `withRetry()` 的内层请求同样属于外层闭包）。
     *
     * 并发但互不嵌套的 `withRetry()` 不会同时出现在同一同步栈上，因此各自持有
     * 独立观测，不会互相污染 —— 这正是「读请求因并发写请求而失去重试」的修复点。
     */
    private readonly _retryFrameStack;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 判断 HTTP 方法是否幂等（仅 GET / HEAD），与 `request()` 的判定保持一致。
     */
    private static isIdempotentMethod;
    /**
     * 将 `this.client` 类型断言为 `MatrixClient & MatrixClientInternalMethods`，
     * 使 Manager 可通过 `this.internalClient.xxx` 类型安全地访问 MatrixClient
     * 内部成员（syncApi、turnServers、serverClockDiff 等）。
     *
     * 这是整个 SDK 中唯一的 `as unknown as` 断言点（针对内部成员访问），
     * 替代了先前散落在各 Manager 中的 45 处类型断言。
     */
    protected get internalClient(): MatrixClient & MatrixClientInternalMethods;
    /**
     * 发送 HTTP 请求，自动合并重试配置、错误归一化和请求统计。
     *
     * 当被 `withRetry()` 包装时（`_withRetryDepth > 0`），本方法退化为单次调用，
     * 重试与统计交由外层 `withRetry()` 统一负责，避免双重计数与嵌套重试。
     *
     * @example
     * const res = await this.request<IUserResponse>({
     *     method: Method.Get,
     *     path: "/users",
     *     prefix: ClientPrefix.V1,
     * });
     */
    protected request<T>(spec: RequestSpec): Promise<T>;
    /**
     * @deprecated 请使用 `this.request({ method, path, prefix: AdminPrefix.V1 })` 替代。
     */
    protected adminRequest<T>(method: Method, path: string, queryParams?: Record<string, string | string[]>, body?: object, label?: string): Promise<T>;
    /**
     * 已知的 Matrix 前缀列表（按从长到短排序，避免短前缀误匹配）。
     *
     * 包含 C-S API 的所有标准版本前缀，以及 Admin/Media/Federation 命名空间。
     * 该列表是 SDK 的运行时前缀注册表——`authedRequestWithPrefix` 会按此列表
     * 剥离传入路径的前缀，并把剥离下来的前缀透传给 transport 层。
     *
     * P1 优化：替代前端 `MatrixHttpClient.ts` 中的 `stripMatrixPrefix` 手动逻辑。
     */
    protected static readonly KNOWN_PREFIXES: readonly string[];
    /**
     * 从完整路径中剥离已知前缀，返回短路径和需要显式设置的 prefix。
     *
     * 若路径不含任何已知前缀，返回原路径（使用默认前缀 ClientPrefix.V3）。
     * 若路径仅由前缀组成（不包含具体子路径），返回 "/"。
     *
     * @example
     * _splitPrefix("/_matrix/client/v3/rooms") → { cleanPath: "/rooms", prefix: "/_matrix/client/v3" }
     * _splitPrefix("/rooms") → { cleanPath: "/rooms", prefix: undefined }
     * _splitPrefix("/_matrix/client/v3") → { cleanPath: "/", prefix: "/_matrix/client/v3" }
     */
    protected _splitPrefix(path: string): {
        cleanPath: string;
        prefix?: string;
    };
    /**
     * 带前缀的认证请求：自动剥离路径中已包含的 Matrix 前缀，避免双前缀拼接到 404。
     *
     * P1 优化：替代前端 `MatrixHttpClient.ts` 的 `stripMatrixPrefix + authedRequest` 两步调用，
     * 统一在 SDK 层处理所有已知前缀。调用方可直接传完整路径，无需关心 SDK 默认前缀。
     *
     * @param method - HTTP 方法
     * @param path - 完整路径（可能含 `/_matrix/client/v3` 等前缀）
     * @param queryParams - 查询参数
     * @param body - 请求体
     * @param opts - 透传至 IRequestOpts
     *
     * @example
     * // 两种调用方式等价:
     * await this.authedRequestWithPrefix('GET', '/_matrix/client/v3/rooms')
     * await this.authedRequestWithPrefix('GET', '/rooms')
     *
     * @example
     * // 跨命名空间调用（自动识别非默认前缀）:
     * await this.authedRequestWithPrefix('GET', '/_synapse/admin/v1/users')
     * await this.authedRequestWithPrefix('GET', '/_matrix/federation/v1/version')
     */
    authedRequestWithPrefix<T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, opts?: IRequestOpts): Promise<T>;
    protected normalizeError(error: unknown, method: string): SdkError;
    /**
     * 更新该 manager 的默认重试选项（浅合并到现有配置之上）。
     *
     * @param options - 要覆盖的重试选项（如 maxRetries、retryDelay、backoffMultiplier 等）
     *
     * @example
     * ```typescript
     * client.getAdminManager().setRetryOptions({ maxRetries: 5, retryDelay: 500 });
     * ```
     */
    setRetryOptions(options: RetryOptions): void;
    protected withRetry<T>(fn: () => Promise<T>, optionsOrLabel?: RetryOptions | string): Promise<T>;
    /**
     * 在「当前同步执行栈」上压入 `withRetry()` 的观测帧，调用闭包后立即出栈。
     *
     * 出栈发生在闭包返回 Promise 的那一刻（同步前奏结束），因此只有闭包在**同步阶段**
     * 发出的请求能拿到归属；闭包 `await` 之后才发的请求会在 `request()` 里看到空栈，
     * 从而走 `recordRetryObservation()` 的保守回退（写入全部在途帧）。
     */
    private invokeWithFrame;
    /**
     * 把一次请求观测回填到它在入口处快照到的「外层帧」。
     *
     * - `enclosingFrames` 非空：只写这些帧 —— 并发但互不嵌套的 `withRetry()` 各自独立，
     *   读请求的观测不会污染写请求的帧（此前写全部帧会让 GET 帧收到 POST 观测，
     *   进而被判为非幂等而放弃重试）。
     * - `enclosingFrames` 为空（请求在闭包 `await` 之后才发出，无法确定归属）：回退写入
     *   全部在途帧，保持历史行为 —— 宁可保守地禁止重放，也不要漏记一个写请求。
     */
    private recordRetryObservation;
    /**
     * 按「本次调用实际发出的请求」推断能否重放整个闭包（S-8）。
     *
     * 全为幂等方法 → 可重放；出现写方法时，只有**每个**写请求都带调用方在外面确定的
     * 幂等键才可重放（P3-1）：那种情况下重放会复用同一个 txnId，服务端按事务去重，
     * 与幂等读等价。没有观测到任何请求时保持历史行为（可重放），因为闭包可能根本没走
     * `request()`（例如 `client.sendEvent` 走 http 层，见 ISSUE-10b 的 txnId 复用）。
     */
    private inferIdempotentFromObserved;
    /**
     * 判断错误是否为服务端的**限流拒绝**（HTTP 429 或 `M_LIMIT_EXCEEDED`）。
     *
     * 归一化后的错误与原始错误都要查：`normalizeError()` 已把 429 转成
     * {@link RetryableError}，但 `withRetry()` 的闭包可能抛出尚未归一化的
     * {@link HTTPError}。
     */
    private static isRateLimitRejection;
    /**
     * 该错误是否值得重试。
     *
     * 以错误**自己的声明** `SdkError.isRetryable` 为准：
     * - `RetryableError`（限流、5xx、连接中断）→ true；
     * - `TimeoutError` → 网络层超时为 true，AbortController 主动取消为 false。
     *
     * 此前这里只判断 `instanceof RetryableError`，于是 `TimeoutError` 的
     * `isRetryable: true` 形同虚设 —— 幂等 GET 的超时**永不重试**（P3-1 的 G1）。
     * `HTTPError && status >= 500` 分支保留作为归一化之外的兜底。
     */
    private static isRetryableFailure;
    /**
     * 读取服务端要求的等待时间（`Retry-After` / `x-ratelimit-after` / `x-retry-after-ms`
     * 响应头，或响应体里的 `retry_after_ms`），没有则返回 `null`。
     *
     * 两个来源都要查：`RetryableError` 只从**响应体**的 `retry_after_ms` 取 `retryAfter`，
     * 归一化之后原始 `HTTPError` 就再也拿不到 `Retry-After` 响应头了 —— 这正是
     * "429 带 Retry-After 却被忽略"（P3-1 的 G2）的成因。
     */
    private static readRetryAfterMs;
    /**
     * 限流请求是否可以安全重试（S-8 的例外条款）。
     *
     * 429 / `M_LIMIT_EXCEEDED` 表示服务端在**执行前**拒绝了请求，没有副作用被提交，
     * 因此对非幂等方法重试也不会重复写入 —— 这与 5xx（可能已提交）有本质区别。
     *
     * 唯一的例外：`withRetry()` 的重试会重跑整个闭包。若闭包中**已有写请求成功返回**，
     * 重放会把那次成功写入再做一遍。此时返回 `false`，放弃重试。
     */
    private canRetryRateLimited;
    /**
     * 清理 manager 持有的资源（监听器、定时器等）。
     *
     * 默认 no-op。子类按需 override——在 `client.stop()` 时由
     * `stopClientLifecycleServices` 统一遍历调用。
     *
     * @example
     * ```typescript
     * client.getAdminManager().stop();
     * ```
     */
    stop(): void;
    /**
     * 获取该 manager 的请求统计快照（总数、成功、失败、重试次数）。
     *
     * @returns 请求统计的浅拷贝
     *
     * @example
     * ```typescript
     * const stats = client.getAdminManager().getRequestStats();
     * console.log(stats.total, stats.successful, stats.failed, stats.retried);
     * ```
     */
    getRequestStats(): RequestStats;
    /**
     * 将该 manager 的请求统计计数重置为 0。
     *
     * @example
     * ```typescript
     * client.getAdminManager().resetRequestStats();
     * ```
     */
    resetRequestStats(): void;
    /**
     * 计算单次重试延迟：基础退避 → 限流覆盖 → 抖动。
     *
     * 提取自 `request()` 与 `withRetry()` 的公共逻辑，确保两条重试路径在
     * 限流 `Retry-After` 覆盖与抖动（`jitterRatio`）行为上保持一致。
     */
    private computeRetryDelay;
    protected sleep(ms: number): Promise<void>;
    protected requireNonEmptyString(value: string | undefined | null, fieldName: string): asserts value is string;
    protected requirePositiveInteger(value: number | undefined | null, fieldName: string): void;
    protected requireNonNull<T>(value: T | undefined | null, fieldName: string): asserts value is T;
    protected requireNonEmptyArray(value: unknown[] | undefined | null, fieldName: string): asserts value is unknown[];
    protected requireMaxLength(value: string | undefined | null, maxLength: number, fieldName: string): void;
}
//# sourceMappingURL=base-manager.d.ts.map