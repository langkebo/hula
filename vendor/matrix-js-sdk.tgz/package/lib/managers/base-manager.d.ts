/**
 * Base Manager - 管理器基类
 *
 * 提供所有 Manager 类的通用功能：
 * - 统一的 HTTP 请求通道 (`request()`) 含可注入的 Transport seam
 * - 重试逻辑（幂等方法默认开启，非幂等方法需显式声明）
 * - 错误归一化（MatrixError/HTTPError → SdkError 子类）
 * - 请求统计
 * - 日志记录
 */
import { TypedEventEmitter } from "../models/typed-event-emitter";
import type { QueryDict } from "../http-api/utils";
import type { Body, IRequestOpts } from "../http-api/interface";
import { Method } from "../http-api/method";
import { SdkError } from "../errors";
import { MatrixClient } from "../client";
import type { MatrixClientInternalMethods } from "../matrix-client-extensions";
export interface RetryOptions {
    maxRetries?: number;
    retryDelay?: number;
    backoffMultiplier?: number;
    idempotent?: boolean;
    retryNonIdempotent?: boolean;
    label?: string;
    /** 抖动比例（0~1），用于避免重试风暴。0 = 无抖动。 */
    jitterRatio?: number;
}
export interface RequestStats {
    total: number;
    successful: number;
    failed: number;
    retried: number;
}
/**
 * `request()` 方法的参数对象。
 */
export interface RequestSpec {
    method: Method;
    path: string;
    prefix?: string;
    queryParams?: QueryDict;
    body?: unknown;
    retry?: RetryOptions;
    /** 用于日志和错误消息的标签，默认使用 `path` */
    label?: string;
    /**
     * 是否携带用户 access token。
     *
     * - `true`（默认）：走 `client.http.authedRequest`（经 transport）。
     * - `false`：走 `client.http.request`（不带 token），用于 federation
     *   查询等无需用户鉴权的端点。
     */
    authenticated?: boolean;
    /** 透传至 IRequestOpts.localTimeoutMs，用于长轮询请求（如 sliding sync） */
    localTimeoutMs?: number;
    /** 透传至 IRequestOpts.headers，用于自定义请求头（如媒体上传的 Content-Type） */
    headers?: Record<string, string>;
    /** 透传至 IRequestOpts.abortSignal，用于取消请求（如 sliding sync 重发） */
    abortSignal?: AbortSignal;
}
/**
 * Transport 请求选项：在 `IRequestOpts` 基础上扩展 `authenticated` 字段。
 *
 * `authenticated` 决定是否携带用户 access token：
 * - `true`（默认）：走 `client.http.authedRequest`（带 token）。
 * - `false`：走 `client.http.request`（不带 token），用于公共端点。
 */
export type TransportOpts = IRequestOpts & {
    authenticated?: boolean;
};
/**
 * HTTP 传输层接口。
 *
 * 生产环境默认适配 `client.http.authedRequest`，测试可注入 in-memory fake。
 *
 * `opts.authenticated`（默认 `true`）决定是否携带用户 access token。
 * 自定义 Transport 实现可忽略该字段；测试用的 FakeTransport 通常直接走单一通道。
 */
export interface Transport {
    request<T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, opts?: TransportOpts): Promise<T>;
}
/**
 * Manager 构造选项，向后兼容 `RetryOptions`。
 */
export interface ManagerOpts extends RetryOptions {
    transport?: Transport;
    /** 默认 API 前缀，不传时 fallback 为 `ClientPrefix.V3` */
    defaultPrefix?: string;
}
export declare abstract class BaseManager<Events extends string = string, EventMap extends Record<Events, any> = Record<Events, any>> extends TypedEventEmitter<Events, EventMap> {
    protected readonly client: MatrixClient;
    protected readonly transport: Transport;
    protected readonly defaultPrefix: string;
    protected retryOptions: RetryOptions;
    protected requestStats: RequestStats;
    /**
     * 当前处于 `withRetry()` 调用链中的深度（并发安全计数器）。
     *
     * Managers 通常是单例，多个并发 `withRetry()` 调用会共享同一实例。使用布尔标志
     * 会在某个调用先结束时被重置为 `false`，导致其它在途调用中的 `request()` 误判
     * 为「未处于 withRetry」从而自行重试并写入统计，造成双重计数与嵌套重试
     * （见 FT-115）。改为深度计数器后，只要仍有任一 `withRetry()` 在途，
     * `request()` 就保持单次调用模式，全部退出后才恢复独立重试+统计。
     *
     * - `> 0`：`request()` 被外层 `withRetry()` 包装，只做单次调用，不重试、不写统计
     *   （由 `withRetry()` 统一负责），避免双重计数与嵌套重试。
     * - `0`：`request()` 被直接调用，自行负责重试与统计。
     */
    private _withRetryDepth;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 将 `this.client` 类型断言为 `MatrixClient & MatrixClientInternalMethods`，
     * 使 Manager 可通过 `this.internalClient.xxx` 类型安全地访问 MatrixClient
     * 内部成员（syncApi、turnServers、serverClockDiff 等）。
     *
     * 这是整个 SDK 中唯一的 `as unknown as` 断言点（针对内部成员访问），
     * 替代了先前散落在各 Manager 中的 45 处类型断言。
     */
    protected get internalClient(): MatrixClient & MatrixClientInternalMethods;
    /**
     * 发送 HTTP 请求，自动合并重试配置、错误归一化和请求统计。
     *
     * 当被 `withRetry()` 包装时（`_withRetryDepth > 0`），本方法退化为单次调用，
     * 重试与统计交由外层 `withRetry()` 统一负责，避免双重计数与嵌套重试。
     *
     * @example
     * const res = await this.request<IUserResponse>({
     *     method: Method.Get,
     *     path: "/users",
     *     prefix: ClientPrefix.V1,
     * });
     */
    protected request<T>(spec: RequestSpec): Promise<T>;
    /**
     * @deprecated 请使用 `this.request({ method, path, prefix: AdminPrefix.V1 })` 替代。
     */
    protected adminRequest<T>(method: Method, path: string, queryParams?: Record<string, string | string[]>, body?: object, label?: string): Promise<T>;
    protected normalizeError(error: unknown, method: string): SdkError;
    setRetryOptions(options: RetryOptions): void;
    protected withRetry<T>(fn: () => Promise<T>, optionsOrLabel?: RetryOptions | string): Promise<T>;
    getRequestStats(): RequestStats;
    resetRequestStats(): void;
    /**
     * 计算单次重试延迟：基础退避 → 限流覆盖 → 抖动。
     *
     * 提取自 `request()` 与 `withRetry()` 的公共逻辑，确保两条重试路径在
     * 限流 `Retry-After` 覆盖与抖动（`jitterRatio`）行为上保持一致。
     */
    private computeRetryDelay;
    protected sleep(ms: number): Promise<void>;
    protected requireNonEmptyString(value: string | undefined | null, fieldName: string): asserts value is string;
    protected requirePositiveInteger(value: number | undefined | null, fieldName: string): void;
    protected requireNonNull<T>(value: T | undefined | null, fieldName: string): asserts value is T;
    protected requireNonEmptyArray(value: unknown[] | undefined | null, fieldName: string): asserts value is unknown[];
    protected requireMaxLength(value: string | undefined | null, maxLength: number, fieldName: string): void;
}
//# sourceMappingURL=base-manager.d.ts.map