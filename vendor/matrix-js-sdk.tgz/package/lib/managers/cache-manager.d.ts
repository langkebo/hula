import { CacheStats } from "../utils/lru-cache";
/**
 * 缓存策略配置
 *
 * 定义了不同场景下的缓存策略，统一管理所有 Manager 的缓存行为
 */
export interface CacheStrategy {
    /**
     * 缓存命名空间（用于隔离不同模块的缓存）
     */
    namespace: string;
    /**
     * 最大缓存条目数
     */
    maxSize: number;
    /**
     * TTL（毫秒），超过此时间的缓存将被视为过期
     */
    ttl: number;
    /**
     * 是否启用 stale-while-revalidate 模式
     * true = 返回旧数据同时后台刷新
     */
    staleWhileRevalidate?: boolean;
    /**
     * 是否允许缓存 null/undefined 值
     * true = 缓存空结果以避免重复请求
     */
    cacheEmpty?: boolean;
    /**
     * 缓存失效事件监听器
     */
    onInvalidate?: (keys: string[]) => void;
}
/**
 * 统一缓存管理器
 *
 * 提供标准化的缓存操作 API，支持：
 * - 按命名空间隔离
 * - 统一的 TTL 策略
 * - 批量无效化
 * - 统计信息聚合
 *
 * 使用示例：
 * ```typescript
 * const cacheManager = new UnifiedCacheManager({
 *     namespace: "space",
 *     maxSize: 100,
 *     ttl: 5 * 60 * 1000 // 5 minutes
 * });
 *
 * // 获取缓存
 * const spaceData = await cacheManager.getOrFetch(
 *     "space:hierarchy",
 *     () => fetchSpaceHierarchy()
 * );
 *
 * // 无效化缓存
 * cacheManager.invalidate(["space:*"]);
 * ```
 */
export declare class UnifiedCacheManager {
    private cache;
    private readonly config;
    private readonly registry;
    constructor(config: CacheStrategy);
    constructor(namespace: string, maxSize: number, ttl: number);
    /**
     * 获取缓存键的标准格式
     * 自动处理重复前缀
     */
    private normalizeKey;
    /**
     * 从缓存获取数据
     * @param key 缓存键
     * @returns 缓存的值，如果不存在或已过期则返回 undefined
     */
    get<T>(key: string): T | undefined;
    /**
     * 设置缓存
     * @param key 缓存键
     * @param value 缓存值
     */
    set<T>(key: string, value: T): void;
    /**
     * 检查缓存是否存在
     * @param key 缓存键
     * @returns 是否存在有效缓存
     */
    has(key: string): boolean;
    /**
     * 删除缓存
     * @param key 缓存键
     * @returns 是否成功删除
     */
    delete(key: string): boolean;
    /**
     * 获取或计算缓存值
     * @param key 缓存键
     * @param fetchFn 获取数据的函数
     * @returns 缓存数据或新获取的数据
     */
    getOrFetch<T>(key: string, fetchFn: () => Promise<T>): Promise<T>;
    /**
     * 批量无效化缓存（支持通配符）
     * @param patterns 缓存键模式，支持 "*" 通配符
     */
    invalidate(patterns: string[]): void;
    /**
     * 清空所有缓存
     */
    clear(): void;
    /**
     * 获取缓存统计信息
     */
    getStats(): CacheStats;
    /**
     * 获取缓存大小
     */
    getSize(): number;
    /**
     * 获取缓存快照
     */
    snapshot(): Map<string, any>;
}
/**
 * 缓存管理器工厂
 * 为不同类型的 Manager 提供预配置的缓存实例
 */
export declare class CacheManagerFactory {
    /**
     * 创建空间相关的缓存管理器
     */
    static createSpaceCache(): UnifiedCacheManager;
    /**
     * 创建房间相关的缓存管理器
     */
    static createRoomCache(): UnifiedCacheManager;
    /**
     * 创建用户相关的缓存管理器
     */
    static createUserCache(): UnifiedCacheManager;
    /**
     * 创建设备相关的缓存管理器
     */
    static createDeviceCache(): UnifiedCacheManager;
    /**
     * 创建 CAS 相关的缓存管理器
     */
    static createCasCache(): UnifiedCacheManager;
    /**
     * 创建 Worker 相关的缓存管理器
     */
    static createWorkerCache(): UnifiedCacheManager;
    /**
     * 创建通用缓存管理器
     */
    static createGenericCache(namespace: string, maxSize?: number, ttl?: number): UnifiedCacheManager;
}
/**
 * 全局缓存监控
 * 可以在开发环境中启用以监控缓存使用情况
 */
export declare class CacheMonitor {
    private static instance;
    private enabled;
    private statsLog;
    static getInstance(): CacheMonitor;
    enable(): void;
    disable(): void;
    /**
     * 记录缓存统计快照
     */
    snapshot(): void;
    /**
     * 获取所有缓存的聚合统计
     */
    getAggregatedStats(): import("../utils/lru-cache").AggregatedCacheStats;
    /**
     * 导出缓存统计报告
     */
    exportReport(): string;
}
export { LRUCache, CacheRegistry } from "../utils/lru-cache";
export type { CacheConfig, CacheStats } from "../utils/lru-cache";
//# sourceMappingURL=cache-manager.d.ts.map