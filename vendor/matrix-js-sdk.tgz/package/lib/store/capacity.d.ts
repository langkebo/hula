/**
 * 统一容量管理 —— 对齐后端 synapse-rust `synapse-cache` 的 `max_capacity`
 * 与按类型分区容量（`synapse-cache/src/query_cache.rs`）。
 *
 * 将 store 原先分散的局部上限（OOB 成员 50、pending 100）泛化为一份整体的
 * 容量预算，并用通用的 {@link LruMap} 做 LRU 淘汰，淘汰事件可回传统计层。
 */
/**
 * store 整体容量预算。各字段含义与默认值：
 *
 * - `maxRooms` / `maxUsers`：对齐后端 `max_capacity: 100_000` 的兜底上限，
 *   防止异常场景下 room / user 无限增长。
 * - `maxOutOfBandMembersRooms`：OOB 成员缓存 room 数上限（沿用原局部 LRU 的 50）。
 * - `maxPendingEventsPerRoom`：单 room pending 事件数上限（沿用原 100）。
 */
export interface StoreCapacityConfig {
    /** room 总数上限。 */
    maxRooms: number;
    /** user 总数上限。 */
    maxUsers: number;
    /** OOB 成员缓存 room 数上限。 */
    maxOutOfBandMembersRooms: number;
    /** 单 room pending 事件数上限。 */
    maxPendingEventsPerRoom: number;
}
/**
 * 默认容量预算。
 */
export declare const DEFAULT_STORE_CAPACITY: StoreCapacityConfig;
/**
 * 泛化的有界 LRU Map。
 *
 * 在 `Map` 插入顺序的基础上实现容量预算 + LRU 淘汰：容量耗尽时淘汰最久未访问
 * 的条目（`Map` 首元素），并通过 `onEvict` 回调上报淘汰事件。它是原先 store 内
 * 手写的「`Map` 首键删除」LRU 逻辑的通用化，供 OOB 成员等集合复用。
 */
export declare class LruMap<K, V> {
    private readonly map;
    private readonly capacity;
    private readonly onEvict?;
    /**
     * @param capacity - 容量上限。
     * @param onEvict - 可选淘汰回调，在条目因容量不足被淘汰时触发。
     */
    constructor(capacity: number, onEvict?: (key: K, value: V) => void);
    /** 当前条目数。 */
    get size(): number;
    /**
     * 读取并「触摸」条目（移到 LRU 末尾）。
     * @returns 值，不存在时为 `undefined`。
     */
    get(key: K): V | undefined;
    /**
     * 写入条目。容量耗尽时先淘汰最久未访问的条目。
     * @returns 自身，便于链式调用。
     */
    set(key: K, value: V): this;
    /** 是否存在指定键。 */
    has(key: K): boolean;
    /** 删除指定键，返回是否删除成功。 */
    delete(key: K): boolean;
    /** 键迭代器（插入顺序）。 */
    keys(): IterableIterator<K>;
    /** 值迭代器（插入顺序）。 */
    values(): IterableIterator<V>;
    /** 清空。 */
    clear(): void;
}
//# sourceMappingURL=capacity.d.ts.map