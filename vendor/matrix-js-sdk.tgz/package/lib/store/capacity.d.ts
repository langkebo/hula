/**
 * store 整体容量预算。各字段含义与默认值：
 *
 * - `maxRooms` / `maxUsers`：对齐后端 `max_capacity: 100_000` 的兜底上限，
 *   防止异常场景下 room / user 无限增长。
 * - `maxOutOfBandMembersRooms`：OOB 成员缓存 room 数上限（沿用原局部 LRU 的 50）。
 * - `maxPendingEventsPerRoom`：单 room pending 事件数上限（沿用原 100）。
 */
export interface StoreCapacityConfig {
    /** room 总数上限。 */
    maxRooms: number;
    /** user 总数上限。 */
    maxUsers: number;
    /** OOB 成员缓存 room 数上限。 */
    maxOutOfBandMembersRooms: number;
    /** 单 room pending 事件数上限。 */
    maxPendingEventsPerRoom: number;
}
/**
 * 默认容量预算。
 */
export declare const DEFAULT_STORE_CAPACITY: StoreCapacityConfig;
/**
 * 泛化的有界 LRU Map，支持可选的分级 TTL。
 *
 * 在 `Map` 插入顺序的基础上实现容量预算 + LRU 淘汰：容量耗尽时淘汰最久未访问
 * 的条目（`Map` 首元素），并通过 `onEvict` 回调上报淘汰事件。当传入 `ttlSeconds`
 * 时，读取命中会先判活（对齐后端 `CacheEntry::is_expired`），过期条目懒清理并同样
 * 上报淘汰。它是原先 store 内手写的「`Map` 首键删除」LRU 逻辑的通用化，供 OOB 成员、
 * room、user 等集合复用。
 *
 * 淘汰事件分两类，均计入统计层的 `evictions`（对齐后端：容量淘汰与过期清理都
 * `record_evictions`）。`delete`/`clear` 属于手动删除，不触发 `onEvict`。
 */
export declare class LruMap<K, V> {
    private readonly map;
    private readonly capacity;
    private readonly ttlSeconds;
    private readonly onEvict?;
    /**
     * @param capacity - 容量上限。
     * @param onEvict - 可选淘汰回调，在条目因容量不足或 TTL 过期被淘汰时触发。
     * @param ttlSeconds - 默认 TTL（秒）；等于 {@link TTL_PERSISTENT}（默认）时永不因时间过期。
     *                     单个条目的 `set` 可通过第三个参数覆盖此默认值（用于 per-key 动态 TTL）。
     */
    constructor(capacity: number, onEvict?: (key: K, value: V) => void, ttlSeconds?: number);
    /** 当前条目数。 */
    get size(): number;
    /**
     * 读取并「触摸」条目（移到 LRU 末尾）。命中但已过期的条目会被惰性淘汰。
     * @returns 值，不存在或已过期时为 `undefined`。
     */
    get(key: K): V | undefined;
    /**
     * 写入条目。容量耗尽时先淘汰最久未访问的条目。
     * @param ttlSeconds - 可选 per-entry TTL（秒），覆盖构造时的默认 TTL。
     * @returns 自身，便于链式调用。
     */
    set(key: K, value: V, ttlSeconds?: number): this;
    /** 是否存在指定键。 */
    has(key: K): boolean;
    /** 删除指定键，返回是否删除成功。 */
    delete(key: K): boolean;
    /** 键迭代器（插入顺序）。 */
    keys(): IterableIterator<K>;
    /** 值迭代器（插入顺序）。 */
    values(): IterableIterator<V>;
    /** 清空。 */
    clear(): void;
}
//# sourceMappingURL=capacity.d.ts.map