/**
 * This is an internal module. See {@link MemoryStore} for the public class.
 */
import { type EventType } from "../@types/event";
import { type Room } from "../models/room";
import { type User } from "../models/user";
import { type IEvent, type MatrixEvent } from "../models/event";
import { type Filter } from "../filter";
import { type ISavedSync, type IStore, type UserCreator } from "./index";
import { type RoomSummary } from "../models/room-summary";
import { type ISyncResponse } from "../sync-accumulator";
import { type IStateEventWithRoomId } from "../@types/search";
import { type IndexedToDeviceBatch, type ToDeviceBatchWithTxnId } from "../models/ToDeviceMessage";
import { type IStoredClientOpts } from "../client";
import { StoreStatsCollector, type StoreStats } from "./stats";
import { type StoreCapacityConfig } from "./capacity";
import { type OobMembersTtlProvider } from "./ttl";
import { PendingEventsCipher } from "./pending-events-cipher";
export interface IOpts {
    /** The local storage instance to persist some forms of data such as tokens. Rooms will NOT be stored. */
    localStorage?: Storage;
    /**
     * 可选容量预算覆盖项。未提供的字段回落到 {@link DEFAULT_STORE_CAPACITY}。
     */
    capacity?: Partial<StoreCapacityConfig>;
    /**
     * 可选 OOB 成员 TTL 解析器：按 roomId 动态返回 TTL（秒）。
     * 未提供时回落到 {@link defaultOobMembersTtl}（统一 room_members 900s）。
     * 返回 `TTL_PERSISTENT` 持久、`0` 禁用缓存、正数为 TTL 秒。
     */
    oobMembersTtl?: OobMembersTtlProvider;
    /**
     * 可选待发事件加密器（ISSUE-08c）。仅 `IndexedDBStore` 落盘路径使用：
     * 提供时待发事件加密后持久化；未提供时 `IndexedDBStore` 不再明文落盘
     * （退化为仅内存，重启后待发事件不恢复）。
     */
    pendingEventsCipher?: PendingEventsCipher;
}
export declare class MemoryStore implements IStore {
    private rooms;
    private users;
    private syncToken;
    private filters;
    accountData: Map<string, MatrixEvent>;
    protected readonly localStorage?: Storage;
    private oobMembers;
    private pendingEvents;
    private clientOptions?;
    private pendingToDeviceBatches;
    private nextToDeviceBatchId;
    protected createUser?: UserCreator;
    /** 整体容量预算（对齐后端 max_capacity + 分区容量）。 */
    private readonly capacity;
    /** OOB 成员 TTL 解析器（按 roomId 动态）。protected 供 IndexedDBStore 复用。 */
    protected readonly oobMembersTtl: OobMembersTtlProvider;
    /** 待发事件加密器（可选）。protected 供 IndexedDBStore 落盘路径使用。 */
    protected readonly pendingEventsCipher?: PendingEventsCipher;
    /** 无锁统计收集器（对齐后端 AtomicCacheStats）。protected 供子类埋点。 */
    protected readonly stats: StoreStatsCollector;
    /**
     * Construct a new in-memory data store for the Matrix Client.
     * @param opts - Config options
     */
    constructor(opts?: IOpts);
    /**
     * Retrieve the token to stream from.
     * @returns The token or null.
     */
    getSyncToken(): string | null;
    /** @returns whether or not the database was newly created in this session. */
    isNewlyCreated(): Promise<boolean>;
    /**
     * Set the token to stream from.
     * @param token - The token to stream from.
     */
    setSyncToken(token: string): void;
    /**
     * Store the given room.
     * @param room - The room to be stored. All properties must be stored.
     */
    storeRoom(room: Room): void;
    setUserCreator(creator: UserCreator): void;
    /**
     * Called when a room member in a room being tracked by this store has been
     * updated.
     */
    private onRoomMember;
    /**
     * Retrieve a room by its' room ID.
     * @param roomId - The room ID.
     * @returns The room or null.
     */
    getRoom(roomId: string): Room | null;
    /**
     * Retrieve all known rooms.
     * @returns A list of rooms, which may be empty.
     */
    getRooms(): Room[];
    /**
     * Permanently delete a room.
     */
    removeRoom(roomId: string): void;
    /**
     * Retrieve a summary of all the rooms.
     * @returns A summary of each room.
     */
    getRoomSummaries(): RoomSummary[];
    /**
     * Store a User.
     * @param user - The user to store.
     */
    storeUser(user: User): void;
    /**
     * Retrieve a User by its' user ID.
     * @param userId - The user ID.
     * @returns The user or null.
     */
    getUser(userId: string): User | null;
    /**
     * Retrieve all known users.
     * @returns A list of users, which may be empty.
     */
    getUsers(): User[];
    /**
     * Retrieve scrollback for this room.
     * @param _room - The matrix room
     * @param _limit - The max number of old events to retrieve.
     * @returns An array of objects which will be at most 'limit'
     * length and at least 0. The objects are the raw event JSON.
     */
    scrollback(_room: Room, _limit: number): MatrixEvent[];
    /**
     * Store events for a room. The events have already been added to the timeline
     * @param _room - The room to store events for.
     * @param _events - The events to store.
     * @param _token - The token associated with these events.
     * @param _toStart - True if these are paginated results.
     */
    storeEvents(_room: Room, _events: MatrixEvent[], _token: string | null, _toStart: boolean): void;
    /**
     * Store a filter.
     */
    storeFilter(filter: Filter): void;
    /**
     * Retrieve a filter.
     * @returns A filter or null.
     */
    getFilter(userId: string, filterId: string): Filter | null;
    /**
     * Retrieve a filter ID with the given name.
     * @param filterName - The filter name.
     * @returns The filter ID or null.
     */
    getFilterIdByName(filterName: string): string | null;
    /**
     * Set a filter name to ID mapping.
     */
    setFilterIdByName(filterName: string, filterId?: string): void;
    /**
     * Store user-scoped account data events.
     * N.B. that account data only allows a single event per type, so multiple
     * events with the same type will replace each other.
     * @param events - The events to store.
     */
    storeAccountDataEvents(events: MatrixEvent[]): void;
    /**
     * Get account data event by event type
     * @param eventType - The event type being queried
     * @returns the user account_data event of given type, if any
     */
    getAccountData(eventType: EventType | string): MatrixEvent | undefined;
    /**
     * setSyncData does nothing as there is no backing data store.
     *
     * @param _syncData - The sync data
     * @returns An immediately resolved promise.
     */
    setSyncData(_syncData: ISyncResponse): Promise<void>;
    /**
     * We never want to save becase we have nothing to save to.
     *
     * @returns If the store wants to save
     */
    wantsSave(): boolean;
    /**
     * Save does nothing as there is no backing data store.
     * @param _force - True to force a save (but the memory
     *     store still can't save anything)
     */
    save(_force: boolean): Promise<void>;
    /**
     * Startup does nothing as this store doesn't require starting up.
     * @returns An immediately resolved promise.
     */
    startup(): Promise<void>;
    /**
     * @returns Promise which resolves with a sync response to restore the
     * client state to where it was at the last save, or null if there
     * is no saved sync data.
     */
    getSavedSync(): Promise<ISavedSync | null>;
    /**
     * @returns If there is a saved sync, the nextBatch token
     * for this sync, otherwise null.
     */
    getSavedSyncToken(): Promise<string | null>;
    /**
     * Delete all data from this store.
     * @returns An immediately resolved promise.
     */
    deleteAllData(): Promise<void>;
    /**
     * Returns the out-of-band membership events for this room that
     * were previously loaded.
     * @returns the events, potentially an empty array if OOB loading didn't yield any new members
     * @returns in case the members for this room haven't been stored yet
     */
    getOutOfBandMembers(roomId: string): Promise<IStateEventWithRoomId[] | null>;
    /**
     * Stores the out-of-band membership events for this room. Note that
     * it still makes sense to store an empty array as the OOB status for the room is
     * marked as fetched, and getOutOfBandMembers will return an empty array instead of null
     * @param membershipEvents - the membership events to store
     * @returns when all members have been stored
     */
    setOutOfBandMembers(roomId: string, membershipEvents: IStateEventWithRoomId[]): Promise<void>;
    clearOutOfBandMembers(roomId: string): Promise<void>;
    getClientOptions(): Promise<IStoredClientOpts | undefined>;
    storeClientOptions(options: IStoredClientOpts): Promise<void>;
    getPendingEvents(roomId: string): Promise<Partial<IEvent>[]>;
    setPendingEvents(roomId: string, events: Partial<IEvent>[]): Promise<void>;
    saveToDeviceBatches(batches: ToDeviceBatchWithTxnId[]): Promise<void>;
    getOldestToDeviceBatch(): Promise<IndexedToDeviceBatch | null>;
    removeToDeviceBatch(id: number): Promise<void>;
    /**
     * 返回 store 缓存统计快照，对齐后端 `CacheStats`。
     *
     * `totalEntries` 与 `memoryUsageBytes` 在此实时重算（而非每次写路径维护），
     * 保证与集合当前实际状态一致；`hits/misses/evictions` 来自无锁计数。
     */
    getStats(): StoreStats;
    /**
     * 估算内存占用字节。仅 advisory，用于对齐后端 `memory_usage_bytes` 指标，
     * 不参与淘汰决策（见文件顶部估算常量说明）。
     */
    private estimateMemoryUsageBytes;
    destroy(): Promise<void>;
}
//# sourceMappingURL=memory.d.ts.map