/**
 * This is an internal module.
 */
import { type EventType } from "../@types/event";
import { type Room } from "../models/room";
import { type User } from "../models/user";
import { type IEvent, type MatrixEvent } from "../models/event";
import { type Filter } from "../filter";
import { type ISavedSync, type IStore, type UserCreator } from "./index";
import { type RoomSummary } from "../models/room-summary";
import { type ISyncResponse } from "../sync-accumulator";
import { type IStateEventWithRoomId } from "../@types/search";
import { type IndexedToDeviceBatch, type ToDeviceBatch } from "../models/ToDeviceMessage";
import { type IStoredClientOpts } from "../client";
import { type StoreStats } from "./stats";
/**
 * Construct a stub store. This does no-ops on most store methods.
 */
export declare class StubStore implements IStore {
    readonly accountData: Map<any, any>;
    private fromToken;
    /** @returns whether or not the database was newly created in this session. */
    isNewlyCreated(): Promise<boolean>;
    /**
     * Get the sync token.
     */
    getSyncToken(): string | null;
    /**
     * Set the sync token.
     */
    setSyncToken(token: string): void;
    /**
     * No-op.
     */
    storeRoom(_room: Room): void;
    /**
     * No-op.
     */
    getRoom(_roomId: string): Room | null;
    /**
     * No-op.
     * @returns An empty array.
     */
    getRooms(): Room[];
    /**
     * Permanently delete a room.
     */
    removeRoom(_roomId: string): void;
    /**
     * No-op.
     * @returns An empty array.
     */
    getRoomSummaries(): RoomSummary[];
    /**
     * No-op.
     */
    storeUser(_user: User): void;
    /**
     * No-op.
     */
    getUser(_userId: string): User | null;
    /**
     * No-op.
     */
    getUsers(): User[];
    /**
     * No-op.
     */
    scrollback(_room: Room, _limit: number): MatrixEvent[];
    /**
     * No-op.
     */
    setUserCreator(_creator: UserCreator): void;
    /**
     * Store events for a room.
     * @param room - The room to store events for.
     * @param events - The events to store.
     * @param token - The token associated with these events.
     * @param toStart - True if these are paginated results.
     */
    storeEvents(_room: Room, _events: MatrixEvent[], _token: string | null, _toStart: boolean): void;
    /**
     * Store a filter.
     */
    storeFilter(_filter: Filter): void;
    /**
     * Retrieve a filter.
     * @returns A filter or null.
     */
    getFilter(_userId: string, _filterId: string): Filter | null;
    /**
     * Retrieve a filter ID with the given name.
     * @param filterName - The filter name.
     * @returns The filter ID or null.
     */
    getFilterIdByName(_filterName: string): string | null;
    /**
     * Set a filter name to ID mapping.
     */
    setFilterIdByName(_filterName: string, _filterId?: string): void;
    /**
     * Store user-scoped account data events
     * @param events - The events to store.
     */
    storeAccountDataEvents(_events: MatrixEvent[]): void;
    /**
     * Get account data event by event type
     * @param eventType - The event type being queried
     */
    getAccountData(_eventType: EventType | string): MatrixEvent | undefined;
    /**
     * setSyncData does nothing as there is no backing data store.
     *
     * @param syncData - The sync data
     * @returns An immediately resolved promise.
     */
    setSyncData(_syncData: ISyncResponse): Promise<void>;
    /**
     * We never want to save because we have nothing to save to.
     *
     * @returns If the store wants to save
     */
    wantsSave(): boolean;
    /**
     * Save does nothing as there is no backing data store.
     */
    save(): Promise<void>;
    /**
     * Startup does nothing.
     * @returns An immediately resolved promise.
     */
    startup(): Promise<void>;
    /**
     * @returns Promise which resolves with a sync response to restore the
     * client state to where it was at the last save, or null if there
     * is no saved sync data.
     */
    getSavedSync(): Promise<ISavedSync | null>;
    /**
     * @returns If there is a saved sync, the nextBatch token
     * for this sync, otherwise null.
     */
    getSavedSyncToken(): Promise<string | null>;
    /**
     * Delete all data from this store. Does nothing since this store
     * doesn't store anything.
     * @returns An immediately resolved promise.
     */
    deleteAllData(): Promise<void>;
    getOutOfBandMembers(): Promise<IStateEventWithRoomId[] | null>;
    setOutOfBandMembers(_roomId: string, _membershipEvents: IStateEventWithRoomId[]): Promise<void>;
    clearOutOfBandMembers(): Promise<void>;
    getClientOptions(): Promise<IStoredClientOpts | undefined>;
    storeClientOptions(_options: IStoredClientOpts): Promise<void>;
    getPendingEvents(_roomId: string): Promise<Partial<IEvent>[]>;
    setPendingEvents(_roomId: string, _events: Partial<IEvent>[]): Promise<void>;
    saveToDeviceBatches(_batch: ToDeviceBatch[]): Promise<void>;
    getOldestToDeviceBatch(): Promise<IndexedToDeviceBatch | null>;
    removeToDeviceBatch(_id: number): Promise<void>;
    destroy(): Promise<void>;
    /**
     * StubStore 不缓存任何数据，返回零值统计快照。
     */
    getStats(): StoreStats;
}
//# sourceMappingURL=stub.d.ts.map