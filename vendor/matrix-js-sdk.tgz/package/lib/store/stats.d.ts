/**
 * store 缓存统计 —— 对齐后端 synapse-rust `synapse-cache` 的 `CacheStats`
 * （`synapse-cache/src/query_cache.rs`）。
 *
 * 后端指标：`hits / misses / evictions / total_entries / memory_usage_bytes / hit_rate`。
 * 前端 store 在 get/set/delete 路径埋点，形成与后端对等的缓存观测。
 */
/**
 * store 缓存统计快照，字段对齐后端 `CacheStats`。
 */
export interface StoreStats {
    /** 命中次数。 */
    hits: number;
    /** 未命中次数。 */
    misses: number;
    /** 淘汰条目数（含容量淘汰与过期清理）。 */
    evictions: number;
    /** 当前条目总数。 */
    totalEntries: number;
    /** 内存占用字节（估算值，见实现说明）。 */
    memoryUsageBytes: number;
    /** 命中率（0~1），对齐后端 `hit_rate`。 */
    hitRate: number;
}
/**
 * 无锁统计收集器 —— 对齐后端 `AtomicCacheStats`。
 *
 * 后端用 `AtomicU64`（`Ordering::Relaxed`）替代 `RwLock<CacheStats>`，避免读路径
 * 加锁。JavaScript 单线程事件循环下，普通数值自增天然无锁，无需 `Atomics`，
 * 故此处采用与后端等价的「纯计数 + 无锁」设计，读写均不加锁。
 */
export declare class StoreStatsCollector {
    private hits;
    private misses;
    private evictions;
    private totalEntries;
    private memoryUsageBytes;
    /** 记录一次命中。 */
    recordHit(): void;
    /** 记录一次未命中。 */
    recordMiss(): void;
    /** 记录 `count` 次淘汰。 */
    recordEvictions(count: number): void;
    /** 设置当前条目总数。 */
    setTotalEntries(total: number): void;
    /** 设置内存占用字节（估算值）。 */
    setMemoryUsageBytes(bytes: number): void;
    /** 生成当前统计快照。 */
    snapshot(): StoreStats;
    /** 重置所有计数。 */
    reset(): void;
}
//# sourceMappingURL=stats.d.ts.map