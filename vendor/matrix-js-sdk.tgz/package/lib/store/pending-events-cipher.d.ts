import type { IEvent } from "../models/event";
/**
 * ISSUE-08c: 待发事件队列落盘前 AES-GCM 加密。
 * 无 key 时拒绝持久化（仅内存），防止明文待发消息泄露。
 */
export declare class PendingEventsCipher {
    private readonly key;
    constructor(key: CryptoKey | null);
    /**
     * 从 32 字节 storageKey 直接派生 AES-GCM CryptoKey（推荐路径）。
     * storageKey 与 crypto store 的 `storageKey` 同一来源（系统 keychain），
     * 保证待发事件队列与密钥库用同一份密钥材料。
     */
    static fromStorageKey(storageKey: Uint8Array): Promise<PendingEventsCipher>;
    /**
     * 从口令派生 AES-GCM CryptoKey（备选路径，慢）。
     * salt 由调用方提供（应与 crypto store 的派生盐一致以保证跨会话可复现）。
     */
    static fromPassword(password: string, salt: Uint8Array, iterations: number): Promise<PendingEventsCipher>;
    encryptEvents(events: Partial<IEvent>[]): Promise<Uint8Array>;
    decryptEvents(blob: Uint8Array): Promise<Partial<IEvent>[]>;
}
//# sourceMappingURL=pending-events-cipher.d.ts.map