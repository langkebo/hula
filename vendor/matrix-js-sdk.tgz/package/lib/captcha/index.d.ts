/**
 * Captcha Manager - 验证码管理
 *
 * 提供验证码发送、验证、状态查询以及管理清理功能
 * 对应后端: /_matrix/client/{r0,v3}/register/captcha/* 与 /_synapse/admin/v1/captcha/cleanup
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export type CaptchaApiVersion = "v3";
export interface CaptchaSendResponse {
    captcha_id: string;
    expires_in: number;
    captcha_type: string;
}
export interface CaptchaVerifyResponse {
    verified: boolean;
}
export interface CaptchaStatusResponse {
    captcha_id: string;
    captcha_type: string;
    target: string;
    status: string;
    attempt_count: number;
    max_attempts: number;
    expires_at: number;
    created_at: number;
}
export interface CaptchaCleanupResponse {
    cleaned_count: number;
    message: string;
}
export interface CaptchaManagerEvents {
    captchaSent: {
        captchaId: string;
        captchaType: string;
        expires_in: number;
    };
    captchaVerified: {
        captchaId: string;
    };
    captchaExpired: {
        captchaId: string;
    };
}
interface CaptchaManagerEventMap {
    captchaSent: (data: CaptchaManagerEvents["captchaSent"]) => void;
    captchaVerified: (data: CaptchaManagerEvents["captchaVerified"]) => void;
    captchaExpired: (data: CaptchaManagerEvents["captchaExpired"]) => void;
}
export declare class CaptchaManager extends BaseManager<keyof CaptchaManagerEvents, CaptchaManagerEventMap> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    sendCaptcha(captchaType: string, target: string, templateName?: string, version?: CaptchaApiVersion): Promise<CaptchaSendResponse>;
    verifyCaptcha(captchaId: string, code: string, version?: CaptchaApiVersion): Promise<CaptchaVerifyResponse>;
    getCaptchaStatus(captchaId: string, version?: CaptchaApiVersion): Promise<CaptchaStatusResponse>;
    cleanupExpiredCaptchas(): Promise<CaptchaCleanupResponse>;
    /**
     * Delete expired captchas via the client-side DELETE route.
     * DELETE /_matrix/client/v3/register/captcha/clean
     *
     * Unlike `cleanupExpiredCaptchas()` which uses the admin POST route,
     * this method uses the client-facing DELETE endpoint.
     */
    deleteExpiredCaptchas(): Promise<CaptchaCleanupResponse>;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map