/** Routes served by the synapse-rust `captcha` module (mirrored from the backend contract). */
export declare const CAPTCHA_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/register/captcha/send";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/register/captcha/status";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/register/captcha/verify";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/captcha/cleanup";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/register/captcha/clean";
}];
/** Union of every (method, path) tuple in `CAPTCHA_ROUTES`. */
export type CaptchaRoute = (typeof CAPTCHA_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type CaptchaMethod = CaptchaRoute["method"];
/** Path templates referenced by this module. */
export type CaptchaPath = CaptchaRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type CaptchaReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${CaptchaReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type CaptchaPathPattern = CaptchaReplaceBraces<CaptchaPath>;
//# sourceMappingURL=route-table.d.ts.map