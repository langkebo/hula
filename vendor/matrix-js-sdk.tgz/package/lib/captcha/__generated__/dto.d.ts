/**
 * DTO snippets extracted from the contract doc for `captcha`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface CaptchaRequestDto {
    session: string;
}
export interface CaptchaResponseDto {
    captcha_url: string;
}
export interface CaptchaAdminResponseDto {
    cleaned: number;
}
//# sourceMappingURL=dto.d.ts.map