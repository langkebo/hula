/**
 * DTO snippets extracted from the contract doc for `captcha`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type CaptchaContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map