export declare const CAPTCHA_ROUTES_ENTRY_COUNT: 8;
export declare const CAPTCHA_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "发送、查询或验证成功";
}, {
    readonly status: 400;
    readonly note: "参数缺失或验证码格式不合法";
}, {
    readonly status: 401;
    readonly note: "管理清理接口缺少管理员身份";
}, {
    readonly status: 404;
    readonly note: "指定 captcha_id 不存在";
}, {
    readonly status: 429;
    readonly note: "验证码请求或校验触发限流";
}];
export type CaptchaStatusScenario = (typeof CAPTCHA_ROUTES_STATUS_SCENARIOS)[number];
export declare const CAPTCHA_ROUTES_ERROR_SCENARIOS: readonly [];
export type CaptchaErrorScenario = (typeof CAPTCHA_ROUTES_ERROR_SCENARIOS)[number];
export declare const CAPTCHA_ROUTES_ERRCODES: readonly [];
export type CaptchaErrcode = (typeof CAPTCHA_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map