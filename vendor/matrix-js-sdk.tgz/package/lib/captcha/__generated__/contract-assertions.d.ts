export declare const CAPTCHA_ROUTES_ENTRY_COUNT: 4;
export declare const CAPTCHA_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "session、验证码响应或请求体格式非法";
}, {
    readonly status: 403;
    readonly note: "管理清理接口权限不足，或验证码校验失败";
}, {
    readonly status: 404;
    readonly note: "指定验证码会话不存在或已过期";
}, {
    readonly status: 429;
    readonly note: "验证码发送或校验频率过高";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type CaptchaStatusScenario = (typeof CAPTCHA_ROUTES_STATUS_SCENARIOS)[number];
export declare const CAPTCHA_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "验证码参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 session、response 或请求体后重试";
}, {
    readonly scenario: "校验失败或管理权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户重试验证码，管理员接口则检查权限";
}, {
    readonly scenario: "验证码会话不存在或已过期";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "重新申请新的验证码会话";
}, {
    readonly scenario: "频率限制触发";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "延迟后重试";
}];
export type CaptchaErrorScenario = (typeof CAPTCHA_ROUTES_ERROR_SCENARIOS)[number];
export declare const CAPTCHA_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "验证码请求体结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "session 或验证码响应字段非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "验证码校验失败或管理权限不足";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "验证码会话不存在、已过期或已被清理";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "验证码发送或校验请求过于频繁";
}];
export type CaptchaErrcode = (typeof CAPTCHA_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map