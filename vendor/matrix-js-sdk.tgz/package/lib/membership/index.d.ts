import { MatrixClient } from "../client";
import { Room } from "../models/room";
import { RoomMember } from "../models/room-member";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface MembershipManagerEvents {
    membership_changed: {
        roomId: string;
        userId: string;
        membership: string;
    };
    member_joined: {
        roomId: string;
        userId: string;
    };
    member_left: {
        roomId: string;
        userId: string;
    };
}
export declare class MembershipManager extends BaseManager<keyof MembershipManagerEvents, MembershipManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getRoomMembers(roomId: string): RoomMember[];
    getInvitedRooms(): Room[];
    getJoinedRooms(): Promise<Room[]>;
    getLeftRooms(): Room[];
    isRoomJoined(roomId: string): boolean;
    isRoomInvited(roomId: string): boolean;
    isRoomLeft(roomId: string): boolean;
    getMember(roomId: string, userId: string): RoomMember | null;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map