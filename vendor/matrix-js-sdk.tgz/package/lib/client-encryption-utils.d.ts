/**
 * Encryption Utils - 加密相关工具函数
 *
 * 从 client.ts 提取的加密相关私有方法
 */
import type { MatrixClient } from "./client";
import type { Room } from "./models/room";
import type { MatrixEvent } from "./models/event";
import { EventType } from "./@types/event";
import { EventStatus } from "./models/event-status";
export interface EncryptionUtils {
    encryptEventIfNeeded(event: MatrixEvent, room?: Room): Promise<void>;
    encryptStateEventIfNeeded(event: MatrixEvent, room?: Room): Promise<void>;
    shouldEncryptEventForRoom(event: MatrixEvent, room: Room): Promise<boolean>;
    getEncryptedIfNeededEventType(roomId: string, eventType?: EventType | string | null): EventType | string | null | undefined;
    updatePendingEventStatus(room: Room | null, event: MatrixEvent, newStatus: EventStatus): void;
}
export declare function createEncryptionUtils(client: MatrixClient): EncryptionUtils;
//# sourceMappingURL=client-encryption-utils.d.ts.map