import { MatrixError } from "./http-api/index";
import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { InviteOpts } from "./@types/requests";
import type { Membership } from "./@types/membership";
import type { EmptyObject } from "./@types/common";
import type { Room } from "./models/room";
import type { QueryDict } from "./utils";
export declare function normalizeInviteOptions(opts: InviteOpts | string): InviteOpts;
export declare function createMissingIdentityServerError(): MatrixError;
export declare function buildInviteByThreePidParams(identityServerUrl: string, medium: string, address: string, identityAccessToken?: string): Record<string, string>;
export declare function buildRoomInvitePath(roomId: string): string;
export declare function buildMembershipChangePath(roomId: string, membership: Membership): string;
export declare function buildRoomForgetPath(roomId: string): string;
export declare function buildRoomUnbanPath(roomId: string): string;
export declare function buildRoomKickPath(roomId: string): string;
export declare function buildMembershipChangeBody(userId: string | undefined, reason?: string): {
    user_id: string | undefined;
    reason?: string;
};
export declare function buildSingleUserBody(userId: string, reason?: string): {
    user_id: string;
    reason?: string;
};
export declare function selectLeaveRoomChainTargets(upgradeHistory: Room[], roomId: string, includeFuture: boolean): Room[];
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export interface InviteRequestContext {
    roomId: string;
    userId: string;
    opts?: InviteOpts | string;
    shareRoomHistoryWithUser?: (roomId: string, userId: string) => Promise<void>;
    membershipChange: (roomId: string, userId: string | undefined, membership: Membership, reason?: string) => Promise<EmptyObject>;
}
export declare function inviteToRoomRequest({ roomId, userId, opts, shareRoomHistoryWithUser, membershipChange, }: InviteRequestContext): Promise<EmptyObject>;
export interface InviteByThreePidRequestContext {
    roomId: string;
    medium: string;
    address: string;
    getIdentityServerUrl: (stripProto?: boolean) => string | undefined;
    getIdentityAccessToken?: () => Promise<string | null | undefined>;
    authedRequest: AuthedRequestFn;
}
export declare function inviteByThreePidRequest({ roomId, medium, address, getIdentityServerUrl, getIdentityAccessToken, authedRequest, }: InviteByThreePidRequestContext): Promise<EmptyObject>;
export declare function forgetRoomRequest(roomId: string, deleteRoom: boolean, authedRequest: AuthedRequestFn, removeRoom: (roomId: string) => void, emitDeleteRoom: (roomId: string) => void): Promise<EmptyObject>;
export declare function unbanRoomUserRequest(roomId: string, userId: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function kickRoomUserRequest(roomId: string, userId: string, reason: string | undefined, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function membershipChangeRequest(roomId: string, userId: string | undefined, membership: Membership, reason: string | undefined, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function leaveRoomChainRequest(roomId: string, includeFuture: boolean, getRoomUpgradeHistory: (roomId: string, verifyLinks: boolean) => Room[], leave: (roomId: string) => Promise<EmptyObject>): Promise<{
    [roomId: string]: Error | MatrixError | null;
}>;
export {};
//# sourceMappingURL=client-membership.d.ts.map