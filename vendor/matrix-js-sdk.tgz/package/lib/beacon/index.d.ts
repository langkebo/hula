/**
 * Beacon Manager - 位置信标管理
 *
 * 提供位置信标(Beacon)相关功能
 * 对应后端: beacon_service
 */
import { MatrixClient } from "../client";
import { type ISendEventResponse } from "../@types/requests";
import { type MBeaconInfoEventContent } from "../@types/beacon";
import { type MatrixEvent } from "../models/event";
import { type Room } from "../models/room";
import { Beacon, type BeaconEventHandlerMap } from "../models/beacon";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface BeaconManagerEvents {
    beacon_created: {
        roomId: string;
        beacon: Beacon;
    };
    beacon_updated: {
        roomId: string;
        beacon: Beacon;
    };
    beacon_stopped: {
        roomId: string;
        beaconId: string;
    };
}
export declare class BeaconManager extends BaseManager<keyof BeaconManagerEvents, BeaconManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    createLiveBeacon(roomId: string, beaconInfoContent: MBeaconInfoEventContent): Promise<ISendEventResponse>;
    setLiveBeacon(roomId: string, beaconInfoContent: MBeaconInfoEventContent): Promise<ISendEventResponse>;
    /**
     * 发送 m.beacon 位置更新事件（MSC3672）。
     *
     * 通过 m.relates_to(m.reference) 关联到 beacon_info 事件，作为该信标的一个位置更新。
     *
     * @param roomId - 房间 ID
     * @param beaconInfoEventId - 关联的 m.beacon_info 事件 ID
     * @param geoUri - geo URI（如 `geo:51.5008,-0.1247`）
     * @param timestamp - 可选时间戳，默认 Date.now()
     * @param description - 可选位置描述
     */
    sendBeaconLocation(roomId: string, beaconInfoEventId: string, geoUri: string, timestamp?: number, description?: string): Promise<ISendEventResponse>;
    /**
     * 停止共享位置（发送 live:false 的 m.beacon_info state event）。
     *
     * 本方法通过 setLiveBeacon 向服务端发送停止事件（与前端此前用 setLiveBeacon(live:false)
     * 绕过 BeaconManager.stopBeacon 仅本地 destroy 的行为一致）。
     *
     * @param roomId - 房间 ID
     * @param timeout - 可选超时，默认 3600000ms
     * @param description - 可选描述
     */
    stopBeaconSharing(roomId: string, timeout?: number, description?: string): Promise<ISendEventResponse>;
    processBeaconEvents(room?: Room, events?: MatrixEvent[]): void;
    getBeaconsForRoom(roomId: string): Beacon[];
    getActiveBeacons(): Beacon[];
    stopBeacon(roomId: string, beaconId: string): void;
    getBeacon(roomId: string, beaconId: string): Beacon | undefined;
    subscribeToBeaconEvents(event: keyof BeaconEventHandlerMap, handler: BeaconEventHandlerMap[keyof BeaconEventHandlerMap]): void;
    unsubscribeFromBeaconEvents(event: keyof BeaconEventHandlerMap, handler: BeaconEventHandlerMap[keyof BeaconEventHandlerMap]): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map