export declare function assertExtendedProfileSupported(supported: boolean): void;
//# sourceMappingURL=client-profile-core.d.ts.map