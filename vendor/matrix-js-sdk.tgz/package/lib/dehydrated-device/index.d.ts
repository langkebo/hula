import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface DehydratedDeviceData {
    algorithm: string;
    account: string;
}
export interface CreateDehydratedDeviceRequest {
    device_data: DehydratedDeviceData;
    initial_device_display_name?: string;
}
export interface CreateDehydratedDeviceResponse {
    device_id: string;
}
export interface DeviceInfo {
    device_id: string;
    device_data?: DehydratedDeviceData;
    initial_device_display_name?: string;
    created_at?: number;
    expires_at?: number;
    [key: string]: unknown;
}
export interface GetDevicesResponse {
    devices: DeviceInfo[];
}
export interface RehydrateData {
    algorithm: string;
    account: string;
}
export interface ClaimDehydratedDeviceRequest {
    rehydrate_data: RehydrateData;
}
export interface ClaimDehydratedDeviceResponse {
    [key: string]: unknown;
}
export interface UpdateDehydratedDeviceRequest {
    device_data: DehydratedDeviceData;
}
export interface UpdateDehydratedDeviceResponse {
    device_id: string;
}
export interface DeviceStatusResponse {
    exists: boolean;
}
export declare class DehydratedDeviceManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    isSupported(): Promise<boolean>;
    createDevice(data: CreateDehydratedDeviceRequest): Promise<CreateDehydratedDeviceResponse>;
    getDevice(deviceId: string): Promise<DeviceInfo>;
    getDevices(): Promise<GetDevicesResponse>;
    getDeviceStatus(): Promise<DeviceStatusResponse>;
    claimDevice(deviceId: string, data: ClaimDehydratedDeviceRequest): Promise<ClaimDehydratedDeviceResponse>;
    updateDeviceData(deviceId: string, data: UpdateDehydratedDeviceRequest): Promise<UpdateDehydratedDeviceResponse>;
    deleteDevice(deviceId: string): Promise<Record<string, never>>;
    getDeviceEvent(deviceId: string): Promise<Record<string, unknown>>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map