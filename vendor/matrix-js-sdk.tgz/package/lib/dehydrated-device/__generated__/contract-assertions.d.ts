export declare const DEHYDRATED_DEVICE_ROUTES_ENTRY_COUNT: 6;
export declare const DEHYDRATED_DEVICE_ROUTES_STATUS_SCENARIOS: readonly [];
export type DehydratedDeviceStatusScenario = (typeof DEHYDRATED_DEVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const DEHYDRATED_DEVICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type DehydratedDeviceErrorScenario = (typeof DEHYDRATED_DEVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const DEHYDRATED_DEVICE_ROUTES_ERRCODES: readonly [];
export type DehydratedDeviceErrcode = (typeof DEHYDRATED_DEVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map