/**
 * DTO snippets extracted from the contract doc for `dehydrated-device`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
import type { IContent } from "../../models/event.ts";
export interface DehydratedDeviceData {
    algorithm: string;
    account: string;
}
export interface DehydratedDevicePutRequest {
    device_data: DehydratedDeviceData;
    /** 创建时希望使用的设备显示名（可选）。 */
    initial_device_display_name?: string;
}
export interface DehydratedDevicePutResponse {
    device_id: string;
}
export interface DehydratedDeviceGetResponse {
    device_id: string;
    device_data: DehydratedDeviceData;
}
export interface DehydratedDeviceStatus {
    device_id: string;
    device_data: DehydratedDeviceData;
}
export interface DehydratedDeviceStatusResponse {
    dehydrated_device?: DehydratedDeviceStatus;
}
export interface DehydratedDeviceEventsRequest {
    next_batch?: string;
}
export interface DehydratedDeviceToDeviceEvent {
    type: string;
    sender: string;
    content: IContent;
}
export interface DehydratedDeviceEventsResponse {
    events: DehydratedDeviceToDeviceEvent[];
    next_batch?: string;
}
//# sourceMappingURL=dto.d.ts.map