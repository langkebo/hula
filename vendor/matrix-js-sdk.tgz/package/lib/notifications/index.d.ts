import { MatrixClient } from "../client";
import { EventTimelineSet } from "../models/event-timeline-set";
import { type LocalNotificationSettings } from "../@types/local_notifications";
import { type EmptyObject } from "../@types/common";
import { type IEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ILocalNotificationSettings {
    is_silenced: boolean;
}
export interface INotificationsResponse {
    next_token?: string;
    notifications: Array<{
        actions: unknown[];
        event: IEvent;
        profile_tag?: string;
        read: boolean;
        room_id: string;
        ts: number;
    }>;
}
export interface NotificationsManagerEvents {
    notifications_updated: {
        count: number;
    };
    notification_cleared: {
        roomId: string;
    };
}
export declare class NotificationsManager extends BaseManager<keyof NotificationsManagerEvents, NotificationsManagerEvents> {
    private notifTimelineSet;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getNotifTimelineSet(): EventTimelineSet | null;
    setNotifTimelineSet(set: EventTimelineSet): void;
    resetNotifTimelineSet(): void;
    setLocalNotificationSettings(deviceId: string, settings: LocalNotificationSettings): Promise<EmptyObject>;
    /**
     * 获取通知列表
     *
     * @param opts - 查询选项
     * @param opts.from - 分页起始位置（可选）
     * @param opts.limit - 返回数量限制（可选，默认由服务器决定）
     * @param opts.only - 过滤条件（可选，如 "highlight"）
     * @returns 通知列表和分页信息
     */
    getNotifications(opts?: {
        from?: string;
        limit?: number;
        only?: string;
    }): Promise<INotificationsResponse>;
    /**
     * 确认通知
     *
     * @param notificationId - 通知 ID (event_id)
     * @returns 成功返回空对象
     */
    ackNotification(notificationId: string): Promise<EmptyObject>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map