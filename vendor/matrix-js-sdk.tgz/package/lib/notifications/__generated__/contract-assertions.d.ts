export declare const NOTIFICATIONS_ROUTES_ENTRY_COUNT: 9;
export declare const NOTIFICATIONS_ROUTES_STATUS_SCENARIOS: readonly [];
export type NotificationsStatusScenario = (typeof NOTIFICATIONS_ROUTES_STATUS_SCENARIOS)[number];
export declare const NOTIFICATIONS_ROUTES_ERROR_SCENARIOS: readonly [];
export type NotificationsErrorScenario = (typeof NOTIFICATIONS_ROUTES_ERROR_SCENARIOS)[number];
export declare const NOTIFICATIONS_ROUTES_ERRCODES: readonly [];
export type NotificationsErrcode = (typeof NOTIFICATIONS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map