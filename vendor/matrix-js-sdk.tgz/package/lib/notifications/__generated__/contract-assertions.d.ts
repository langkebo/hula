export declare const NOTIFICATIONS_ROUTES_ENTRY_COUNT: 9;
export declare const NOTIFICATIONS_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "分页参数或过滤条件不合法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "无权查看通知流";
}, {
    readonly status: 404;
    readonly note: "分页锚点或关联事件不存在";
}, {
    readonly status: 429;
    readonly note: "触发限流";
}];
export type NotificationsStatusScenario = (typeof NOTIFICATIONS_ROUTES_STATUS_SCENARIOS)[number];
export declare const NOTIFICATIONS_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录";
}, {
    readonly scenario: "查询参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 from、limit、only 后重试";
}, {
    readonly scenario: "权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户当前账号无权访问通知历史";
}, {
    readonly scenario: "分页锚点或关联数据不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "清空本地分页游标并重新拉取第一页";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底处理";
}];
export type NotificationsErrorScenario = (typeof NOTIFICATIONS_ROUTES_ERROR_SCENARIOS)[number];
export declare const NOTIFICATIONS_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "通知查询参数结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "limit、from 或 only 参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权读取通知历史";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "分页游标或关联通知事件不存在";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "通知查询触发限流";
}];
export type NotificationsErrcode = (typeof NOTIFICATIONS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map