/** Routes served by the synapse-rust `notifications` module (mirrored from the backend contract). */
export declare const NOTIFICATIONS_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/push/cleanup";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/push/process";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/push/devices";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/push/devices";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/push/devices/{device_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/push/send";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/push/config";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/admin/v1/push/config";
}];
/** Union of every (method, path) tuple in `NOTIFICATIONS_ROUTES`. */
export type NotificationsRoute = (typeof NOTIFICATIONS_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type NotificationsMethod = NotificationsRoute["method"];
/** Path templates referenced by this module. */
export type NotificationsPath = NotificationsRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type NotificationsReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${NotificationsReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type NotificationsPathPattern = NotificationsReplaceBraces<NotificationsPath>;
//# sourceMappingURL=route-table.d.ts.map