/**
 * DTO snippets extracted from the contract doc for `push_notification`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type NotificationsContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map