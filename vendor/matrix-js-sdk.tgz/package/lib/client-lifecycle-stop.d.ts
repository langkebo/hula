import type { MatrixClient } from "./client";
/**
 * Stop all client lifecycle services (crypto, sync, VOIP, queues, managers, room timers).
 * Extracted from stopClient to keep client.ts thin.
 */
export declare function stopClientLifecycleServices(client: MatrixClient): void;
//# sourceMappingURL=client-lifecycle-stop.d.ts.map