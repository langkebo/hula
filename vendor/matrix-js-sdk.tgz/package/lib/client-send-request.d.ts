import { type SendDelayedEventRequestOpts } from "./@types/requests";
import type { QueryDict } from "./utils";
export interface ResolvedSendEventRequestArgs {
    delayOpts?: SendDelayedEventRequestOpts;
    queryOpts?: QueryDict;
}
export declare function resolveSendEventRequestArgs(queryOrDelayOpts?: SendDelayedEventRequestOpts | QueryDict, queryDict?: QueryDict): ResolvedSendEventRequestArgs;
//# sourceMappingURL=client-send-request.d.ts.map