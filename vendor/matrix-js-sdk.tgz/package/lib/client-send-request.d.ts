import { type SendDelayedEventRequestOpts } from "./@types/requests.ts";
import type { QueryDict } from "./utils.ts";
export interface ResolvedSendEventRequestArgs {
    delayOpts?: SendDelayedEventRequestOpts;
    queryOpts?: QueryDict;
}
export declare function resolveSendEventRequestArgs(queryOrDelayOpts?: SendDelayedEventRequestOpts | QueryDict, queryDict?: QueryDict): ResolvedSendEventRequestArgs;
//# sourceMappingURL=client-send-request.d.ts.map