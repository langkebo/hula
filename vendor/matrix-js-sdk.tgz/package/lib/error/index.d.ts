/**
 * Unified Error Handling Module - 统一错误处理模块
 *
 * 提供 SDK 统一的错误类型、错误码和错误处理工具
 */
export declare class SDKError extends Error {
    code: string;
    statusCode?: number | undefined;
    details?: unknown | undefined;
    constructor(message: string, code: string, statusCode?: number | undefined, details?: unknown | undefined);
}
export declare const ErrorCodes: {
    readonly NETWORK_ERROR: "NETWORK_ERROR";
    readonly UNAUTHORIZED: "UNAUTHORIZED";
    readonly FORBIDDEN: "FORBIDDEN";
    readonly NOT_FOUND: "NOT_FOUND";
    readonly BAD_REQUEST: "BAD_REQUEST";
    readonly SERVER_ERROR: "SERVER_ERROR";
    readonly TIMEOUT: "TIMEOUT";
    readonly VALIDATION_ERROR: "VALIDATION_ERROR";
    readonly RATE_LIMITED: "RATE_LIMITED";
    readonly CONFLICT: "CONFLICT";
    readonly SERVICE_UNAVAILABLE: "SERVICE_UNAVAILABLE";
};
export type ErrorCode = (typeof ErrorCodes)[keyof typeof ErrorCodes];
export declare function createError(code: ErrorCode, message: string, statusCode?: number, details?: unknown): SDKError;
export declare function isSDKError(error: unknown): error is SDKError;
/** Options for controlling error handling behavior in Manager methods */
export type ErrorHandlingOptions = {
    /** If true (default), errors are thrown. If false, errors are caught and null is returned. */
    throwOnError?: boolean;
    /** Optional callback when an error occurs, regardless of throwOnError */
    onError?: (error: SDKError) => void;
};
/**
 * Unified error handler for Manager methods.
 * Replaces the inconsistent `throwOnError` parameter pattern with a structured options approach.
 *
 * Usage:
 *   return handleManagerError(error, { throwOnError: false }, "getUser");
 *   // or with the legacy boolean shorthand:
 *   return handleManagerError(error, throwOnError, "getUser");
 */
export declare function handleManagerError<T = null>(error: unknown, options?: ErrorHandlingOptions | boolean, _context?: string): T | null;
export declare function withErrorHandling<T>(fn: () => Promise<T>, fallback?: T, onError?: (error: SDKError) => void): Promise<T>;
export declare function mapHttpError(status: number, message?: string): SDKError;
/**
 * Bridge utilities for converting SDK errors to application-level error formats.
 * Used by hula frontend to convert SDKError to AppError/AppException.
 */
/** Structured error info that can be consumed by application error handlers */
export type SDKErrorInfo = {
    code: string;
    message: string;
    statusCode?: number;
    details?: unknown;
    isRetryable: boolean;
    retryAfter?: unknown;
    traceId?: string;
};
/**
 * Convert any error to a structured SDKErrorInfo object.
 * This provides a stable serialization format that hula's AppError can consume
 * without depending on the SDKError class directly.
 */
export declare function toErrorInfo(error: unknown): SDKErrorInfo;
/**
 * Create an SDKError from an SDKErrorInfo object (reverse bridge).
 * Useful for re-creating errors from serialized error info.
 */
export declare function fromErrorInfo(info: SDKErrorInfo): SDKError;
//# sourceMappingURL=index.d.ts.map