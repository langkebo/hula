export declare const BACKGROUND_UPDATE_ROUTES_ENTRY_COUNT: 19;
export declare const BACKGROUND_UPDATE_ROUTES_STATUS_SCENARIOS: readonly [];
export type BackgroundUpdateStatusScenario = (typeof BACKGROUND_UPDATE_ROUTES_STATUS_SCENARIOS)[number];
export declare const BACKGROUND_UPDATE_ROUTES_ERROR_SCENARIOS: readonly [];
export type BackgroundUpdateErrorScenario = (typeof BACKGROUND_UPDATE_ROUTES_ERROR_SCENARIOS)[number];
export declare const BACKGROUND_UPDATE_ROUTES_ERRCODES: readonly [];
export type BackgroundUpdateErrcode = (typeof BACKGROUND_UPDATE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map