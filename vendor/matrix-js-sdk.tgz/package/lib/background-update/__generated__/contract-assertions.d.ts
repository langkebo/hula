export declare const BACKGROUND_UPDATE_ROUTES_ENTRY_COUNT: 19;
export declare const BACKGROUND_UPDATE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "按后端真实 19 条路由重写文档，并补齐 BackgroundUpdateManager、测试与路径绑定 | 修复旧文档长期漂移";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type BackgroundUpdateStatusScenario = (typeof BACKGROUND_UPDATE_ROUTES_STATUS_SCENARIOS)[number];
export declare const BACKGROUND_UPDATE_ROUTES_ERROR_SCENARIOS: readonly [];
export type BackgroundUpdateErrorScenario = (typeof BACKGROUND_UPDATE_ROUTES_ERROR_SCENARIOS)[number];
export declare const BACKGROUND_UPDATE_ROUTES_ERRCODES: readonly [];
export type BackgroundUpdateErrcode = (typeof BACKGROUND_UPDATE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map