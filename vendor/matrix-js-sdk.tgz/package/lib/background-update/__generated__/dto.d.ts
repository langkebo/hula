/**
 * DTO snippets extracted from the contract doc for `background_update`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface BackgroundUpdatesResponse {
    updates: Array<{
        name: string;
        status: string;
        progress: number;
        started_ts?: number;
    }>;
}
export interface PendingUpdates {
    pending: string[];
}
export interface RunningUpdates {
    running: Array<{
        name: string;
        progress: number;
        started_ts: number;
    }>;
}
export interface UpdateStatus {
    enabled: boolean;
    current_updates: number;
    total_duration_ms: number;
}
export interface JobDetail {
    name: string;
    status: string;
    progress: number;
    started_ts?: number;
    completed_ts?: number;
    error?: string;
}
export interface UpdateStats {
    total_updates: number;
    completed: number;
    failed: number;
    running: number;
    pending: number;
}
export interface BackgroundUpdateResponseDto {
    count: number;
}
//# sourceMappingURL=dto.d.ts.map