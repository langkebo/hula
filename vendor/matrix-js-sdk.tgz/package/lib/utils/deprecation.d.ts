/**
 * Utilities for handling deprecated APIs
 */
/**
 * Emit a deprecation warning for a method or API
 *
 * @param oldMethod - The deprecated method name
 * @param newMethod - The replacement method name
 * @param removeVersion - The version in which the old method will be removed
 * @param migrationUrl - Optional URL to migration guide
 *
 * @example
 * ```typescript
 * function oldMethod() {
 *     deprecationWarning(
 *         "oldMethod()",
 *         "newMethod()",
 *         "v41.0.0",
 *         "https://example.com/migration"
 *     );
 *     // ... implementation
 * }
 * ```
 */
export declare function deprecationWarning(oldMethod: string, newMethod: string, removeVersion: string, migrationUrl?: string): void;
/**
 * Emit a deprecation warning once per session
 *
 * @param key - Unique key for this warning
 * @param oldMethod - The deprecated method name
 * @param newMethod - The replacement method name
 * @param removeVersion - The version in which the old method will be removed
 * @param migrationUrl - Optional URL to migration guide
 */
export declare function deprecationWarningOnce(key: string, oldMethod: string, newMethod: string, removeVersion: string, migrationUrl?: string): void;
/**
 * Clear all shown warnings (useful for testing)
 */
export declare function clearDeprecationWarnings(): void;
//# sourceMappingURL=deprecation.d.ts.map