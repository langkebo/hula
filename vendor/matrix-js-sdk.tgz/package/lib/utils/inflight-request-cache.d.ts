import { LRUCache } from "./lru-cache";
export declare function stableSerialize(value: unknown): string;
export declare class InflightRequestCache<T> {
    private readonly cache?;
    private readonly inflight;
    constructor(cache?: LRUCache<T> | undefined);
    get(key: string): T | undefined;
    getOrCreate(key: string, factory: () => Promise<T>): Promise<T>;
    delete(key: string): void;
    clear(): void;
}
//# sourceMappingURL=inflight-request-cache.d.ts.map