/**
 * Type guard utilities for safe runtime type narrowing.
 *
 * P2 优化：为 `unknown` / `Record<string, unknown>` 类型提供安全的属性访问，
 * 减少对 `as any` 的依赖，提升类型安全性。
 */
import { MatrixError, HTTPError } from "../http-api/errors";
import { SdkError } from "../errors";
/**
 * Narrow a value to `Record<string, unknown>` if it is a non-null object.
 */
export declare function isObject(value: unknown): value is Record<string, unknown>;
/**
 * Narrow a value to `Array<unknown>` if it is an array.
 */
export declare function isArray(value: unknown): value is Array<unknown>;
/**
 * Check whether an object has a property of the given name.
 * Unlike `"key" in obj`, this also narrows the type when `K` is a literal.
 *
 * @example
 * ```ts
 * const result = hasProperty(response, "errcode")
 *   ? response.errcode  // type: string | undefined
 *   : undefined;
 * ```
 */
export declare function hasProperty<T extends Record<string, unknown>, K extends string>(obj: T, key: K): obj is T & Record<K, unknown>;
/**
 * Check whether `error` is an SDK error (SdkError subclass).
 * Useful for catching SDK errors in generic `catch (error: unknown)` blocks.
 *
 * @example
 * ```ts
 * try {
 *   await room.sendEvent(content);
 * } catch (error: unknown) {
 *   if (isSdkError(error)) {
 *     console.error(error.errorCode, error.statusCode);
 *   }
 * }
 * ```
 */
export declare function isSdkError(error: unknown): error is SdkError;
/**
 * Check whether `error` is a MatrixError.
 * MatrixError wraps Matrix protocol error responses (HTTP 200 with errcode body).
 *
 * @example
 * ```ts
 * if (isMatrixError(error) && error.errcode === "M_FORBIDDEN") {
 *   // handle forbidden
 * }
 * ```
 */
export declare function isMatrixError(error: unknown): error is MatrixError;
/**
 * Check whether `error` is an HTTPError.
 * HTTPError wraps raw HTTP failures (non-2xx status codes).
 */
export declare function isHTTPError(error: unknown): error is HTTPError;
/**
 * Extract a named string field from an unknown error cause.
 * Returns `undefined` if the field is missing or not a string.
 *
 * @param cause - The error cause (e.g. `error.cause`)
 * @param field - The field name to extract
 *
 * @example
 * ```ts
 * const errcode = extractString(cause, "errcode");
 * // errcode: string | undefined
 * ```
 */
export declare function extractString(cause: unknown, field: string): string | undefined;
/**
 * Extract a named number field from an unknown error cause.
 * Returns `undefined` if the field is missing or not a number.
 */
export declare function extractNumber(cause: unknown, field: string): number | undefined;
/**
 * Extract a nested field `parent.child` from an unknown error cause.
 * Returns `undefined` if either level is missing or not an object.
 *
 * @example
 * ```ts
 * const retryAfter = extractNested(cause, "data", "retry_after_ms");
 * ```
 */
export declare function extractNested(cause: unknown, parent: string, child: string): unknown;
/**
 * Extract a header value from an error cause that carries `httpHeaders`.
 * Handles both browser `Headers` objects and plain `{ get(name: string): string | null }`.
 */
export declare function extractHeader(cause: unknown, headerName: string): string | undefined;
/**
 * Type predicate narrowing to `RetryableError` — used for retry policy checks.
 *
 * @example
 * ```ts
 * if (isRetryableError(error)) {
 *   console.log(`Retryable: ${error.retryAfter}ms`);
 * }
 * ```
 */
export declare function isRetryableError(error: unknown): error is import("../errors").RetryableError;
/**
 * Type predicate narrowing to `TimeoutError` — used for timeout-specific handling.
 */
export declare function isTimeoutError(error: unknown): error is import("../errors").TimeoutError;
/**
 * Type predicate narrowing to `ValidationError` — used for input validation handling.
 */
export declare function isValidationError(error: unknown): error is import("../errors").ValidationError;
/**
 * Type predicate narrowing to `AuthError` — used for auth-specific handling.
 */
export declare function isAuthError(error: unknown): error is import("../errors").AuthError;
/**
 * Type predicate narrowing to `NotFoundError` — used for 404 handling.
 */
export declare function isNotFoundError(error: unknown): error is import("../errors").NotFoundError;
/**
 * Check whether a raw error's `code` field indicates a network/timeout problem.
 *
 * @param error - Any caught error
 * @param code - The `error.code` value to check
 *
 * @example
 * ```ts
 * } catch (error: unknown) {
 *   if (isNetworkErrorCode((error as NodeJS.ErrnoException).code)) {
 *     // handle timeout / network failure
 *   }
 * }
 * ```
 */
export declare function isNetworkErrorCode(code: string | undefined): boolean;
/**
 * Check whether an error cause carries a timeout/connection-reset error code.
 * Combines the check with a loose `code` field extraction.
 */
export declare function hasTimeoutCode(cause: unknown): boolean;
//# sourceMappingURL=type-guards.d.ts.map