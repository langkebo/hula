interface CacheEntry<T> {
    value: T;
    timestamp: number;
}
export interface CacheStats {
    size: number;
    maxSize: number;
    hits: number;
    misses: number;
    hitRate: number;
    evictions: number;
    expiredPurges: number;
}
export type EvictionListener<T> = (key: string, value: T, reason: "capacity" | "expired" | "manual") => void;
export interface CacheConfig {
    maxSize: number;
    ttl: number;
    name?: string;
}
export interface AggregatedCacheStats {
    totalCaches: number;
    totalSize: number;
    totalMaxSize: number;
    totalHits: number;
    totalMisses: number;
    overallHitRate: number;
    totalEvictions: number;
    totalExpiredPurges: number;
    caches: Record<string, CacheStats>;
}
export declare class LRUCache<T> {
    private cache;
    private readonly maxSize;
    private readonly ttl;
    private readonly name;
    private hits;
    private misses;
    private evictions;
    private expiredPurges;
    private evictionListener?;
    constructor(config: CacheConfig);
    constructor(maxSize: number, ttl: number);
    private static instanceCounter;
    getName(): string;
    getMaxSize(): number;
    getTtl(): number;
    onEviction(listener: EvictionListener<T>): void;
    get(key: string): T | undefined;
    set(key: string, value: T): void;
    has(key: string): boolean;
    delete(key: string): boolean;
    clear(): void;
    size(): number;
    values(): T[];
    entries(): IterableIterator<[string, CacheEntry<T>]>;
    purgeExpired(): number;
    getStats(): CacheStats;
}
export declare class CacheRegistry {
    private static instance;
    private caches;
    private purgeTimer;
    private purgeIntervalMs;
    private constructor();
    static getInstance(): CacheRegistry;
    static resetInstance(): void;
    register<T>(cache: LRUCache<T>): void;
    unregister(name: string): void;
    getCache(name: string): LRUCache<unknown> | undefined;
    getCacheNames(): string[];
    getAggregatedStats(): AggregatedCacheStats;
    purgeAllExpired(): number;
    clearAll(): void;
    /**
     * Start the periodic sweep that purges expired entries from every registered cache.
     *
     * Idempotent. Note that `LRUCache.get()` / `has()` already expire entries lazily, so
     * this sweep only reclaims the slots held by entries that are never read again — it is
     * a memory-hygiene measure, not a correctness requirement.
     *
     * The interval is `unref()`-ed where the runtime supports it (Node) so a client that
     * never calls `stopClient()` does not keep the process alive; browsers/ webviews have
     * no `unref` and are long-lived by nature, so the optional call is a no-op there.
     */
    startPurgeTimer(): void;
    stopPurgeTimer(): void;
    setPurgeInterval(ms: number): void;
}
export {};
//# sourceMappingURL=lru-cache.d.ts.map