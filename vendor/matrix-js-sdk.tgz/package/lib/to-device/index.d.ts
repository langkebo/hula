/**
 * To-Device Manager - 设备消息管理
 *
 * 提供设备间消息发送功能
 * 对应后端: synapse-rust/src/web/routes/e2ee_routes.rs
 *
 * 后端端点:
 * - PUT /sendToDevice/{event_type}/{transaction_id}
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { SendToDeviceContentMap } from "../client-api-types";
import type { EmptyObject } from "../@types/common";
import type { ToDeviceBatch as ModelToDeviceBatch, ToDevicePayload } from "../models/ToDeviceMessage";
import type { IContent } from "../models/event";
export interface ToDeviceMessage {
    [userId: string]: {
        [deviceId: string]: IContent;
    };
}
export interface ToDeviceBatch {
    eventType: string;
    batch: ToDeviceMessage;
}
export interface ToDeviceResult {
    success: boolean;
    failures?: Record<string, Record<string, {
        error: string;
    }>>;
}
export declare class ToDeviceManager extends BaseManager {
    private txnId;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 发送设备间消息
     * PUT /_matrix/client/v3/sendToDevice/{event_type}/{txnId}
     */
    sendToDevice(eventType: string, messages: ToDeviceMessage, txnId?: string): Promise<ToDeviceResult>;
    /**
     * Send an event to a specific list of devices using SendToDeviceContentMap.
     * This is the client.ts-compatible API that accepts Map<string, Map<string, ...>> format.
     * PUT /_matrix/client/v3/sendToDevice/{event_type}/{txnId}
     */
    sendToDeviceFromContentMap(eventType: string, contentMap: SendToDeviceContentMap, txnId?: string): Promise<EmptyObject>;
    /**
     * Queue a ToDeviceBatch for batch sending via the client's ToDeviceMessageQueue.
     */
    queueToDeviceBatch(batch: ModelToDeviceBatch): Promise<void>;
    /**
     * 批量发送设备间消息
     */
    sendBatchToDevice(batch: ToDeviceBatch[]): Promise<ToDeviceResult[]>;
    /**
     * Encrypt the payload for all devices in the list and queue it.
     * The type of the sent to-device message will be `m.room.encrypted`.
     * @param eventType - The type of event to send
     * @param devices - The list of devices to send the event to.
     * @param payload - The payload to send. This will be encrypted.
     * @returns Promise which resolves once queued.
     */
    encryptAndSendToDevice(eventType: string, devices: {
        userId: string;
        deviceId: string;
    }[], payload: ToDevicePayload): Promise<void>;
    /**
     * 发送加密的设备间消息
     */
    sendEncryptedToDevice(eventType: string, encryptedMessages: ToDeviceMessage, txnId?: string): Promise<ToDeviceResult>;
    private makeTxnId;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map