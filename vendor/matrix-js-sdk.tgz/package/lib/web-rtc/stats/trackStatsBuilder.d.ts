import { type MediaTrackStats } from "./media/mediaTrackStats";
import { type TrackSummary } from "./callStatsReportSummary";
interface RTCStatsBase {
    id?: string;
    timestamp?: number;
    type?: string;
    [key: string]: unknown;
}
export declare class TrackStatsBuilder {
    static buildFramerateResolution(trackStats: MediaTrackStats, now: RTCStatsBase): void;
    static calculateSimulcastFramerate(trackStats: MediaTrackStats, now: RTCStatsBase, before: RTCStatsBase, layer: number): void;
    static buildCodec(report: RTCStatsReport | undefined, trackStats: MediaTrackStats, now: RTCStatsBase): void;
    static buildBitrateReceived(trackStats: MediaTrackStats, now: RTCStatsBase, before: RTCStatsBase): void;
    static buildBitrateSend(trackStats: MediaTrackStats, now: RTCStatsBase, before: RTCStatsBase): void;
    static buildPacketsLost(trackStats: MediaTrackStats, now: RTCStatsBase, before: RTCStatsBase): void;
    private static calculateBitrate;
    static setTrackStatsState(trackStats: MediaTrackStats, transceiver: RTCRtpTransceiver | undefined): void;
    static buildTrackSummary(trackStatsList: MediaTrackStats[]): {
        audioTrackSummary: TrackSummary;
        videoTrackSummary: TrackSummary;
    };
    static buildJitter(trackStats: MediaTrackStats, statsReport: RTCStatsBase): void;
    static buildAudioConcealment(trackStats: MediaTrackStats, statsReport: RTCStatsBase): void;
}
export {};
//# sourceMappingURL=trackStatsBuilder.d.ts.map