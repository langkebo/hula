import { type TrackID } from "../statsReport";
import { MediaTrackStats } from "./mediaTrackStats";
import { type MediaTrackHandler, type TrackId } from "./mediaTrackHandler";
import { type MediaSsrcHandler } from "./mediaSsrcHandler";
interface RTCStatsReportItem {
    trackIdentifier?: string;
    mid?: string;
    ssrc?: string | number;
    [key: string]: unknown;
}
export declare class MediaTrackStatsHandler {
    readonly mediaSsrcHandler: MediaSsrcHandler;
    readonly mediaTrackHandler: MediaTrackHandler;
    private readonly track2stats;
    constructor(mediaSsrcHandler: MediaSsrcHandler, mediaTrackHandler: MediaTrackHandler);
    /**
     * Find tracks by rtc stats
     * Argument report is any because the stats api is not consistent:
     * For example `trackIdentifier`, `mid` not existing in every implementations
     * https://www.w3.org/TR/webrtc-stats/#dom-rtcinboundrtpstreamstats
     * https://developer.mozilla.org/en-US/docs/Web/API/RTCInboundRtpStreamStats
     */
    findTrack2Stats(report: RTCStatsReportItem, type: "remote" | "local"): MediaTrackStats | undefined;
    findLocalVideoTrackStats(report: RTCStatsReportItem): MediaTrackStats | undefined;
    getTrack2stats(): Map<TrackID, MediaTrackStats>;
    findTransceiverByTrackId(trackID: TrackId): undefined | RTCRtpTransceiver;
}
export {};
//# sourceMappingURL=mediaTrackStatsHandler.d.ts.map