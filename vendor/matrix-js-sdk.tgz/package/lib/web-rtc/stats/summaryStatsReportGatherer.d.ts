import { type StatsReportEmitter } from "./statsReportEmitter";
import { type CallStatsReportSummary } from "./callStatsReportSummary";
import { type SummaryStatsReport } from "./statsReport";
import { type ParticipantState } from "../groupCall";
import { type RoomMember } from "../../matrix";
export declare class SummaryStatsReportGatherer {
    private emitter;
    constructor(emitter: StatsReportEmitter);
    build(allSummary: CallStatsReportSummary[]): void;
    static extendSummaryReport(report: SummaryStatsReport, callParticipants: Map<RoomMember, Map<string, ParticipantState>>): void;
    private countTrackListReceivedMedia;
    private buildMaxJitter;
    private buildMaxPacketLoss;
    private countConcealedAudio;
}
//# sourceMappingURL=summaryStatsReportGatherer.d.ts.map