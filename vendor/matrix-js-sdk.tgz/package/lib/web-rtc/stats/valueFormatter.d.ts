export declare class ValueFormatter {
    static getNonNegativeValue(input: unknown): number;
}
//# sourceMappingURL=valueFormatter.d.ts.map