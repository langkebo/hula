import { type Bitrate } from "./media/mediaTrackStats";
export declare class ConnectionStatsBuilder {
    static buildBandwidthReport(now: RTCIceCandidatePairStats): Bitrate;
}
//# sourceMappingURL=connectionStatsBuilder.d.ts.map