import { type MatrixClient } from "../client";
import { type RoomMember } from "../models/room-member";
import { CallFeed } from "./callFeed";
import { type TransceiverKey } from "./call-sdp";
import { type SDPStreamMetadata, SDPStreamMetadataPurpose } from "./callEventTypes";
import { type MatrixCall } from "./call";
export interface CallFeedSetOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    client: MatrixClient;
    roomId: string;
    /** The owning call, passed to `CallFeed` so feeds can find their way back. */
    getCall: () => MatrixCall;
    /** Group calls keep local feeds alive when the underlying call goes away. */
    getGroupCallId: () => string | undefined;
    getPeerConnection: () => RTCPeerConnection | undefined;
    getTransceivers: () => Map<TransceiverKey, RTCRtpTransceiver>;
    getOpponentMember: () => RoomMember | undefined;
    getOpponentDeviceId: () => string | undefined;
    opponentSupportsSDPStreamMetadata: () => boolean;
    getRemoteSDPStreamMetadata: () => SDPStreamMetadata | undefined;
    /** Notify the call that the feed list changed (`CallEvent.FeedsChanged`). */
    onFeedsChanged: (feeds: CallFeed[]) => void;
}
export declare class CallFeedSet {
    private readonly opts;
    private feeds;
    constructor(opts: CallFeedSetOptions);
    get allFeeds(): Array<CallFeed>;
    get localFeeds(): Array<CallFeed>;
    get remoteFeeds(): Array<CallFeed>;
    get localUsermediaFeed(): CallFeed | undefined;
    get localScreensharingFeed(): CallFeed | undefined;
    get remoteUsermediaFeed(): CallFeed | undefined;
    get remoteScreensharingFeed(): CallFeed | undefined;
    getFeedByStreamId(streamId: string): CallFeed | undefined;
    /** Whether there are no incoming feeds at all. */
    hasIncomingFeeds(): boolean;
    pushRemoteFeed(stream: MediaStream): void;
    /**
     * This method is used ONLY if the other client doesn't support sending SDPStreamMetadata
     */
    pushRemoteFeedWithoutMetadata(stream: MediaStream): void;
    pushNewLocalFeed(stream: MediaStream, purpose: SDPStreamMetadataPurpose, addToPeerConnection?: boolean): void;
    /**
     * Pushes supplied feed to the call
     * @param callFeed - to push
     * @param addToPeerConnection - whether to add the tracks to the peer connection
     */
    pushLocalFeed(callFeed: CallFeed, addToPeerConnection?: boolean): void;
    /**
     * Removes local call feed from the call and its tracks from the peer
     * connection
     * @param callFeed - to remove
     */
    removeLocalFeed(callFeed: CallFeed): void;
    deleteAllFeeds(): void;
    deleteFeedByStream(stream: MediaStream): void;
    private deleteFeed;
    private emitFeedsChanged;
}
//# sourceMappingURL=call-feeds.d.ts.map