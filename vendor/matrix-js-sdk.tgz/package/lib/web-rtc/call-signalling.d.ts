/**
 * Invite/answer signalling state machine of a {@link MatrixCall}.
 *
 * Extracted verbatim from `call.ts` (C-8 split, fourth batch): this module owns
 * the "how a call is set up and torn down" logic — `initWithInvite`, `answer`,
 * `hangup`, `reject`, the answer/offer feed plumbing and the remote answer
 * handlers. Everything it touches on the call (state, peer connection, feeds,
 * VoIP event sending, termination) is injected through
 * {@link CallSignallingOptions}, so the class holds no call state of its own.
 */
import { type MatrixEvent } from "../models/event";
import { type TimelineEvents } from "../@types/event";
import { type MatrixClient } from "../client";
import { type SDPStreamMetadata } from "./callEventTypes";
import { CallFeed } from "./callFeed";
import { CallDirection, CallError, CallErrorCode, CallParty, CallState, type CallEventType } from "./call";
export interface CallSignallingOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    client: MatrixClient;
    roomId: string;
    ourPartyId: string;
    getDirection: () => CallDirection | undefined;
    setDirection: (direction: CallDirection) => void;
    getPeerConnection: () => RTCPeerConnection | undefined;
    setPeerConnection: (peerConn: RTCPeerConnection) => void;
    setHangupParty: (party: CallParty) => void;
    getState: () => CallState;
    setState: (state: CallState) => void;
    getInviteOrAnswerSent: () => boolean;
    setInviteOrAnswerSent: (sent: boolean) => void;
    getWaitForLocalAVStream: () => boolean;
    setWaitForLocalAVStream: (wait: boolean) => void;
    getOpponentVersion: () => number | string | undefined;
    getOpponentPartyId: () => string | null | undefined;
    isOnlyDataChannelAllowed: () => boolean;
    /** Shared with `queueGotLocalOffer` in `call.ts`: one negotiate/answer at a time. */
    getResponsePromiseChain: () => Promise<void> | undefined;
    setResponsePromiseChain: (chain: Promise<void> | undefined) => void;
    /** `onNegotiateReceived` in `call.ts` reads this flag, so it stays on the call. */
    setIsSettingRemoteAnswerPending: (pending: boolean) => void;
    getRemoteStream: () => MediaStream | undefined;
    getLocalFeeds: () => CallFeed[];
    getLocalUsermediaStream: () => MediaStream | undefined;
    getLocalScreensharingFeed: () => CallFeed | undefined;
    hasLocalUserMediaAudioTrack: () => boolean;
    hasLocalUserMediaVideoTrack: () => boolean;
    hasRemoteUserMediaAudioTrack: () => boolean;
    hasRemoteUserMediaVideoTrack: () => boolean;
    pushLocalFeed: (feed: CallFeed) => void;
    updateLocalUsermediaStream: (stream: MediaStream, forceAudio?: boolean, forceVideo?: boolean) => Promise<void>;
    opponentSupportsSDPStreamMetadata: () => boolean;
    updateRemoteSDPStreamMetadata: (metadata: SDPStreamMetadata) => void;
    getLocalSDPStreamMetadata: (updateStreamIds?: boolean) => SDPStreamMetadata;
    /** Hand local feeds to a replacement call; returns false when there is none. */
    forwardFeedsToSuccessor: (feeds: CallFeed[]) => boolean;
    callHasEnded: () => boolean;
    createPeerConnection: () => RTCPeerConnection;
    chooseOpponent: (event: MatrixEvent) => void;
    initOpponentCrypto: () => Promise<void>;
    addBufferedRemoteCandidates: (partyId: string) => Promise<void>;
    terminate: (hangupParty: CallParty, hangupReason: CallErrorCode, shouldEmit: boolean) => Promise<void>;
    stopAllMedia: () => void;
    removeStatsReportGatherer: () => void;
    sendVoipEvent: <K extends CallEventType>(eventType: K, content: Omit<TimelineEvents[K], "version" | "call_id" | "party_id" | "conf_id">) => Promise<void>;
    sendCandidateQueue: () => void;
    discardDuplicateCandidates: () => number;
    getRidOfRTXCodecs: () => void;
    createAnswer: () => Promise<RTCSessionDescriptionInit>;
    /**
     * Resolved through the owning call so that instance-level overrides (tests,
     * consumers) still take effect.
     */
    shouldAnswerWithMediaType: (wantedValue: boolean | undefined, valueOfTheOtherSide: boolean, type: "audio" | "video") => boolean;
    getUserMediaFailed: (error: Error) => void;
    emitPeerConnectionCreated: (peerConn: RTCPeerConnection) => void;
    emitHangup: () => void;
    emitError: (error: CallError) => void;
    /** Subscribe to `CallEvent.State`; returns the unsubscribe function. */
    subscribeToState: (onState: (state: CallState) => void) => () => void;
}
export declare class CallSignalling {
    private readonly opts;
    constructor(opts: CallSignallingOptions);
    /**
     * Configure this call from an invite event. Used by MatrixClient.
     * @param event - The m.call.invite event
     * @param throwOnError - Whether to throw on error (default true)
     */
    initWithInvite(event: MatrixEvent, throwOnError?: boolean): Promise<void>;
    /**
     * Configure this call from a hangup or reject event. Used by MatrixClient.
     * @param _event - The m.call.hangup event
     */
    initWithHangup(_event: MatrixEvent): void;
    shouldAnswerWithMediaType(wantedValue: boolean | undefined, valueOfTheOtherSide: boolean, type: "audio" | "video"): boolean;
    /**
     * Answer a call.
     */
    answer(audio?: boolean, video?: boolean): Promise<void>;
    answerWithCallFeeds(callFeeds: CallFeed[]): void;
    /**
     * Hangup a call.
     * @param reason - The reason why the call is being hung up.
     * @param suppressEvent - True to suppress emitting an event.
     */
    hangup(reason: CallErrorCode, suppressEvent: boolean): void;
    /**
     * Reject a call
     * This used to be done by calling hangup, but is a separate method and protocol
     * event as of MSC2746.
     */
    reject(): void;
    /**
     * Adds an audio and/or video track - upgrades the call
     * @param audio - should add an audio track
     * @param video - should add an video track
     */
    upgradeCall(audio: boolean, video: boolean): Promise<void>;
    gotCallFeedsForInvite(callFeeds: CallFeed[], requestScreenshareFeed?: boolean): void;
    sendAnswer(): Promise<void>;
    queueGotCallFeedsForAnswer(callFeeds: CallFeed[]): void;
    gotCallFeedsForAnswer(callFeeds: CallFeed[]): Promise<void>;
    /**
     * Used by MatrixClient.
     */
    onAnswerReceived(event: MatrixEvent): Promise<void>;
    onSelectAnswerReceived(event: MatrixEvent): Promise<void>;
}
//# sourceMappingURL=call-signalling.d.ts.map