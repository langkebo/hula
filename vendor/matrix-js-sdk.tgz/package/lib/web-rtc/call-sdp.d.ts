import { SDPStreamMetadataPurpose } from "./callEventTypes";
export declare enum MediaType {
    AUDIO = "audio",
    VIDEO = "video"
}
export declare enum CodecName {
    OPUS = "opus"
}
export interface CodecParamsMod {
    mediaType: MediaType;
    codec: CodecName;
    enableDtx?: boolean;
    maxAverageBitrate?: number;
}
export declare function getCodecParamMods(isPtt: boolean): CodecParamsMod[];
export type TransceiverKey = string;
export declare function getTransceiverKey(purpose: SDPStreamMetadataPurpose, kind: TransceiverKey): string;
export declare function mungeSdp(description: RTCSessionDescriptionInit, mods: CodecParamsMod[], callId: string): void;
/**
 * This removes all video/rtx codecs from screensharing video
 * transceivers. This is necessary since they can cause problems. Without
 * this the following steps should produce an error:
 *   Chromium calls Firefox
 *   Firefox answers
 *   Firefox starts screen-sharing
 *   Chromium starts screen-sharing
 *   Call crashes for Chromium with:
 *       [96685:23:0518/162603.933321:ERROR:webrtc_video_engine.cc(3296)] RTX codec (PT=97) mapped to PT=96 which is not in the codec list.
 *       [96685:23:0518/162603.933377:ERROR:webrtc_video_engine.cc(1171)] GetChangedRecvParameters called without any video codecs.
 *       [96685:23:0518/162603.933430:ERROR:sdp_offer_answer.cc(4302)] Failed to set local video description recv parameters for m-section with mid='2'. (INVALID_PARAMETER)
 */
export declare function getRidOfRTXCodecs(transceivers: Map<TransceiverKey, RTCRtpTransceiver>): void;
//# sourceMappingURL=call-sdp.d.ts.map