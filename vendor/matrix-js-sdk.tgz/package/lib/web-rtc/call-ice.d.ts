import { type MCallCandidates } from "./callEventTypes";
export interface CallIceCandidateSenderOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    /** Whether the call has already ended: a dead call has nothing left to signal. */
    isCallEnded: () => boolean;
    /**
     * Don't send the candidates yet: either the call is in the ringing state
     * (a failed answer went back to ringing) or the invite/answer has not been
     * sent, in which case the first batch rides along with it.
     */
    isHeldBack: () => boolean;
    /** MSC2746 delay before the first flush: longer for outbound calls. */
    getSendDelayMs: () => number;
    /** Actually send the amalgamated candidates. */
    sendCandidates: (content: Pick<MCallCandidates, "candidates">) => Promise<void>;
    /** A send failed; lets the owner cancel the pending event. */
    onSendError: (error: unknown) => void;
    /** Too many consecutive failed sends ⇒ signalling is broken, give up on the call. */
    onSignallingFailed: (error: Error) => void;
}
/**
 * De-trickles outbound ICE candidates.
 *
 * Candidates trickle in continuously during gathering; we wait `getSendDelayMs()`
 * and send them as one message, because `m.call.candidates` is rate limited in
 * Matrix (in practice it would be better to remove rate limits for `m.call.*`).
 */
export declare class CallIceCandidateSender {
    private readonly opts;
    private queue;
    private sendTries;
    private ended;
    private timer?;
    constructor(opts: CallIceCandidateSenderOptions);
    /** Whether end-of-candidates has been signalled for this generation. */
    get hasCandidatesEnded(): boolean;
    /** ICE restart: a new generation of candidates is about to be gathered. */
    resetCandidatesEnded(): void;
    /**
     * Queue a candidate to be sent.
     *
     * @param content - The candidate to queue up, or null if candidates have finished
     *                being generated and end-of-candidates should be signalled.
     */
    queueCandidate(content: RTCIceCandidate | null): void;
    /**
     * Schedule a deferred flush of the queue.
     *
     * The handle is retained so that a pending flush can be cancelled when the
     * call ends (see {@link clearTimer}); otherwise the timer - and the closure
     * it captures - would survive the call and keep it alive until it fired.
     *
     * If a flush is already pending we keep the earliest scheduled one rather
     * than pushing it back: candidates trickle in continuously during gathering,
     * and resetting the delay on each arrival could postpone the flush
     * indefinitely.
     */
    private schedule;
    /** Cancel any pending deferred flush. */
    clearTimer(): void;
    /**
     * Discard all non-end-of-candidates messages.
     *
     * Call this before sending an invite or answer: the local description being
     * sent already contains every candidate gathered so far.
     *
     * @returns the number of candidate messages that were discarded.
     */
    discardDuplicateCandidates(): number;
    /** Flush the queue, retrying with exponential backoff on failure. */
    send(): Promise<void>;
}
export interface CallIceCandidateReceiverOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    /** Add candidates to the peer connection (owned by `MatrixCall`). */
    addRemoteCandidates: (candidates: RTCIceCandidate[] | MCallCandidates["candidates"]) => Promise<void>;
}
/**
 * Buffers inbound ICE candidates until an opponent has been chosen.
 *
 * Candidates can arrive eagerly, before the user answers, so we hold them per
 * party ID and then add the ones from the party we picked (see
 * {@link addBuffered}).
 */
export declare class CallIceCandidateReceiver {
    private readonly opts;
    private buffer;
    constructor(opts: CallIceCandidateReceiverOptions);
    /** Buffer candidates from `partyId` until {@link addBuffered} picks the opponent. */
    bufferCandidates(partyId: string, candidates: MCallCandidates["candidates"]): void;
    /**
     * Add the buffered candidates belonging to `partyId` and drop the rest.
     *
     * Called right after an opponent is chosen via an invite or answer.
     */
    addBuffered(partyId: string): Promise<void>;
}
//# sourceMappingURL=call-ice.d.ts.map