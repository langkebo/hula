/**
 * Secret Storage Manager - 密钥存储管理
 *
 * 提供 secret storage 功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export type SecretStorageKeyResult = [string, string] | null;
export type SecretStorageKeys = Record<string, string>;
export interface SecretStorageManagerEvents {
    secret_stored: (data: {
        name: string;
    }) => void;
    secret_retrieved: (data: {
        name: string;
    }) => void;
    storage_ready: () => void;
}
export declare class SecretStorageManager extends BaseManager<keyof SecretStorageManagerEvents, SecretStorageManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Is secret storage enabled
     */
    isSecretStorageReady(): Promise<boolean>;
    /**
     * Get secret storage key
     */
    getSecretStorageKey(keyId: string): Promise<SecretStorageKeyResult>;
    /**
     * Store secret
     */
    storeSecret(name: string, secret: string, keys?: string[]): Promise<void>;
    /**
     * Get secret
     */
    getSecret(name: string): Promise<string | null>;
    /**
     * Check if secret exists
     */
    hasSecret(name: string): Promise<boolean>;
    /**
     * Get secret storage keys
     */
    getSecretStorageKeys(): Promise<SecretStorageKeys>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map