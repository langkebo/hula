import type { SigningKey } from "oidc-client-ts";
import { type ValidatedAuthMetadata } from "./validate";
export * from "./authorize";
export * from "./discovery";
export * from "./error";
export * from "./register";
export * from "./tokenRefresher";
export * from "./validate";
export { OidcManager } from "./manager";
/**
 * Validated config for native OIDC authentication, as returned by {@link discoverAndValidateOIDCIssuerWellKnown}.
 * Contains metadata and signing keys from the issuer's well-known (https://oidc-issuer.example.com/.well-known/openid-configuration).
 */
export interface OidcClientConfig extends ValidatedAuthMetadata {
    signingKeys: SigningKey[] | null;
}
//# sourceMappingURL=index.d.ts.map