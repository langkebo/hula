/** Routes served by the synapse-rust `oidc` module (mirrored from the backend contract). */
export declare const OIDC_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/.well-known/jwks.json";
}, {
    readonly method: "GET";
    readonly path: "/.well-known/openid-configuration";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/login/sso/redirect";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/login/sso/userinfo";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/oidc/authorize";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/oidc/callback";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/oidc/login";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/oidc/logout";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/oidc/token";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/oidc/userinfo";
}];
/** Union of every (method, path) tuple in `OIDC_ROUTES`. */
export type OidcRoute = (typeof OIDC_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type OidcMethod = OidcRoute["method"];
/** Path templates referenced by this module. */
export type OidcPath = OidcRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type OidcReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${OidcReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type OidcPathPattern = OidcReplaceBraces<OidcPath>;
//# sourceMappingURL=route-table.d.ts.map