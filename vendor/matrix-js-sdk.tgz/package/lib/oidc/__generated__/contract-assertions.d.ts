export declare const OIDC_ROUTES_ENTRY_COUNT: 17;
export declare const OIDC_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "查询或回调处理成功";
}, {
    readonly status: 302;
    readonly note: "重定向到 OIDC 提供方或登录完成后的目标地址";
}, {
    readonly status: 400;
    readonly note: "OIDC 未启用、缺少 code/state 或请求参数不合法";
}, {
    readonly status: 401;
    readonly note: "state 失效、会话过期或 PKCE 校验失败";
}, {
    readonly status: 403;
    readonly note: "OIDC 提供方拒绝授权或用户无权完成流程";
}, {
    readonly status: 429;
    readonly note: "触发限流";
}];
export type OidcStatusScenario = (typeof OIDC_ROUTES_STATUS_SCENARIOS)[number];
export declare const OIDC_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "OIDC 状态失效或会话过期";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "重新发起授权流程，不复用旧 state";
}, {
    readonly scenario: "请求参数缺失或 OIDC 未启用";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "检查 redirectUrl、code、state 与服务端开关";
}, {
    readonly scenario: "授权被拒绝或回调校验失败";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户重新授权，必要时更换账号";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底处理";
}];
export type OidcErrorScenario = (typeof OIDC_ROUTES_ERROR_SCENARIOS)[number];
export declare const OIDC_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "OIDC state 缺失、已过期或已被消费";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "回调参数结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "redirectUrl、code、state 或 PKCE 参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "提供方拒绝授权或当前用户不允许完成绑定";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "OIDC 登录链路触发限流";
}];
export type OidcErrcode = (typeof OIDC_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map