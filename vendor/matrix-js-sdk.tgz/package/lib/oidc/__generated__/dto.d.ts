/**
 * DTO snippets extracted from the contract doc for `oidc`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type OidcContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map