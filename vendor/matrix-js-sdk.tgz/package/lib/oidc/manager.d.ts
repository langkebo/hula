/**
 * OIDC Manager - OpenID Connect 认证管理
 *
 * 对接后端: synapse-rust/src/web/routes/oidc.rs
 * 后端提供完整的 OIDC Provider 和 Consumer 功能:
 *   - GET  /.well-known/openid-configuration  (OIDC Discovery)
 *   - GET  /.well-known/jwks.json             (JWKS 密钥集)
 *   - GET  /v3/oidc/authorize                 (授权端点)
 *   - POST /v3/oidc/register                  (动态客户端注册)
 *   - POST /v3/oidc/token                     (令牌端点)
 *   - GET  /v3/oidc/userinfo                  (用户信息)
 *   - POST /v3/oidc/logout                    (登出)
 *   - GET  /v3/oidc/callback                  (回调)
 *   - POST /v3/oidc/login                     (内置OIDC登录)
 *   - GET  /v3/login/sso/redirect             (SSO重定向)
 *   - GET  /v3/login/sso/userinfo             (SSO用户信息)
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IOidcDiscovery {
    issuer: string;
    authorization_endpoint: string;
    token_endpoint: string;
    userinfo_endpoint?: string;
    jwks_uri?: string;
    registration_endpoint?: string;
    scopes_supported?: string[];
    response_types_supported?: string[];
    code_challenge_methods_supported?: string[];
}
export interface IOidcUserInfo {
    sub: string;
    name?: string;
    picture?: string;
    email?: string;
}
export interface IOidcTokenResponse {
    access_token: string;
    refresh_token?: string;
    id_token?: string;
    token_type: string;
    expires_in: number;
}
export interface IOidcTokenRequest {
    grant_type: string;
    code?: string;
    redirect_uri?: string;
    code_verifier?: string;
    refresh_token?: string;
    client_id?: string;
    client_secret?: string;
}
export interface IOidcAuthorizationParams {
    client_id: string;
    redirect_uri: string;
    response_type: string;
    scope: string;
    state?: string;
    nonce?: string;
    code_challenge?: string;
    code_challenge_method?: string;
}
export interface IOidcClientRegistration {
    client_id: string;
    client_secret?: string;
    client_name?: string;
    redirect_uris: string[];
}
export interface IOidcLoginRequest {
    client_id: string;
    redirect_uri: string;
    scope?: string;
    state?: string;
    nonce?: string;
    code_verifier?: string;
    username: string;
    password: string;
}
export interface IOidcLoginResponse {
    code: string;
}
export interface IOidcLogoutRequest {
    client_id?: string;
    post_logout_redirect_uri?: string;
    id_token_hint?: string;
}
export interface IOidcJwks {
    keys: Array<{
        kty: string;
        kid: string;
        use?: string;
        alg?: string;
        n?: string;
        e?: string;
    }>;
}
export interface IOidcRegisterRequest {
    client_name?: string;
    redirect_uris: string[];
    grant_types?: string[];
    response_types?: string[];
    token_endpoint_auth_method?: string;
}
export interface OidcManagerEvents {
    oidcDiscovered: (payload: {
        issuer: string;
    }) => void;
    oidcTokenRefreshed: (payload: {
        expires_in: number;
    }) => void;
    oidcAuthorized: (payload: {
        state: string;
        code: string;
    }) => void;
    oidcLoggedOut: (payload: Record<string, never>) => void;
    oidcError: (payload: {
        error: Error;
    }) => void;
}
export declare class OidcManager extends BaseManager<keyof OidcManagerEvents, OidcManagerEvents> {
    private currentProvider;
    private discoveryCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    authorize(params: IOidcAuthorizationParams): Promise<string>;
    registerClient(request: IOidcRegisterRequest): Promise<IOidcClientRegistration>;
    token(request: IOidcTokenRequest): Promise<IOidcTokenResponse>;
    getUserInfo(): Promise<IOidcUserInfo>;
    refreshToken(refreshToken: string): Promise<IOidcTokenResponse>;
    logout(request?: IOidcLogoutRequest): Promise<void>;
    builtinLogin(request: IOidcLoginRequest): Promise<IOidcLoginResponse>;
    oidcLogin(body: IOidcLoginRequest): Promise<IOidcLoginResponse>;
    ssoRedirect(redirectUrl?: string): Promise<string>;
    /**
     * 构造 OIDC 回调 URL。
     * @param code - 授权码
     * @param state - 状态
     */
    buildCallbackUrl(code: string, state: string): string;
    ssoUserInfo(): Promise<IOidcUserInfo>;
    getProvider(): string | null;
    getCachedDiscovery(): IOidcDiscovery | null;
    stop(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=manager.d.ts.map