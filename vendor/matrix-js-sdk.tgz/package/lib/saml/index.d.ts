import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type SamlLoginResponse, type SamlAuthResult, type SamlLogoutResponse, type SamlMetadata, type SamlSpMetadata, type SamlAdminConfig, type SamlUserMapping, type SamlUserMappingPage, type SamlRefreshResult } from "./__generated__/dto";
/**
 * SAML Auth Manager - SAML 认证管理 API 封装
 *
 * 提供 SAML SSO 登录重定向、回调处理、登出、元数据查询等功能
 * 同时包含管理端的 SAML 配置和用户映射管理
 * 对接后端: synapse-rust/src/web/routes/saml.rs
 * API 路径:
 *   公共: /_matrix/client/v3/login/sso/redirect/saml, /login/saml/callback, /saml/metadata 等
 *   管理: /_synapse/admin/v1/saml/config, /saml/mappings 等
 *
 * 使用方式:
 * ```typescript
 * const manager = client.getSamlAuthManager();
 * // 发起 SAML SSO 登录
 * const redirectUrl = await manager.initiateLogin("https://app.example.com/login");
 * // 获取 SAML 元数据
 * const metadata = await manager.getIdpMetadata();
 * // 管理端: 获取 SAML 配置
 * const config = await manager.getAdminConfig();
 * ```
 */
export type { SamlLoginResponse, SamlAuthResult, SamlLogoutResponse, SamlMetadata, SamlSpMetadata, SamlAdminConfig, SamlUserMapping, SamlUserMappingPage, SamlRefreshResult, };
export declare class SamlAuthManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    initiateLogin(redirectUrl?: string): Promise<string>;
    getLoginRedirectUrl(redirectUrl: string): string;
    handleCallback(samlResponse: string, relayState?: string): Promise<SamlAuthResult>;
    /**
     * GET variant of handleCallback.
     * Convenience method that uses GET instead of POST for the SAML callback endpoint.
     *
     * @param params - Optional query parameters to include in the callback request
     */
    getLoginCallback(params?: Record<string, string>): Promise<SamlAuthResult>;
    /**
     * GET variant for SSO redirect.
     * Convenience method that uses GET to retrieve the SAML SSO redirect URL.
     *
     * @param redirectUrl - Optional redirect URL after SSO completion
     */
    getSsoRedirect(redirectUrl?: string): Promise<string>;
    logout(redirectUrl?: string): Promise<SamlLogoutResponse>;
    handleLogoutCallback(): Promise<void>;
    getIdpMetadata(): Promise<SamlMetadata>;
    getSpMetadata(): Promise<SamlSpMetadata>;
    getAdminConfig(): Promise<SamlAdminConfig>;
    updateAdminConfig(config: Partial<SamlAdminConfig>): Promise<SamlAdminConfig>;
    refreshMetadata(): Promise<SamlRefreshResult>;
    getUserMappings(limit?: number, from?: string): Promise<SamlUserMappingPage>;
    getUserMapping(nameId: string): Promise<SamlUserMapping>;
    updateUserMapping(nameId: string, mapping: Partial<SamlUserMapping>): Promise<SamlUserMapping>;
    removeUserMapping(nameId: string): Promise<void>;
    adminLogout(userId: string): Promise<void>;
    private samlAdminRequest;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map