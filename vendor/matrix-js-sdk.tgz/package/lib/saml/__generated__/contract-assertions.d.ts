export declare const SAML_ROUTES_ENTRY_COUNT: 9;
export declare const SAML_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "元数据读取、回调解析或登出回调成功";
}, {
    readonly status: 302;
    readonly note: "重定向到 SAML IdP 或返回登出跳转";
}, {
    readonly status: 400;
    readonly note: "SAMLResponse 缺失、元数据不完整或请求格式非法";
}, {
    readonly status: 401;
    readonly note: "响应签名校验失败、请求已过期或未知用户被阻止";
}, {
    readonly status: 403;
    readonly note: "身份提供方拒绝认证或当前配置不允许现有用户复用";
}, {
    readonly status: 404;
    readonly note: "登出会话不存在";
}, {
    readonly status: 429;
    readonly note: "触发限流";
}];
export type SamlStatusScenario = (typeof SAML_ROUTES_STATUS_SCENARIOS)[number];
export declare const SAML_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "SAML 请求已过期或响应校验失败";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "重新发起 SSO 流程，不复用旧 RelayState";
}, {
    readonly scenario: "SAML 断言或元数据格式不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "检查 SAMLResponse、RelayState 与 IdP 元数据配置";
}, {
    readonly scenario: "身份映射被策略拒绝";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户联系管理员确认账号映射策略";
}, {
    readonly scenario: "登出会话不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "将本地会话视为已失效并刷新登录态";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底处理";
}];
export type SamlErrorScenario = (typeof SAML_ROUTES_ERROR_SCENARIOS)[number];
export declare const SAML_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "SAML 请求已过期、签名校验失败或响应已失效";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "SAMLResponse 或元数据结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "RelayState、Issuer、Audience 或时间窗口校验失败";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "当前映射策略拒绝登录或提供方拒绝认证";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "登出回调引用的会话不存在";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "SAML 登录链路触发限流";
}];
export type SamlErrcode = (typeof SAML_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map