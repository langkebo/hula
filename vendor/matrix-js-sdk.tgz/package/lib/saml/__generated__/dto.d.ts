/**
 * DTO snippets extracted from the contract doc for `saml`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type SamlContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map