/** Routes served by the synapse-rust `saml` module (mirrored from the backend contract). */
export declare const SAML_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/saml/config";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/admin/v1/saml/config";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/saml/logout";
}, {
    readonly method: "DELETE";
    readonly path: "/_synapse/admin/v1/saml/mapping/{name_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/saml/mapping/{name_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/admin/v1/saml/mapping/{name_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/saml/mappings";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/saml/metadata/refresh";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/logout/saml";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/logout/saml/callback";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/login/saml/callback";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/login/saml/callback";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/login/sso/redirect/saml";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/saml/metadata";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/saml/sp_metadata";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/login/sso/redirect/saml";
}];
/** Union of every (method, path) tuple in `SAML_ROUTES`. */
export type SamlRoute = (typeof SAML_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type SamlMethod = SamlRoute["method"];
/** Path templates referenced by this module. */
export type SamlPath = SamlRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type SamlReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${SamlReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type SamlPathPattern = SamlReplaceBraces<SamlPath>;
//# sourceMappingURL=route-table.d.ts.map