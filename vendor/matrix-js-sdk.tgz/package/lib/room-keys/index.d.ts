/**
 * Room Keys Manager - 房间密钥请求管理
 *
 * 提供房间密钥请求相关功能
 * 对应后端: synapse-rust/src/web/routes/e2ee_routes.rs
 *
 * 后端端点:
 * - GET/POST /room_keys/request
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface RoomKeyRequest {
    request_id: string;
    room_id: string;
    session_id: string;
    device_id: string;
    state: "pending" | "approved" | "rejected";
    created_ts: number;
    updated_ts: number;
}
export interface RoomKeyRequestsResponse {
    requests: RoomKeyRequest[];
}
export interface CreateRoomKeyRequest {
    room_id: string;
    session_id: string;
    device_id?: string;
}
export declare class RoomKeysManager extends BaseManager {
    private requestsCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取房间密钥请求列表
     * GET /_matrix/client/v3/room_keys/request
     */
    getRoomKeyRequests(forceRefresh?: boolean): Promise<RoomKeyRequestsResponse>;
    /**
     * 创建房间密钥请求
     * POST /_matrix/client/v3/room_keys/request
     */
    createRoomKeyRequest(request: CreateRoomKeyRequest): Promise<void>;
    /**
     * 删除房间密钥请求
     * DELETE /_matrix/client/v3/room_keys/request/{request_id}
     *
     * @param requestId - 要删除的请求 ID
     * @throws {ValidationError} 如果 requestId 为空
     */
    deleteRoomKeyRequest(requestId: string): Promise<void>;
    clearCache(): void;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map