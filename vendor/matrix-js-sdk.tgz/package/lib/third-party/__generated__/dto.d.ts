/**
 * DTO snippets extracted from the contract doc for `third-party`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ProtocolsResponse {
    [protocol_id: string]: {
        user_fields: string[];
        location_fields: string[];
        icon: string;
        field_types: Record<string, {
            regexp: string;
            placeholder: string;
        }>;
        instances: Array<{
            network_id: string;
            fields: Record<string, string>;
        }>;
    };
}
export interface LocationResponse {
    alias: string;
    protocol: string;
    fields: Record<string, string>;
}
export interface UserResponse {
    userid: string;
    protocol: string;
    fields: Record<string, string>;
}
//# sourceMappingURL=dto.d.ts.map