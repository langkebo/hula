/** Routes served by the synapse-rust `third-party` module (mirrored from the backend contract). */
export declare const THIRDPARTY_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/thirdparty/location";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/thirdparty/location/{protocol}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/thirdparty/protocol/{protocol}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/thirdparty/protocols";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/thirdparty/user";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/thirdparty/user/{protocol}";
}];
/** Union of every (method, path) tuple in `THIRDPARTY_ROUTES`. */
export type ThirdpartyRoute = (typeof THIRDPARTY_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type ThirdpartyMethod = ThirdpartyRoute["method"];
/** Path templates referenced by this module. */
export type ThirdpartyPath = ThirdpartyRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type ThirdpartyReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${ThirdpartyReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type ThirdpartyPathPattern = ThirdpartyReplaceBraces<ThirdpartyPath>;
//# sourceMappingURL=route-table.d.ts.map