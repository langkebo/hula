import { MatrixClient, type IProtocol } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type ErrorHandlingOptions } from "../error/index.js";
import type { QueryDict } from "../http-api/utils";
/**
 * ThirdParty Manager - 第三方服务管理
 *
 * 提供第三方协议和 bridges 管理功能
 */
export interface ThirdPartyProtocol extends IProtocol {
    protocol: string;
}
export interface ThirdPartyLocation {
    alias: string;
    protocol: string;
    fields: Record<string, string>;
    info?: {
        [key: string]: unknown;
    };
}
export interface ThirdPartyUser {
    userid: string;
    protocol: string;
    fields: Record<string, string>;
    display_name?: string;
    avatar_url?: string;
}
export interface ThirdPartySearchParams {
    [key: string]: string;
}
export declare class ThirdPartyManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Get the third party protocols that can be reached using this HS.
     * GET /_matrix/client/v3/thirdparty/protocols
     */
    getThirdpartyProtocols(): Promise<{
        [protocol: string]: IProtocol;
    }>;
    /**
     * Get third party locations for a protocol.
     * GET /_matrix/client/v3/thirdparty/location/{protocol}
     */
    getThirdpartyLocation(protocol: string, params?: {
        searchFields?: string[];
    }): Promise<ThirdPartyLocation[]>;
    /**
     * Get third party users for a protocol.
     * GET /_matrix/client/v3/thirdparty/user/{protocol}
     */
    getThirdpartyUser(protocol: string, params?: QueryDict): Promise<ThirdPartyUser[]>;
    /**
     * 获取支持的第三方协议
     *
     * @param options - 错误处理选项；传入 `boolean` 时等价于 `{ throwOnError }`（默认 `{}`，即抛出错误）
     * @returns 第三方协议数组，每项包含协议名 `protocol` 及协议详情；请求失败且 `throwOnError` 为 false 时返回空数组
     *
     * @example
     * ```typescript
     * // 获取 homeserver 支持的全部第三方协议
     * const protocols = await thirdPartyManager.getProtocols();
     * for (const protocol of protocols) {
     *     console.log(`${protocol.protocol}: ${protocol.icon}`);
     * }
     *
     * // 失败时不抛出错误，返回空数组
     * const safeProtocols = await thirdPartyManager.getProtocols({ throwOnError: false });
     * ```
     *
     * @throws {SDKError} 当请求失败且 `throwOnError` 为 true（默认）时
     */
    getProtocols(options?: ErrorHandlingOptions | boolean): Promise<ThirdPartyProtocol[]>;
    /**
     * 获取指定第三方协议的详细信息
     *
     * @param protocol - 协议名称，取自 `getProtocols()` 返回项的 `protocol` 字段，例如 `"irc"`
     * @param options - 错误处理选项；传入 `boolean` 时等价于 `{ throwOnError }`（默认 `{}`，即抛出错误）
     * @returns 协议详情（包含协议名 `protocol`）；请求失败且 `throwOnError` 为 false 时返回 null
     *
     * @example
     * ```typescript
     * // 查询 irc 协议的字段定义
     * const protocol = await thirdPartyManager.getProtocol("irc");
     * if (protocol) {
     *     console.log(protocol.icon, protocol.location_fields);
     * }
     *
     * // 失败时返回 null 而不是抛出错误
     * const maybeProtocol = await thirdPartyManager.getProtocol("unknown", { throwOnError: false });
     * ```
     *
     * @throws {SDKError} 当请求失败且 `throwOnError` 为 true（默认）时
     */
    getProtocol(protocol: string, options?: ErrorHandlingOptions | boolean): Promise<ThirdPartyProtocol | null>;
    /**
     * 在指定第三方协议中按字段搜索位置
     *
     * @param protocol - 协议名称，例如 `"irc"`
     * @param params - 搜索字段键值对，字段名由该协议的 `location_fields` 定义，例如 `{ search_term: "Berlin" }`
     * @param throwOnError - 请求失败时是否抛出错误（默认 true；传 false 时记录警告并返回空数组）
     * @returns 匹配的第三方位置列表；失败且 `throwOnError` 为 false 时返回空数组
     *
     * @example
     * ```typescript
     * // 在 irc 协议中搜索名为 Berlin 的位置
     * const locations = await thirdPartyManager.searchLocations("irc", { search_term: "Berlin" });
     * for (const location of locations) {
     *     console.log(location.alias, location.fields);
     * }
     *
     * // 失败时返回空数组，不中断调用方
     * const safeLocations = await thirdPartyManager.searchLocations("irc", { search_term: "Berlin" }, false);
     * ```
     *
     * @throws {SdkError} 当请求失败且 `throwOnError` 为 true（默认）时
     */
    searchLocations(protocol: string, params: ThirdPartySearchParams, throwOnError?: boolean): Promise<ThirdPartyLocation[]>;
    /**
     * 在指定第三方协议中按字段搜索用户
     *
     * @param protocol - 协议名称，例如 `"irc"`
     * @param params - 搜索字段键值对，字段名由该协议的 `user_fields` 定义，例如 `{ userid: "@alice:example.org" }`
     * @param throwOnError - 请求失败时是否抛出错误（默认 true；传 false 时记录警告并返回空数组）
     * @returns 匹配的第三方用户列表；失败且 `throwOnError` 为 false 时返回空数组
     *
     * @example
     * ```typescript
     * // 在 irc 协议中按用户 ID 搜索
     * const users = await thirdPartyManager.searchUsers("irc", { userid: "@alice:example.org" });
     * for (const user of users) {
     *     console.log(user.userid, user.display_name);
     * }
     *
     * // 失败时返回空数组，不中断调用方
     * const safeUsers = await thirdPartyManager.searchUsers("irc", { userid: "@alice:example.org" }, false);
     * ```
     *
     * @throws {SdkError} 当请求失败且 `throwOnError` 为 true（默认）时
     */
    searchUsers(protocol: string, params: ThirdPartySearchParams, throwOnError?: boolean): Promise<ThirdPartyUser[]>;
    /**
     * 在所有第三方协议中按字段搜索位置
     *
     * @param params - 搜索字段键值对，例如 `{ search_term: "Berlin" }`（默认 `{}`）
     * @param options - 错误处理选项；传入 `boolean` 时等价于 `{ throwOnError }`（默认 `{}`，即抛出错误）
     * @returns 匹配的第三方位置列表；请求失败且 `throwOnError` 为 false 时返回空数组
     *
     * @example
     * ```typescript
     * // 跨协议搜索位置
     * const locations = await thirdPartyManager.searchAllLocations({ search_term: "Berlin" });
     * console.log(`${locations.length} location(s) found`);
     *
     * // 失败时不抛出错误，返回空数组
     * const safeLocations = await thirdPartyManager.searchAllLocations({ search_term: "Berlin" }, false);
     * ```
     *
     * @throws {SDKError} 当请求失败且 `throwOnError` 为 true（默认）时
     */
    searchAllLocations(params?: ThirdPartySearchParams, options?: ErrorHandlingOptions | boolean): Promise<ThirdPartyLocation[]>;
    /**
     * 在所有第三方协议中按字段搜索用户
     *
     * @param params - 搜索字段键值对，例如 `{ search_term: "alice" }`（默认 `{}`）
     * @param options - 错误处理选项；传入 `boolean` 时等价于 `{ throwOnError }`（默认 `{}`，即抛出错误）
     * @returns 匹配的第三方用户列表；请求失败且 `throwOnError` 为 false 时返回空数组
     *
     * @example
     * ```typescript
     * // 跨协议搜索用户
     * const users = await thirdPartyManager.searchAllUsers({ search_term: "alice" });
     * console.log(`${users.length} user(s) found`);
     *
     * // 失败时不抛出错误，返回空数组
     * const safeUsers = await thirdPartyManager.searchAllUsers({ search_term: "alice" }, false);
     * ```
     *
     * @throws {SDKError} 当请求失败且 `throwOnError` 为 true（默认）时
     */
    searchAllUsers(params?: ThirdPartySearchParams, options?: ErrorHandlingOptions | boolean): Promise<ThirdPartyUser[]>;
    /**
     * 获取位置别名信息
     */
    getLocation(alias: string): Promise<ThirdPartyLocation | null>;
    /**
     * 获取用户信息
     */
    getUser(userId: string): Promise<ThirdPartyUser | null>;
    /**
     * 解析第三方统一标识符
     */
    parseMatrixUri(uri: string): Promise<{
        type: "user" | "room" | "event";
        id: string;
        fields?: Record<string, unknown>;
    } | null>;
    /**
     * 生成第三方统一标识符
     */
    encodeMatrixUri(type: "user" | "room" | "event", id: string, params?: Record<string, string>): string;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map