/**
 * Invite Blocklist Manager - 邀请黑名单管理 (MSC4380)
 *
 * 提供房间邀请黑名单/白名单管理功能
 * 对应后端 API:
 * - GET /_matrix/client/v3/rooms/{room_id}/invite_blocklist - 获取邀请黑名单
 * - POST /_matrix/client/v3/rooms/{room_id}/invite_blocklist - 设置邀请黑名单
 * - GET /_matrix/client/v3/rooms/{room_id}/invite_allowlist - 获取邀请白名单
 * - POST /_matrix/client/v3/rooms/{room_id}/invite_allowlist - 设置邀请白名单
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
import { type InvitePermissionConfigContent } from "../@types/event";
export declare enum InviteBlocklistEvent {
    BlocklistUpdated = "BlocklistUpdated",
    AllowlistUpdated = "AllowlistUpdated",
    Error = "Error"
}
export interface IBlocklistResponse {
    blocklist: string[];
    blocked_users?: string[];
}
export interface IAllowlistResponse {
    allowlist: string[];
    allowed_users?: string[];
}
export interface IBlocklistResult {
    success: boolean;
    blocklist: string[];
    blocked_users?: string[];
}
export interface IAllowlistResult {
    success: boolean;
    allowlist: string[];
    allowed_users?: string[];
}
interface InviteBlocklistManagerEventMap {
    [InviteBlocklistEvent.BlocklistUpdated]: (blocklist: string[]) => void;
    [InviteBlocklistEvent.AllowlistUpdated]: (allowlist: string[]) => void;
    [InviteBlocklistEvent.Error]: (error: Error) => void;
}
export declare class InviteBlocklistManager extends BaseManager<InviteBlocklistEvent, InviteBlocklistManagerEventMap> {
    private blocklistCache;
    private allowlistCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Get invite blocklist for a room
     * GET /_matrix/client/v3/rooms/{room_id}/invite_blocklist
     */
    getBlocklist(roomId: string): Promise<string[]>;
    /**
     * Set invite blocklist for a room (room admin only)
     * POST /_matrix/client/v3/rooms/{room_id}/invite_blocklist
     */
    setBlocklist(roomId: string, userIds: string[]): Promise<IBlocklistResult>;
    /**
     * Add users to blocklist
     */
    addToBlocklist(roomId: string, userIds: string[]): Promise<IBlocklistResult>;
    /**
     * Remove users from blocklist
     */
    removeFromBlocklist(roomId: string, userIds: string[]): Promise<IBlocklistResult>;
    /**
     * Clear blocklist for a room
     */
    clearBlocklist(roomId: string): Promise<IBlocklistResult>;
    /**
     * Get invite allowlist for a room
     * GET /_matrix/client/v3/rooms/{room_id}/invite_allowlist
     */
    getAllowlist(roomId: string): Promise<string[]>;
    /**
     * Set invite allowlist for a room (room admin only)
     * POST /_matrix/client/v3/rooms/{room_id}/invite_allowlist
     */
    setAllowlist(roomId: string, userIds: string[]): Promise<IAllowlistResult>;
    /**
     * Add users to allowlist
     */
    addToAllowlist(roomId: string, userIds: string[]): Promise<IAllowlistResult>;
    /**
     * Remove users from allowlist
     */
    removeFromAllowlist(roomId: string, userIds: string[]): Promise<IAllowlistResult>;
    /**
     * Clear allowlist for a room
     */
    clearAllowlist(roomId: string): Promise<IAllowlistResult>;
    /**
     * Check if a user is blocked from being invited
     */
    isUserBlocked(roomId: string, userId: string): Promise<boolean>;
    /**
     * Check if a user is in the allowlist (only这些人可以邀请)
     */
    isUserAllowed(roomId: string, userId: string): Promise<boolean>;
    /**
     * Get the user's invite permission config (MSC4155).
     * Reads the global account data event `m.invite_permission_config`.
     *
     * **Draft — not implemented by synapse-rust.** The backend borrows the
     * `msc4155` namespace for its thread-subscription endpoints and does not
     * implement MSC4155 invite filtering, so this read is never served with a
     * meaningful value: an unset event 404s and is treated as "not configured"
     * (`null`). No invite filtering is applied server-side. See
     * `docs/MSC_SEMANTICS.md`.
     *
     * @returns the config content, or null if it is not set / cannot be read.
     * @example
     * ```typescript
     * const config = await client.getInviteBlocklistManager().getInvitePermissionConfig();
     * if (config?.default_action === "block") {
     *     console.log("invites blocked by default (client-side policy only)");
     * }
     * ```
     */
    getInvitePermissionConfig(): Promise<InvitePermissionConfigContent | null>;
    /**
     * Set the user's invite permission config (MSC4155).
     * Writes the global account data event `m.invite_permission_config`.
     *
     * **Draft — not implemented by synapse-rust.** The event is stored as
     * ordinary account data and the backend performs no invite filtering based
     * on it. See `docs/MSC_SEMANTICS.md`.
     *
     * @param content - the invite permission configuration to store.
     * @example
     * ```typescript
     * await client.getInviteBlocklistManager().setInvitePermissionConfig({
     *     default_action: "block",
     *     user_exceptions: { "@trusted:example.org": {} },
     * });
     * ```
     */
    setInvitePermissionConfig(content: InvitePermissionConfigContent): Promise<void>;
    /**
     * Get cached blocklist
     */
    getCachedBlocklist(roomId: string): string[];
    /**
     * Get cached allowlist
     */
    getCachedAllowlist(roomId: string): string[];
    /**
     * Clear cache for a room
     */
    clearCache(roomId?: string): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map