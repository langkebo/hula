/**
 * DTO snippets extracted from the contract doc for `invite-blocklist`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface IBlocklistResponse {
    blocklist: string[];
    /** 兼容字段（后端部分版本不回） */
    blocked_users?: string[];
}
export interface IAllowlistResponse {
    allowlist: string[];
    /** 兼容字段（后端部分版本不回） */
    allowed_users?: string[];
}
export interface IBlocklistResult {
    success: boolean;
    blocklist: string[];
    blocked_users?: string[];
}
export interface IAllowlistResult {
    success: boolean;
    allowlist: string[];
    allowed_users?: string[];
}
//# sourceMappingURL=dto.d.ts.map