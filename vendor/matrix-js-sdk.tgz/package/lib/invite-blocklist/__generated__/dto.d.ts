/**
 * DTO snippets extracted from the contract doc for `invite-blocklist`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type InviteBlocklistContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map