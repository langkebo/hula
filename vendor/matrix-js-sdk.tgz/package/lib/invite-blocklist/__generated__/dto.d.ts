/**
 * DTO snippets extracted from the contract doc for `invite-blocklist`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface IBlocklistResponse {
    blocklist: string[];
    /** 同一份名单的第二个键：后端 `get_invite_blocklist` 两个键**都发**（值相同） */
    blocked_users: string[];
}
export interface IAllowlistResponse {
    allowlist: string[];
    /** 同 `IBlocklistResponse.blocked_users`：后端两个键都发 */
    allowed_users: string[];
}
export interface IBlocklistUpsertResponse {
    room_id: string;
    blocklist: string[];
    blocked_users: string[];
    updated_ts: number;
}
export interface IAllowlistUpsertResponse {
    room_id: string;
    allowlist: string[];
    allowed_users: string[];
    updated_ts: number;
}
export interface IBlocklistResult {
    success: boolean;
    blocklist: string[];
    blocked_users?: string[];
}
export interface IAllowlistResult {
    success: boolean;
    allowlist: string[];
    allowed_users?: string[];
}
//# sourceMappingURL=dto.d.ts.map