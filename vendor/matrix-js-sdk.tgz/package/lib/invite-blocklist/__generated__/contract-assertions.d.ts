export declare const INVITE_BLOCKLIST_ROUTES_ENTRY_COUNT: 4;
export declare const INVITE_BLOCKLIST_ROUTES_STATUS_SCENARIOS: readonly [];
export type InviteBlocklistStatusScenario = (typeof INVITE_BLOCKLIST_ROUTES_STATUS_SCENARIOS)[number];
export declare const INVITE_BLOCKLIST_ROUTES_ERROR_SCENARIOS: readonly [];
export type InviteBlocklistErrorScenario = (typeof INVITE_BLOCKLIST_ROUTES_ERROR_SCENARIOS)[number];
export declare const INVITE_BLOCKLIST_ROUTES_ERRCODES: readonly [];
export type InviteBlocklistErrcode = (typeof INVITE_BLOCKLIST_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map