export declare const TELEMETRY_ROUTES_ENTRY_COUNT: 6;
export declare const TELEMETRY_ROUTES_STATUS_SCENARIOS: readonly [];
export type TelemetryStatusScenario = (typeof TELEMETRY_ROUTES_STATUS_SCENARIOS)[number];
export declare const TELEMETRY_ROUTES_ERROR_SCENARIOS: readonly [];
export type TelemetryErrorScenario = (typeof TELEMETRY_ROUTES_ERROR_SCENARIOS)[number];
export declare const TELEMETRY_ROUTES_ERRCODES: readonly [];
export type TelemetryErrcode = (typeof TELEMETRY_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map