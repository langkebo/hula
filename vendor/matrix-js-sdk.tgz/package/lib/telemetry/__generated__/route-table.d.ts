/** Routes served by the synapse-rust `telemetry` module (mirrored from the backend contract). */
export declare const TELEMETRY_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/telemetry/alerts";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/telemetry/alerts/{alert_id}/ack";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/telemetry/attributes";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/telemetry/health";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/telemetry/metrics";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/telemetry/status";
}];
/** Union of every (method, path) tuple in `TELEMETRY_ROUTES`. */
export type TelemetryRoute = (typeof TELEMETRY_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type TelemetryMethod = TelemetryRoute["method"];
/** Path templates referenced by this module. */
export type TelemetryPath = TelemetryRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type TelemetryReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${TelemetryReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type TelemetryPathPattern = TelemetryReplaceBraces<TelemetryPath>;
//# sourceMappingURL=route-table.d.ts.map