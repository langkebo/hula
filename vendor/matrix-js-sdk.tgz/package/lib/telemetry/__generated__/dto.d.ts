/**
 * DTO snippets extracted from the contract doc for `telemetry`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ServerTelemetryStatus {
    enabled: boolean;
    trace_enabled: boolean;
    metrics_enabled: boolean;
    service_name: string;
    service_version: string;
    sampling_ratio: number;
    export_config: {
        otlp_endpoint?: string | null;
        prometheus_port?: number | null;
        prometheus_path?: string | null;
        batch_export: boolean;
    };
}
export interface ServerTelemetryAttributes {
    attributes: Record<string, string>;
}
export interface ServerTelemetryMetricsSummary {
    total_metrics: number;
    total_counters: number;
    total_gauges: number;
    total_histograms: number;
    rendered_bytes: number;
    snapshot_ts: number;
}
export interface ServerTelemetryAlert {
    alert_id: string;
    alert_key: string;
    severity: string;
    status: string;
    title?: string;
    message?: string;
    created_at_ms?: number;
    updated_at_ms?: number;
    acknowledged_by?: string | null;
    acknowledged_at_ms?: number | null;
    metadata?: Record<string, unknown>;
}
export interface ServerTelemetryHealth {
    status: string;
    service: string;
    trace_enabled: boolean;
    metrics_enabled: boolean;
    checks: Array<Record<string, unknown>>;
    database: Record<string, unknown>;
    alerts: ServerTelemetryAlert[];
}
//# sourceMappingURL=dto.d.ts.map