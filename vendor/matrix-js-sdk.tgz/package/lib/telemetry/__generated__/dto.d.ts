/**
 * DTO snippets extracted from the contract doc for `telemetry`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface TelemetryStatus {
    enabled: boolean;
    collection_interval_ms: number;
    last_collection_ts: number;
}
export interface TelemetryAttributes {
    server_name: string;
    server_version: string;
    python_version: string;
    database_engine: string;
    database_version: string;
}
export interface TelemetryMetrics {
    metrics: Array<{
        name: string;
        value: number;
        timestamp: number;
        labels?: Record<string, string>;
    }>;
}
export interface TelemetryAlerts {
    alerts: Array<{
        id: string;
        severity: string;
        message: string;
        created_ts: number;
        acknowledged: boolean;
    }>;
}
export interface HealthStatus {
    healthy: boolean;
    checks: Array<{
        name: string;
        status: string;
        message?: string;
    }>;
}
export type TelemetryResponseDto = Record<string, never>;
//# sourceMappingURL=dto.d.ts.map