import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface TelemetryEvent {
    event: string;
    timestamp: number;
    data?: Record<string, unknown>;
}
export interface TelemetryConfig {
    enabled: boolean;
    endpoint?: string;
    sampleRate?: number;
}
export interface UsageStats {
    messagesSent: number;
    messagesReceived: number;
    roomsJoined: number;
    callsMade: number;
    mediaUploaded: number;
    lastActive: number;
}
export interface ClientMetrics {
    version: string;
    platform: string;
    runtime: string;
    features: string[];
}
export interface ServerTelemetryStatus {
    enabled: boolean;
    trace_enabled: boolean;
    metrics_enabled: boolean;
    service_name: string;
    service_version: string;
    sampling_ratio: number;
    export_config: {
        otlp_endpoint?: string | null;
        prometheus_port?: number | null;
        prometheus_path?: string | null;
        batch_export: boolean;
    };
}
export interface ServerTelemetryAttributes {
    attributes: Record<string, string>;
}
export interface ServerTelemetryMetricsSummary {
    total_metrics: number;
    total_counters: number;
    total_gauges: number;
    total_histograms: number;
    rendered_bytes: number;
    snapshot_ts: number;
}
export interface ServerTelemetryAlert {
    alert_id: string;
    alert_key: string;
    severity: string;
    status: string;
    title?: string;
    message?: string;
    created_at_ms?: number;
    updated_at_ms?: number;
    acknowledged_by?: string | null;
    acknowledged_at_ms?: number | null;
    metadata?: Record<string, unknown>;
}
export interface ServerTelemetryAlertsResponse {
    alerts: ServerTelemetryAlert[];
}
export interface TelemetryCheckResult {
    status: string;
    message: string;
    duration_ms: number;
}
export interface ConnectionPoolTelemetry {
    total_connections: number;
    idle_connections: number;
    busy_connections: number;
    max_connections: number;
    connection_utilization: number;
}
export interface DatabasePerformanceMetrics {
    average_query_time_ms: number;
    slow_queries_count: number;
    total_queries: number;
    transactions_per_second: number;
    cache_hit_ratio: number;
    deadlock_count: number;
    redis_latency_ms: number;
    redis_slow_commands_count: number;
}
export interface DatabaseTelemetry {
    is_healthy: boolean;
    connection_pool_status: ConnectionPoolTelemetry;
    performance_metrics: DatabasePerformanceMetrics;
    last_checked: string;
}
export interface ServerTelemetryHealth {
    status: string;
    service: string;
    trace_enabled: boolean;
    metrics_enabled: boolean;
    checks: Record<string, TelemetryCheckResult>;
    database: DatabaseTelemetry;
    alerts: ServerTelemetryAlert[];
}
export interface ServerTelemetryAlertQuery {
    status?: string;
    severity?: string;
    refresh?: boolean;
}
export interface TelemetryManagerEvents {
    telemetry_enabled: void;
    telemetry_disabled: void;
    telemetry_flushed: {
        count: number;
    };
}
export declare class TelemetryManager extends BaseManager<keyof TelemetryManagerEvents, TelemetryManagerEvents> {
    private config;
    private eventQueue;
    private sessionStart;
    private stats;
    constructor(client: MatrixClient, config?: Partial<TelemetryConfig>, opts?: ManagerOpts);
    configure(config: Partial<TelemetryConfig>): void;
    enable(): void;
    disable(): void;
    isEnabled(): boolean;
    track(event: string, data?: Record<string, unknown>): void;
    trackMessageSent(roomId: string, type: string): void;
    trackMessageReceived(roomId: string, type: string): void;
    trackRoomJoined(roomId: string): void;
    trackCall(type: "voice" | "video"): void;
    trackMediaUploaded(size: number, type: string): void;
    trackError(error: Error, context?: Record<string, unknown>): void;
    getClientInfo(): ClientMetrics;
    private getPlatform;
    private getRuntime;
    private getEnabledFeatures;
    getUsageStats(): UsageStats;
    getSessionDuration(): number;
    getPendingEvents(): TelemetryEvent[];
    getServerStatus(): Promise<ServerTelemetryStatus>;
    getServerAttributes(): Promise<ServerTelemetryAttributes>;
    getServerMetricsSummary(): Promise<ServerTelemetryMetricsSummary>;
    getServerAlerts(query?: ServerTelemetryAlertQuery): Promise<ServerTelemetryAlertsResponse>;
    acknowledgeServerAlert(alertId: string): Promise<ServerTelemetryAlert>;
    getServerHealth(): Promise<ServerTelemetryHealth>;
    flush(): void;
    private sendToServer;
    resetStats(): void;
    stop(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map