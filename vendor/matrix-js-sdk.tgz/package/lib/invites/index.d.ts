/**
 * Invites Manager - 邀请管理
 *
 * 提供邀请相关功能
 */
import { MatrixClient } from "../client";
import { MatrixEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IInviteEvent {
    roomId: string;
    sender: string;
    timestamp: number;
    event: MatrixEvent;
}
export interface IInviteResponse {
    room_id: string;
}
export interface InvitesManagerEvents {
    invite_received: {
        roomId: string;
        sender: string;
    };
    invite_accepted: {
        roomId: string;
    };
    invite_declined: {
        roomId: string;
    };
}
export declare class InvitesManager extends BaseManager<keyof InvitesManagerEvents, InvitesManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    inviteByThreePid(medium: string, address: string, roomId: string): Promise<IInviteResponse>;
    inviteUserToRoom(userId: string, roomId: string): Promise<IInviteResponse>;
    getInviteEvents(): IInviteEvent[];
    hasInvite(roomId: string): boolean;
    acceptInvite(roomId: string): Promise<IInviteResponse>;
    declineInvite(roomId: string): Promise<IInviteResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map