/**
 * Re-export aggregator for internal request builders used by MatrixClient.
 *
 * Only re-exports that are actually consumed by `src/client.ts` are listed here.
 * Other request builders in `client-*-requests.ts` files have been superseded
 * by manager methods and are no longer re-exported; they remain in their source
 * files for backwards compatibility but are not part of the active call graph.
 */
export { getJoinedRoomMembersRequest, getJoinedRoomsRequest, getOpenIdTokenRequest, membersRequest, publicRoomsRequest, } from "./client-batch-requests";
export { deleteRoomKeyRequestHttpRequest, getRoomKeyRequestsHttpRequest, requestRoomKeyHttpRequest, } from "./client-crypto-requests";
export { timestampToEventRequest } from "./client-room-discovery-requests";
export { createSecureBackupRequest, deleteSecureBackupRequest, getClientConfigRequest, getSSOUserInfoRequest, getSecureBackupRequest, restoreSecureBackupRequest, storeSecureBackupKeysRequest, verifySecureBackupPassphraseRequest, } from "./client-secure-backup-requests";
//# sourceMappingURL=client-request-delegates.d.ts.map