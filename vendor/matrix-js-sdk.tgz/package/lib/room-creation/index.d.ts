/**
 * Room Creation Manager - 房间创建管理
 *
 * 提供房间创建相关功能
 */
import { MatrixClient } from "../client";
import { type IContent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ICreateRoomOptions {
    room_alias_name?: string;
    visibility?: "public" | "private";
    invite?: string[];
    invite_3pid?: Array<{
        id_server: string;
        id_access_token: string;
        medium: string;
        address: string;
    }>;
    room_version?: string;
    creation_content?: IContent;
    initial_state?: Array<{
        type: string;
        state_key?: string;
        content: IContent;
    }>;
    preset?: "private_chat" | "public_chat" | "trusted_private_chat";
    is_direct?: boolean;
    name?: string;
    topic?: string;
    power_level_content_override?: IContent;
}
export interface ICreateRoomResponse {
    room_id: string;
}
export interface ICreateRoomOptionsConfig extends ICreateRoomOptions {
    [key: string]: unknown;
}
export interface RoomCreationManagerEvents {
    room_created: {
        roomId: string;
    };
    room_creation_failed: {
        error: Error;
    };
    direct_room_created: {
        roomId: string;
        userId: string;
    };
}
export declare class RoomCreationManager extends BaseManager<keyof RoomCreationManagerEvents, RoomCreationManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    createRoom(options?: ICreateRoomOptions): Promise<ICreateRoomResponse>;
    createDirectRoom(userId: string, options?: ICreateRoomOptions): Promise<ICreateRoomResponse>;
    findOrCreateDirectRoom(userId: string): Promise<ICreateRoomResponse>;
    getCreateRoomOptions(): ICreateRoomOptionsConfig;
    setCreateRoomOptions(options: ICreateRoomOptionsConfig): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map