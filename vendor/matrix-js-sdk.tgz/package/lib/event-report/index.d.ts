/**
 * Event Report Manager - 事件举报管理
 *
 * 提供事件举报的创建、查询、处理（解决、忽略、升级）、删除及统计功能。
 * 对应后端: synapse-rust/src/web/routes/event_report.rs
 *
 * 遵循 D7 契约驱动开发标准，按最新 ledger 绑定调用路径。
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IContent } from "../models/event";
export type ReportStatus = "open" | "resolved" | "dismissed" | "escalated" | string;
export interface CreateReportBody {
    event_id: string;
    room_id: string;
    reported_user_id?: string;
    event_json?: IContent;
    reason?: string;
    description?: string;
    score?: number;
}
export interface UpdateReportBody {
    status?: ReportStatus;
    score?: number;
}
export interface ReportResponse {
    id: number;
    event_id: string;
    room_id: string;
    reporter_user_id: string;
    reported_user_id?: string;
    reason?: string;
    description?: string;
    status: ReportStatus;
    score: number;
    received_ts: number;
    resolved_ts?: number;
    resolved_by?: string;
    resolution_reason?: string;
    canonical_alias?: string;
    event_json?: IContent;
    sender?: string;
}
export interface ReportHistoryResponse {
    id: number;
    report_id: number;
    action: string;
    actor_user_id?: string;
    old_status?: string;
    new_status?: string;
    reason?: string;
    created_ts: number;
}
export interface ResolveReportBody {
    resolution_reason?: string;
}
export interface DismissReportBody {
    reason?: string;
}
export interface EscalateReportBody {
    reason?: string;
}
export interface RateLimitResponse {
    blocked: boolean;
    user_id: string;
    reason?: string;
    blocked_at?: number;
}
export interface QueryParams {
    limit?: number;
    since_score?: number;
    since_ts?: number;
    since_id?: number;
}
export interface StatsResponse {
    total: number;
    open: number;
    resolved: number;
    dismissed: number;
    escalated: number;
}
export interface StatusCountResponse {
    status: string;
    count: number;
}
export interface EventReportCountResponse {
    total_reports?: number;
    status?: string;
    count?: number;
}
/**
 * EventReportManager 处理事件举报流程。
 * 对应后端 `event_report.rs` 中的所有 Admin REST 端点。
 */
export declare class EventReportManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    private buildQueryParams;
    /**
     * 创建举报
     * 对应 POST /_synapse/admin/v1/event_reports
     *
     * @example
     * ```typescript
     * const report = await client.getEventReportManager().createReport({
     *     event_id: "$event:example.org",
     *     room_id: "!room:example.org",
     *     reason: "spam",
     * });
     * console.log(report.id, report.status);
     * ```
     */
    createReport(body: CreateReportBody): Promise<ReportResponse>;
    /**
     * 获取所有举报
     * 对应 GET /_synapse/admin/v1/event_reports
     */
    getAllReports(params?: QueryParams): Promise<ReportResponse[]>;
    /**
     * 列出举报
     * 对应 GET /_synapse/admin/v1/event_reports
     *
     * @example
     * ```typescript
     * const reports = await client.getEventReportManager().listReports({ limit: 20, since_id: 100 });
     * console.log(`fetched ${reports.length} reports`);
     * ```
     */
    listReports(params?: QueryParams): Promise<ReportResponse[]>;
    /**
     * 获取举报总数
     * 对应 GET /_synapse/admin/v1/event_reports/count
     *
     * @example
     * ```typescript
     * const count = await client.getEventReportManager().getReportsCount();
     * console.log(`total reports: ${count.total_reports}`);
     * ```
     */
    getReportsCount(): Promise<EventReportCountResponse>;
    /**
     * 获取举报详情
     * 对应 GET /_synapse/admin/v1/event_reports/{id}
     *
     * @example
     * ```typescript
     * const report = await client.getEventReportManager().getReport(42);
     * console.log(report.event_id, report.status, report.score);
     * ```
     */
    getReport(id: number): Promise<ReportResponse>;
    /**
     * 按事件查询举报
     * 对应 GET /_synapse/admin/v1/event_reports/event/{event_id}
     *
     * @example
     * ```typescript
     * const reports = await client.getEventReportManager().getReportsByEvent("$event:example.org");
     * console.log(reports.map((r) => r.id));
     * ```
     */
    getReportsByEvent(eventId: string): Promise<ReportResponse[]>;
    /**
     * 按房间查询举报
     * 对应 GET /_synapse/admin/v1/event_reports/room/{room_id}
     *
     * @example
     * ```typescript
     * const reports = await client.getEventReportManager().getReportsByRoom("!room:example.org", {
     *     limit: 50,
     * });
     * console.log(reports.length);
     * ```
     */
    getReportsByRoom(roomId: string, params?: QueryParams): Promise<ReportResponse[]>;
    /**
     * 按举报人查询举报
     * 对应 GET /_synapse/admin/v1/event_reports/reporter/{reporter_user_id}
     *
     * @example
     * ```typescript
     * const reports = await client
     *     .getEventReportManager()
     *     .getReportsByReporter("@alice:example.org", { limit: 10 });
     * console.log(reports.length);
     * ```
     */
    getReportsByReporter(reporterUserId: string, params?: QueryParams): Promise<ReportResponse[]>;
    /**
     * 按状态查询举报
     * 对应 GET /_synapse/admin/v1/event_reports/status/{status}
     *
     * @example
     * ```typescript
     * const openReports = await client
     *     .getEventReportManager()
     *     .getReportsByStatus("open", { limit: 100 });
     * console.log(openReports.length);
     * ```
     */
    getReportsByStatus(status: ReportStatus, params?: QueryParams): Promise<ReportResponse[]>;
    /**
     * 按状态获取举报计数
     * 对应 GET /_synapse/admin/v1/event_reports/status/{status}/count
     *
     * @example
     * ```typescript
     * const { status, count } = await client.getEventReportManager().getStatusCount("resolved");
     * console.log(`${status}: ${count}`);
     * ```
     */
    getStatusCount(status: ReportStatus): Promise<StatusCountResponse>;
    /**
     * 更新举报
     * 对应 PUT /_synapse/admin/v1/event_reports/{id}
     *
     * @example
     * ```typescript
     * const updated = await client
     *     .getEventReportManager()
     *     .updateReport(42, { status: "open", score: 5 });
     * console.log(updated.status, updated.score);
     * ```
     */
    updateReport(id: number, body: UpdateReportBody): Promise<ReportResponse>;
    /**
     * 解决举报
     * 对应 POST /_synapse/admin/v1/event_reports/{id}/resolve
     *
     * @example
     * ```typescript
     * const resolved = await client
     *     .getEventReportManager()
     *     .resolveReport(42, { resolution_reason: "confirmed spam" });
     * console.log(resolved.status);
     * ```
     */
    resolveReport(id: number, body?: ResolveReportBody): Promise<ReportResponse>;
    /**
     * 驳回举报
     * 对应 POST /_synapse/admin/v1/event_reports/{id}/dismiss
     *
     * @example
     * ```typescript
     * const dismissed = await client
     *     .getEventReportManager()
     *     .dismissReport(42, { reason: "not a violation" });
     * console.log(dismissed.status);
     * ```
     */
    dismissReport(id: number, body?: DismissReportBody): Promise<ReportResponse>;
    /**
     * 升级举报
     * 对应 POST /_synapse/admin/v1/event_reports/{id}/escalate
     *
     * @example
     * ```typescript
     * const escalated = await client
     *     .getEventReportManager()
     *     .escalateReport(42, { reason: "needs senior review" });
     * console.log(escalated.status);
     * ```
     */
    escalateReport(id: number, body?: EscalateReportBody): Promise<ReportResponse>;
    /**
     * 删除举报
     * 对应 DELETE /_synapse/admin/v1/event_reports/{id}
     *
     * @example
     * ```typescript
     * await client.getEventReportManager().deleteReport(42);
     * console.log("report deleted");
     * ```
     */
    deleteReport(id: number): Promise<void>;
    /**
     * 获取举报历史
     * 对应 GET /_synapse/admin/v1/event_reports/{id}/history
     *
     * @example
     * ```typescript
     * const history = await client.getEventReportManager().getReportHistory(42);
     * console.log(history.map((entry) => `${entry.action}: ${entry.new_status}`));
     * ```
     */
    getReportHistory(id: number): Promise<ReportHistoryResponse[]>;
    /**
     * 获取举报统计
     * 对应 GET /_synapse/admin/v1/event_reports/stats
     *
     * @example
     * ```typescript
     * const stats = await client.getEventReportManager().getStats();
     * console.log(`open: ${stats.open}, resolved: ${stats.resolved}, total: ${stats.total}`);
     * ```
     */
    getStats(): Promise<StatsResponse>;
    /**
     * 查询用户频率限制状态
     * 对应 GET /_synapse/admin/v1/event_reports/rate_limit/{user_id}
     *
     * @example
     * ```typescript
     * const limit = await client.getEventReportManager().checkRateLimit("@alice:example.org");
     * if (!limit.is_allowed) {
     *     console.log(`blocked: ${limit.block_reason}`);
     * }
     * ```
     */
    checkRateLimit(userId: string): Promise<{
        is_allowed: boolean;
        remaining_reports: number;
        block_reason?: string;
    }>;
    /**
     * 封禁用户举报频率
     * 对应 POST /_synapse/admin/v1/event_reports/rate_limit/{user_id}/block
     *
     * @example
     * ```typescript
     * const blockedUntil = Date.now() + 24 * 60 * 60 * 1000;
     * await client.getEventReportManager().blockUser("@alice:example.org", blockedUntil, "report flooding");
     * ```
     */
    blockUser(userId: string, blockedUntil: number, reason: string): Promise<void>;
    /**
     * 解封用户举报频率
     * 对应 POST /_synapse/admin/v1/event_reports/rate_limit/{user_id}/unblock
     *
     * @example
     * ```typescript
     * await client.getEventReportManager().unblockUser("@alice:example.org");
     * console.log("user unblocked");
     * ```
     */
    unblockUser(userId: string): Promise<void>;
}
/** @internal */
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map