/** Routes served by the synapse-rust `event-report` module (mirrored from the backend contract). */
export declare const EVENT_REPORT_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/event_reports";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/count";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/event/{event_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/rate_limit/{user_id}";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/event_reports/rate_limit/{user_id}/block";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/event_reports/rate_limit/{user_id}/unblock";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/reporter/{reporter_user_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/room/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/stats";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/status/{status}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/status/{status}/count";
}, {
    readonly method: "DELETE";
    readonly path: "/_synapse/admin/v1/event_reports/{id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/{id}";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/admin/v1/event_reports/{id}";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/event_reports/{id}/dismiss";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/event_reports/{id}/escalate";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/admin/v1/event_reports/{id}/history";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/admin/v1/event_reports/{id}/resolve";
}];
/** Union of every (method, path) tuple in `EVENT_REPORT_ROUTES`. */
export type EventReportRoute = (typeof EVENT_REPORT_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type EventReportMethod = EventReportRoute["method"];
/** Path templates referenced by this module. */
export type EventReportPath = EventReportRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type EventReportReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${EventReportReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type EventReportPathPattern = EventReportReplaceBraces<EventReportPath>;
//# sourceMappingURL=route-table.d.ts.map