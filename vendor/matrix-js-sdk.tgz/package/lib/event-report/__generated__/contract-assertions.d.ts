export declare const EVENT_REPORT_ROUTES_ENTRY_COUNT: 19;
export declare const EVENT_REPORT_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "补齐 EventReportManager 缺失端点并增加单测 | SDK 覆盖率提升至 100%";
}];
export type EventReportStatusScenario = (typeof EVENT_REPORT_ROUTES_STATUS_SCENARIOS)[number];
export declare const EVENT_REPORT_ROUTES_ERROR_SCENARIOS: readonly [];
export type EventReportErrorScenario = (typeof EVENT_REPORT_ROUTES_ERROR_SCENARIOS)[number];
export declare const EVENT_REPORT_ROUTES_ERRCODES: readonly [];
export type EventReportErrcode = (typeof EVENT_REPORT_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map