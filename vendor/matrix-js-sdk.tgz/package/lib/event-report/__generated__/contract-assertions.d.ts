export declare const EVENT_REPORT_ROUTES_ENTRY_COUNT: 18;
export declare const EVENT_REPORT_ROUTES_STATUS_SCENARIOS: readonly [];
export type EventReportStatusScenario = (typeof EVENT_REPORT_ROUTES_STATUS_SCENARIOS)[number];
export declare const EVENT_REPORT_ROUTES_ERROR_SCENARIOS: readonly [];
export type EventReportErrorScenario = (typeof EVENT_REPORT_ROUTES_ERROR_SCENARIOS)[number];
export declare const EVENT_REPORT_ROUTES_ERRCODES: readonly [];
export type EventReportErrcode = (typeof EVENT_REPORT_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map