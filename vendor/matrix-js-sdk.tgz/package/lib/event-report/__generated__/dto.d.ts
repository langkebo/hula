/**
 * DTO snippets extracted from the contract doc for `event_report`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface EventReportsResponse {
    event_reports: Array<{
        id: number;
        received_ts: number;
        room_id: string;
        event_id: string;
        user_id: string;
        reason?: string;
        score?: number;
        sender: string;
    }>;
    next_token?: number;
    total: number;
}
export interface EventReportDetail {
    id: number;
    received_ts: number;
    room_id: string;
    event_id: string;
    user_id: string;
    reason?: string;
    score?: number;
    sender: string;
    canonical_alias?: string;
    event_json: object;
}
export type EventReportResponseDto = Record<string, never>;
//# sourceMappingURL=dto.d.ts.map