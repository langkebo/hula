/**
 * Media Manager - 媒体管理
 *
 * 提供媒体上传、下载、删除、URL预览功能
 */
import { MatrixClient } from "../client";
import type { UploadResponse } from "../http-api/interface";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IMediaConfig } from "../client-internal-types";
export interface UrlPreview {
    url?: string;
    title?: string;
    description?: string;
    image_url?: string;
    image?: string;
    og_image?: string;
    "matrix:image"?: string;
}
export interface MediaDownloadUrlOptions {
    filename?: string;
    allowDirectLinks?: boolean;
    allowRedirects?: boolean;
    useAuthentication?: boolean;
    version?: "v1" | "v3" | "r1";
    signature?: string;
    timestamp?: number;
}
export interface MediaThumbnailUrlOptions {
    width?: number;
    height?: number;
    method?: "crop" | "scale";
    allowDirectLinks?: boolean;
    allowRedirects?: boolean;
    useAuthentication?: boolean;
    animated?: boolean;
    signature?: string;
    timestamp?: number;
}
export interface UploadProviderInfo {
    provider: string;
    supports_chunked_upload: boolean;
    supports_resume: boolean;
    max_file_size: number;
    chunk_size: number;
}
export interface UploadTokenResponse {
    upload_token: string;
    storage_type: string;
    upload_url: string;
    filename: string;
    content_type: string;
    max_file_size: number;
}
export interface MediaQuotaCheckResponse {
    limit: number;
    used: number;
    remaining: number;
    rule: string;
}
export interface MediaQuotaStatsResponse {
    user_id: string;
    storage_bytes: number;
    media_count: number;
    limit_bytes: number;
    statistics: Record<string, unknown>;
}
export interface MediaQuotaAlert {
    alert_id: string;
    alert_type: "quota_warning" | "quota_exceeded";
    threshold_percent: number;
    current_usage_bytes: number;
    quota_limit_bytes: number;
    message: string;
    created_ts: number;
    is_read: boolean;
}
export interface MediaQuotaAlertsResponse {
    alerts: MediaQuotaAlert[];
}
export interface ChunkUploadStartRequest {
    filename: string;
    content_type: string;
    total_size?: number;
}
export interface ChunkUploadStartResponse {
    upload_id: string;
    [key: string]: unknown;
}
export interface ChunkUploadRequest {
    upload_id: string;
    chunk_index: number;
    data: ArrayBuffer | Blob;
}
export interface ChunkUploadResponse {
    upload_id: string;
    chunk_index: number;
    received_bytes: number;
    [key: string]: unknown;
}
export interface ChunkUploadCompleteResponse {
    upload_id: string;
    content_uri: string;
    [key: string]: unknown;
}
export interface ChunkUploadCancelResponse {
    upload_id: string;
    cancelled: boolean;
    [key: string]: unknown;
}
export interface ChunkUploadProgressResponse {
    upload_id: string;
    total_chunks: number;
    received_chunks: number;
    bytes_received: number;
    total_bytes: number;
    [key: string]: unknown;
}
export declare class MediaManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Get the media config for the homeserver.
     * GET /_matrix/client/v1/media/config (authenticated) or GET /_matrix/media/v3/config (unauthenticated)
     *
     * @param useAuthenticatedMedia - Whether to use the authenticated media endpoint.
     * Note that the server's support for authenticated media will *not* be checked -
     * it is the caller's responsibility to do so before calling this function.
     * @returns Promise which resolves with an object containing the config.
     */
    getMediaConfig(useAuthenticatedMedia?: boolean): Promise<IMediaConfig>;
    /**
     * Get the upload provider configuration for the homeserver.
     * GET /_matrix/client/v3/upload/provider
     *
     * Returns information about the server's media upload capabilities,
     * including supported upload modes and size limits.
     */
    getUploadProvider(): Promise<UploadProviderInfo>;
    /**
     * Request an upload token from the homeserver.
     * POST /_matrix/client/v3/upload/token
     *
     * @param filename - The name of the file to upload.
     * @param contentType - The MIME type of the file.
     * @returns Upload token and related metadata for the upload session.
     */
    getUploadToken(filename: string, contentType: string): Promise<UploadTokenResponse>;
    /**
     * 上传媒体内容
     *
     * @param file - 文件内容（File, Blob 或 ArrayBuffer）
     * @param opts - 上传选项
     * @param opts.name - 文件名（可选）
     * @param opts.type - MIME 类型（可选）
     * @param opts.progress - 进度回调（可选）
     * @returns 包含 content_uri 的对象
     *
     * @example
     * ```typescript
     * // 上传文件
     * const file = document.querySelector('input[type="file"]').files[0];
     * const result = await mediaManager.uploadContent(file);
     * console.log("Uploaded:", result.content_uri);
     *
     * // 带进度回调
     * const result = await mediaManager.uploadContent(file, {
     *     progress: ({ loaded, total }) => {
     *         console.log(`Progress: ${(loaded / total * 100).toFixed(2)}%`);
     *     }
     * });
     *
     * // 上传 Blob
     * const blob = new Blob(['Hello, world!'], { type: 'text/plain' });
     * const result = await mediaManager.uploadContent(blob, {
     *     name: 'hello.txt',
     *     type: 'text/plain'
     * });
     * ```
     *
     * @throws {ValidationError} 如果文件为空
     * @throws {ApiError} 如果上传失败
     */
    uploadContent(file: File | Blob | ArrayBuffer, opts?: {
        name?: string;
        type?: string;
        progress?: (progress: {
            loaded: number;
            total: number;
        }) => void;
    }): Promise<{
        content_uri: string;
    }>;
    /**
     * ISSUE-07: 上传前消费 `m.upload.size` 做客户端预检——超限直接抛
     * M_TOO_LARGE，而不是等服务器拒绝后得到难以识别的错误。
     * 预检失败（配置拉取异常）不阻断上传，由服务端兜底。
     */
    private uploadContentWithPrecheck;
    private uploadSizeLimitCache?;
    private getCachedUploadSizeLimit;
    /**
     * Upload content with a specific media ID
     * PUT /_matrix/media/v3/upload/{server_name}/{media_id}
     */
    uploadContentWithId(serverName: string, mediaId: string, content: ArrayBuffer | Blob, contentType: string): Promise<{
        content_uri: string;
    }>;
    /**
     * Cancel an upload
     */
    cancelUpload(upload: Promise<UploadResponse>): boolean;
    getCurrentUploads(): Array<{
        loaded: number;
        total: number;
        promise: Promise<UploadResponse>;
    }>;
    /**
     * Get content repository URI
     */
    getHomeserverUrl(): string;
    /**
     * Get content repository URI
     */
    getContentRepositoryUri(): string | null;
    /**
     * Delete media
     * POST /_matrix/media/v1/delete/{server_name}/{media_id}
     */
    deleteMedia(serverName: string, mediaId: string): Promise<void>;
    /**
     * 获取 URL 预览
     *
     * @param url - 要预览的 URL
     * @param ts - 时间戳（可选，用于缓存控制）
     * @returns URL 预览信息
     *
     * @example
     * ```typescript
     * // 获取 URL 预览
     * const preview = await mediaManager.previewUrl("https://example.com");
     * console.log("Title:", preview.title);
     * console.log("Description:", preview.description);
     * console.log("Image:", preview["og_image"]);
     *
     * // 带时间戳（强制刷新）
     * const preview = await mediaManager.previewUrl(
     *     "https://example.com",
     *     Date.now()
     * );
     * ```
     *
     * @throws {ValidationError} 如果 URL 为空或格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    previewUrl(url: string, ts?: number): Promise<UrlPreview>;
    getDownloadUrl(mxcUrl: string, options?: MediaDownloadUrlOptions): string;
    startChunkUpload(filename: string, contentType: string, totalSize?: number): Promise<ChunkUploadStartResponse>;
    uploadChunk(uploadId: string, chunkIndex: number, data: ArrayBuffer | Blob): Promise<ChunkUploadResponse>;
    completeChunkUpload(uploadId: string): Promise<ChunkUploadCompleteResponse>;
    cancelChunkUpload(uploadId: string): Promise<ChunkUploadCancelResponse>;
    getChunkUploadProgress(uploadId: string): Promise<ChunkUploadProgressResponse>;
    /**
     * Check media quota status
     * GET /_matrix/media/v1/quota/check
     */
    checkMediaQuota(): Promise<MediaQuotaCheckResponse>;
    /**
     * Get media quota statistics
     * GET /_matrix/media/v1/quota/stats
     */
    getMediaQuotaStats(): Promise<MediaQuotaStatsResponse>;
    /**
     * Get media quota alerts
     * GET /_matrix/media/v1/quota/alerts
     */
    getMediaQuotaAlerts(): Promise<MediaQuotaAlertsResponse>;
    getThumbnailUrl(mxcUrl: string, options?: MediaThumbnailUrlOptions): string;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map