/**
 * DTO snippets extracted from the contract doc for `media`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type MediaContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map