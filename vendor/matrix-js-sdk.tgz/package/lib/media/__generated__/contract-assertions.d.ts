export declare const MEDIA_ROUTES_ENTRY_COUNT: 41;
export declare const MEDIA_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "上传 body 为空等参数错误";
}, {
    readonly status: 401;
    readonly note: "需用户认证的接口未登录";
}, {
    readonly status: 409;
    readonly note: "具名上传使用了已存在 ID";
}, {
    readonly status: 404;
    readonly note: "媒体不存在";
}];
export type MediaStatusScenario = (typeof MEDIA_ROUTES_STATUS_SCENARIOS)[number];
export declare const MEDIA_ROUTES_ERROR_SCENARIOS: readonly [];
export type MediaErrorScenario = (typeof MEDIA_ROUTES_ERROR_SCENARIOS)[number];
export declare const MEDIA_ROUTES_ERRCODES: readonly [];
export type MediaErrcode = (typeof MEDIA_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map