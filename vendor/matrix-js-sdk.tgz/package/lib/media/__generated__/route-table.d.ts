/** Routes served by the synapse-rust `media` module (mirrored from the backend contract). */
export declare const MEDIA_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/media/download/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/media/download/{server_name}/{media_id}/{filename}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/media/preview_url";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/media/thumbnail/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/r0/config";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/r0/upload";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/r1/download/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/r1/download/{server_name}/{media_id}/{filename}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/config";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v1/delete/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/download/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/download/{server_name}/{media_id}/{filename}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/preview_url";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/quota/alerts";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/quota/check";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/quota/stats";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v1/upload";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v1/upload/chunk";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v1/upload/chunk/cancel";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v1/upload/chunk/complete";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v1/upload/chunk/progress";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v1/upload/chunk/start";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/config";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v3/delete/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/download/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/download/{server_name}/{media_id}/{filename}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/download_signed/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/download_signed/{server_name}/{media_id}/{filename}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/preview_url";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/thumbnail/{server_name}/{media_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v3/upload";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/media/v3/upload/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/v3/upload/provider";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/v3/upload/token";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/media/r0/delete/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/r0/download/{server_name}/{media_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/r0/download/{server_name}/{media_id}/{filename}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/media/r0/preview_url";
}];
/** Union of every (method, path) tuple in `MEDIA_ROUTES`. */
export type MediaRoute = (typeof MEDIA_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type MediaMethod = MediaRoute["method"];
/** Path templates referenced by this module. */
export type MediaPath = MediaRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type MediaReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${MediaReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type MediaPathPattern = MediaReplaceBraces<MediaPath>;
//# sourceMappingURL=route-table.d.ts.map