export declare const BURN_AFTER_READ_ROUTES_ENTRY_COUNT: 19;
export declare const BURN_AFTER_READ_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "按后端真实 7 条路由重写字段、返回体与覆盖率口径，并补充 SDK 路径绑定说明 | 修复长期文档漂移";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type BurnAfterReadStatusScenario = (typeof BURN_AFTER_READ_ROUTES_STATUS_SCENARIOS)[number];
export declare const BURN_AFTER_READ_ROUTES_ERROR_SCENARIOS: readonly [];
export type BurnAfterReadErrorScenario = (typeof BURN_AFTER_READ_ROUTES_ERROR_SCENARIOS)[number];
export declare const BURN_AFTER_READ_ROUTES_ERRCODES: readonly [];
export type BurnAfterReadErrcode = (typeof BURN_AFTER_READ_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map