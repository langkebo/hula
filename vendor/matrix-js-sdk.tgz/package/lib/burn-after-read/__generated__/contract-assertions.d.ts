export declare const BURN_AFTER_READ_ROUTES_ENTRY_COUNT: 7;
export declare const BURN_AFTER_READ_ROUTES_STATUS_SCENARIOS: readonly [];
export type BurnAfterReadStatusScenario = (typeof BURN_AFTER_READ_ROUTES_STATUS_SCENARIOS)[number];
export declare const BURN_AFTER_READ_ROUTES_ERROR_SCENARIOS: readonly [];
export type BurnAfterReadErrorScenario = (typeof BURN_AFTER_READ_ROUTES_ERROR_SCENARIOS)[number];
export declare const BURN_AFTER_READ_ROUTES_ERRCODES: readonly [];
export type BurnAfterReadErrcode = (typeof BURN_AFTER_READ_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map