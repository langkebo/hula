export declare const BURN_AFTER_READ_ROUTES_ENTRY_COUNT: 7;
export declare const BURN_AFTER_READ_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "timeout_ms、default_burn_ms 或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "非房间成员，或无权操作目标焚毁配置/消息";
}, {
    readonly status: 404;
    readonly note: "房间、事件或配置记录不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "按 synapse-rust 路由与 BurnAfterReadManager 修正字段名、覆盖率和测试状态 | 覆盖率从 0% 修正为 100%";
}];
export type BurnAfterReadStatusScenario = (typeof BURN_AFTER_READ_ROUTES_STATUS_SCENARIOS)[number];
export declare const BURN_AFTER_READ_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录";
}, {
    readonly scenario: "焚毁参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正超时时间、事件 ID 或请求体后重试";
}, {
    readonly scenario: "权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户需要房间访问权或管理权限";
}, {
    readonly scenario: "房间、事件或配置不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新房间状态并核对待焚毁消息列表";
}];
export type BurnAfterReadErrorScenario = (typeof BURN_AFTER_READ_ROUTES_ERROR_SCENARIOS)[number];
export declare const BURN_AFTER_READ_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "阅后即焚请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "timeout_ms、default_burn_ms 或事件参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权读取或修改目标房间的焚毁配置";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "房间、事件或焚毁配置不存在";
}];
export type BurnAfterReadErrcode = (typeof BURN_AFTER_READ_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map