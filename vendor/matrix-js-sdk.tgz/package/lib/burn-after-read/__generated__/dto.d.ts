/**
 * DTO snippets extracted from the contract doc for `burn-after-read`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface BurnSettings {
    enabled: boolean;
    burn_after_ms: number;
    /**
     * 作用域。后端 2026-11-10（`247ad28a9`）起恒为 `"room"`：
     * 任意成员写入的最新设置对整个房间生效，读取取最新一行。
     * 旧部署（按用户存储）会返回 `"per_user"`，SDK 必须原样透传而不是丢弃。
     */
    scope: "room" | "per_user";
}
export interface PendingBurnEvent {
    event_id: string;
    created_at: number;
    delete_ts: number;
    is_processed: boolean;
    is_dead_letter: boolean;
}
export interface MarkBurnReadResponse {
    success: boolean;
    will_delete_at: number;
}
export interface CancelBurnResponse {
    success: boolean;
}
export interface SetBurnConfigResponse {
    default_burn_ms: number;
}
export interface BurnStats {
    total_burned: number;
    total_pending: number;
    rooms_with_burn_enabled: number;
}
//# sourceMappingURL=dto.d.ts.map