/**
 * DTO snippets extracted from the contract doc for `burn_after_read`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface IBurnSettings {
    enabled: boolean;
    burn_after_ms: number;
}
export interface IBurnPendingEvent {
    event_id: string;
    created_at: number;
    delete_at: number;
}
export interface ISetBurnConfigResponse {
    default_burn_ms: number;
}
export interface IBurnStats {
    total_burned: number;
    total_pending: number;
    rooms_with_burn_enabled: number;
}
export interface BurnAfterReadRequestDto {
    enabled: boolean;
    timeout_ms: number;
}
//# sourceMappingURL=dto.d.ts.map