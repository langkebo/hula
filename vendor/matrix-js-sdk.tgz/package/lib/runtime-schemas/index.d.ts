import { z } from "zod";
import type { MatrixClient } from "../client";
import type { IContent, IEvent, IUnsigned, MatrixEvent } from "../models/event";
import type { Room } from "../models/room";
export declare const matrixEventContentSchema: z.ZodType<IContent>;
export declare const matrixUnsignedSchema: z.ZodType<IUnsigned>;
export declare const matrixEventWireSchema: z.ZodType<IEvent>;
export type MatrixEventWire = z.infer<typeof matrixEventWireSchema>;
export declare const matrixEventSnapshotSchema: z.ZodObject<{
    eventId: z.ZodNullable<z.ZodString>;
    roomId: z.ZodNullable<z.ZodString>;
    type: z.ZodString;
    sender: z.ZodNullable<z.ZodString>;
    ts: z.ZodNumber;
    stateKey: z.ZodNullable<z.ZodString>;
    content: z.ZodType<IContent, unknown, z.core.$ZodTypeInternals<IContent, unknown>>;
    unsigned: z.ZodType<IUnsigned, unknown, z.core.$ZodTypeInternals<IUnsigned, unknown>>;
}, z.core.$strip>;
export type MatrixEventSnapshot = z.infer<typeof matrixEventSnapshotSchema>;
export declare const roomSnapshotSchema: z.ZodObject<{
    roomId: z.ZodString;
    name: z.ZodString;
    normalizedName: z.ZodString;
    myMembership: z.ZodString;
    roomType: z.ZodOptional<z.ZodString>;
    pendingEventCount: z.ZodNumber;
    tags: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
export type RoomSnapshot = z.infer<typeof roomSnapshotSchema>;
export declare const matrixClientSnapshotSchema: z.ZodObject<{
    baseUrl: z.ZodString;
    clientRunning: z.ZodBoolean;
    userId: z.ZodNullable<z.ZodString>;
    deviceId: z.ZodNullable<z.ZodString>;
    supportsVoip: z.ZodBoolean;
}, z.core.$strip>;
export type MatrixClientSnapshot = z.infer<typeof matrixClientSnapshotSchema>;
export declare function parseMatrixEventWire(event: unknown): MatrixEventWire;
export declare function createMatrixEventSnapshot(event: Pick<MatrixEvent, "getId" | "getRoomId" | "getType" | "getSender" | "getTs" | "getStateKey" | "getContent" | "getUnsigned">): MatrixEventSnapshot;
export declare function createRoomSnapshot(room: Pick<Room, "roomId" | "name" | "normalizedName" | "tags" | "getMyMembership" | "getType" | "getPendingEvents">): RoomSnapshot;
export declare function createMatrixClientSnapshot(client: Pick<MatrixClient, "baseUrl" | "clientRunning" | "getUserId" | "getDeviceId" | "supportsVoip">): MatrixClientSnapshot;
//# sourceMappingURL=index.d.ts.map