/**
 * User Manager - 用户管理
 *
 * 提供用户信息获取、忽略用户等功能
 */
import { MatrixClient } from "../client";
import { User } from "../models/user";
import { type EmptyObject } from "../@types/common";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface UserManagerEvents {
    user_ignored: {
        userId: string;
    };
    user_unignored: {
        userId: string;
    };
    user_updated: {
        userId: string;
    };
}
export declare class UserManager extends BaseManager<keyof UserManagerEvents, UserManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getUserId(): string | null;
    getSafeUserId(): string;
    getUserIdLocalpart(): string | null;
    getDomain(): string | null;
    getUser(userId: string): User | null;
    getUsers(): User[];
    getIgnoredUsers(): string[];
    setIgnoredUsers(userIds: string[]): Promise<EmptyObject>;
    isUserIgnored(userId: string): boolean;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map