export { extendMatrixClientWithManagers as default } from "./manager-extensions/index";
export { extendMatrixClientWithManagers } from "./manager-extensions/index";
export * from "./manager-extensions/index";
//# sourceMappingURL=manager-extensions.d.ts.map