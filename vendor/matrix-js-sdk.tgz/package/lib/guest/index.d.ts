import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export declare enum GuestEvent {
    GuestRegistered = "GuestRegistered",
    GuestLoggedIn = "GuestLoggedIn",
    GuestUpgraded = "GuestUpgraded",
    GuestInfoReceived = "GuestInfoReceived",
    GuestError = "GuestError"
}
export interface IGuestRegisterResponse {
    user_id: string;
    device_id: string;
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
}
export interface IGuestLoginResponse {
    user_id: string;
    device_id: string;
    access_token: string;
    refresh_token?: string;
    expires_in?: number;
    well_known?: {
        [key: string]: unknown;
    };
}
export interface IGuestInfo {
    userId: string;
    deviceId: string;
    accessToken: string;
    refreshToken?: string;
    expiresAt?: number;
}
export interface IServerGuestInfo {
    user_id: string;
    device_id: string;
    is_guest: boolean;
    created_at?: number;
}
export type IServerGuestInfoResponse = IServerGuestInfo | {
    guest: IServerGuestInfo;
};
export interface IAuthDict {
    type?: string;
    session?: string;
    [key: string]: unknown;
}
export interface IUpgradeGuestRequest {
    username: string;
    password: string;
    auth?: IAuthDict;
}
export interface IUpgradeGuestResponse {
    success: boolean;
    user_id: string;
    access_token: string;
    device_id?: string;
}
interface GuestManagerEventMap {
    [GuestEvent.GuestRegistered]: (guestInfo: IGuestInfo) => void;
    [GuestEvent.GuestLoggedIn]: (guestInfo: IGuestInfo) => void;
    [GuestEvent.GuestUpgraded]: (userId: string) => void;
    [GuestEvent.GuestInfoReceived]: (guestInfo: IServerGuestInfo) => void;
    [GuestEvent.GuestError]: (error: Error) => void;
}
export declare class GuestManager extends BaseManager<GuestEvent, GuestManagerEventMap> {
    private guestInfo;
    private baseUrl;
    constructor(client: MatrixClient, baseUrl: string, opts?: ManagerOpts);
    registerGuest(deviceId?: string, initialDeviceDisplayName?: string): Promise<IGuestRegisterResponse>;
    loginGuest(deviceId?: string, initialDeviceDisplayName?: string): Promise<IGuestLoginResponse>;
    isGuest(userId?: string): Promise<boolean>;
    getGuestAccessToken(): Promise<string | null>;
    upgradeGuestAccount(password: string, authDict?: IAuthDict): Promise<void>;
    getGuestInfo(): IGuestInfo | null;
    getGuestRooms(): Promise<string[]>;
    joinRoomAsGuest(roomIdOrAlias: string): Promise<{
        roomId: string;
    }>;
    canJoinRoom(roomIdOrAlias: string): Promise<boolean>;
    clearGuestInfo(): void;
    isGuestTokenValid(): boolean;
    getGuestInfoFromServer(): Promise<IServerGuestInfo>;
    upgradeGuestAccountOnServer(request: IUpgradeGuestRequest): Promise<IUpgradeGuestResponse>;
    registerGuestOnServer(deviceId?: string, initialDeviceDisplayName?: string): Promise<IGuestRegisterResponse>;
    stop(): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map