/**
 * DTO snippets extracted from the contract doc for `guest`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type GuestContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map