/**
 * DTO snippets extracted from the contract doc for `guest`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface GuestRegisterResponse {
    user_id: string;
    device_id: string;
    access_token: string;
    expires_in: number;
}
export interface ServerGuestInfo {
    user_id: string;
    is_guest: boolean;
}
export interface UpgradeGuestRequest {
    username: string;
    password: string;
}
export interface UpgradeGuestResponse {
    success: boolean;
    user_id: string;
    access_token: string;
}
//# sourceMappingURL=dto.d.ts.map