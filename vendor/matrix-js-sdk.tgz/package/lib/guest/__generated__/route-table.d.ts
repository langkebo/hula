/** Routes served by the synapse-rust `guest` module (mirrored from the backend contract). */
export declare const GUEST_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/account/guest";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/guest/upgrade";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/register/guest";
}];
/** Union of every (method, path) tuple in `GUEST_ROUTES`. */
export type GuestRoute = (typeof GUEST_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type GuestMethod = GuestRoute["method"];
/** Path templates referenced by this module. */
export type GuestPath = GuestRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type GuestReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${GuestReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type GuestPathPattern = GuestReplaceBraces<GuestPath>;
//# sourceMappingURL=route-table.d.ts.map