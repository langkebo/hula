export declare const GUEST_ROUTES_ENTRY_COUNT: 3;
export declare const GUEST_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "访客注册成功";
}, {
    readonly status: 400;
    readonly note: "注册参数、请求体或 kind 查询参数非法";
}, {
    readonly status: 403;
    readonly note: "服务器禁用访客注册";
}, {
    readonly status: 429;
    readonly note: "访客注册被限流";
}];
export type GuestStatusScenario = (typeof GUEST_ROUTES_STATUS_SCENARIOS)[number];
export declare const GUEST_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "访客注册参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正注册请求体或确保 kind=guest 后重试";
}, {
    readonly scenario: "服务器禁用访客注册";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "改走普通注册或联系服务器管理员开启 guest 模式";
}, {
    readonly scenario: "访客注册触发限流";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "按 retry_after_ms 退避后重试";
}];
export type GuestErrorScenario = (typeof GUEST_ROUTES_ERROR_SCENARIOS)[number];
export declare const GUEST_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "访客注册请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "注册参数或 kind 查询参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "服务器禁用访客注册";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "访客注册被限流";
}];
export type GuestErrcode = (typeof GUEST_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map