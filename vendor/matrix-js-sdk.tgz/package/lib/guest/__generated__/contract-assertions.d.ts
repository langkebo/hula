export declare const GUEST_ROUTES_ENTRY_COUNT: 3;
export declare const GUEST_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "升级请求参数不合法，例如用户名或密码长度校验失败";
}, {
    readonly status: 403;
    readonly note: "服务器禁用注册，或当前用户不是 guest";
}, {
    readonly status: 409;
    readonly note: "升级为正式账号时用户名已存在";
}, {
    readonly status: 500;
    readonly note: "创建 guest 用户、设备或 token 失败";
}];
export type GuestStatusScenario = (typeof GUEST_ROUTES_STATUS_SCENARIOS)[number];
export declare const GUEST_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "服务器禁用注册";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "改走普通注册或联系管理员开启注册";
}, {
    readonly scenario: "当前用户不是 guest";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "不要对正式账号调用 guest 升级接口";
}, {
    readonly scenario: "升级参数校验失败";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 username / password 后重试";
}, {
    readonly scenario: "升级用户名冲突";
    readonly httpOrErrcode: "409 / M_CONFLICT";
    readonly sdkErrorType: "ApiError";
    readonly handling: "更换用户名";
}];
export type GuestErrorScenario = (typeof GUEST_ROUTES_ERROR_SCENARIOS)[number];
export declare const GUEST_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "升级请求体结构不合法或校验失败";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "用户名或密码不符合要求";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "服务器禁用注册或当前用户不是 guest";
}, {
    readonly errcode: "M_CONFLICT";
    readonly httpStatus: "409";
    readonly note: "用户名已存在";
}];
export type GuestErrcode = (typeof GUEST_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map