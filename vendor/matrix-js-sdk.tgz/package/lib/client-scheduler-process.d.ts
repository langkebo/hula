import type { MatrixEvent } from "./models/event.ts";
import { EventStatus } from "./models/event.ts";
import type { ISendEventResponse } from "./@types/requests.ts";
import type { Room } from "./models/room.ts";
export interface SchedulerProcessDeps {
    /** 取事件所在房间（可能已被丢弃 → null）。 */
    getRoom: (roomId: string | undefined) => Room | null;
    /** 更新 pending 事件状态（有 room 时走 room，否则直接改事件）。 */
    updatePendingEventStatus: (room: Room | null, event: MatrixEvent, status: EventStatus) => void;
    /** 真正发出 HTTP 请求。 */
    sendEventHttpRequest: (event: MatrixEvent) => Promise<ISendEventResponse>;
}
/** 构造 `MatrixScheduler.setProcessFunction()` 需要的回调。 */
export declare function createSchedulerProcessFunction({ getRoom, updatePendingEventStatus, sendEventHttpRequest, }: SchedulerProcessDeps): (event: MatrixEvent) => Promise<ISendEventResponse>;
//# sourceMappingURL=client-scheduler-process.d.ts.map