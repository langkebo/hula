import { Method } from "./http-api/index";
import type { EmptyObject } from "./@types/common";
export interface IdentityHashDetails {
    algorithms: string[];
    lookup_pepper: string;
}
export interface IdentityLookupResult {
    address: string;
    mxid: string;
}
export interface IdServerRequestFn {
    <T extends object = Record<string, unknown>>(method: Method, path: string, params: Record<string, string | string[]> | undefined, prefix: string, accessToken?: string): Promise<T>;
}
export declare function getIdentityHashDetailsRequest(idServerRequest: IdServerRequestFn, identityAccessToken: string): Promise<IdentityHashDetails>;
export declare function identityHashedLookupRequest(addressPairs: [string, string][], identityAccessToken: string, idServerRequest: IdServerRequestFn): Promise<IdentityLookupResult[]>;
export declare function lookupThreePidRequest(medium: string, address: string, identityAccessToken: string, idServerRequest: IdServerRequestFn): Promise<{
    address: string;
    medium: string;
    mxid: string;
} | EmptyObject>;
export declare function bulkLookupThreePidsRequest(query: [string, string][], identityAccessToken: string, idServerRequest: IdServerRequestFn): Promise<{
    threepids: [medium: string, address: string, mxid: string][];
}>;
//# sourceMappingURL=client-identity-lookup.d.ts.map