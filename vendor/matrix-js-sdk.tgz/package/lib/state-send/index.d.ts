/**
 * State Send Manager - 状态发送管理
 *
 * 提供状态事件发送相关功能，包括权限级别设置等
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { ISendEventResponse } from "../@types/requests";
export interface StateSendManagerEvents {
    stateEventSent: (data: {
        roomId: string;
        eventType: string;
        stateKey: string;
    }) => void;
    powerLevelsChanged: (data: {
        roomId: string;
        userIds: string[];
        powerLevel: number | undefined;
    }) => void;
}
export declare class StateSendManager extends BaseManager<keyof StateSendManagerEvents, StateSendManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    setPowerLevel(roomId: string, userId: string | string[], powerLevel: number | undefined): Promise<ISendEventResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map