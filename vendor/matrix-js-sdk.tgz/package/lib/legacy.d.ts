export { FilterManager } from "./filter/index";
//# sourceMappingURL=legacy.d.ts.map