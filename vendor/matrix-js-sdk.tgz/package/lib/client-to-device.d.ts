import { Method, type Body, type IRequestOpts } from "./http-api/index";
import type { EmptyObject } from "./@types/common";
import type { SendToDeviceContentMap } from "./client-api-types";
import { type QueryDict } from "./utils";
export interface SendToDeviceOptions {
    eventType: string;
    contentMap: SendToDeviceContentMap;
    txnId?: string;
    makeTxnId: () => string;
}
export interface AuthedRequestFn {
    <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, paramOpts?: IRequestOpts): Promise<T>;
}
export interface SendToDeviceDeps {
    authedRequest: AuthedRequestFn;
    logger: {
        debug: (...args: unknown[]) => void;
    };
}
export declare function buildSendToDevicePath(eventType: string, txnId: string): string;
export declare function buildSendToDeviceBody(contentMap: SendToDeviceContentMap): {
    body: {
        messages: Record<string, Record<string, unknown>>;
    };
    targets: Map<string, string[]>;
};
export declare function sendToDeviceRequest(options: SendToDeviceOptions, deps: SendToDeviceDeps): Promise<EmptyObject>;
//# sourceMappingURL=client-to-device.d.ts.map