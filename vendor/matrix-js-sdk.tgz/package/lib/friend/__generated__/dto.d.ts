/**
 * DTO snippets extracted from the contract doc for `friend`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type FriendContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map