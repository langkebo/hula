/**
 * DTO snippets extracted from the contract doc for `friend`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface Friend {
    user_id: string;
    reason?: string;
    since?: number;
    display_name?: string;
    displayname?: string;
    username?: string;
    avatar_url?: string;
    note?: string;
    presence?: string;
    online?: boolean;
    last_active_ts?: number;
    last_seen_ts?: number;
    added_ts?: number;
    status?: string;
    dm_room_id?: string;
    dm_room_active?: boolean;
    dm_room_state?: string;
    dm_room_updated_ts?: number;
    dm_room_affected_user_id?: string;
    dm_room_changed_by?: string;
    dm_room_reason?: string;
}
export interface FriendRequest {
    user_id: string;
    reason?: string;
    status: "pending" | "accepted" | "rejected" | "cancelled";
    timestamp?: number;
    display_name?: string;
    displayname?: string;
    avatar_url?: string;
    message?: string;
    direction?: "incoming" | "outgoing";
    request_id?: string;
}
export interface FriendStatusInfo {
    user_id: string;
    status: string;
    is_friend?: boolean;
    are_friends?: boolean;
}
export interface FriendshipCheckResponse {
    user_id: string;
    is_friend: boolean;
    are_friends: boolean;
}
export interface FriendSearchResult {
    user_id: string;
    username?: string;
    displayname?: string;
    avatar_url?: string;
    presence?: string;
    online?: boolean;
    last_active_ts?: number;
    last_seen_ts?: number;
    created_ts?: number;
    match_score?: number;
    match_type?: string;
}
export interface FriendSearchResponse {
    results?: FriendSearchResult[];
    count?: number;
    mode?: string;
    limited?: boolean;
    /**
     * 限流剩余时间，**单位是秒**，且后端**恒返回**（未限流时为 `0`）。
     *
     * ⚠️ 不是 `retry_after_ms`。`retry_after_ms` 是 429 **错误信封**里的字段（毫秒），
     * 两者同名不同义，SDK 曾把 200 响应的这个键写成 `retry_after_ms` ⇒ 调用方永远读不到
     * （审计 B5-3）。别把这两个改名改混了。
     */
    retry_after_seconds: number;
}
export interface FriendGroup {
    id: string;
    name: string;
    members: string[];
    created_at?: number;
    updated_ts?: number;
}
export interface IFriendsResponse {
    friends?: Friend[];
    /**
     * ⚠️ 后端**不返回** `items`（`friend_room.rs::get_friends` 的 `json!` 只有 `friends`）。
     *
     * 这里曾经声明过它（文档也照抄成"后端实际返回"），于是「后端多一个字段、SDK 丢掉」之外的
     * 反形态出现了：**SDK 多一个字段、后端从不发** ⇒ 读 `response.items` 恒 `undefined`，
     * 而类型说有（审计 §13.4）。运行时的兼容回退仍在实现里（见 `friend-list-manager.ts`
     * 的 `LegacyFriendsResponse`），但契约不声明它。
     */
    total?: number;
    limit?: number;
    offset?: number;
    next_offset?: number;
    next_batch?: string;
    room_id?: string;
    version?: number;
    cached?: boolean;
    generated_ts?: number;
}
//# sourceMappingURL=dto.d.ts.map