export declare const FRIEND_ROUTES_ENTRY_COUNT: 54;
export declare const FRIEND_ROUTES_STATUS_SCENARIOS: readonly [];
export type FriendStatusScenario = (typeof FRIEND_ROUTES_STATUS_SCENARIOS)[number];
export declare const FRIEND_ROUTES_ERROR_SCENARIOS: readonly [];
export type FriendErrorScenario = (typeof FRIEND_ROUTES_ERROR_SCENARIOS)[number];
export declare const FRIEND_ROUTES_ERRCODES: readonly [];
export type FriendErrcode = (typeof FRIEND_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map