export interface GeneratedSnippetBundle {
    acceptanceSpec?: string;
    contractAssertions?: string;
    dto?: string;
    routeTable?: string;
}
/**
 * Render a markdown section that mirrors the latest generated code snippets
 * for one contract module.
 *
 * @param moduleName - Human-readable module name.
 * @param snippets - Generated TypeScript snippets keyed by artifact role.
 * @param maxSnippetLines - Maximum number of lines to include per snippet.
 * @returns A standalone `## 代码生成产物` markdown section.
 * @throws {Error} If no snippet content is provided.
 *
 * @example
 * ```ts
 * const section = buildGeneratedCodeSection("friend", {
 *     routeTable: "export const FRIEND_ROUTES = [];",
 * });
 * console.log(section.includes("## 代码生成产物"));
 * ```
 */
export declare function buildGeneratedCodeSection(moduleName: string, snippets: GeneratedSnippetBundle, maxSnippetLines?: number): string;
/**
 * Upsert a markdown section by second-level heading.
 *
 * @param markdown - Original markdown document.
 * @param sectionHeading - Full second-level heading, for example `## 代码生成产物`.
 * @param sectionBody - Replacement body, including the heading itself.
 * @returns Updated markdown with the section inserted or replaced.
 *
 * @example
 * ```ts
 * const updated = upsertMarkdownSection("# Title\n", "## 代码生成产物", "## 代码生成产物\n\ncontent");
 * console.log(updated.includes("content"));
 * ```
 */
export declare function upsertMarkdownSection(markdown: string, sectionHeading: string, sectionBody: string): string;
/**
 * Synchronize generated code snippets back into a contract markdown page.
 *
 * @param markdown - Original contract markdown.
 * @param moduleName - Human-readable module name.
 * @param snippets - Generated TypeScript snippets keyed by artifact role.
 * @param maxSnippetLines - Maximum number of lines to include per snippet.
 * @returns Markdown with an updated `## 代码生成产物` section.
 *
 * @example
 * ```ts
 * const synced = syncContractDoc("# Friend\n", "friend", {
 *     routeTable: "export const FRIEND_ROUTES = [];",
 * });
 * console.log(synced.includes("FRIEND_ROUTES"));
 * ```
 */
export declare function syncContractDoc(markdown: string, moduleName: string, snippets: GeneratedSnippetBundle, maxSnippetLines?: number): string;
//# sourceMappingURL=syncDocs.d.ts.map