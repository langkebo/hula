export interface OpenApiParameter {
    in: "path" | "query" | "header" | "cookie";
    name: string;
    required: boolean;
}
export interface NormalizedApiOperation {
    auth: "none" | "user" | "admin" | "federation";
    errorStatuses: string[];
    examples: string[];
    method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
    moduleName: string;
    operationId: string;
    parameters: OpenApiParameter[];
    path: string;
    requestBodyContentTypes: string[];
    responseStatuses: string[];
    summary: string;
}
export interface GeneratedApiArtifact {
    content: string;
    fileName: string;
    moduleName: string;
    operations: NormalizedApiOperation[];
}
export interface ExistingGeneratedArtifactAudit {
    generatedDir: string;
    hasAcceptanceSpec: boolean;
    hasContractAssertions: boolean;
    hasDto: boolean;
    hasRouteTable: boolean;
    moduleName: string;
}
type UnknownRecord = Record<string, unknown>;
/**
 * Parse a JSON OpenAPI or Swagger document.
 *
 * @param documentText - Raw document text.
 * @param sourceName - Friendly source name used in error messages.
 * @returns Parsed OpenAPI/Swagger object.
 * @throws {Error} If the document is not valid JSON or lacks an OpenAPI/Swagger version marker.
 *
 * @example
 * ```ts
 * const document = parseOpenApiDocument('{"openapi":"3.1.0","paths":{}}');
 * console.log(document.openapi);
 * ```
 */
export declare function parseOpenApiDocument(documentText: string, sourceName?: string): UnknownRecord;
/**
 * Normalize OpenAPI operations into a compact repo-friendly shape that can be
 * rendered into side-effect-free TypeScript metadata files.
 *
 * @param document - Parsed OpenAPI or Swagger document.
 * @returns Flattened and normalized operations.
 *
 * @example
 * ```ts
 * const operations = normalizeOpenApiOperations(document);
 * console.log(operations[0]?.path);
 * ```
 */
export declare function normalizeOpenApiOperations(document: UnknownRecord): NormalizedApiOperation[];
/**
 * Inspect the current repo's generated contract helper directories to spot
 * missing route tables, DTO files, assertions, or acceptance specs.
 *
 * @param repoRoot - Repository root directory.
 * @returns One audit row per generated module directory.
 *
 * @example
 * ```ts
 * const audit = auditExistingGeneratedArtifacts(process.cwd());
 * console.log(audit.every((item) => item.hasRouteTable));
 * ```
 */
export declare function auditExistingGeneratedArtifacts(repoRoot: string): ExistingGeneratedArtifactAudit[];
/**
 * Render a side-effect-free metadata artifact for one normalized module.
 *
 * @param moduleName - Logical module name.
 * @param operations - Operations that belong to the module.
 * @returns TypeScript source code for the generated metadata artifact.
 *
 * @example
 * ```ts
 * const artifact = renderApiModuleArtifact("friend", operations);
 * console.log(artifact.includes("export const FRIEND_OPERATIONS"));
 * ```
 */
export declare function renderApiModuleArtifact(moduleName: string, operations: readonly NormalizedApiOperation[]): string;
/**
 * Generate one metadata artifact per module from a JSON OpenAPI/Swagger
 * document.
 *
 * @param documentText - Raw OpenAPI/Swagger JSON text.
 * @param templateText - Governance template used to guard generator assumptions.
 * @param sourceName - Friendly source name used in error messages.
 * @returns Generated module artifacts grouped by normalized module name.
 * @throws {Error} If the prompt template is invalid.
 *
 * @example
 * ```ts
 * const artifacts = generateApisFromOpenApiDocument(openApiText, templateText);
 * console.log(artifacts.map((artifact) => artifact.fileName));
 * ```
 */
export declare function generateApisFromOpenApiDocument(documentText: string, templateText: string, sourceName?: string): GeneratedApiArtifact[];
export {};
//# sourceMappingURL=generateApis.d.ts.map