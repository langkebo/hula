export interface TemplateValidationIssue {
    code: "missing-section" | "missing-placeholder" | "missing-checklist-heading" | "missing-input-bound" | "missing-prompt-requirement";
    message: string;
}
export interface PromptTemplateFingerprint {
    canonicalPromptSha256: string;
    checklistHeadings: string[];
    inputBoundFields: string[];
    placeholders: string[];
    sectionHeadings: string[];
}
export interface PromptTemplateValidationReport {
    fingerprint: PromptTemplateFingerprint;
    issues: TemplateValidationIssue[];
    valid: boolean;
}
/**
 * Extract the canonical fenced prompt body from the governance template.
 *
 * @param templateText - Full markdown template text.
 * @returns The raw canonical prompt body, without surrounding markdown headings.
 * @throws {Error} If the canonical prompt section or code fence is missing.
 *
 * @example
 * ```ts
 * const prompt = extractCanonicalPrompt(templateText);
 * console.log(prompt.includes("{{ change_type }}"));
 * ```
 */
export declare function extractCanonicalPrompt(templateText: string): string;
/**
 * Build a snapshot-friendly fingerprint for the current prompt template.
 *
 * @param templateText - Full markdown template text.
 * @returns A stable summary that can be used by snapshot tests.
 *
 * @example
 * ```ts
 * const fingerprint = buildPromptTemplateFingerprint(templateText);
 * console.log(fingerprint.canonicalPromptSha256);
 * ```
 */
export declare function buildPromptTemplateFingerprint(templateText: string): PromptTemplateFingerprint;
/**
 * Validate that the governance prompt template still contains the required
 * fields, reviewer checkpoints, and input-bound metadata.
 *
 * @param templateText - Full markdown template text.
 * @returns Validation result with a fingerprint and any discovered issues.
 *
 * @example
 * ```ts
 * const report = validatePromptTemplate(templateText);
 * if (!report.valid) {
 *     throw new Error(report.issues.map((issue) => issue.message).join("\\n"));
 * }
 * ```
 */
export declare function validatePromptTemplate(templateText: string): PromptTemplateValidationReport;
/**
 * Validate a template file from disk.
 *
 * @param filePath - Absolute or repo-relative path to the markdown template.
 * @returns Validation report for the file contents.
 * @throws {Error} If the file cannot be read.
 *
 * @example
 * ```ts
 * const report = validatePromptTemplateFile("docs/api-contract/governance/SDK_CODEGEN_PROMPT_TEMPLATE.md");
 * console.log(report.valid);
 * ```
 */
export declare function validatePromptTemplateFile(filePath: string): PromptTemplateValidationReport;
//# sourceMappingURL=validateTemplates.d.ts.map