import { type ISendEventResponse, type SendDelayedEventRequestOpts, type SendDelayedEventResponse } from "./@types/requests.ts";
import { Method } from "./http-api/method.ts";
import type { MatrixEvent } from "./models/event.ts";
import type { QueryDict } from "./utils.ts";
interface LoggerLike {
    debug(message: string): void;
}
interface HttpLike {
    authedRequest<T>(method: Method, path: string, queryParams?: QueryDict, body?: unknown): Promise<T>;
}
export interface DispatchSendEventHttpRequestArgs {
    event: MatrixEvent;
    queryOrDelayOpts?: SendDelayedEventRequestOpts | QueryDict;
    queryDict?: QueryDict;
    makeTxnId: () => string;
    http: HttpLike;
    logger: LoggerLike;
    unstableDelayFeatureName: string;
}
export declare function dispatchSendEventHttpRequest({ event, queryOrDelayOpts, queryDict, makeTxnId, http, logger, unstableDelayFeatureName, }: DispatchSendEventHttpRequestArgs): Promise<ISendEventResponse | SendDelayedEventResponse>;
export {};
//# sourceMappingURL=client-send-http.d.ts.map