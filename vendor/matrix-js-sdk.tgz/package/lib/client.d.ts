/**
 * This is an internal module. See {@link MatrixClient} for the public class.
 */
import { type ISyncStateData, type SetPresence, SyncApi, type SyncApiOptions, SyncState } from "./sync";
import type { MatrixClientExtensionMethods, MatrixClientInternalMethods, SharedWithUsersMap, WidgetData } from "./matrix-client-extensions";
import { EventStatus, type IContent, type IDecryptOptions, type IEvent, MatrixEvent, MatrixEventEvent, type MatrixEventHandlerMap, type PushDetails } from "./models/event";
import { type CallEvent, type CallEventHandlerMap, type MatrixCall } from "./web-rtc/call";
import { Filter, type IFilterDefinition, type IRoomEventFilter } from "./filter";
import { CallEventHandler, type CallEventHandlerEvent, type CallEventHandlerEventHandlerMap } from "./web-rtc/callEventHandler";
import { GroupCallEventHandler, type GroupCallEventHandlerEvent, type GroupCallEventHandlerEventHandlerMap } from "./web-rtc/groupCallEventHandler";
import { type QueryDict } from "./utils";
import { Direction, EventTimeline } from "./models/event-timeline";
import { type IActionsObject, PushProcessor } from "./pushprocessor";
import { TypedReEmitter } from "./ReEmitter";
import { type Logger } from "./logger";
import { type FileType, type HttpApiEvent, type HttpApiEventHandlerMap, type IHttpOpts, type IRequestOpts, MatrixError, MatrixHttpApi, type Upload, type UploadOpts, type UploadResponse } from "./http-api/index";
import { User, UserEvent, type UserEventHandlerMap } from "./models/user";
import { ProfileManager, type IExtendedProfile } from "./profile/index";
import { type IIdentityServerProvider } from "./@types/IIdentityServerProvider";
import { type MatrixScheduler } from "./scheduler";
import { type BeaconEvent, type BeaconEventHandlerMap } from "./models/beacon";
import { type AuthDict } from "./interactive-auth";
import { type ReceivedToDeviceMessage } from "./sync-accumulator";
import type { EventTimelineSet } from "./models/event-timeline-set";
import { LRUCache } from "./utils/lru-cache";
import { type Room, type RoomEvent, type RoomEventHandlerMap } from "./models/room";
import { RoomMemberEvent, type RoomMemberEventHandlerMap } from "./models/room-member";
import { type RoomStateEvent, type RoomStateEventHandlerMap } from "./models/room-state";
import { type ICreateRoomOpts, type IEventSearchOpts, type IGuestAccessOpts, type IJoinRoomOpts, type InviteOpts, type IPaginateOpts, type IRedactOpts, type IRelationsRequestOpts, type IRelationsResponse, type IRoomDirectoryOptions, type ISearchOpts, type ISendEventResponse, type ITagsResponse, type KnockRoomOpts, type SendDelayedEventRequestOpts, type SendDelayedEventResponse } from "./@types/requests";
import { type AccountDataEvents, EventType, RelationType, type RoomAccountDataEvents, type StateEvents, type TimelineEvents, type WritableAccountDataEvents } from "./@types/event";
import { type IdServerUnbindResult, Preset, type Visibility } from "./@types/partials";
import { type EventMapper, type MapperOpts } from "./event-mapper";
import { MSC3089TreeSpace } from "./models/MSC3089TreeSpace";
import { type IStore } from "./store/index";
import { type ISearchRequestBody, type ISearchResponse, type ISearchResults, type IStateEventWithRoomId } from "./@types/search";
import { type ISynapseAdminDeactivateResponse, type ISynapseAdminWhoisResponse } from "./@types/synapse";
import type { IMediaConfig, IMessagesResponse, IMyRoomInfo, IRoomHierarchy, ITagMetadata, IThirdPartyLocation, IThirdPartyUser, IUserDirectoryResponse, IWhoamiResponse } from "./client-internal-types";
import { type IPushRule, type IPushRules } from "./@types/PushRules";
import { type CryptoStore } from "./crypto/store/base";
import { GroupCall, type GroupCallIntent, type GroupCallType, type IGroupCallDataChannelOptions } from "./web-rtc/groupCall";
import { MediaHandler } from "./web-rtc/mediaHandler";
import { type ILoginFlowsResponse, type IRefreshTokenResponse, type LoginRequest, type LoginResponse, type LoginTokenPostResponse, type SSOAction } from "./@types/auth";
import { TypedEventEmitter } from "./models/typed-event-emitter";
import { type MSC3575SlidingSyncRequest, type MSC3575SlidingSyncResponse } from "./sliding-sync";
import { SlidingSyncSdk } from "./sliding-sync-sdk";
import { FeatureSupport, ThreadFilterType } from "./models/thread";
import { NamespacedValue, UnstableValue } from "./NamespacedValue";
import { ToDeviceMessageQueue } from "./ToDeviceMessageQueue";
import { IgnoredInvites } from "./models/invites-ignorer";
import { type LocalNotificationSettings } from "./@types/local_notifications";
import { Feature, ServerSupport } from "./feature";
import { type MBeaconInfoEventContent } from "./@types/beacon";
import { type CryptoBackend } from "./common-crypto/CryptoBackend";
import { type CryptoApi, type CryptoCallbacks, CryptoEvent, type CryptoEventHandlerMap } from "./crypto-api/index";
import { type SecretStorageKeyDescription, type ServerSideSecretStorage } from "./secret-storage";
import { type RegisterRequest, type RegisterResponse } from "./@types/registration";
import { MatrixRTCSessionManager } from "./matrix-rtc/MatrixRTCSessionManager";
import { type RoomMessageEventContent } from "./@types/events";
import { type ImageInfo } from "./@types/media";
import { type Capabilities, ServerCapabilities } from "./serverCapabilities";
import { type SynapseRustFeatureName, type SynapseRustFeatureSupport } from "./server-capabilities";
import { type OidcClientConfig } from "./oidc/index";
import { type EmptyObject } from "./@types/common";
import { type Transport } from "./matrix-rtc/index";
import { type PreparedSendEventParams } from "./client-send-event";
import { fixNotificationCountOnDecryption, inMainTimelineForReceipt, threadIdForReceipt } from "./client-receipts";
import { type CrossSigningKeys, type IClientWellKnown, type ICreateRoomKeyRequest, type IClaimOTKsResult, type IDownloadKeyResult, type IGetRoomKeyRequestsQuery, type IJoinedMembersResponse, type IJoinedRoomsResponse, type IOpenIDToken, type IPublicRoomsResponse, type IProtocol, type IPreviewUrlResponse, type IRoomKeyRequestCreateResponse, type IRoomKeyRequestsResponse, type IRequestMsisdnTokenResponse, type IRequestTokenResponse, type IRoomInitialSyncResponse, type ISecureBackupInfo, type ISecureBackupRestoreResponse, type ISecureBackupSessionKey, type ISecureBackupStoreKeysResponse, type ISecureBackupVerifyResponse, type IServerVersions, type ITurnServer, type ITurnServerResponse, type IUploadKeySignaturesResponse, type TimestampToEventResponse, type IUploadKeysRequest, type KeySignatures } from "./client-api-types";
import { type ICreateClientOpts, type IKeysUploadResponse, type IMatrixClientCreateOpts, type IStartClientOpts, type IStoredClientOpts } from "./client-config-types";
import { EventManager } from "./event/EventManager";
export type { IClientWellKnown, ICreateRoomKeyRequest, IDeviceSigningVerificationAcceptRequest, IDeviceSigningVerificationAcceptResponse, IDeviceSigningVerificationCancelRequest, IDeviceSigningVerificationCancelResponse, IDeviceSigningVerificationDoneRequest, IDeviceSigningVerificationDoneResponse, IDeviceSigningVerificationKeyAgreementRequest, IDeviceSigningVerificationKeyAgreementResponse, IDeviceSigningVerificationMacRequest, IDeviceSigningVerificationMacResponse, IDeviceSigningVerificationStartRequest, IDeviceSigningVerificationStartResponse, IClaimKeysRequest, IClaimOTKsResult, IDownloadKeyResult, IFieldType, IGetRoomKeyRequestsQuery, IInstance, IJoinedMembersResponse, IJoinedRoomsResponse, IMyDevice, IOpenIDToken, IPublicRoomsChunkRoom, IPublicRoomsResponse, IPreviewUrlResponse, IProtocol, IQueryKeysRequest, IRequestMsisdnTokenResponse, IRequestTokenResponse, IRoomKeyRequestCreateResponse, IRoomKeyRequestsResponse, IRoomInitialSyncResponse, IScanQrCodeRequest, IScanQrCodeResponse, ISecureBackupInfo, ISecureBackupRestoreResponse, ISecureBackupSessionKey, ISecureBackupStoreKeysResponse, ISecureBackupVerifyResponse, IShowQrCodeResponse, IServerVersions, ITurnServer, ITurnServerResponse, IUploadKeySignaturesResponse, RoomSummary, IVerificationRequestsResponse, IWellKnownConfig, KeySignatures, CrossSigningKeys, SendToDeviceContentMap, TimestampToEventResponse, RoomKeyRequestStatus, IUploadKeysRequest, Keys, SigningKeys, } from "./client-api-types";
export { PendingEventOrdering } from "./client-config-types";
export type { ICreateClientOpts, IKeysUploadResponse, IMatrixClientCreateOpts, IStartClientOpts, IStoredClientOpts, } from "./client-config-types";
export type Store = IStore;
export type ResetTimelineCallback = (roomId: string) => boolean;
export { TURN_CHECK_INTERVAL } from "./client-lifecycle-start";
export declare const UNSTABLE_MSC3852_LAST_SEEN_UA: UnstableValue<"last_seen_user_agent", "org.matrix.msc3852.last_seen_user_agent">;
export declare const GET_LOGIN_TOKEN_CAPABILITY: NamespacedValue<"m.get_login_token", "org.matrix.msc3882.get_login_token">;
export declare const UNSTABLE_MSC2666_SHARED_ROOMS = "uk.half-shot.msc2666";
export declare const UNSTABLE_MSC2666_MUTUAL_ROOMS = "uk.half-shot.msc2666.mutual_rooms";
export declare const UNSTABLE_MSC2666_QUERY_MUTUAL_ROOMS = "uk.half-shot.msc2666.query_mutual_rooms";
export declare const UNSTABLE_MSC4140_DELAYED_EVENTS = "org.matrix.msc4140";
export declare const UNSTABLE_MSC4354_STICKY_EVENTS = "org.matrix.msc4354";
export declare const UNSTABLE_MSC4133_EXTENDED_PROFILES = "uk.tcpip.msc4133";
export declare const STABLE_MSC4133_EXTENDED_PROFILES = "uk.tcpip.msc4133.stable";
export type IRegisterRequestParams = RegisterRequest;
export declare enum ClientEvent {
    /**
     * Fires whenever the SDK's syncing state is updated. The state can be one of:
     * <ul>
     *
     * <li>PREPARED: The client has synced with the server at least once and is
     * ready for methods to be called on it. This will be immediately followed by
     * a state of SYNCING. <i>This is the equivalent of "syncComplete" in the
     * previous API.</i></li>
     *
     * <li>CATCHUP: The client has detected the connection to the server might be
     * available again and will now try to do a sync again. As this sync might take
     * a long time (depending how long ago was last synced, and general server
     * performance) the client is put in this mode so the UI can reflect trying
     * to catch up with the server after losing connection.</li>
     *
     * <li>SYNCING : The client is currently polling for new events from the server.
     * This will be called <i>after</i> processing latest events from a sync.</li>
     *
     * <li>ERROR : The client has had a problem syncing with the server. If this is
     * called <i>before</i> PREPARED then there was a problem performing the initial
     * sync. If this is called <i>after</i> PREPARED then there was a problem polling
     * the server for updates. This may be called multiple times even if the state is
     * already ERROR. <i>This is the equivalent of "syncError" in the previous
     * API.</i></li>
     *
     * <li>RECONNECTING: The sync connection has dropped, but not (yet) in a way that
     * should be considered erroneous.
     * </li>
     *
     * <li>STOPPED: The client has stopped syncing with server due to stopClient
     * being called.
     * </li>
     * </ul>
     * State transition diagram:
     * ```
     *                                          +---->STOPPED
     *                                          |
     *              +----->PREPARED -------> SYNCING <--+
     *              |                        ^  |  ^    |
     *              |      CATCHUP ----------+  |  |    |
     *              |        ^                  V  |    |
     *   null ------+        |  +------- RECONNECTING   |
     *              |        V  V                       |
     *              +------->ERROR ---------------------+
     *
     * NB: 'null' will never be emitted by this event.
     *
     * ```
     * Transitions:
     * <ul>
     *
     * <li>`null -> PREPARED` : Occurs when the initial sync is completed
     * first time. This involves setting up filters and obtaining push rules.
     *
     * <li>`null -> ERROR` : Occurs when the initial sync failed first time.
     *
     * <li>`ERROR -> PREPARED` : Occurs when the initial sync succeeds
     * after previously failing.
     *
     * <li>`PREPARED -> SYNCING` : Occurs immediately after transitioning
     * to PREPARED. Starts listening for live updates rather than catching up.
     *
     * <li>`SYNCING -> RECONNECTING` : Occurs when the live update fails.
     *
     * <li>`RECONNECTING -> RECONNECTING` : Can occur if the update calls
     * continue to fail, but the keepalive calls (to /versions) succeed.
     *
     * <li>`RECONNECTING -> ERROR` : Occurs when the keepalive call also fails
     *
     * <li>`ERROR -> SYNCING` : Occurs when the client has performed a
     * live update after having previously failed.
     *
     * <li>`ERROR -> ERROR` : Occurs when the client has failed to keepalive
     * for a second time or more.</li>
     *
     * <li>`SYNCING -> SYNCING` : Occurs when the client has performed a live
     * update. This is called <i>after</i> processing.</li>
     *
     * <li>`* -> STOPPED` : Occurs once the client has stopped syncing or
     * trying to sync after stopClient has been called.</li>
     * </ul>
     *
     * The payloads consits of the following 3 parameters:
     *
     * - state - An enum representing the syncing state. One of "PREPARED",
     * "SYNCING", "ERROR", "STOPPED".
     *
     * - prevState - An enum representing the previous syncing state.
     * One of "PREPARED", "SYNCING", "ERROR", "STOPPED" <b>or null</b>.
     *
     * - data - Data about this transition.
     *
     * @example
     * ```
     * matrixClient.on("sync", function(state, prevState, data) {
     *   switch (state) {
     *     case "ERROR":
     *       // update UI to say "Connection Lost"
     *       break;
     *     case "SYNCING":
     *       // update UI to remove any "Connection Lost" message
     *       break;
     *     case "PREPARED":
     *       // the client instance is ready to be queried.
     *       var rooms = matrixClient.getRooms();
     *       break;
     *   }
     * });
     * ```
     */
    Sync = "sync",
    /**
     * Fires whenever the SDK receives a new event.
     * <p>
     * This is only fired for live events received via /sync - it is not fired for
     * events received over context, search, or pagination APIs.
     *
     * The payload is the matrix event which caused this event to fire.
     * @example
     * ```
     * matrixClient.on("event", function(event){
     *   var sender = event.getSender();
     * });
     * ```
     */
    Event = "event",
    /** @deprecated Use {@link ReceivedToDeviceMessage}. */
    ToDeviceEvent = "toDeviceEvent",
    /**
     * Fires whenever the SDK receives a new (potentially decrypted) to-device message.
     * The payload is the to-device message and the encryption info for that message ({@link ReceivedToDeviceMessage}).
     * @example
     * ```
     * matrixClient.on("receivedToDeviceMessage", function(payload){
     *   const { message, encryptionInfo } = payload;
     *   var claimed_sender = encryptionInfo ? encryptionInfo.sender : message.sender;
     *   var isVerified = encryptionInfo ? encryptionInfo.verified : false;
     *   var type = message.type;
     * });
     */
    ReceivedToDeviceMessage = "receivedToDeviceMessage",
    /**
     * Fires whenever new user-scoped account_data is added.
     * The payload is a pair of event ({@link MatrixEvent}) describing the account_data just added, and the previous event, if known:
     *  - event: The event describing the account_data just added
     *  - oldEvent: The previous account data, if known.
     * @example
     * ```
     * matrixClient.on("accountData", function(event, oldEvent){
     *   myAccountData[event.type] = event.content;
     * });
     * ```
     */
    AccountData = "accountData",
    /**
     * Fires whenever a new Room is added. This will fire when you are invited to a
     * room, as well as when you join a room. <strong>This event is experimental and
     * may change.</strong>
     *
     * The payload is the newly created room, fully populated.
     * @example
     * ```
     * matrixClient.on("Room", function(room){
     *   var roomId = room.roomId;
     * });
     * ```
     */
    Room = "Room",
    /**
     * Fires whenever a Room is removed. This will fire when you forget a room.
     * <strong>This event is experimental and may change.</strong>
     * The payload is the roomId of the deleted room.
     * @example
     * ```
     * matrixClient.on("deleteRoom", function(roomId){
     *   // update UI from getRooms()
     * });
     * ```
     */
    DeleteRoom = "deleteRoom",
    SyncUnexpectedError = "sync.unexpectedError",
    /**
     * Fires when the client .well-known info is fetched.
     * The payload is the JSON object (see {@link IClientWellKnown}) returned by the server
     */
    ClientWellKnown = "WellKnown.client",
    ReceivedVoipEvent = "received_voip_event",
    TurnServers = "turnServers",
    TurnServersError = "turnServers.error"
}
type RoomEvents = RoomEvent.Name | RoomEvent.Redaction | RoomEvent.RedactionCancelled | RoomEvent.Receipt | RoomEvent.Tags | RoomEvent.LocalEchoUpdated | RoomEvent.HistoryImportedWithinTimeline | RoomEvent.AccountData | RoomEvent.MyMembership | RoomEvent.Timeline | RoomEvent.TimelineReset;
type RoomStateEvents = RoomStateEvent.Events | RoomStateEvent.Members | RoomStateEvent.NewMember | RoomStateEvent.Update | RoomStateEvent.Marker;
type CryptoEvents = (typeof CryptoEvent)[keyof typeof CryptoEvent];
type MatrixEventEvents = MatrixEventEvent.Decrypted | MatrixEventEvent.Replaced | MatrixEventEvent.VisibilityChange;
type RoomMemberEvents = RoomMemberEvent.Name | RoomMemberEvent.Typing | RoomMemberEvent.PowerLevel | RoomMemberEvent.Membership;
type UserEvents = UserEvent.AvatarUrl | UserEvent.DisplayName | UserEvent.Presence | UserEvent.CurrentlyActive | UserEvent.LastPresenceTs;
export type EmittedEvents = ClientEvent | RoomEvents | RoomStateEvents | CryptoEvents | MatrixEventEvents | RoomMemberEvents | UserEvents | CallEvent | CallEventHandlerEvent.Incoming | GroupCallEventHandlerEvent.Incoming | GroupCallEventHandlerEvent.Outgoing | GroupCallEventHandlerEvent.Ended | GroupCallEventHandlerEvent.Participants | HttpApiEvent.SessionLoggedOut | HttpApiEvent.NoConsent | BeaconEvent;
export type ClientEventHandlerMap = {
    [ClientEvent.Sync]: (state: SyncState, prevState: SyncState | null, data?: ISyncStateData) => void;
    [ClientEvent.Event]: (event: MatrixEvent) => void;
    [ClientEvent.ToDeviceEvent]: (event: MatrixEvent) => void;
    [ClientEvent.ReceivedToDeviceMessage]: (payload: ReceivedToDeviceMessage) => void;
    [ClientEvent.AccountData]: (event: MatrixEvent, lastEvent?: MatrixEvent) => void;
    [ClientEvent.Room]: (room: Room) => void;
    [ClientEvent.DeleteRoom]: (roomId: string) => void;
    [ClientEvent.SyncUnexpectedError]: (error: Error) => void;
    [ClientEvent.ClientWellKnown]: (data: IClientWellKnown) => void;
    [ClientEvent.ReceivedVoipEvent]: (event: MatrixEvent) => void;
    [ClientEvent.TurnServers]: (servers: ITurnServer[]) => void;
    [ClientEvent.TurnServersError]: (error: Error, fatal: boolean) => void;
} & RoomEventHandlerMap & RoomStateEventHandlerMap & CryptoEventHandlerMap & MatrixEventHandlerMap & RoomMemberEventHandlerMap & UserEventHandlerMap & CallEventHandlerEventHandlerMap & GroupCallEventHandlerEventHandlerMap & CallEventHandlerMap & HttpApiEventHandlerMap & BeaconEventHandlerMap;
/**
 * Represents a Matrix Client. Only directly construct this if you want to use
 * custom modules. Normally, {@link createClient} should be used
 * as it specifies 'sensible' defaults for these modules.
 */
export interface MatrixClient extends MatrixClientExtensionMethods, MatrixClientInternalMethods {
}
export declare class MatrixClient extends TypedEventEmitter<EmittedEvents, ClientEventHandlerMap> {
    static readonly RESTORE_BACKUP_ERROR_BAD_KEY = "RESTORE_BACKUP_ERROR_BAD_KEY";
    readonly logger: Logger;
    reEmitter: TypedReEmitter<EmittedEvents, ClientEventHandlerMap>;
    olmVersion: [number, number, number] | null;
    usingExternalCrypto: boolean;
    private _store;
    deviceId: string | null;
    credentials: {
        userId: string | null;
    };
    /**
     * Encryption key used for encrypting sensitive data (such as e2ee keys) in storage.
     *
     * As supplied in the constructor via {@link IMatrixClientCreateOpts#pickleKey}.
     * Used for migration from the legacy crypto to the rust crypto
     */
    private readonly legacyPickleKey?;
    scheduler?: MatrixScheduler;
    clientRunning: boolean;
    timelineSupport: boolean;
    urlPreviewCache: LRUCache<IPreviewUrlResponse>;
    private readonly publicRoomsCache;
    private readonly publicRoomsRequestCache;
    identityServer?: IIdentityServerProvider;
    http: MatrixHttpApi<IHttpOpts & {
        onlyData: true;
    }>;
    private readonly authedRequestProxy;
    cryptoBackend?: CryptoBackend;
    /**
     * Support MSC4362: Simplified Encrypted State Events.
     *
     * The client must be recreated for changes to this setting to take effect
     * reliably.
     *
     * When this setting is true, if we find a state event that is encrypted
     * (within a room that supports encrypted state), we will attempt to decrypt
     * it as specified in MSC4362. If the user was in the room at the time an
     * encrypted state event was received (meaning we have the key), even if
     * this setting was set to false at the time it was received, recreating the
     * client with this setting set to true will allow decrypting that event.
     *
     * When this setting is false, any state event that is encrypted will not be
     * decrypted, meaning it will have no effect. This matched the behaviour of
     * a client that does not support MSC4362.
     */
    enableEncryptedStateEvents: boolean;
    cryptoCallbacks: CryptoCallbacks;
    callEventHandler?: CallEventHandler;
    groupCallEventHandler?: GroupCallEventHandler;
    supportsCallTransfer: boolean;
    forceTURN: boolean;
    iceCandidatePoolSize: number;
    idBaseUrl?: string;
    baseUrl: string;
    readonly isVoipWithNoMediaAllowed: boolean;
    disableVoip: boolean;
    useLivekitForGroupCalls: boolean;
    protected canSupportVoip: boolean;
    peekSync: SyncApi | null;
    protected isGuestAccount: boolean;
    /**
     * Legacy crypto store used for migration from the legacy crypto to the rust crypto
     * @private
     */
    readonly legacyCryptoStore?: CryptoStore;
    protected verificationMethods?: string[];
    protected fallbackICEServerAllowed: boolean;
    syncApi?: SlidingSyncSdk | SyncApi;
    roomNameGenerator?: ICreateClientOpts["roomNameGenerator"];
    pushRules?: IPushRules;
    protected syncLeftRoomsPromise?: Promise<Room[]>;
    protected syncedLeftRooms: boolean;
    clientOpts?: IStoredClientOpts;
    clientWellKnownIntervalID?: ReturnType<typeof setInterval>;
    canResetTimelineCallback?: ResetTimelineCallback;
    canSupport: Map<Feature, ServerSupport>;
    readonly pushProcessor: PushProcessor;
    protected serverVersionsPromise?: Promise<IServerVersions>;
    clientWellKnown?: IClientWellKnown;
    protected clientWellKnownPromise?: Promise<IClientWellKnown>;
    turnServers: ITurnServer[];
    turnServersExpiry: number;
    checkTurnServersIntervalID?: ReturnType<typeof setInterval>;
    protected txnCtr: number;
    protected mediaHandler: MediaHandler;
    protected sessionId: string;
    /** IDs of events which are currently being encrypted.
     *
     * This is part of the cancellation mechanism: if the event is no longer listed here when encryption completes,
     * that tells us that it has been cancelled, and we should not send it.
     */
    private eventsBeingEncrypted;
    private useE2eForGroupCall;
    toDeviceMessageQueue: ToDeviceMessageQueue;
    livekitServiceURL?: string;
    private _secretStorage;
    private _encryptionUtils;
    private eventManager;
    private get encryptionUtils();
    readonly ignoredInvites: IgnoredInvites;
    readonly matrixRTC: MatrixRTCSessionManager;
    serverCapabilitiesService: ServerCapabilities;
    /**
     * Manager 扩展初始化完成的 Promise（由 createClient 注入）。
     * createClient 同步返回时仅 8 个核心 manager 可用，其余约 55 个私有
     * manager（friend/ai/...）经异步动态 import 挂载。调用方在使用这些
     * manager 前应 `await client.whenManagerExtensionsReady()`。
     */
    private managerExtensionsReady?;
    constructor(opts: IMatrixClientCreateOpts);
    set store(newStore: Store);
    /**
     * 注入 manager 扩展初始化的 Promise（由 createClient 调用）。
     * @internal
     */
    setManagerExtensionsReady(promise: Promise<void>): void;
    /**
     * 等待所有 manager 扩展异步挂载完成。
     *
     * `createClient()` 同步返回时仅核心 manager 可用，friend/ai/... 等私有
     * manager 经异步动态 import 挂载。使用这些 manager 前应 `await` 本方法。
     *
     * @returns 当 manager 初始化完成（或已跳过/失败）时 resolve 的 Promise。
     */
    whenManagerExtensionsReady(): Promise<void>;
    getEventManager(): EventManager;
    get store(): Store;
    /**
     * High level helper method to begin syncing and poll for new events. To listen for these
     * events, add a listener for {@link ClientEvent.Event}
     * via {@link MatrixClient#on}. Alternatively, listen for specific
     * state change events.
     * @param opts - Options to apply when syncing.
     */
    startClient(opts?: IStartClientOpts): Promise<void>;
    /**
     * Construct a SyncApiOptions for this client, suitable for passing into the SyncApi constructor
     */
    buildSyncApiOptions(): SyncApiOptions;
    /**
     * High level helper method to stop the client from polling and allow a
     * clean shutdown.
     */
    stopClient(): void;
    /**
     * Clear any data out of the persistent stores used by the client.
     *
     * @param args.cryptoDatabasePrefix - The database name to use for indexeddb, defaults to 'matrix-js-sdk'.
     * @returns Promise which resolves when the stores have been cleared.
     */
    clearStores(args?: {
        cryptoDatabasePrefix?: string;
    }): Promise<void>;
    /**
     * Get the user-id of the logged-in user
     *
     * @returns MXID for the logged-in user, or null if not logged in
     */
    getUserId(): string | null;
    /**
     * Get the user-id of the logged-in user
     *
     * @returns MXID for the logged-in user
     * @throws Error if not logged in
     */
    getSafeUserId(): string;
    /**
     * Get the domain for this client's MXID
     * @returns Domain of this MXID
     */
    getDomain(): string | null;
    /**
     * Get the local part of the current user ID e.g. "foo" in "\@foo:bar".
     * @returns The user ID localpart or null.
     */
    getUserIdLocalpart(): string | null;
    /**
     * Get the device ID of this client
     * @returns device ID
     */
    getDeviceId(): string | null;
    /**
     * Get the session ID of this client
     * @returns session ID
     */
    getSessionId(): string;
    /**
     * Check if the runtime environment supports VoIP calling.
     * @returns True if VoIP is supported.
     */
    supportsVoip(): boolean;
    /**
     * @returns
     */
    getMediaHandler(): MediaHandler;
    /**
     * Set whether VoIP calls are forced to use only TURN
     * candidates. This is the same as the forceTURN option
     * when creating the client.
     * @param force - True to force use of TURN servers
     */
    setForceTURN(force: boolean): void;
    /**
     * Set whether to advertise transfer support to other parties on Matrix calls.
     * @param support - True to advertise the 'm.call.transferee' capability
     */
    setSupportsCallTransfer(support: boolean): void;
    /**
     * Returns true if to-device signalling for group calls will be encrypted with Olm.
     * If false, it will be sent unencrypted.
     * @returns boolean Whether group call signalling will be encrypted
     */
    getUseE2eForGroupCall(): boolean;
    /**
     * Creates a new call.
     * The place*Call methods on the returned call can be used to actually place a call
     *
     * @param roomId - The room the call is to be placed in.
     * @returns the call or null if the browser doesn't support calling.
     */
    createCall(roomId: string): MatrixCall | null;
    /**
     * Creates a new group call and sends the associated state event
     * to alert other members that the room now has a group call.
     *
     * @param roomId - The room the call is to be placed in.
     */
    createGroupCall(roomId: string, type: GroupCallType, isPtt: boolean, intent: GroupCallIntent, dataChannelsEnabled?: boolean, dataChannelOptions?: IGroupCallDataChannelOptions): Promise<GroupCall>;
    getLivekitServiceURL(): string | undefined;
    setLivekitServiceURL(newURL: string): void;
    /**
     * Wait until an initial state for the given room has been processed by the
     * client and the client is aware of any ongoing group calls. Awaiting on
     * the promise returned by this method before calling getGroupCallForRoom()
     * avoids races where getGroupCallForRoom is called before the state for that
     * room has been processed. It does not, however, fix other races, eg. two
     * clients both creating a group call at the same time.
     * @param roomId - The room ID to wait for
     * @returns A promise that resolves once existing group calls in the room
     *          have been processed.
     */
    waitUntilRoomReadyForGroupCalls(roomId: string): Promise<void>;
    /**
     * Get an existing group call for the provided room.
     * @returns The group call or null if it doesn't already exist.
     */
    getGroupCallForRoom(roomId: string): GroupCall | null;
    /**
     * Get the current sync state.
     * @returns the sync state, which may be null.
     * @see MatrixClient#event:"sync"
     */
    getSyncState(): SyncState | null;
    /**
     * Returns the additional data object associated with
     * the current sync state, or null if there is no
     * such data.
     * Sync errors, if available, are put in the 'error' key of
     * this object.
     */
    getSyncStateData(): ISyncStateData | null;
    /**
     * Whether the initial sync has completed.
     * @returns True if at least one sync has happened.
     */
    isInitialSyncComplete(): boolean;
    /**
     * Return whether the client is configured for a guest account.
     * @returns True if this is a guest access_token (or no token is supplied).
     */
    isGuest(): boolean;
    /**
     * Set whether this client is a guest account. <b>This method is experimental
     * and may change without warning.</b>
     * @param guest - True if this is a guest account.
     * @experimental if the token is a macaroon, it should be encoded in it that it is a 'guest'
     * access token, which means that the SDK can determine this entirely without
     * the dev manually flipping this flag.
     */
    setGuest(guest: boolean): void;
    /**
     * Return the provided scheduler, if any.
     * @returns The scheduler or undefined
     */
    getScheduler(): MatrixScheduler | undefined;
    /**
     * Retry a backed off syncing request immediately. This should only be used when
     * the user <b>explicitly</b> attempts to retry their lost connection.
     * Will also retry any outbound to-device messages currently in the queue to be sent
     * (retries of regular outgoing events are handled separately, per-event).
     * @returns True if this resulted in a request being retried.
     */
    retryImmediately(): boolean;
    /**
     * Return the global notification EventTimelineSet, if any
     *
     * @returns the globl notification EventTimelineSet
     */
    getNotifTimelineSet(): EventTimelineSet | null;
    /**
     * Set the global notification EventTimelineSet
     *
     */
    setNotifTimelineSet(set: EventTimelineSet): void;
    /**
     * Gets the cached capabilities of the homeserver, returning cached ones if available.
     * If there are no cached capabilities and none can be fetched, throw an exception.
     *
     * @returns Promise resolving with The capabilities of the homeserver
     */
    getCapabilities(): Promise<Capabilities>;
    /**
     * Gets the cached capabilities of the homeserver. If none have been fetched yet,
     * return undefined.
     *
     * @returns The capabilities of the homeserver
     */
    getCachedCapabilities(): Capabilities | undefined;
    /**
     * Fetches the latest capabilities from the homeserver, ignoring any cached
     * versions. The newly returned version is cached.
     *
     * @returns A promise which resolves to the capabilities of the homeserver
     */
    fetchCapabilities(): Promise<Capabilities>;
    /**
     * Initialise support for end-to-end encryption in this client, using the rust matrix-sdk-crypto.
     *
     * **WARNING**: the cryptography stack is not thread-safe. Having multiple `MatrixClient` instances connected to
     * the same Indexed DB will cause data corruption and decryption failures. The application layer is responsible for
     * ensuring that only one `MatrixClient` issue is instantiated at a time.
     *
     * @param args.useIndexedDB - True to use an indexeddb store, false to use an in-memory store. Defaults to 'true'.
     * @param args.cryptoDatabasePrefix - The database name to use for indexeddb, defaults to 'matrix-js-sdk'.
     *    Unused if useIndexedDB is 'false'.
     * @param args.storageKey - A key with which to encrypt the indexeddb store. If provided, it must be exactly
     *    32 bytes of data, and must be the same each time the client is initialised for a given device.
     *    If both this and `storagePassword` are unspecified, the store will be unencrypted.
     * @param args.storagePassword - An alternative to `storageKey`. A password which will be used to derive a key to
     *    encrypt the store with. Deriving a key from a password is (deliberately) a slow operation, so prefer
     *    to pass a `storageKey` directly where possible.
     *
     * @returns a Promise which will resolve when the crypto layer has been
     *    successfully initialised.
     */
    initRustCrypto(args?: {
        useIndexedDB?: boolean;
        cryptoDatabasePrefix?: string;
        storageKey?: Uint8Array;
        storagePassword?: string;
        /**
         * Explicit opt-out from the ISSUE-08b default-deny guard on unencrypted in-memory
         * crypto stores. For tests / temporary sessions only.
         *
         * Production callers must instead provide `storageKey`/`storagePassword` derived
         * from a system keychain. Not auto-implied by `useIndexedDB: false`.
         */
        allowInMemoryStore?: boolean;
    }): Promise<void>;
    /**
     * Access the server-side secret storage API for this client.
     */
    get secretStorage(): ServerSideSecretStorage;
    /**
     * Access the crypto API for this client.
     *
     * If end-to-end encryption has been enabled for this client (via {@link initRustCrypto}),
     * returns an object giving access to the crypto API. Otherwise, returns `undefined`.
     */
    getCrypto(): CryptoApi | undefined;
    /**
     * Get the crypto backend instance.
     * This is intended for internal use by managers that need direct access to crypto functionality.
     * @returns The crypto backend instance, or undefined if crypto is not enabled.
     * @internal
     */
    getCryptoBackend(): CryptoBackend | undefined;
    /**
     * Get the stored client options.
     * This is intended for internal use by managers that need access to client configuration.
     * @returns The stored client options, or undefined if not set.
     * @internal
     */
    getClientOpts(): IStoredClientOpts | undefined;
    /**
     * Build sync API options for this client.
     * This is intended for internal use by managers that need to create SyncApi instances.
     * @returns The sync API options.
     * @internal
     */
    getSyncApiOptions(): SyncApiOptions;
    /**
     * Check whether the key backup private key is stored in secret storage.
     * @returns map of key name to key info the secret is
     *     encrypted with, or null if it is not present or not encrypted with a
     *     trusted key
     */
    isKeyBackupKeyStored(): Promise<Record<string, SecretStorageKeyDescription> | null>;
    private makeKeyBackupPath;
    deleteKeysFromBackup(roomId: undefined, sessionId: undefined, version?: string): Promise<void>;
    deleteKeysFromBackup(roomId: string, sessionId: undefined, version?: string): Promise<void>;
    deleteKeysFromBackup(roomId: string, sessionId: string, version?: string): Promise<void>;
    /**
     * Get the config for the media repository.
     *
     * @param useAuthenticatedMedia - If true, the caller supports authenticated
     * media and wants an authentication-required URL. Note that server support
     * for authenticated media will *not* be checked - it is the caller's responsibility
     * to do so before calling this function.
     *
     * @returns Promise which resolves with an object containing the config.
     */
    getMediaConfig(useAuthenticatedMedia?: boolean): Promise<IMediaConfig>;
    /**
     * Get the room for the given room ID.
     * This function will return a valid room for any room for which a Room event
     * has been emitted. Note in particular that other events, eg. RoomState.members
     * will be emitted for a room before this function will return the given room.
     * @param roomId - The room ID
     * @returns The Room or null if it doesn't exist or there is no data store.
     */
    getRoom(roomId: string | undefined): Room | null;
    /**
     * Retrieve all known rooms.
     * @returns A list of rooms, or an empty list if there is no data store.
     */
    getRooms(): Room[];
    /**
     * Retrieve all rooms that should be displayed to the user
     * This is essentially getRooms() with some rooms filtered out, eg. old versions
     * of rooms that have been replaced or (in future) other rooms that have been
     * marked at the protocol level as not to be displayed to the user.
     *
     * @param msc3946ProcessDynamicPredecessor - if true, look for an
     *                                           m.room.predecessor state event and
     *                                           use it if found (MSC3946).
     * @returns A list of rooms, or an empty list if there is no data store.
     */
    getVisibleRooms(msc3946ProcessDynamicPredecessor?: boolean): Room[];
    /**
     * Retrieve a user.
     * @param userId - The user ID to retrieve.
     * @returns A user or null if there is no data store or the user does
     * not exist.
     */
    getUser(userId: string): User | null;
    /**
     * Retrieve all known users.
     * @returns A list of users, or an empty list if there is no data store.
     */
    getUsers(): User[];
    /**
     * Set account data event for the current user, and wait for the result to be echoed over `/sync`.
     *
     * Waiting for the remote echo ensures that a subsequent call to {@link getAccountData} will return the updated
     * value.
     *
     * If called before the client is started with {@link startClient}, logs a warning and falls back to
     * {@link setAccountDataRaw}.
     *
     * Retries the request up to 5 times in the case of an {@link ConnectionError}.
     *
     * @param eventType - The event type
     * @param content - the contents object for the event
     */
    setAccountData<K extends keyof WritableAccountDataEvents>(eventType: K, content: AccountDataEvents[K] | Record<string, never>): Promise<EmptyObject>;
    /**
     * Set account data event for the current user, without waiting for the remote echo.
     *
     * @param eventType - The event type
     * @param content - the contents object for the event
     */
    setAccountDataRaw<K extends keyof WritableAccountDataEvents>(eventType: K, content: AccountDataEvents[K] | Record<string, never>): Promise<EmptyObject>;
    /**
     * Get account data event of given type for the current user.
     * @param eventType - The event type
     * @returns The contents of the given account data event
     */
    getAccountData<K extends keyof AccountDataEvents>(eventType: K): MatrixEvent | undefined;
    /**
     * Get account data event of given type for the current user. This variant
     * gets account data directly from the homeserver if the local store is not
     * ready, which can be useful very early in startup before the initial sync.
     * @param eventType - The event type
     * @returns Promise which resolves: The contents of the given account data event.
     * @returns Rejects: with an error response.
     */
    getAccountDataFromServer<K extends keyof AccountDataEvents>(eventType: K): Promise<AccountDataEvents[K] | null>;
    deleteAccountData(eventType: keyof WritableAccountDataEvents): Promise<void>;
    /**
     * Gets the users that are ignored by this client
     * @returns The array of users that are ignored (empty if none)
     */
    getIgnoredUsers(): string[];
    /**
     * Sets the users that the current user should ignore.
     * @param userIds - the user IDs to ignore
     * @returns Promise which resolves: an empty object
     * @returns Rejects: with an error response.
     */
    setIgnoredUsers(userIds: string[]): Promise<EmptyObject>;
    /**
     * Gets whether or not a specific user is being ignored by this client.
     * @param userId - the user ID to check
     * @returns true if the user is ignored, false otherwise
     */
    isUserIgnored(userId: string): boolean;
    /**
     * Join a room. If you have already joined the room, this will no-op.
     * @param roomIdOrAlias - The room ID or room alias to join.
     * @param opts - Options when joining the room.
     * @returns Promise which resolves: Room object.
     * @returns Rejects: with an error response.
     */
    /**
     * Join a room. If you are already in the room, this will no-op.
     * @param roomIdOrAlias - The room ID or room alias to join.
     * @param opts - Options when joining the room.
     * @returns Promise which resolves: the room joined.
     * @returns Rejects: with an error response.
     */
    joinRoom(roomIdOrAlias: string, opts?: IJoinRoomOpts): Promise<Room>;
    /**
     * Knock a room. If you have already knocked the room, this will no-op.
     * @param roomIdOrAlias - The room ID or room alias to knock.
     * @param opts - Options when knocking the room.
     * @returns Promise which resolves: `{room_id: {string}}`
     * @returns Rejects: with an error response.
     */
    knockRoom(roomIdOrAlias: string, opts?: KnockRoomOpts): Promise<{
        room_id: string;
    }>;
    /**
     * Resend an event. Will also retry any to-device messages waiting to be sent.
     * @param event - The event to resend.
     * @param room - Optional. The room the event is in. Will update the
     * timeline entry if provided.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    resendEvent(event: MatrixEvent, room: Room): Promise<ISendEventResponse>;
    /**
     * Cancel a queued or unsent event.
     *
     * @param event -   Event to cancel
     * @throws Error if the event is not in QUEUED, NOT_SENT or ENCRYPTING state
     */
    cancelPendingEvent(event: MatrixEvent): void;
    /**
     * @returns Promise which resolves with the request result.
     * @returns Rejects: with an error response.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    setRoomName(roomId: string, name: string): Promise<ISendEventResponse>;
    setRoomTopic(roomId: string, topic?: string, htmlTopic?: string): Promise<ISendEventResponse>;
    getRoomTags(roomId: string): Promise<ITagsResponse>;
    setRoomTag(roomId: string, tagName: string, metadata?: ITagMetadata): Promise<EmptyObject>;
    deleteRoomTag(roomId: string, tagName: string): Promise<EmptyObject>;
    /**
     * @param roomId - the ID of the room this event should be stored within
     * @param eventType - event type to be set
     * @param content - event content
     * @returns Promise which resolves: to an empty object `{}`
     * @returns Rejects: with an error response.
     */
    setRoomAccountData<K extends keyof RoomAccountDataEvents>(roomId: string, eventType: K, content: RoomAccountDataEvents[K] | Record<string, never>): Promise<EmptyObject>;
    /**
     * Set a power level to one or multiple users.
     * Will apply changes atop of current power level event from local state if running & synced, falling back
     * to fetching latest from the `/state/` API.
     * @param roomId - the room to update power levels in
     * @param userId - the ID of the user or users to update power levels of
     * @param powerLevel - the numeric power level to update given users to
     * @returns Promise which resolves: to an ISendEventResponse object
     * @returns Rejects: with an error response.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    setPowerLevel(roomId: string, userId: string | string[], powerLevel: number | undefined): Promise<ISendEventResponse>;
    /**
     * Create an m.beacon_info event
     * @returns
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    unstable_createLiveBeacon(roomId: Room["roomId"], beaconInfoContent: MBeaconInfoEventContent): Promise<ISendEventResponse>;
    /**
     * Upsert a live beacon event
     * using a specific m.beacon_info.* event variable type
     * @param roomId - string
     * @returns
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    unstable_setLiveBeacon(roomId: string, beaconInfoContent: MBeaconInfoEventContent): Promise<ISendEventResponse>;
    /**
     * Send a Matrix timeline event.
     * @param roomId The room to send to.
     * @param eventType The event type.
     * @param content The event content.
     * @param txnId An optional ID to deduplicate requests in case of repeated attempts.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    sendEvent<K extends keyof TimelineEvents>(roomId: string, eventType: K, content: TimelineEvents[K], txnId?: string): Promise<ISendEventResponse>;
    sendEvent<K extends keyof TimelineEvents>(roomId: string, threadId: string | null, eventType: K, content: TimelineEvents[K], txnId?: string): Promise<ISendEventResponse>;
    get clientOptions(): IStoredClientOpts | undefined;
    /**
     * @param eventObject - An object with the partial structure of an event, to which event_id, user_id, room_id and origin_server_ts will be added.
     * @param txnId - Optional.
     * @returns Promise which resolves: to an empty object `{}`
     * @returns Rejects: with an error response.
     */
    private sendCompleteEvent;
    /**
     * encrypts the event if necessary; adds the event to the queue, or sends it; marks the event as sent/unsent
     * @returns returns a promise which resolves with the result of the send request
     */
    protected encryptAndSendEvent(room: Room | null, event: MatrixEvent, queryDict?: QueryDict): Promise<ISendEventResponse>;
    /**
     * Simply sends a delayed event without encrypting it.
     * Known limitation: delayed events are currently sent without encryption.
     * @param delayOpts - Properties of the delay for this event.
     * @returns returns a promise which resolves with the result of the delayed send request
     */
    protected encryptAndSendEvent(room: Room | null, event: MatrixEvent, delayOpts: SendDelayedEventRequestOpts, queryDict?: QueryDict): Promise<ISendEventResponse>;
    private encryptEventIfNeeded;
    /**
     * Returns the eventType that should be used taking encryption into account
     * for a given eventType.
     * @param roomId - the room for the events `eventType` relates to
     * @param eventType - the event type
     * @returns the event type taking encryption into account
     */
    private getEncryptedIfNeededEventType;
    protected updatePendingEventStatus(room: Room | null, event: MatrixEvent, newStatus: EventStatus): void;
    private sendEventHttpRequest;
    /**
     * @param txnId -  transaction id. One will be made up if not supplied.
     * @param opts - Redact options
     * @returns Promise which resolves with an empty object.
     * @returns Rejects: with an error response.
     * @throws Error if called with `with_rel_types` (MSC3912) but the server does not support it.
     *         Callers should check whether the server supports MSC3912 via `MatrixClient.canSupport`.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    redactEvent(roomId: string, eventId: string, txnId?: string | undefined, opts?: IRedactOpts): Promise<ISendEventResponse>;
    redactEvent(roomId: string, threadId: string | null, eventId: string, txnId?: string | undefined, opts?: IRedactOpts): Promise<ISendEventResponse>;
    sendMessage(roomId: string, threadId: string | null | RoomMessageEventContent, content?: RoomMessageEventContent | string, txnId?: string): Promise<ISendEventResponse>;
    sendTextMessage(roomId: string, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendTextMessage(roomId: string, threadId: string | null, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendNotice(roomId: string, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendNotice(roomId: string, threadId: string | null, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendEmoteMessage(roomId: string, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendEmoteMessage(roomId: string, threadId: string | null, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendImageMessage(roomId: string, threadId: string | null, url?: string | ImageInfo, info?: ImageInfo | string, text?: string): Promise<ISendEventResponse>;
    sendStickerMessage(roomId: string, threadId: string | null, url?: string | ImageInfo, info?: ImageInfo | string, text?: string): Promise<ISendEventResponse>;
    sendHtmlMessage(roomId: string, threadIdOrBody: string | null, bodyOrHtml: string, htmlBody?: string): Promise<ISendEventResponse>;
    sendHtmlNotice(roomId: string, threadIdOrBody: string | null, bodyOrHtml: string, htmlBody?: string): Promise<ISendEventResponse>;
    sendHtmlEmote(roomId: string, threadIdOrBody: string | null, bodyOrHtml: string, htmlBody?: string): Promise<ISendEventResponse>;
    protected prepareSendEventWithThreadRelation(roomId: string, threadIdOrEventType: string | null, eventTypeOrContent: string | IContent, contentOrTxnId?: IContent | string, txnIdOrVoid?: string): PreparedSendEventParams;
    private sendPreparedCompleteEvent;
    private assertDelayedEventsSupported;
    private assertStickyEventsSupported;
    /**
     * Send a delayed timeline event.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) for more details.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    _unstable_sendDelayedEvent<K extends keyof TimelineEvents>(roomId: string, delayOpts: SendDelayedEventRequestOpts, threadId: string | null, eventType: K, content: TimelineEvents[K], txnId?: string): Promise<SendDelayedEventResponse>;
    /**
     * Send a delayed sticky timeline event.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) and
     *   [MSC4354](https://github.com/matrix-org/matrix-spec-proposals/pull/4354) for more details.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    _unstable_sendStickyDelayedEvent<K extends keyof TimelineEvents>(roomId: string, stickDuration: number, delayOpts: SendDelayedEventRequestOpts, threadId: string | null, eventType: K, content: TimelineEvents[K] & {
        msc4354_sticky_key?: string;
    }, txnId?: string): Promise<SendDelayedEventResponse>;
    /**
     * Send a delayed state event.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) for more details.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    _unstable_sendDelayedStateEvent<K extends keyof StateEvents>(roomId: string, delayOpts: SendDelayedEventRequestOpts, eventType: K, content: StateEvents[K], stateKey?: string, opts?: IRequestOpts): Promise<SendDelayedEventResponse>;
    /**
     * Send a sticky timeline event.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4354](https://github.com/matrix-org/matrix-spec-proposals/pull/4354) for more details.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    _unstable_sendStickyEvent<K extends keyof TimelineEvents>(roomId: string, stickDuration: number, threadId: string | null, eventType: K, content: TimelineEvents[K] & {
        msc4354_sticky_key?: string;
    }, txnId?: string): Promise<ISendEventResponse>;
    /**
     * Cancel the scheduled delivery of the delayed event matching the provided delayId.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) for more details.
     *
     * SDK-BL-005: Delegates to {@link DelayedEventsManager.cancelScheduledDelayedEvent}.
     * The manager uses the action-in-BODY single request format
     * (`POST /delayed_events/{delay_id}` body `{ action }`), removing the previous
     * action-in-PATH + fallback flow that issued an extra failed request per call.
     *
     * @throws A M_NOT_FOUND error if no matching delayed event could be found.
     */
    _unstable_cancelScheduledDelayedEvent(delayId: string | number, requestOptions?: IRequestOpts): Promise<EmptyObject>;
    /**
     * Restart the scheduled delivery of the delayed event matching the given delayId.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) for more details.
     *
     * SDK-BL-005: Delegates to {@link DelayedEventsManager.restartScheduledDelayedEvent}
     * (action-in-BODY single request, no fallback).
     *
     * @throws A M_NOT_FOUND error if no matching delayed event could be found.
     */
    _unstable_restartScheduledDelayedEvent(delayId: string | number, requestOptions?: IRequestOpts): Promise<EmptyObject>;
    /**
     * Immediately send the delayed event matching the given delayId,
     * instead of waiting for its scheduled delivery.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC4140](https://github.com/matrix-org/matrix-spec-proposals/pull/4140) for more details.
     *
     * SDK-BL-005: Delegates to {@link DelayedEventsManager.sendScheduledDelayedEvent}
     * (action-in-BODY single request, no fallback).
     *
     * @throws A M_NOT_FOUND error if no matching delayed event could be found.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    _unstable_sendScheduledDelayedEvent(delayId: string | number, requestOptions?: IRequestOpts): Promise<EmptyObject>;
    /**
     *
     * @param roomId
     * @param notificationEventId
     * @returns
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    sendRtcDecline(roomId: string, notificationEventId: string): Promise<ISendEventResponse>;
    /**
     * Get a preview of the given URL as of (roughly) the given point in time,
     * described as an object with OpenGraph keys and associated values.
     * Attributes may be synthesized where actual OG metadata is lacking.
     * Caches results to prevent hammering the server.
     * @param url - The URL to get preview data for
     * @param ts - The preferred point in time that the preview should
     * describe (ms since epoch).  The preview returned will either be the most
     * recent one preceding this timestamp if available, or failing that the next
     * most recent available preview.
     * @returns Promise which resolves: Object of OG metadata.
     * @returns Rejects: with an error response.
     * May return synthesized attributes if the URL lacked OG meta.
     */
    getUrlPreview(url: string, ts: number): Promise<IPreviewUrlResponse>;
    /**
     * @returns Promise which resolves: to an empty object `{}`
     * @returns Rejects: with an error response.
     */
    sendTyping(roomId: string, isTyping: boolean, timeoutMs: number): Promise<EmptyObject>;
    /**
     * Get typing users in a room
     * @param roomId - The room ID
     * @returns Array of user IDs currently typing
     */
    getRoomTyping(roomId: string): Promise<string[]>;
    /**
     * Get typing users in multiple rooms
     * @param roomIds - Array of room IDs
     * @returns Map of room ID to array of typing user IDs
     */
    getBatchTyping(roomIds: string[]): Promise<Record<string, string[]>>;
    /**
     * Determines the history of room upgrades for a given room, as far as the
     * client can see. Returns an array of Rooms where the first entry is the
     * oldest and the last entry is the newest (likely current) room. If the
     * provided room is not found, this returns an empty list. This works in
     * both directions, looking for older and newer rooms of the given room.
     * @param roomId - The room ID to search from
     * @param verifyLinks - If true, the function will only return rooms
     * which can be proven to be linked. For example, rooms which have a create
     * event pointing to an old room which the client is not aware of or doesn't
     * have a matching tombstone would not be returned.
     * @param msc3946ProcessDynamicPredecessor - if true, look for
     * m.room.predecessor state events as well as create events, and prefer
     * predecessor events where they exist (MSC3946).
     * @returns An array of rooms representing the upgrade
     * history.
     */
    getRoomUpgradeHistory(roomId: string, verifyLinks?: boolean, msc3946ProcessDynamicPredecessor?: boolean): Room[];
    /**
     * Send an invite to the given user to join the given room.
     *
     * @param roomId - The ID of the room to which the user should be invited.
     * @param userId - The ID of the user that should be invited.
     * @param opts - Optional reason object. For backwards compatibility, a string is also accepted, and will be interpreted as a reason.
     *
     * @returns An empty object.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    invite(roomId: string, userId: string, opts?: InviteOpts | string): Promise<EmptyObject>;
    /**
     * Invite a user to a room based on their email address.
     * @param roomId - The room to invite the user to.
     * @param email - The email address to invite.
     * @returns Promise which resolves: `{}` an empty object.
     * @returns Rejects: with an error response.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    inviteByEmail(roomId: string, email: string): Promise<EmptyObject>;
    /**
     * Invite a user to a room based on a third-party identifier.
     * @param roomId - The room to invite the user to.
     * @param medium - The medium to invite the user e.g. "email".
     * @param address - The address for the specified medium.
     * @returns Promise which resolves: `{}` an empty object.
     * @returns Rejects: with an error response.
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    inviteByThreePid(roomId: string, medium: string, address: string): Promise<EmptyObject>;
    /**
     * @returns Promise which resolves: `{}` an empty object.
     * @returns Rejects: with an error response.
     */
    leave(roomId: string): Promise<EmptyObject>;
    /**
     * Leaves all rooms in the chain of room upgrades based on the given room. By
     * default, this will leave all the previous and upgraded rooms, including the
     * given room. To only leave the given room and any previous rooms, keeping the
     * upgraded (modern) rooms untouched supply `false` to `includeFuture`.
     * @param roomId - The room ID to start leaving at
     * @param includeFuture - If true, the whole chain (past and future) of
     * upgraded rooms will be left.
     * @returns Promise which resolves when completed with an object keyed
     * by room ID and value of the error encountered when leaving or null.
     */
    leaveRoomChain(roomId: string, includeFuture?: boolean): Promise<{
        [roomId: string]: Error | MatrixError | null;
    }>;
    /**
     * @param reason - Optional.
     * @returns Promise which resolves with an empty object.
     * @returns Rejects: with an error response.
     */
    ban(roomId: string, userId: string, reason?: string): Promise<EmptyObject>;
    /**
     * @param deleteRoom - True to delete the room from the store on success.
     * Default: true.
     * @returns Promise which resolves: `{}` an empty object.
     * @returns Rejects: with an error response.
     */
    forget(roomId: string, deleteRoom?: boolean): Promise<EmptyObject>;
    unban(roomId: string, userId: string): Promise<EmptyObject>;
    kick(roomId: string, userId: string, reason?: string): Promise<EmptyObject>;
    getPushActionsForEvent(event: MatrixEvent, forceRecalculate?: boolean): IActionsObject | null;
    getPushDetailsForEvent(event: MatrixEvent, forceRecalculate?: boolean): PushDetails | null;
    setSyncPresence(presence?: SetPresence): Promise<void>;
    scrollback(room: Room, limit?: number): Promise<Room>;
    /**
     * Get the event context for a given event.
     * @param roomId - The room ID.
     * @param eventId - The event ID.
     * @param params - Optional parameters.
     * @returns The event context.
     */
    getEventContext(roomId: string, eventId: string, params?: {
        limit?: number;
        filter?: IRoomEventFilter;
    }): Promise<import("./@types/requests").IContextResponse>;
    /**
     * Retrieve scrollback for this room from the store.
     * @param room - The room.
     * @param limit - The limit.
     * @returns The events.
     */
    storeScrollback(room: Room, limit: number): MatrixEvent[];
    /**
     * Store events for a room in the store.
     * @param room - The room.
     * @param events - The events.
     * @param token - The token.
     * @param backwards - Whether these are paginated results.
     */
    storeEvents(room: Room, events: MatrixEvent[], token: string | null, backwards: boolean): void;
    getEventMapper(options?: MapperOpts): EventMapper;
    getEventTimeline(timelineSet: EventTimelineSet, eventId: string): Promise<EventTimeline | null>;
    getThreadTimeline(timelineSet: EventTimelineSet, eventId: string): Promise<EventTimeline | undefined>;
    getLatestTimeline(timelineSet: EventTimelineSet): Promise<EventTimeline | null>;
    createMessagesRequest(roomId: string, fromToken: string | null, limit: number | undefined, dir: Direction, timelineFilter?: Filter): Promise<IMessagesResponse>;
    createThreadListMessagesRequest(roomId: string, fromToken: string | null, limit?: number, dir?: Direction, threadListType?: ThreadFilterType | null, timelineFilter?: Filter): Promise<IMessagesResponse>;
    paginateEventTimeline(eventTimeline: EventTimeline, opts: IPaginateOpts): Promise<boolean>;
    resetNotifTimelineSet(): void;
    peekInRoom(roomId: string, limit?: number): Promise<Room>;
    stopPeeking(): void;
    setGuestAccess(roomId: string, opts: IGuestAccessOpts): Promise<void>;
    requestRegisterEmailToken(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestTokenResponse>;
    requestRegisterMsisdnToken(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestMsisdnTokenResponse>;
    requestAdd3pidEmailToken(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestTokenResponse>;
    requestAdd3pidMsisdnToken(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestMsisdnTokenResponse>;
    requestPasswordEmailToken(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestTokenResponse>;
    requestPasswordMsisdnToken(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink: string): Promise<IRequestMsisdnTokenResponse>;
    getRoomPushRule(scope: "global" | "device", roomId: string): IPushRule | undefined;
    setRoomMutePushRule(scope: "global" | "device", roomId: string, mute: boolean): Promise<void> | undefined;
    searchMessageText(opts: ISearchOpts): Promise<ISearchResponse>;
    searchRoomEvents(opts: IEventSearchOpts): Promise<ISearchResults>;
    backPaginateRoomEventsSearch<T extends ISearchResults>(searchResults: T): Promise<T>;
    /** @internal */
    processRoomEventsSearch<T extends ISearchResults>(searchResults: T, response: ISearchResponse): T;
    syncLeftRooms(): Promise<Room[]>;
    createFilter(content: IFilterDefinition): Promise<Filter>;
    getFilter(userId: string, filterId: string, allowCached: boolean): Promise<Filter>;
    getOrCreateFilter(filterName: string, filter: Filter): Promise<string>;
    getOpenIdToken(): Promise<IOpenIDToken>;
    private startCallEventHandler;
    private startMatrixRTC;
    /**
     * Once the client has been initialised, we want to clear notifications we
     * know for a fact should be here.
     * This issue should also be addressed on synapse's side and is tracked as part
     * of https://github.com/matrix-org/synapse/issues/14837
     *
     * We consider a room or a thread as fully read if the current user has sent
     * the last event in the live timeline of that context and if the read receipt
     * we have on record matches.
     */
    private fixupRoomNotifications;
    turnServer(): Promise<ITurnServerResponse>;
    getTurnServers(): ITurnServer[];
    getTurnServersExpiry(): number;
    get pollingTurnServers(): boolean;
    checkTurnServers(): Promise<boolean | undefined>;
    setFallbackICEServerAllowed(allow: boolean): void;
    isFallbackICEServerAllowed(): boolean;
    isSynapseAdministrator(): Promise<boolean>;
    whoisSynapseUser(userId: string): Promise<ISynapseAdminWhoisResponse>;
    deactivateSynapseUser(userId: string): Promise<ISynapseAdminDeactivateResponse>;
    fetchClientWellKnown(): Promise<void>;
    getClientWellKnown(): IClientWellKnown | undefined;
    waitForClientWellKnown(): Promise<IClientWellKnown>;
    /**
     * store client options with boolean/string/numeric values
     * to know in the next session what flags the sync data was
     * created with (e.g. lazy loading)
     * @returns for store operation
     */
    storeClientOptions(): Promise<void>;
    /**
     * Gets a set of room IDs in common with another user.
     *
     * Note: This endpoint is unstable, and can throw an `Error`.
     *   Check progress on [MSC2666](https://github.com/matrix-org/matrix-spec-proposals/pull/2666) for more details.
     *
     * @param userId - The userId to check.
     * @returns Promise which resolves to an array of rooms
     * @returns Rejects: with an error response.
     */
    _unstable_getSharedRooms(userId: string): Promise<string[]>;
    /**
     * Returns a set of configured RTC transports supported by the homeserver.
     * Requires homeserver support for MSC4143.
     * @throws A M_NOT_FOUND error if not supported by the homeserver.
     */
    _unstable_getRTCTransports(): Promise<Transport[]>;
    getVersions(): Promise<IServerVersions>;
    isVersionSupported(version: string): Promise<boolean>;
    doesServerSupportUnstableFeature(feature: string): Promise<boolean>;
    doesServerAdvertiseSynapseRustFeature(feature: SynapseRustFeatureName): Promise<boolean>;
    getSynapseRustFeatureSupport(): Promise<SynapseRustFeatureSupport>;
    doesServerForceEncryptionForPreset(presetName: Preset): Promise<boolean>;
    doesServerSupportThread(): Promise<{
        threads: FeatureSupport;
        list: FeatureSupport;
        fwdPagination: FeatureSupport;
    }>;
    hasLazyLoadMembersEnabled(): boolean;
    setCanResetTimelineCallback(cb: ResetTimelineCallback): void;
    getCanResetTimelineCallback(): ResetTimelineCallback | undefined;
    /**
     * Returns relations for a given event. Handles encryption transparently,
     * with the caveat that the amount of events returned might be 0, even though you get a nextBatch.
     * When the returned promise resolves, all messages should have finished trying to decrypt.
     * @param roomId - the room of the event
     * @param eventId - the id of the event
     * @param relationType - the rel_type of the relations requested
     * @param eventType - the event type of the relations requested
     * @param opts - options with optional values for the request.
     * @returns an object with `events` as `MatrixEvent[]` and optionally `nextBatch` if more relations are available.
     */
    relations(roomId: string, eventId: string, relationType: RelationType | string | null, eventType?: EventType | string | null, opts?: IRelationsRequestOpts): Promise<{
        originalEvent?: MatrixEvent | null;
        events: MatrixEvent[];
        nextBatch?: string | null;
        prevBatch?: string | null;
    }>;
    /**
     * Get aggregations for an event
     * @param roomId - The room ID
     * @param eventId - The event ID
     * @param relType - The relation type
     * @returns Aggregation data
     */
    getAggregations(roomId: string, eventId: string, relType: string): Promise<{
        chunk: Array<{
            type: string;
            key: string;
            count: number;
        }>;
    }>;
    /**
     * Generates a random string suitable for use as a client secret. <strong>This
     * method is experimental and may change.</strong>
     * @returns A new client secret
     */
    generateClientSecret(): string;
    /**
     * Attempts to decrypt an event
     * @param event - The event to decrypt
     * @returns A decryption promise
     */
    decryptEventIfNeeded(event: MatrixEvent, options?: IDecryptOptions): Promise<void>;
    /**
     * Get the Homeserver URL of this client
     * @returns Homeserver URL of this client
     */
    getHomeserverUrl(): string;
    /**
     * Get the access token associated with this account.
     * @returns The access_token or null
     */
    getAccessToken(): string | null;
    /**
     * Get the refresh token associated with this account.
     * @returns The refresh_token or null
     */
    getRefreshToken(): string | null;
    /**
     * Set the access token associated with this account.
     * @param token - The new access token.
     */
    setAccessToken(token: string): void;
    /**
     * @returns true if there is a valid access_token for this client.
     */
    isLoggedIn(): boolean;
    /**
     * Make up a new transaction id
     *
     * @returns a new, unique, transaction id
     */
    makeTxnId(): string;
    isUsernameAvailable(username: string): Promise<boolean>;
    register(username: string, password: string, sessionId: string | null, auth: {
        session?: string;
        type: string;
    }, bindThreepids?: {
        email?: boolean;
        msisdn?: boolean;
    }, guestAccessToken?: string, inhibitLogin?: boolean): Promise<RegisterResponse>;
    registerGuest({ body }?: {
        body?: RegisterRequest;
    }): Promise<RegisterResponse>;
    registerRequest(data: RegisterRequest, kind?: string): Promise<RegisterResponse>;
    refreshToken(refreshToken: string): Promise<IRefreshTokenResponse>;
    loginFlows(): Promise<ILoginFlowsResponse>;
    getCasLoginUrl(redirectUrl: string): string;
    getSsoLoginUrl(redirectUrl: string, loginType?: string, idpId?: string, action?: SSOAction): string;
    loginRequest(data: LoginRequest): Promise<LoginResponse>;
    logout(stopClient?: boolean): Promise<EmptyObject>;
    deactivateAccount(auth?: AuthDict, erase?: boolean): Promise<{
        id_server_unbind_result: IdServerUnbindResult;
    }>;
    requestLoginToken(auth?: AuthDict): Promise<LoginTokenPostResponse>;
    getFallbackAuthUrl(loginType: string, authSessionId: string): string;
    createRoom(options: ICreateRoomOpts): Promise<{
        room_id: string;
    }>;
    fetchRelations(roomId: string, eventId: string, relationType: RelationType | string | null, eventType?: string | null, opts?: IRelationsRequestOpts): Promise<IRelationsResponse>;
    roomState(roomId: string): Promise<IStateEventWithRoomId[]>;
    fetchRoomEvent(roomId: string, eventId: string): Promise<Partial<IEvent>>;
    members(roomId: string, includeMembership?: string, excludeMembership?: string, atEventId?: string): Promise<{
        [userId: string]: IStateEventWithRoomId[];
    }>;
    upgradeRoom(roomId: string, newVersion: string, additionalCreators?: string[]): Promise<{
        replacement_room: string;
    }>;
    getStateEvent(roomId: string, eventType: string, stateKey?: string): Promise<IContent>;
    sendStateEvent<K extends keyof StateEvents>(roomId: string, eventType: K, content: StateEvents[K], stateKey?: string, opts?: IRequestOpts): Promise<ISendEventResponse>;
    private encryptStateEventIfNeeded;
    roomInitialSync(roomId: string, _limit: number): Promise<IRoomInitialSyncResponse>;
    getJoinedRooms(): Promise<IJoinedRoomsResponse>;
    getJoinedRoomMembers(roomId: string): Promise<IJoinedMembersResponse>;
    publicRooms({ server, limit, since, ...options }?: IRoomDirectoryOptions): Promise<IPublicRoomsResponse>;
    createAlias(alias: string, roomId: string): Promise<EmptyObject>;
    deleteAlias(alias: string): Promise<EmptyObject>;
    getLocalAliases(roomId: string): Promise<{
        aliases: string[];
    }>;
    getRoomIdForAlias(alias: string): Promise<{
        room_id: string;
        servers: string[];
    }>;
    getRoomDirectoryVisibility(roomId: string): Promise<{
        visibility: Visibility;
    }>;
    setRoomDirectoryVisibility(roomId: string, visibility: Visibility): Promise<EmptyObject>;
    searchUserDirectory({ term, limit }: {
        term: string;
        limit?: number;
    }): Promise<IUserDirectoryResponse>;
    uploadContent(file: FileType, opts?: UploadOpts): Promise<UploadResponse>;
    cancelUpload(upload: Promise<UploadResponse>): boolean;
    getCurrentUploads(): Upload[];
    doesServerSupportExtendedProfiles(): Promise<boolean>;
    getExtendedProfile(userId: string): Promise<IExtendedProfile>;
    getExtendedProfileProperty(userId: string, key: string): Promise<unknown>;
    setExtendedProfileProperty(key: string, value: unknown): Promise<void>;
    deleteExtendedProfileProperty(key: string): Promise<void>;
    patchExtendedProfile(profile: IExtendedProfile): Promise<IExtendedProfile>;
    setExtendedProfile(profile: IExtendedProfile): Promise<void>;
    setPassword(authDict: AuthDict, newPassword: string, logoutDevices?: boolean): Promise<EmptyObject>;
    setLocalNotificationSettings(deviceId: string, notificationSettings: LocalNotificationSettings): Promise<EmptyObject>;
    search({ body, next_batch: nextBatch }: {
        body: ISearchRequestBody;
        next_batch?: string;
    }, abortSignal?: AbortSignal): Promise<ISearchResponse>;
    uploadKeysRequest(content: IUploadKeysRequest, _opts?: void): Promise<IKeysUploadResponse>;
    uploadKeySignatures(content: KeySignatures): Promise<IUploadKeySignaturesResponse>;
    downloadKeysForUsers(userIds: string[], { token }?: {
        token?: string;
    }): Promise<IDownloadKeyResult>;
    claimOneTimeKeys(devices: [string, string][], keyAlgorithm?: string, timeout?: number): Promise<IClaimOTKsResult>;
    getKeyChanges(oldToken: string, newToken: string): Promise<{
        changed: string[];
        left: string[];
    }>;
    uploadDeviceSigningKeys(auth?: AuthDict, keys?: CrossSigningKeys): Promise<EmptyObject>;
    requestRoomKey(request: ICreateRoomKeyRequest): Promise<IRoomKeyRequestCreateResponse>;
    getRoomKeyRequests(query?: IGetRoomKeyRequestsQuery): Promise<IRoomKeyRequestsResponse>;
    deleteRoomKeyRequest(requestId: string): Promise<EmptyObject>;
    getThirdpartyProtocols(): Promise<{
        [protocol: string]: IProtocol;
    }>;
    getThirdpartyLocation(protocol: string, params: {
        searchFields?: string[];
    }): Promise<IThirdPartyLocation[]>;
    getThirdpartyUser(protocol: string, params?: QueryDict): Promise<IThirdPartyUser[]>;
    getRoomHierarchy(roomId: string, limit?: number, maxDepth?: number, suggestedOnly?: boolean, fromToken?: string): Promise<IRoomHierarchy>;
    unstableCreateFileTree(name: string): Promise<MSC3089TreeSpace>;
    unstableGetFileTreeSpace(roomId: string): MSC3089TreeSpace | null;
    slidingSync(req: MSC3575SlidingSyncRequest, proxyBaseUrl?: string, abortSignal?: AbortSignal): Promise<MSC3575SlidingSyncResponse>;
    isSlidingSyncSupported(): Promise<boolean>;
    supportsThreads(): boolean;
    supportsIntentionalMentions(): boolean;
    getMyRooms(): Promise<{
        rooms: IMyRoomInfo[];
        total: number;
    }>;
    createSecureBackup(passphrase: string): Promise<ISecureBackupInfo>;
    searchRooms(searchTerm: string, limit?: number): Promise<{
        results: unknown[];
        count: number;
        next_batch: string | null;
    }>;
    searchRecipients(searchTerm: string, limit?: number): Promise<{
        results: unknown[];
        count: number;
        next_batch: string | null;
    }>;
    getClientConfig(): Promise<{
        homeserver: {
            base_url: string;
            server_name: string;
        };
        identity_server: {
            base_url: string;
        };
        push: {
            enabled: boolean;
        };
        email: {
            enabled: boolean;
        };
        features: Record<string, boolean>;
        defaults: Record<string, unknown>;
    }>;
    getSSOUserInfo(): Promise<{
        sub: string;
        name?: string;
        picture?: string;
        email?: string;
    }>;
    getSecureBackup(backupId: string): Promise<ISecureBackupInfo>;
    verifySecureBackupPassphrase(backupId: string, passphrase: string): Promise<ISecureBackupVerifyResponse>;
    storeSecureBackupKeys(backupId: string, passphrase: string, sessionKeys: ISecureBackupSessionKey[]): Promise<ISecureBackupStoreKeysResponse>;
    restoreSecureBackup(backupId: string, passphrase: string): Promise<ISecureBackupRestoreResponse>;
    deleteSecureBackup(backupId: string): Promise<EmptyObject>;
    processThreadEvents(room: Room, threadedEvents: MatrixEvent[], toStartOfTimeline: boolean): void;
    processThreadRoots(room: Room, threadedEvents: MatrixEvent[], toStartOfTimeline: boolean): void;
    processBeaconEvents(room?: Room, events?: MatrixEvent[]): void;
    processAggregatedTimelineEvents(room?: Room, events?: MatrixEvent[]): void;
    private processPaginationEvents;
    whoami(): Promise<IWhoamiResponse>;
    timestampToEvent(roomId: string, timestamp: number, dir: Direction): Promise<TimestampToEventResponse>;
    getAuthMetadata(): Promise<OidcClientConfig>;
    getCryptoAlgorithm(): unknown;
    setCryptoAlgorithm(_algorithm: unknown): void;
    hasCrypto(): boolean;
    initCrypto(): Promise<void>;
    stopCrypto(): void;
    cryptoStore: unknown;
    deleteCryptoStore(): Promise<void>;
    isCryptoStoreReady(): boolean;
    rotateEncryptionKeys(): Promise<void>;
    isRotationNeeded(): boolean;
    getRotationPeriod(): number;
    setRotationPeriod(_period: number): void;
    getLastRotationTime(): number;
    getRoomWithHighestUnread(): Room | null;
    getRoomsWithUnreadNotifications(): Room[];
    rooms: Room[];
    getRoomByAlias(_alias: string): Room | null;
    sortRoomsByLastMessage(): void;
    claimKeys(_users: Record<string, string[]>): Promise<unknown>;
    claimedKeys: Record<string, Record<string, string>>;
    getUserStorageUsage(_userId: string): Promise<{
        size: number;
        ntFiles: number;
    } | null>;
    getNotificationCount(_roomId: string): number;
    getHighlightCount(_roomId: string): number;
    hasUnreadNotifications(_roomId: string): boolean;
    hasUnreadHighlights(_roomId: string): boolean;
    notificationCallback: unknown;
    getTotalNotificationCount(): number;
    getTotalHighlightCount(): number;
    getPendingEvents(_roomId: string): MatrixEvent[];
    hasPendingEvents(_roomId: string): boolean;
    getUnsentEvents(_roomId: string): MatrixEvent[];
    reactToMessage(roomId: string, eventId: string, key: string): Promise<string | undefined>;
    redactReaction(roomId: string, eventId: string, reason?: string): Promise<{
        event_id: string;
    }>;
    getReactionUsers(roomId: string, eventId: string): Promise<Array<{
        userId: string;
    }>>;
    hasReaction(roomId: string, eventId: string, userId: string, key: string): Promise<boolean>;
    getRoomRetention(_roomId: string): Promise<unknown>;
    setRoomRetention(_roomId: string, _retention: unknown): Promise<void>;
    getServerRetention(): Promise<unknown>;
    shareRoomKey(_roomId: string, _users: string[]): Promise<unknown>;
    getSharedWithUsers(_roomId: string): Promise<SharedWithUsersMap>;
    hasSharedKeyWithUser(_userId: string): Promise<boolean>;
    exportRoomKeys(): Promise<unknown>;
    importRoomKeys(_keys: unknown[], _options?: unknown): Promise<unknown>;
    isSecretStorageReady(): Promise<boolean>;
    getSecretStorageKey(keyId: string): Promise<[string, string] | null>;
    storeSecret(name: string, secret: string, keys?: string[]): Promise<void>;
    getSecret(name: string): Promise<string | null>;
    hasSecret(name: string): Promise<boolean>;
    getSecretStorageKeys(): Promise<Record<string, string>>;
    getServerCapabilities(): Promise<Capabilities>;
    hasServerSupport(feature: string): boolean;
    getServerVersion(): Promise<string>;
    supportsLocation(): boolean;
    serverClockDiff: number;
    getLocalTimestampForServerTime(serverTs: number): number;
    getServerTimestamp(): number;
    updateServerTimeInfo(serverTime: number, serverDate: string): void;
    waitForPendingRequests(_timeoutMs: number): Promise<void>;
    hasStartedSync(): boolean;
    isSyncing(): boolean;
    waitForSync(): Promise<void>;
    syncToken: string | null;
    syncing: boolean;
    getTurnServerURIs(): Promise<string[]>;
    getUserWidgets(): Promise<WidgetData>;
    getRoomWidgets(_roomId: string): Promise<WidgetData>;
    setUserWidgets(_widgets: WidgetData): Promise<void>;
    setRoomWidgets(_roomId: string, _widgets: WidgetData): Promise<void>;
    getAllWidgetEvents(_roomId: string): Promise<MatrixEvent[]>;
    getProfileManager(): ProfileManager;
}
export { fixNotificationCountOnDecryption, inMainTimelineForReceipt, threadIdForReceipt };
//# sourceMappingURL=client.d.ts.map