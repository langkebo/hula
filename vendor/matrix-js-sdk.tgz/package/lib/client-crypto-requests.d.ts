import { Method, type Body, type IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function performSearchRequest<T>(body: Body, nextBatch: string | undefined, abortSignal: AbortSignal | undefined, authedRequest: AuthedRequestFn): Promise<T>;
export declare function uploadKeysHttpRequest<T>(content: Body, authedRequest: AuthedRequestFn): Promise<T>;
export declare function uploadKeySignaturesHttpRequest<T>(content: Body, authedRequest: AuthedRequestFn): Promise<T>;
export declare function queryKeysForUsersRequest<T>(userIds: string[], token: string | undefined, authedRequest: AuthedRequestFn): Promise<T>;
export declare function claimOneTimeKeysHttpRequest<T>(devices: [string, string][], keyAlgorithm: string | undefined, timeout: number | undefined, authedRequest: AuthedRequestFn): Promise<T>;
export declare function getKeyChangesRequest<T>(oldToken: string, newToken: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function uploadDeviceSigningKeysHttpRequest<T>(auth: Body | undefined, keys: Body | undefined, authedRequest: AuthedRequestFn): Promise<T>;
export declare function requestRoomKeyHttpRequest<T>(request: Body, authedRequest: AuthedRequestFn): Promise<T>;
export declare function getRoomKeyRequestsHttpRequest<T>(query: QueryDict, authedRequest: AuthedRequestFn): Promise<T>;
export declare function deleteRoomKeyRequestHttpRequest<T>(requestId: string, authedRequest: AuthedRequestFn): Promise<T>;
export {};
//# sourceMappingURL=client-crypto-requests.d.ts.map