import type { RoomMessageEventContent, StickerEventContent } from "./@types/events";
import type { ImageInfo } from "./@types/media";
export interface NormalizedSendMessageArgs {
    threadId: string | null;
    content: RoomMessageEventContent;
    txnId?: string;
}
export declare function normalizeSendMessageArgs(threadId: string | null | RoomMessageEventContent, content?: RoomMessageEventContent | string, txnId?: string): NormalizedSendMessageArgs;
export declare function buildTextMessagePayload(threadId: string | null, body: string, txnId: string | undefined, eventIdPrefix: string): NormalizedSendMessageArgs;
export declare function buildNoticeMessagePayload(threadId: string | null, body: string, txnId: string | undefined, eventIdPrefix: string): NormalizedSendMessageArgs;
export declare function buildEmoteMessagePayload(threadId: string | null, body: string, txnId: string | undefined, eventIdPrefix: string): NormalizedSendMessageArgs;
export declare function buildHtmlMessagePayload(threadId: string | null, body: string, htmlBody: string | undefined, eventIdPrefix: string): Pick<NormalizedSendMessageArgs, "threadId" | "content">;
export declare function buildHtmlNoticePayload(threadId: string | null, body: string, htmlBody: string | undefined, eventIdPrefix: string): Pick<NormalizedSendMessageArgs, "threadId" | "content">;
export declare function buildHtmlEmotePayload(threadId: string | null, body: string, htmlBody: string | undefined, eventIdPrefix: string): Pick<NormalizedSendMessageArgs, "threadId" | "content">;
export declare function buildImageMessagePayload(threadId: string | null, url?: string | ImageInfo, info?: ImageInfo | string, text?: string, eventIdPrefix?: string): Pick<NormalizedSendMessageArgs, "threadId" | "content">;
export declare function buildStickerMessagePayload(threadId: string | null, url?: string | ImageInfo, info?: ImageInfo | string, text?: string, eventIdPrefix?: string): {
    threadId: string | null;
    content: StickerEventContent;
};
//# sourceMappingURL=client-send-message.d.ts.map