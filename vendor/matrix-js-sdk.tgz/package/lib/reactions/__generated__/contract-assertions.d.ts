export declare const REACTIONS_ROUTES_ENTRY_COUNT: 1;
export declare const REACTIONS_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 400;
    readonly note: "M_BAD_JSON | 缺失 m.relates_to 或 rel_type 非 m.annotation";
}, {
    readonly status: 401;
    readonly note: "M_UNAUTHORIZED | 未认证";
}, {
    readonly status: 403;
    readonly note: "M_FORBIDDEN | 非房间成员";
}, {
    readonly status: 404;
    readonly note: "M_NOT_FOUND | 目标事件或房间不存在";
}];
export type ReactionsStatusScenario = (typeof REACTIONS_ROUTES_STATUS_SCENARIOS)[number];
export declare const REACTIONS_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "缺失 m.relates_to 或 rel_type 非 m.annotation";
    readonly httpOrErrcode: "400 / M_BAD_JSON";
    readonly sdkErrorType: "ApiError";
    readonly handling: "缺失 m.relates_to 或 rel_type 非 m.annotation";
}, {
    readonly scenario: "未认证";
    readonly httpOrErrcode: "401 / M_UNAUTHORIZED";
    readonly sdkErrorType: "AuthError";
    readonly handling: "未认证";
}, {
    readonly scenario: "非房间成员";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "非房间成员";
}, {
    readonly scenario: "目标事件或房间不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "目标事件或房间不存在";
}];
export type ReactionsErrorScenario = (typeof REACTIONS_ROUTES_ERROR_SCENARIOS)[number];
export declare const REACTIONS_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "缺失 m.relates_to 或 rel_type 非 m.annotation";
}, {
    readonly errcode: "M_UNAUTHORIZED";
    readonly httpStatus: "401";
    readonly note: "未认证";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "非房间成员";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "目标事件或房间不存在";
}];
export type ReactionsErrcode = (typeof REACTIONS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map