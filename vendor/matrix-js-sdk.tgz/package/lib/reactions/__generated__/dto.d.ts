/**
 * DTO snippets extracted from the contract doc for `reactions`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ReactionsRequestDto {
    "m.relates_to": {
        rel_type: string;
        event_id: string;
        key: string;
    };
}
export interface ReactionsResponseDto {
    event_id: string;
}
//# sourceMappingURL=dto.d.ts.map