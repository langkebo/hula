/**
 * Reactions Manager - 表情回应管理
 *
 * 提供表情回应相关功能 (增厚版)
 * 对应后端: reactions
 */
import { MatrixClient } from "../client";
import { type MatrixEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ReactionCount {
    key: string;
    count: number;
    users: string[];
}
export interface ReactionSummary {
    eventId: string;
    reactions: ReactionCount[];
    totalReactions: number;
}
export interface ReactionsManagerEvents {
    reaction_added: {
        roomId: string;
        eventId: string;
        key: string;
        userId: string;
    };
    reaction_removed: {
        roomId: string;
        eventId: string;
        key: string;
        userId: string;
    };
}
export declare class ReactionsManager extends BaseManager<keyof ReactionsManagerEvents, ReactionsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    reactToMessage(roomId: string, eventId: string, key: string): Promise<string | undefined>;
    redactReaction(roomId: string, eventId: string): Promise<{
        event_id: string;
    }>;
    /**
     * Returns the list of users who reacted to the given event.
     *
     * Reads directly from the room's relations cache to avoid delegating back
     * to `client.getReactionUsers`, which would create an infinite recursion
     * (client.getReactionUsers -> manager.getReactionUsers -> client...).
     */
    getReactionUsers(roomId: string, eventId: string): Promise<string[]>;
    /**
     * Checks whether a user has reacted to an event with the given key.
     *
     * Reads directly from the room's relations cache to avoid delegating back
     * to `client.hasReaction`, which would create an infinite recursion.
     */
    hasReaction(roomId: string, eventId: string, userId: string, key: string): Promise<boolean>;
    getReactionsForEvent(roomId: string, eventId: string): MatrixEvent[];
    getReactionSummary(roomId: string, eventId: string): ReactionSummary;
    getReactionCount(roomId: string, eventId: string, key: string): number;
    toggleReaction(roomId: string, eventId: string, key: string): Promise<string | {
        event_id: string;
    } | undefined>;
    getReactionsByUser(roomId: string, userId: string, eventId: string): MatrixEvent[];
    getMostReactedMessages(roomId: string, limit?: number): ReactionSummary[];
    removeAllReactions(roomId: string, eventId: string): Promise<Array<{
        event_id: string;
    }>>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map