import type { IRoomEventFilter } from "./filter";
import { Direction } from "./models/event-timeline";
export declare function buildMessagesRequestPath(roomId: string): string;
export declare function buildThreadListRequestPath(roomId: string): string;
export declare function buildEventContextPath(roomId: string, eventId: string): string;
export declare function buildEventContextParams(lazyLoadMembers: boolean): Record<string, string | string[]>;
/**
 * Default number of events requested for `/messages` pagination when the caller
 * does not specify a limit.
 *
 * Note this applies to the `/messages` endpoint only - the `/notifications`
 * pagination path keeps its own default (see `paginateEventTimelineRequest`), as
 * the two endpoints are independent and should be free to diverge.
 */
export declare const DEFAULT_MESSAGES_LIMIT = 30;
export declare function buildMessagesRequestParams({ fromToken, limit, dir, lazyLoadMembers, timelineFilter, }: {
    fromToken: string | null;
    limit?: number | undefined;
    dir: Direction;
    lazyLoadMembers: boolean;
    timelineFilter?: IRoomEventFilter;
}): Record<string, string>;
export declare function buildThreadListRequestParams({ fromToken, limit, dir, include, }: {
    fromToken: string | null;
    limit: number;
    dir: Direction;
    include: string;
}): Record<string, string>;
//# sourceMappingURL=client-timeline-requests.d.ts.map