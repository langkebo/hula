import type { IRoomEventFilter } from "./filter";
import { Direction } from "./models/event-timeline";
export declare function buildMessagesRequestPath(roomId: string): string;
export declare function buildThreadListRequestPath(roomId: string): string;
export declare function buildEventContextPath(roomId: string, eventId: string): string;
export declare function buildEventContextParams(lazyLoadMembers: boolean): Record<string, string | string[]>;
export declare function buildMessagesRequestParams({ fromToken, limit, dir, lazyLoadMembers, timelineFilter, }: {
    fromToken: string | null;
    limit: number;
    dir: Direction;
    lazyLoadMembers: boolean;
    timelineFilter?: IRoomEventFilter;
}): Record<string, string>;
export declare function buildThreadListRequestParams({ fromToken, limit, dir, include, lazyLoadMembers, timelineFilter, }: {
    fromToken: string | null;
    limit: number;
    dir: Direction;
    include: string;
    lazyLoadMembers: boolean;
    timelineFilter?: IRoomEventFilter;
}): Record<string, string>;
//# sourceMappingURL=client-timeline-requests.d.ts.map