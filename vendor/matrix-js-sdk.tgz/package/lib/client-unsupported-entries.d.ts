/**
 * 本构建**不提供**的公开入口（"死入口"）清单。
 *
 * 这些方法在 `MatrixClient` 上仍然存在（类型签名是真的，调用方不会编译失败），但一调就抛错 ——
 * 以前每个方法体都内联一段 6~9 行的 `new Error("client.xxx() is not supported: ...")`，
 * 14 个方法合计占掉上百行。真正有价值的是**文案本身**（它告诉调用方替代入口），
 * 而不是那段重复的拼接代码，于是把文案收进这张表，方法体只剩一行委托。
 *
 * 为什么集中在一处而不是散落在各方法里：
 * - 文案是"这一版为什么不提供"的唯一出处，集中后可以一眼审阅全部死入口；
 * - 拼接格式（`client.<name>() <detail>`）只有一处实现，不会出现某个方法漏写前缀；
 * - `MatrixClient` 的体积压力直接来自这些重复代码块，移走即净减。
 *
 * ⚠️ 新增一条前先确认：**真的没有可用的替代入口**时才登记。若只是"暂时没接"，
 * 应该补实现而不是加到这里 —— `quality:fake-implementations` 守的是"假成功"，
 * 这张表守的是"明确失败"，两者都不能用来掩盖欠账。
 */
/** 每个键 = `MatrixClient` 上的方法名；值 = 拼在 `client.<name>() ` 之后的说明。 */
declare const UNSUPPORTED_ENTRY_DETAILS: {
    readonly setCryptoAlgorithm: string;
    readonly initCrypto: string;
    readonly stopCrypto: "is not supported: the crypto backend's lifecycle is tied to the client. Call client.stopClient() instead.";
    readonly deleteCryptoStore: string;
    readonly isRotationNeeded: string;
    readonly getRotationPeriod: string;
    readonly setRotationPeriod: string;
    readonly getLastRotationTime: string;
    readonly claimKeys: string;
    readonly getUserStorageUsage: "is not implemented: the homeserver exposes no per-user storage-usage endpoint in this build.";
    readonly shareRoomKey: string;
    readonly getSharedWithUsers: string;
    readonly hasSharedKeyWithUser: "is not implemented: the Rust crypto backend does not expose per-room key-sharing recipients.";
    readonly waitForPendingRequests: string;
};
/** 可登记的入口名（= `UNSUPPORTED_ENTRY_DETAILS` 的键），写错方法名是编译错误。 */
type UnsupportedEntryName = keyof typeof UNSUPPORTED_ENTRY_DETAILS;
/** 同步入口的显式失败：直接抛出，调用方拿不到任何"看起来成功"的返回值。 */
export declare function throwUnsupportedEntry(name: UnsupportedEntryName): never;
/** 异步入口的显式失败：reject，而不是 `resolve(undefined)`。 */
export declare function rejectUnsupportedEntry(name: UnsupportedEntryName): Promise<never>;
export {};
//# sourceMappingURL=client-unsupported-entries.d.ts.map