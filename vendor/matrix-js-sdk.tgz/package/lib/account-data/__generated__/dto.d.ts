/**
 * DTO snippets extracted from the contract doc for `account_data`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type AccountDataContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map