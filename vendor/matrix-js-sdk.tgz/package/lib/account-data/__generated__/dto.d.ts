/**
 * DTO snippets extracted from the contract doc for `account-data`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type AccountDataJsonValue = string | number | boolean | null | AccountDataJsonValue[] | {
    [key: string]: AccountDataJsonValue;
};
export interface AccountDataMapResponse {
    account_data: {
        [dataType: string]: AccountDataJsonValue;
    };
}
export type AccountDataContentResponse = AccountDataJsonValue;
export type RoomAccountDataContentResponse = AccountDataJsonValue;
export type AccountDataEmptyResponse = {
    [key: string]: never;
};
export type FilterUploadRequest = {
    [key: string]: AccountDataJsonValue;
};
export interface FilterCreateResponse {
    filter_id: string;
}
export type FilterContentResponse = {
    [key: string]: AccountDataJsonValue;
};
export type FilterDeleteResponse = {
    [key: string]: never;
};
export interface OpenIdTokenResponse {
    access_token: string;
    token_type: string;
    matrix_server_name: string;
    expires_in: number;
}
//# sourceMappingURL=dto.d.ts.map