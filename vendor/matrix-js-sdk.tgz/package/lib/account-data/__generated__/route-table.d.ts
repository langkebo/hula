/** Routes served by the synapse-rust `account-data` module (mirrored from the backend contract). */
export declare const ACCOUNT_DATA_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/account_data/";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/user/{user_id}/account_data/{type}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/account_data/{type}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/user/{user_id}/account_data/{type}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/user/{user_id}/filter";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/user/{user_id}/filter";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/user/{user_id}/filter/{filter_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/filter/{filter_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/openid/request_token";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/user/{user_id}/openid/request_token";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/account_data/{type}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/account_data/{type}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/account_data/{type}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/user/{user_id}/account_data/{type}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/account_data/{type}";
}];
/** Union of every (method, path) tuple in `ACCOUNT_DATA_ROUTES`. */
export type AccountDataRoute = (typeof ACCOUNT_DATA_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type AccountDataMethod = AccountDataRoute["method"];
/** Path templates referenced by this module. */
export type AccountDataPath = AccountDataRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type AccountDataReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${AccountDataReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type AccountDataPathPattern = AccountDataReplaceBraces<AccountDataPath>;
//# sourceMappingURL=route-table.d.ts.map