export declare const ACCOUNT_DATA_ROUTES_ENTRY_COUNT: 26;
export declare const ACCOUNT_DATA_ROUTES_STATUS_SCENARIOS: readonly [];
export type AccountDataStatusScenario = (typeof ACCOUNT_DATA_ROUTES_STATUS_SCENARIOS)[number];
export declare const ACCOUNT_DATA_ROUTES_ERROR_SCENARIOS: readonly [];
export type AccountDataErrorScenario = (typeof ACCOUNT_DATA_ROUTES_ERROR_SCENARIOS)[number];
export declare const ACCOUNT_DATA_ROUTES_ERRCODES: readonly [];
export type AccountDataErrcode = (typeof ACCOUNT_DATA_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map