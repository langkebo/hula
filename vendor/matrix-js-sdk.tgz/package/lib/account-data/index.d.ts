/**
 * Account Data Manager - 账户数据管理
 *
 * 提供账户数据获取、设置、删除等功能
 *
 * 契约文档: docs/api-contract/account-data.md
 *
 * 数据约束:
 * - data_type 最大长度: 128 字符
 * - Account Data 内容最大大小: 64KB (65536 字节)
 * - 用户只能访问自己的数据
 */
import { MatrixClient } from "../client";
import { MatrixEvent, type IContent } from "../models/event";
import { type EmptyObject } from "../@types/common";
import { type AccountDataEvents, type WritableAccountDataEvents } from "../@types/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export declare enum AccountDataEvent {
    AccountDataUpdated = "AccountDataUpdated",
    AccountDataError = "AccountDataError"
}
interface AccountDataManagerEventMap {
    [AccountDataEvent.AccountDataUpdated]: (eventType: string, event: MatrixEvent) => void;
    [AccountDataEvent.AccountDataError]: (error: Error) => void;
}
export declare class AccountDataManager extends BaseManager<AccountDataEvent, AccountDataManagerEventMap> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 验证 data_type 长度
     */
    private validateDataType;
    /**
     * 验证内容大小
     */
    private validateContentSize;
    /**
     * Set account data with remote echo waiting.
     *
     * @param eventType - The event type
     * @param content - The contents object for the event
     * @returns Promise which resolves: an empty object
     */
    setAccountData<K extends keyof WritableAccountDataEvents>(eventType: K, content: AccountDataEvents[K] | Record<string, never>): Promise<EmptyObject>;
    /**
     * Set account data event for the current user, without waiting for the remote echo.
     *
     * @param eventType - The event type
     * @param content - the contents object for the event
     */
    setAccountDataRaw<K extends keyof WritableAccountDataEvents>(eventType: K, content: AccountDataEvents[K] | Record<string, never>): Promise<EmptyObject>;
    /**
     * Get account data event of given type for the current user.
     * @param eventType - The event type
     * @returns The contents of the given account data event
     */
    getAccountData<K extends keyof AccountDataEvents>(eventType: K): MatrixEvent | undefined;
    /**
     * Get account data event of given type for the current user. This variant
     * gets account data directly from the homeserver if the local store is not
     * ready, which can be useful very early in startup before the initial sync.
     * @param eventType - The event type
     * @returns Promise which resolves: The contents of the given account data event.
     * @returns Rejects: with an error response.
     */
    getAccountDataFromServer<K extends keyof AccountDataEvents>(eventType: K): Promise<AccountDataEvents[K] | null>;
    /**
     * List all account data for the current user
     *
     * @returns 包含所有 account data 的对象，格式为 { account_data: { type: content, ... } }
     *
     * 响应示例:
     * {
     *   "account_data": {
     *     "m.direct": { "@alice:example.com": ["!room1:example.com"] },
     *     "m.push_rules": { "global": { ... } }
     *   }
     * }
     */
    listAccountData(): Promise<{
        account_data: Record<string, IContent>;
    }>;
    /**
     * Get room account data from server
     *
     * @param roomId - 房间 ID
     * @param eventType - 数据类型
     * @returns MatrixEvent 或 undefined（当数据不存在时）
     * @throws Error 当请求失败时（404 表示数据不存在）
     */
    getRoomAccountDataFromServer<K extends string>(roomId: string, eventType: K): Promise<MatrixEvent | undefined>;
    /**
     * Set room account data
     *
     * @param roomId - 房间 ID
     * @param eventType - 数据类型
     * @param content - 数据内容
     */
    setRoomAccountData<K extends string>(roomId: string, eventType: K, content: IContent): Promise<void>;
    /**
     * Delete room account data
     *
     * @param roomId - 房间 ID
     * @param eventType - 数据类型
     * @throws Error 当数据不存在时（404）
     */
    deleteRoomAccountData(roomId: string, eventType: string): Promise<void>;
    /**
     * Delete account data.
     * @param eventType - The event type to delete
     */
    deleteAccountData(eventType: keyof WritableAccountDataEvents): Promise<void>;
    /**
     * Gets the users that are ignored by this client
     * @returns The array of users that are ignored (empty if none)
     */
    getIgnoredUsers(): string[];
    /**
     * Sets the users that the current user should ignore.
     * @param userIds - the user IDs to ignore
     * @returns Promise which resolves: an empty object
     * @returns Rejects: with an error response.
     */
    setIgnoredUsers(userIds: string[]): Promise<EmptyObject>;
    /**
     * Gets whether or not a specific user is being ignored by this client.
     * @param userId - the user ID to check
     * @returns true if the user is ignored, false otherwise
     */
    isUserIgnored(userId: string): boolean;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map