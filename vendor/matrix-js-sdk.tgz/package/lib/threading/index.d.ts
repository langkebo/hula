/**
 * Threading Manager - 线程管理
 *
 * 提供线程相关功能，包括线程时间线获取
 */
import { MatrixClient } from "../client";
import { Thread } from "../models/thread";
import { EventTimeline } from "../models/event-timeline";
import type { EventTimelineSet } from "../models/event-timeline-set";
import type { IContent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ThreadingManagerEvents {
    threadTimelineFetched: (data: {
        threadId: string;
        eventId: string;
    }) => void;
}
export interface ThreadListQuery {
    limit?: number;
    from?: string;
    includeAll?: boolean;
}
export interface ThreadSearchQuery {
    q: string;
    limit?: number;
}
export interface ThreadRepliesQuery {
    limit?: number;
    from?: string;
}
export interface ThreadDetailQuery {
    includeReplies?: boolean;
    replyLimit?: number;
}
export interface ThreadSummaryResponse {
    id: number;
    room_id: string;
    thread_id: string;
    root_event_id: string;
    root_sender: string;
    root_content: IContent;
    root_origin_server_ts: number;
    latest_event_id: string | null;
    latest_sender: string | null;
    latest_content: IContent | null;
    latest_origin_server_ts: number | null;
    reply_count: number;
    participants: unknown;
    is_frozen: boolean;
    created_ts: number;
    updated_ts: number;
}
export interface ThreadReadReceiptResponse {
    id: number;
    room_id: string;
    thread_id: string;
    user_id: string;
    last_read_event_id: string | null;
    last_read_ts: number;
    unread_count: number;
    updated_ts: number;
}
export interface ThreadSubscriptionResponse {
    id: number;
    room_id: string;
    thread_id: string;
    user_id: string;
    notification_level: string;
    is_muted: boolean;
    subscribed_ts: number;
    updated_ts: number;
}
export interface ThreadReplyResponse {
    event_id: string;
    thread_id: string;
    room_id: string;
    sender: string;
    content: IContent;
    origin_server_ts: number;
    in_reply_to_event_id: string | null;
    is_edited: boolean;
    is_redacted: boolean;
}
export interface ThreadCreateResponse {
    thread_id: string | null;
    root_event_id: string;
    room_id: string;
    sender: string;
    reply_count: number;
    last_reply_event_id: string | null;
    last_reply_sender: string | null;
    last_reply_ts: number | null;
    participants: unknown;
    is_fetched: boolean;
    created_ts: number;
}
export interface ThreadRootResponse {
    id: number;
    room_id: string;
    root_event_id: string;
    sender: string;
    thread_id: string | null;
    reply_count: number;
    last_reply_event_id: string | null;
    last_reply_sender: string | null;
    last_reply_ts: number | null;
    participants: unknown;
    is_fetched: boolean;
    created_ts: number;
    updated_ts: number | null;
}
export interface ThreadCreateParams {
    roomId?: string;
    rootEventId: string;
    content?: IContent;
    originServerTs?: number;
}
export interface ThreadReplyCreateParams {
    eventId: string;
    rootEventId: string;
    content: IContent;
    inReplyToEventId?: string;
    originServerTs?: number;
}
export interface ThreadDetailResponse {
    root: ThreadRootResponse;
    replies: ThreadReplyResponse[];
    reply_count: number;
    participants: string[];
    summary: ThreadSummaryResponse | null;
    user_receipt: ThreadReadReceiptResponse | null;
    user_subscription: ThreadSubscriptionResponse | null;
}
export interface ThreadListResponse {
    threads: ThreadSummaryResponse[];
    next_batch: string | null;
    total: number;
}
export interface ThreadUnreadResponse {
    threads: ThreadReadReceiptResponse[];
    total_unread: number;
    total_threads: number;
}
export interface SubscribedThreadsResponse {
    threads: ThreadSummaryResponse[];
    subscribed: ThreadSubscriptionResponse[];
    next_batch?: string | null;
}
export interface ThreadLegacyChunkItem {
    event_id: string;
    sender: string;
    content: IContent;
    origin_server_ts: number;
}
export interface ThreadLegacySearchResponse {
    chunk: ThreadLegacyChunkItem[];
    next_batch: string | null;
}
export interface ThreadStatisticsResponse {
    id: number;
    room_id: string;
    thread_id: string;
    total_replies: number;
    total_participants: number;
    total_edits: number;
    total_redactions: number;
    first_reply_ts: number | null;
    last_reply_ts: number | null;
    avg_reply_time_ms: number | null;
    created_ts: number;
    updated_ts: number;
}
export declare class ThreadingManager extends BaseManager<keyof ThreadingManagerEvents, ThreadingManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    private buildQuery;
    private requestThreadV1;
    private requestThreadV3;
    getThread(threadId: string): Thread | null;
    getThreadList(): Thread[];
    getThreads(): Thread[];
    hasThread(threadId: string): boolean;
    getGlobalThreadList(query?: ThreadListQuery): Promise<ThreadListResponse>;
    getSubscribedThreads(query?: {
        limit?: number;
        from?: string;
    }): Promise<SubscribedThreadsResponse>;
    getGlobalUnreadThreads(): Promise<ThreadUnreadResponse>;
    getRoomThreadList(roomId: string, query?: ThreadListQuery): Promise<ThreadListResponse>;
    searchRoomThreads(roomId: string, query: ThreadSearchQuery): Promise<ThreadSummaryResponse[]>;
    getLegacyRoomThreadList(userId: string, roomId: string, query?: ThreadListQuery): Promise<ThreadLegacySearchResponse>;
    getRoomUnreadThreads(roomId: string): Promise<ThreadUnreadResponse>;
    getRoomThread(roomId: string, threadId: string, query?: ThreadDetailQuery): Promise<ThreadDetailResponse>;
    createGlobalThread(params: ThreadCreateParams): Promise<ThreadCreateResponse>;
    createRoomThread(roomId: string, rootEventId: string, options?: Pick<ThreadCreateParams, "content" | "originServerTs">): Promise<ThreadCreateResponse>;
    deleteRoomThread(roomId: string, threadId: string): Promise<void>;
    freezeThread(roomId: string, threadId: string): Promise<void>;
    unfreezeThread(roomId: string, threadId: string): Promise<void>;
    addThreadReply(roomId: string, threadId: string, params: ThreadReplyCreateParams): Promise<ThreadReplyResponse>;
    getThreadReplies(roomId: string, threadId: string, query?: ThreadRepliesQuery): Promise<ThreadReplyResponse[]>;
    subscribeToThread(roomId: string, threadId: string, notificationLevel?: string): Promise<ThreadSubscriptionResponse>;
    unsubscribeFromThread(roomId: string, threadId: string): Promise<void>;
    muteThread(roomId: string, threadId: string): Promise<ThreadSubscriptionResponse>;
    markThreadRead(roomId: string, threadId: string, eventId: string, originServerTs?: number): Promise<ThreadReadReceiptResponse>;
    getThreadStats(roomId: string, threadId: string): Promise<ThreadStatisticsResponse | null>;
    redactThreadReply(roomId: string, eventId: string): Promise<void>;
    createThread(roomId: string, eventId: string): Promise<Thread | null>;
    getThreadTimeline(timelineSet: EventTimelineSet, eventId: string): Promise<EventTimeline | undefined>;
    private getThreadTimelineWithFwdPagination;
    private getThreadTimelineLegacy;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map