import type { IRedactOpts } from "./@types/requests.ts";
import { ServerSupport } from "./feature.ts";
import type { IContent } from "./models/event.ts";
interface RelationPropertyNames {
    stable?: string | null;
    unstable?: string | null;
}
export interface BuildRedactEventContentArgs {
    opts?: IRedactOpts;
    relationBasedRedactionsSupport?: ServerSupport;
    relationPropertyNames: RelationPropertyNames;
    roomId: string;
    eventId: string;
    txnId?: string;
    threadId: string | null;
}
export declare function buildRedactEventContent({ opts, relationBasedRedactionsSupport, relationPropertyNames, roomId, eventId, txnId, threadId, }: BuildRedactEventContentArgs): IContent;
export {};
//# sourceMappingURL=client-send-redaction.d.ts.map