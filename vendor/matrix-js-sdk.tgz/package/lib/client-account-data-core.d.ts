import { ServerSupport } from "./feature";
export interface AccountDataEventLike {
    getContent(): unknown;
}
export declare function getAccountDataFromStoreWhenReady<T>(isInitialSyncComplete: boolean, event: AccountDataEventLike | undefined): T | null | undefined;
export declare function isAccountDataNotFoundError(error: unknown): boolean;
export declare function shouldFallbackDeleteAccountDataToEmptyContent(serverSupport: ServerSupport | undefined): boolean;
//# sourceMappingURL=client-account-data-core.d.ts.map