import { MatrixClient } from "../client";
import { BaseManager } from "../managers/base-manager";
export interface TaskMetadata {
    trace_id?: string;
    priority?: number;
    [key: string]: unknown;
}
export interface WorkerInfo {
    id: number;
    worker_id: string;
    worker_name: string;
    worker_type: string;
    host: string;
    port: number;
    status: string;
    last_heartbeat_ts: number | null;
    started_ts: number;
}
export interface WorkerCommand {
    command_id: string;
    target_worker_id: string;
    command_type: string;
    status: string;
    created_ts: number;
}
export interface WorkerTask {
    task_id: string;
    task_type: string;
    status: string;
    assigned_worker_id: string | null;
}
export interface WorkerConfig {
    thread_count?: number;
    cache_size_mb?: number;
    timeout_ms?: number;
    [key: string]: unknown;
}
export interface WorkerStatisticsEntry {
    id: number;
    worker_id: string;
    worker_name: string;
    worker_type: string;
    status: string;
    host: string;
    port: number;
    last_heartbeat_ts: number | null;
    started_ts: number;
    cpu_usage?: number | null;
    memory_usage?: number | null;
    active_connections?: number | null;
    requests_per_second?: number | null;
    average_latency_ms?: number | null;
    queue_depth?: number | null;
    pending_commands: number;
    active_tasks: number;
}
export interface WorkerTypeStatistics {
    worker_type: string;
    total_count: number;
    running_count: number;
    starting_count: number;
    stopping_count: number;
    stopped_count: number;
    avg_cpu_usage?: number | null;
    avg_memory_usage?: number | null;
    total_connections?: number | null;
}
export interface RegisterWorkerRequest {
    worker_id: string;
    worker_name: string;
    worker_type: string;
    host: string;
    port: number;
    config?: WorkerConfig;
    metadata?: TaskMetadata;
    version?: string;
}
export interface SendCommandRequest {
    command_type: string;
    command_data: unknown;
    priority?: number;
    max_retries?: number;
}
export interface SelectWorkerResponse {
    task_type: string;
    selected_worker: string | null;
}
export interface AssignTaskRequest {
    task_type: string;
    task_data: unknown;
    priority?: number;
    preferred_worker_id?: string;
}
export declare class WorkerAdminManager extends BaseManager<string, Record<string, never>> {
    constructor(client: MatrixClient);
    private doRequest;
    /** POST /_synapse/worker/v1/register */
    registerWorker(req: RegisterWorkerRequest): Promise<WorkerInfo>;
    /** GET /_synapse/worker/v1/workers */
    listWorkers(limit?: number): Promise<{
        workers: WorkerInfo[];
        total?: number;
    }>;
    /** GET /_synapse/worker/v1/workers/type/{worker_type} */
    listWorkersByType(workerType: string, limit?: number): Promise<{
        workers: WorkerInfo[];
    }>;
    /** GET /_synapse/worker/v1/workers/{worker_id} */
    getWorker(workerId: string): Promise<WorkerInfo>;
    /** DELETE /_synapse/worker/v1/workers/{worker_id} */
    unregisterWorker(workerId: string): Promise<void>;
    /** POST /_synapse/worker/v1/workers/{worker_id}/commands */
    sendCommand(workerId: string, req: SendCommandRequest): Promise<WorkerCommand>;
    /** POST /_synapse/worker/v1/tasks */
    assignTask(req: AssignTaskRequest): Promise<WorkerTask>;
    /** GET /_synapse/worker/v1/tasks */
    getPendingTasks(limit?: number): Promise<{
        tasks: WorkerTask[];
    }>;
    /** POST /_synapse/worker/v1/tasks/claim/{worker_id} */
    claimTask(workerId: string): Promise<WorkerTask | null>;
    /** POST /_synapse/worker/v1/tasks/{task_id}/claim/{worker_id} */
    claimSpecificTask(taskId: string, workerId: string): Promise<WorkerTask>;
    /** GET /_synapse/worker/v1/statistics */
    getStatistics(): Promise<WorkerStatisticsEntry[]>;
    /** GET /_synapse/worker/v1/statistics/types */
    getStatisticsByType(): Promise<WorkerTypeStatistics[]>;
    /** GET /_synapse/worker/v1/select/{task_type} */
    selectWorker(taskType: string): Promise<SelectWorkerResponse>;
    /** GET /_synapse/worker/v1/topology */
    getTopology(): Promise<Record<string, unknown>>;
    /** GET /_synapse/worker/v1/topology/validate */
    validateTopology(): Promise<{
        valid: boolean;
        errors?: string[];
    }>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map