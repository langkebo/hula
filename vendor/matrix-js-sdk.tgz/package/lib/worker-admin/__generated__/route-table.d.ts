/** Routes served by the synapse-rust `worker-admin` module (mirrored from the backend contract). */
export declare const WORKER_ADMIN_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/register";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/select/{task_type}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/statistics";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/statistics/types";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/tasks";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/tasks";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/tasks/claim/{worker_id}";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/tasks/{task_id}/claim/{worker_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/topology";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/topology/validate";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/workers";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/workers/type/{worker_type}";
}, {
    readonly method: "DELETE";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}/commands";
}];
/** Union of every (method, path) tuple in `WORKER_ADMIN_ROUTES`. */
export type WorkerAdminRoute = (typeof WORKER_ADMIN_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type WorkerAdminMethod = WorkerAdminRoute["method"];
/** Path templates referenced by this module. */
export type WorkerAdminPath = WorkerAdminRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type WorkerAdminReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${WorkerAdminReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type WorkerAdminPathPattern = WorkerAdminReplaceBraces<WorkerAdminPath>;
//# sourceMappingURL=route-table.d.ts.map