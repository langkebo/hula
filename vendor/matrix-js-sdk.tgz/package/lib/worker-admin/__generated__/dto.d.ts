/**
 * DTO snippets extracted from the contract doc for `worker-admin`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type WorkerAdminContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map