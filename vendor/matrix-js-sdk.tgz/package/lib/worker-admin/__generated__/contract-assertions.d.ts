export declare const WORKER_ADMIN_ROUTES_ENTRY_COUNT: 26;
export declare const WORKER_ADMIN_ROUTES_STATUS_SCENARIOS: readonly [];
export type WorkerAdminStatusScenario = (typeof WORKER_ADMIN_ROUTES_STATUS_SCENARIOS)[number];
export declare const WORKER_ADMIN_ROUTES_ERROR_SCENARIOS: readonly [];
export type WorkerAdminErrorScenario = (typeof WORKER_ADMIN_ROUTES_ERROR_SCENARIOS)[number];
export declare const WORKER_ADMIN_ROUTES_ERRCODES: readonly [];
export type WorkerAdminErrcode = (typeof WORKER_ADMIN_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map