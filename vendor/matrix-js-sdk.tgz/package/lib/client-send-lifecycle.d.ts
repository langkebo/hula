import { type IEvent, type MatrixEvent } from "./models/event";
import type { SendDelayedEventRequestOpts } from "./@types/requests";
import type { QueryDict } from "./utils";
import type { Room } from "./models/room";
interface LoggerLike {
    debug(message: string): void;
}
interface ReEmitterLike {
    reEmit(target: MatrixEvent, events: string[]): void;
}
interface PrepareSendCompleteEventLifecycleArgs {
    roomId: string;
    threadId: string | null;
    eventObject: Partial<IEvent>;
    delayOpts?: SendDelayedEventRequestOpts;
    queryDict?: QueryDict;
    txnId?: string;
    userId: string;
    makeTxnId: () => string;
    getRoom: (roomId: string) => Room | null;
    logger: LoggerLike;
    reEmitter: ReEmitterLike;
}
export interface PreparedSendCompleteEventLifecycle {
    room: Room | null;
    localEvent: MatrixEvent;
    txnId: string;
}
export declare function prepareSendCompleteEventLifecycle({ roomId, threadId, eventObject, delayOpts, queryDict, txnId, userId, makeTxnId, getRoom, logger, reEmitter, }: PrepareSendCompleteEventLifecycleArgs): PreparedSendCompleteEventLifecycle;
export {};
//# sourceMappingURL=client-send-lifecycle.d.ts.map