/**
 * DTO snippets extracted from the contract doc for `openclaw`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface OpenClawConnectionConfig {
    api_key?: string;
    model_id?: string;
    max_tokens?: number;
    temperature?: number;
    top_p?: number;
    [key: string]: unknown;
}
export interface IOpenClawConnection {
    id: number;
    name: string;
    provider: string;
    base_url: string;
    has_api_key: boolean;
    config?: OpenClawConnectionConfig;
    is_default: boolean;
    is_active: boolean;
    created_ts: number;
    updated_ts: number;
}
export interface IOpenClawConversation {
    id: number;
    connection_id?: number;
    title?: string;
    model_id?: string;
    system_prompt?: string;
    temperature?: number;
    max_tokens?: number;
    is_pinned: boolean;
    created_ts: number;
    updated_ts: number;
}
export interface OpenClawToolCall {
    id: string;
    type: "function";
    function: {
        name: string;
        arguments: string;
    };
}
export interface IOpenClawMessage {
    id: number;
    conversation_id: number;
    role: string;
    content: string;
    token_count?: number;
    tool_calls?: OpenClawToolCall[];
    created_ts: number;
}
export interface IOpenClawChatRole {
    id: number;
    name: string;
    description?: string;
    system_message: string;
    model_id?: string;
    avatar_url?: string;
    category?: string;
    temperature?: number;
    max_tokens?: number;
    is_public: boolean;
    created_ts: number;
    updated_ts: number;
}
//# sourceMappingURL=dto.d.ts.map