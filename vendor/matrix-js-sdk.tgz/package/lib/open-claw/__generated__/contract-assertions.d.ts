export declare const OPENCLAW_ROUTES_ENTRY_COUNT: 23;
export declare const OPENCLAW_ROUTES_STATUS_SCENARIOS: readonly [];
export type OpenclawStatusScenario = (typeof OPENCLAW_ROUTES_STATUS_SCENARIOS)[number];
export declare const OPENCLAW_ROUTES_ERROR_SCENARIOS: readonly [];
export type OpenclawErrorScenario = (typeof OPENCLAW_ROUTES_ERROR_SCENARIOS)[number];
export declare const OPENCLAW_ROUTES_ERRCODES: readonly [];
export type OpenclawErrcode = (typeof OPENCLAW_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map