import type { MatrixClient } from "../client";
import { type ParticipantDeviceInfo, type Statistics } from "./types";
import { type Logger } from "../logger";
import { KeyTransportEvents, type KeyTransportEventsHandlerMap, type IKeyTransport } from "./IKeyTransport";
import { type MatrixEvent } from "../models/event";
import { TypedEventEmitter } from "../models/typed-event-emitter";
import { type Room } from "../models/room";
/**
 * @deprecated This is deprecated and not used anymore. Use the ToDeviceTransport instead.
 */
export declare class RoomKeyTransport extends TypedEventEmitter<KeyTransportEvents, KeyTransportEventsHandlerMap> implements IKeyTransport {
    private room;
    private client;
    private statistics;
    private logger;
    setParentLogger(parentLogger: Logger): void;
    constructor(room: Pick<Room, "on" | "off" | "roomId">, client: Pick<MatrixClient, "sendEvent" | "getDeviceId" | "getUserId" | "cancelPendingEvent" | "decryptEventIfNeeded">, statistics: Statistics, parentLogger?: Logger);
    start(): void;
    stop(): void;
    private consumeCallEncryptionEvent;
    /** implements {@link IKeyTransport#sendKey} */
    sendKey(keyBase64Encoded: string, index: number, _members: ParticipantDeviceInfo[]): Promise<void>;
    onEncryptionEvent(event: MatrixEvent): void;
}
//# sourceMappingURL=RoomKeyTransport.d.ts.map