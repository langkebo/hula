import { type Logger } from "../logger";
import { type EncryptionConfig } from "./MatrixRTCSession";
import { type CallMembership } from "./CallMembership";
import { type KeyTransportEventListener, type IKeyTransport } from "./IKeyTransport";
import { type EncryptionKeyMapKey, type Statistics } from "./types";
/**
 * The string used for the keys in the the encryption key map.
 * `@bob:examle.org:DEVICEID(UUIDRANDOM_MEMBERID_RANDOMUUID)`
 */
export declare function getEncryptionKeyMapKey(membership: CallMembershipIdentityParts): EncryptionKeyMapKey;
/**
 * This interface is for testing and for making it possible to interchange the encryption manager.
 * @internal
 */
export interface IEncryptionManager {
    /**
     * Joins the encryption manager with the provided configuration.
     *
     * @param joinConfig - The configuration for joining encryption, or undefined
     * if no specific configuration is provided.
     */
    join(joinConfig: EncryptionConfig | undefined): void;
    /**
     * Leaves the encryption manager, cleaning up any associated resources.
     */
    leave(): void;
    /**
     * Called from the MatrixRTCSession when the memberships in this session updated.
     *
     * @param oldMemberships - The previous state of call memberships before the update.
     */
    onMembershipsUpdate(oldMemberships: CallMembership[]): void;
    /**
     * Retrieves the encryption keys currently managed by the encryption manager.
     *
     * @returns A map of participant IDs to their encryption keys.
     */
    getEncryptionKeys(): ReadonlyMap<EncryptionKeyMapKey, ReadonlyArray<{
        key: Uint8Array<ArrayBuffer>;
        keyIndex: number;
        membership: CallMembershipIdentityParts;
        rtcBackendIdentity: string;
    }>>;
}
export type CallMembershipIdentityParts = Pick<CallMembership, "userId" | "deviceId" | "memberId">;
/**
 * This class implements the IEncryptionManager interface,
 * and takes care of managing the encryption keys of all rtc members:
 *  - generate new keys for the local user and send them to other participants
 *  - track all keys of all other members and update livekit.
 *
 * @internal
 */
export declare class EncryptionManager implements IEncryptionManager {
    private membership;
    private getMemberships;
    private transport;
    private statistics;
    private onEncryptionKeysChanged;
    private manageMediaKeys;
    private keysEventUpdateTimeout?;
    private makeNewKeyTimeout?;
    private setNewKeyTimeouts;
    private get updateEncryptionKeyThrottle();
    private get makeKeyDelay();
    private get useKeyDelay();
    private encryptionKeys;
    private lastEncryptionKeyUpdateRequest?;
    private lastMembershipFingerprints;
    private latestGeneratedKeyIndex;
    private joinConfig;
    private logger;
    constructor(membership: CallMembershipIdentityParts, getMemberships: () => CallMembership[], transport: IKeyTransport, statistics: Statistics, onEncryptionKeysChanged: (keyBin: Uint8Array<ArrayBuffer>, encryptionKeyIndex: number, membership: CallMembershipIdentityParts, rtcBackendIdentity: string) => void, parentLogger?: Logger);
    private rtcBackendIdentityFromMembershipParts;
    /**
     * 返回当前已知的全部加密密钥。
     *
     * @returns 以 `userId:deviceId(memberId)` 为键的密钥环映射（含 keyIndex 与 rtcBackendIdentity）。
     * @example
     * ```ts
     * // 内部类：由 MatrixRTCSession 在加入会话时创建并调用，无公开访问器。
     * this.encryptionManager!.getEncryptionKeys().forEach((keyRing, mapKey) => {
     *     // 将 keyRing 交给 LiveKit / 媒体加密层使用
     * });
     * ```
     */
    getEncryptionKeys(): ReadonlyMap<EncryptionKeyMapKey, ReadonlyArray<{
        key: Uint8Array<ArrayBuffer>;
        keyIndex: number;
        membership: CallMembershipIdentityParts;
        rtcBackendIdentity: string;
    }>>;
    private joined;
    /**
     * 加入会话并启动密钥交换。
     *
     * @param joinConfig - 加密配置；`manageMediaKeys` 为真时自动生成并分发发送端密钥。
     * @example
     * ```ts
     * // 内部类：由 MatrixRTCSession.joinRoomSession() 创建后调用。
     * this.encryptionManager!.join(joinConfig);
     * ```
     */
    join(joinConfig: EncryptionConfig): void;
    /**
     * 离开会话并清理本地密钥与定时器。
     *
     * @example
     * ```ts
     * // 内部类：由 MatrixRTCSession.leaveRoomSession() 调用。
     * this.encryptionManager!.leave();
     * ```
     */
    leave(): void;
    /**
     * 会话成员变更时由 MatrixRTCSession 调用，决定是否轮换或重发密钥。
     *
     * @param oldMemberships - 更新前的成员列表，用于对比出加入/离开/更新。
     * @example
     * ```ts
     * // 内部类：由 MatrixRTCSession 在成员变化时调用。
     * void this.encryptionManager?.onMembershipsUpdate(oldMemberships);
     * ```
     */
    onMembershipsUpdate(oldMemberships: CallMembership[]): void;
    /**
     * Generate a new sender key and add it at the next available index
     * @param delayBeforeUse - If true, wait for a short period before setting the key for the
     *                         media encryptor to use. If false, set the key immediately.
     * @returns The index of the new key
     */
    private makeNewSenderKey;
    /**
     * Requests that we resend our current keys to the room. May send a keys event immediately
     * or queue for alter if one has already been sent recently.
     */
    private requestSendCurrentKey;
    /**
     * Get the known encryption keys for a given participant device.
     *
     * @param membership - The membership identity parts of the participant
     * @returns The encryption keys for the given participant, or undefined if they are not known.
     */
    private getKeysForParticipant;
    /**
     * Re-sends the encryption keys room event
     */
    private sendEncryptionKeysEvent;
    onNewKeyReceived: KeyTransportEventListener;
    private storeLastMembershipFingerprints;
    private getNewEncryptionKeyIndex;
    /**
     * Sets an encryption key at a specified index for a participant.
     * The encryption keys for the local participant are also stored here under the
     * user and device ID of the local participant.
     * If the key is older than the existing key at the index, it will be ignored.
     * @param userId - The user ID of the participant
     * @param deviceId - Device ID of the participant
     * @param encryptionKeyIndex - The index of the key to set
     * @param encryptionKeyString - The string representation of the key to set in base64
     * @param timestamp - The timestamp of the key. We assume that these are monotonic for each participant device.
     * @param delayBeforeUse - If true, delay before emitting a key changed event. Useful when setting
     *                         encryption keys for the local participant to allow time for the key to
     *                         be distributed.
     */
    private setEncryptionKey;
    private onRotateKeyTimeout;
}
//# sourceMappingURL=EncryptionManager.d.ts.map