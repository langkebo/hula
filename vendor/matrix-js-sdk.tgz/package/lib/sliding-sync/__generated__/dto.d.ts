/**
 * DTO snippets extracted from the contract doc for `sliding_sync`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type SlidingSyncContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map