/**
 * DTO snippets extracted from the contract doc for `sliding-sync`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface SlidingSyncRequest {
    /** Sliding sync 位置令牌，null 或空字符串表示初始同步 */
    pos?: string;
    /** 长轮询超时（毫秒），默认 30000 */
    timeout?: number;
    /** 列表配置（Map<string, SlidingSyncList>） */
    lists?: Record<string, SlidingSyncList>;
    /** 房间订阅 */
    room_subscriptions?: Record<string, SlidingSyncRoomSubscription>;
    /** 退订房间 ID 列表 */
    unsubscribe_rooms?: string[];
    /** 扩展配置 */
    extensions?: SlidingSyncExtensions;
    /** MSC4186: 事务 ID，用于幂等重试 */
    txn_id?: string;
    /** 本地客户端超时（毫秒），仅用于 localTimeoutMs，不进入 HTTP 请求体 */
    clientTimeout?: number;
}
export interface SlidingSyncList {
    /** 排序规则，如 ["by_recency", "by_name"] */
    sort?: string[];
    /** 过滤器 */
    filters?: SlidingSyncFilters;
    /** 请求的房间详情字段 */
    room_details?: boolean;
    /** 包含未读线程通知数 */
    unread_thread_notifications?: boolean;
    /** 房间订阅（数组或对象） */
    subscriptions?: string[] | Record<string, SlidingSyncRoomSubscription>;
    /** 同步类型 */
    sync_type?: string;
    /** 范围，如 [[0, 49]] 表示前 50 个房间 */
    ranges?: number[][];
    /** 时间线事件数量限制 */
    timeline_limit?: number;
    /** 要求的 state 类型列表 [[event_type, state_key], ...] */
    required_state?: string[][];
    /** 慢速房间排序权重 */
    slow_by?: number;
    /** Bump 事件类型列表 */
    bump_event_types?: string[];
}
export interface SlidingSyncFilters {
    /** 是否为邀请房间 */
    is_invite?: boolean;
    /** 是否为主页房间 */
    is_home?: boolean;
    /** 排除的房间 ID 列表 */
    not_rooms?: string[];
    /** 包含的房间 ID 列表 */
    rooms?: string[];
    /** 房间名称模糊匹配 */
    room_name_like?: string;
    /** 包含的标签列表 */
    tags?: string[];
    /** 排除的标签列表 */
    not_tags?: string[];
    /** 临时事件过滤器 */
    ephemeral?: Array<{
        type: string;
        key?: string;
    }>;
}
export interface SlidingSyncRoomSubscription {
    /** 要求的 state 类型列表 */
    required_state?: string[][];
    /** 时间线事件数量限制 */
    timeline_limit?: number;
    /** 永久化的 state（服务端缓存） */
    permanent?: string[][];
    /** 强制重新发送事件 */
    force_resend?: boolean;
}
export interface SlidingSyncExtensions {
    /** E2EE 扩展 */
    e2ee?: SlidingSyncE2EEExtension;
    /** ToDevice 消息扩展 */
    todevice?: SlidingSyncToDeviceExtension;
    /** 账户数据扩展 */
    account_data?: SlidingSyncAccountDataExtension;
    /** Receipt 扩展 */
    receipts?: SlidingSyncReceiptsExtension;
    /** Typing 通知扩展 */
    typing?: SlidingSyncTypingExtension;
}
export interface SlidingSyncE2EEExtension {
    enabled: boolean;
}
export interface SlidingSyncToDeviceExtension {
    enabled: boolean;
    /** 最大 ToDevice 事件数 */
    limit?: number;
}
export interface SlidingSyncAccountDataExtension {
    enabled: boolean;
}
export interface SlidingSyncReceiptsExtension {
    enabled: boolean;
}
export interface SlidingSyncTypingExtension {
    enabled: boolean;
}
export interface SlidingSyncResponse {
    /** 下一批位置令牌 */
    pos: string;
    /** 列表更新操作 */
    lists?: Record<string, SlidingSyncListUpdate>;
    /** 房间数据 */
    rooms?: Record<string, SlidingSyncRoom>;
    /** 扩展响应 */
    extensions?: SlidingSyncExtensionsResponse;
}
export interface SlidingSyncListUpdate {
    /** 房间总数 */
    count: number;
    /** 更新操作列表 */
    ops?: SlidingSyncListOperation[];
}
export interface SlidingSyncListOperation {
    op: "SYNC" | "POST" | "DELETE";
    range?: number[];
    room_id?: string;
}
export interface SlidingSyncRoom {
    /** 房间 ID */
    room_id: string;
    /** 房间名称 */
    name?: string;
    /** 房间头像 URL */
    avatar?: string;
    /** 必选 state 事件数组 */
    required_state?: SlidingSyncStateEvent[];
    /** 时间线事件 */
    timeline?: SlidingSyncTimeline;
    /** 临时事件 */
    ephemeral?: Array<{
        type: string;
        sender?: string;
        content: unknown;
    }>;
    /** 账户数据事件 */
    account_data?: Array<{
        type: string;
        content: unknown;
    }>;
    /** 未读通知数 */
    unread_count?: number;
    /** Joined 成员数 */
    joined_member_count?: number;
    /** Invited 成员数 */
    invited_member_count?: number;
    /** 高亮未读数 */
    highlight_count?: number;
    /** 通知数 */
    notification_count?: number;
    /** 粘性事件（MSC4354） */
    sticky_events?: SlidingSyncStateEvent[];
}
export interface SlidingSyncStateEvent {
    type: string;
    state_key: string;
    sender?: string;
    content: unknown;
    /** 事件 ID（可选） */
    event_id?: string;
    /** 服务器时间戳（可选） */
    origin_server_ts?: number;
}
export interface SlidingSyncTimeline {
    /** 事件数组 */
    events: unknown[];
    /** 是否被截断 */
    limited?: boolean;
    /** 上一页 batch token */
    prev_batch?: string;
}
export interface SlidingSyncExtensionsResponse {
    /** E2EE 扩展响应 */
    e2ee?: SlidingSyncE2EEExtensionResponse;
    /** ToDevice 扩展响应 */
    todevice?: SlidingSyncToDeviceExtensionResponse;
    /** 账户数据扩展响应 */
    account_data?: SlidingSyncAccountDataExtensionResponse;
    /** Receipt 扩展响应 */
    receipts?: Record<string, Record<string, SlidingSyncReceipt>>;
    /** Typing 扩展响应 */
    typing?: SlidingSyncTypingExtensionResponse;
}
export interface SlidingSyncE2EEExtensionResponse {
    device_lists?: {
        changed?: string[];
        left?: string[];
    };
    device_one_time_keys_count?: Record<string, number>;
    device_unused_fallback_key_types?: string[];
    fallback_key?: string;
}
export interface SlidingSyncToDeviceExtensionResponse {
    events: unknown[];
}
export interface SlidingSyncAccountDataExtensionResponse {
    events: Array<{
        type: string;
        content: unknown;
    }>;
}
export interface SlidingSyncReceipt {
    receipt_type: string;
    user_id: string;
    event_id: string;
    ts: number;
}
export interface SlidingSyncTypingExtensionResponse {
    events: Array<{
        type: string;
        sender: string;
        content: {
            user_ids: string[];
        };
    }>;
}
//# sourceMappingURL=dto.d.ts.map