export declare const SLIDING_SYNC_ROUTES_ENTRY_COUNT: 4;
export declare const SLIDING_SYNC_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "pos、列表窗口或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 429;
    readonly note: "Sliding Sync 长轮询触发限流";
}];
export type SlidingSyncStatusScenario = (typeof SLIDING_SYNC_ROUTES_STATUS_SCENARIOS)[number];
export declare const SLIDING_SYNC_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录";
}, {
    readonly scenario: "Sliding Sync 参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 pos、list ranges、subscriptions 或 extensions 后重试";
}, {
    readonly scenario: "长轮询限流或暂时拥塞";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试并保留上一次 pos";
}];
export type SlidingSyncErrorScenario = (typeof SLIDING_SYNC_ROUTES_ERROR_SCENARIOS)[number];
export declare const SLIDING_SYNC_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "Sliding Sync 请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "pos、列表窗口、订阅或扩展参数非法";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "Sliding Sync 长轮询触发限流";
}];
export type SlidingSyncErrcode = (typeof SLIDING_SYNC_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map