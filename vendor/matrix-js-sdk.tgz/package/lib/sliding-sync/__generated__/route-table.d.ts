/** Routes served by the synapse-rust `sliding-sync` module (mirrored from the backend contract). */
export declare const SLIDING_SYNC_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/unstable/org.matrix.msc3575/sync";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/unstable/org.matrix.simplified_msc3575/sync";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/sync";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v4/sync";
}];
/** Union of every (method, path) tuple in `SLIDING_SYNC_ROUTES`. */
export type SlidingSyncRoute = (typeof SLIDING_SYNC_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type SlidingSyncMethod = SlidingSyncRoute["method"];
/** Path templates referenced by this module. */
export type SlidingSyncPath = SlidingSyncRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type SlidingSyncReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${SlidingSyncReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type SlidingSyncPathPattern = SlidingSyncReplaceBraces<SlidingSyncPath>;
//# sourceMappingURL=route-table.d.ts.map