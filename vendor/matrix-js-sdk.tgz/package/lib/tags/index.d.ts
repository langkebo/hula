/**
 * Tag Manager - 标签管理
 *
 * 提供房间标签的添加、删除、查询功能
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export declare enum TagEvent {
    TagAdded = "TagAdded",
    TagRemoved = "TagRemoved",
    TagsUpdated = "TagsUpdated",
    TagError = "TagError"
}
export interface IRoomTag {
    name: string;
    order?: number;
}
export interface IRoomTags {
    [tagName: string]: {
        order?: number;
    };
}
interface TagManagerEventMap {
    [TagEvent.TagAdded]: (roomId: string, tag: string) => void;
    [TagEvent.TagRemoved]: (roomId: string, tag: string) => void;
    [TagEvent.TagsUpdated]: (roomId: string, tags: IRoomTags) => void;
    [TagEvent.TagError]: (roomId: string, error: Error) => void;
}
export declare class TagManager extends BaseManager<TagEvent, TagManagerEventMap> {
    private roomTags;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getRoomTags(roomId: string): Promise<IRoomTags>;
    addRoomTag(roomId: string, tag: string, order?: number): Promise<void>;
    removeRoomTag(roomId: string, tag: string): Promise<void>;
    getRoomsByTag(tag: string): Promise<string[]>;
    setRoomTagOrder(roomId: string, tag: string, order: number): Promise<void>;
    clearRoomTags(roomId: string): Promise<void>;
    getTaggedRooms(): Promise<Map<string, string[]>>;
    getFavoriteRooms(): Promise<string[]>;
    addToFavorites(roomId: string): Promise<void>;
    removeFromFavorites(roomId: string): Promise<void>;
    isFavorite(roomId: string): Promise<boolean>;
    getLowPriorityRooms(): Promise<string[]>;
    addToLowPriority(roomId: string): Promise<void>;
    removeFromLowPriority(roomId: string): Promise<void>;
    isLowPriority(roomId: string): Promise<boolean>;
    getCachedTags(roomId: string): IRoomTags;
    getCachedRoomsByTag(tag: string): string[];
    clearCache(): void;
    start(): Promise<void>;
    stop(): void;
}
export {};
//# sourceMappingURL=index.d.ts.map