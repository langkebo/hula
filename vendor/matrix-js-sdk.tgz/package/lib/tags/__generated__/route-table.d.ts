/** Routes served by the synapse-rust `tags` module (mirrored from the backend contract). */
export declare const TAGS_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/tags";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/tags/{tag}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/tags/{tag}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/tags";
}];
/** Union of every (method, path) tuple in `TAGS_ROUTES`. */
export type TagsRoute = (typeof TAGS_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type TagsMethod = TagsRoute["method"];
/** Path templates referenced by this module. */
export type TagsPath = TagsRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type TagsReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${TagsReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type TagsPathPattern = TagsReplaceBraces<TagsPath>;
//# sourceMappingURL=route-table.d.ts.map