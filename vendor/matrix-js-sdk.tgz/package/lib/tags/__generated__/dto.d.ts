/**
 * DTO snippets extracted from the contract doc for `tags`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type TagsContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map