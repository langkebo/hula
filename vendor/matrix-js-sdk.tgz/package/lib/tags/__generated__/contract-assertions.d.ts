export declare const TAGS_ROUTES_ENTRY_COUNT: 8;
export declare const TAGS_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "标签名、排序值或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "非房间成员或无权修改目标房间标签";
}, {
    readonly status: 404;
    readonly note: "房间或标签不存在";
}, {
    readonly status: 429;
    readonly note: "触发限流";
}];
export type TagsStatusScenario = (typeof TAGS_ROUTES_STATUS_SCENARIOS)[number];
export declare const TAGS_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录";
}, {
    readonly scenario: "标签参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正标签名、order 或请求体后重试";
}, {
    readonly scenario: "权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户需要对应房间访问权限";
}, {
    readonly scenario: "房间或标签不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新本地标签状态后再决定是否重试";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底处理";
}];
export type TagsErrorScenario = (typeof TAGS_ROUTES_ERROR_SCENARIOS)[number];
export declare const TAGS_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "标签请求体结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "标签名或 order 参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权读取或写入该房间标签";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "房间或指定标签不存在";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "标签相关请求触发限流";
}];
export type TagsErrcode = (typeof TAGS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map