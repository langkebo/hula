/** Routes served by the synapse-rust `sync` module (mirrored from the backend contract). */
export declare const SYNC_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/events";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/joined_rooms";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/my_rooms";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/sync";
}];
/** Union of every (method, path) tuple in `SYNC_ROUTES`. */
export type SyncRoute = (typeof SYNC_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type SyncMethod = SyncRoute["method"];
/** Path templates referenced by this module. */
export type SyncPath = SyncRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type SyncReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${SyncReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type SyncPathPattern = SyncReplaceBraces<SyncPath>;
//# sourceMappingURL=route-table.d.ts.map