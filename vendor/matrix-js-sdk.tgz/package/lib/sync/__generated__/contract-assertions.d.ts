export declare const SYNC_ROUTES_ENTRY_COUNT: 11;
export declare const SYNC_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 357;
    readonly note: "POST /sync";
}, {
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "参数错误";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 429;
    readonly note: "长轮询或同步请求被限流";
}];
export type SyncStatusScenario = (typeof SYNC_ROUTES_STATUS_SCENARIOS)[number];
export declare const SYNC_ROUTES_ERROR_SCENARIOS: readonly [];
export type SyncErrorScenario = (typeof SYNC_ROUTES_ERROR_SCENARIOS)[number];
export declare const SYNC_ROUTES_ERRCODES: readonly [];
export type SyncErrcode = (typeof SYNC_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map