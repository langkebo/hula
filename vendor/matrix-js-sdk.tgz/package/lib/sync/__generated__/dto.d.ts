/**
 * DTO snippets extracted from the contract doc for `sync`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type SyncContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map