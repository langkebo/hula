/**
 * Account Manager - 账户与认证管理
 *
 * 提供登录、登出、Token 管理等功能
 */
import { BaseManager } from "../managers/base-manager";
import { type EmptyObject } from "../@types/common";
import { type LoginRequest, type LoginResponse, type ILoginFlowsResponse, SSOAction, type LoginTokenPostResponse } from "../@types/auth";
import { type AuthDict } from "../interactive-auth";
import { type IdServerUnbindResult } from "../@types/partials";
import type { IContent } from "../models/event";
export interface MyRoomEntry {
    room_id: string;
    name?: string;
}
export interface MyRoomsResponse {
    rooms: MyRoomEntry[];
    total: number;
}
export interface EventsResponse {
    chunk: IContent[];
    start?: string;
    end?: string;
}
export interface EventsRequestOptions {
    from?: string;
    to?: string;
    dir?: "f" | "b";
    limit?: number;
    timeout?: number;
}
export declare class AccountManager extends BaseManager {
    /**
     * Get the session ID
     */
    getSessionId(): string;
    /**
     * Check if the current user is a guest
     */
    isGuest(): boolean;
    /**
     * Set whether the current user is a guest
     */
    setGuest(guest: boolean): void;
    /**
     * Get the access token
     */
    getAccessToken(): string | null;
    /**
     * Set the access token
     */
    setAccessToken(token: string): void;
    /**
     * Get login flows supported by the server
     */
    loginFlows(): Promise<ILoginFlowsResponse>;
    /**
     * Get CAS login URL
     */
    getCasLoginUrl(redirectUrl: string): string;
    /**
     * Get SSO login URL
     */
    getSsoLoginUrl(redirectUrl: string, loginType?: string, idpId?: string, action?: SSOAction): string;
    /**
     * Send a login request
     */
    loginRequest(data: LoginRequest): Promise<LoginResponse>;
    /**
     * Login with credentials. Sends a login request and updates the client's
     * access token and user ID.
     *
     * @param type - The login type (e.g. "m.login.password")
     * @param params - Login parameters (user, password, token, etc.)
     * @returns The login response containing access_token, user_id, device_id
     * @example
     * ```typescript
     * const response = await accountManager.login("m.login.password", {
     *     user: "@alice:example.com",
     *     password: "secret",
     * });
     * ```
     */
    login(type: LoginRequest["type"], params: Omit<LoginRequest, "type">): Promise<LoginResponse>;
    /**
     * Logout
     */
    logout(stopClient?: boolean): Promise<EmptyObject>;
    /**
     * Logout from all devices
     */
    logoutAll(stopClient?: boolean): Promise<EmptyObject>;
    /**
     * Submit email verification token for registration
     */
    submitEmailToken(sid: string, clientSecret: string, token: string): Promise<{
        success: boolean;
    }>;
    /**
     * Deactivate account
     */
    deactivateAccount(auth?: AuthDict, erase?: boolean): Promise<{
        id_server_unbind_result: IdServerUnbindResult;
    }>;
    /**
     * Request login token
     */
    requestLoginToken(auth?: AuthDict): Promise<LoginTokenPostResponse>;
    /**
     * Get fallback auth URL
     */
    getFallbackAuthUrl(loginType: string, authSessionId: string): string;
    /**
     * Get my rooms
     * GET /_matrix/vendor/v1/my_rooms
     */
    getMyRooms(): Promise<MyRoomsResponse>;
    /**
     * Get global events
     * GET /_matrix/client/v3/events
     */
    getEvents(options?: EventsRequestOptions): Promise<EventsResponse>;
    /**
     * Poll event updates using the legacy events stream with long-poll timeout.
     * GET /_matrix/client/v3/events?from=...&timeout=...
     *
     * @param from - Pagination token from a previous response
     * @param timeout - Long-poll timeout in milliseconds (default: 30000)
     * @returns Event stream chunk with start/end tokens
     */
    getEventStream(from?: string, timeout?: number): Promise<EventsResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map