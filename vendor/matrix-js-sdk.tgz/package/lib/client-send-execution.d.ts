import { EventStatus, type MatrixEvent } from "./models/event";
import type { ISendEventResponse } from "./@types/requests";
import type { Room } from "./models/room";
import type { MatrixScheduler } from "./scheduler";
import type { QueryDict } from "./utils";
interface SendExecutionArgs {
    scheduler?: MatrixScheduler<ISendEventResponse>;
    room: Room | null;
    event: MatrixEvent;
    queryOpts?: QueryDict;
    sendEventHttpRequest: (event: MatrixEvent, queryDict?: QueryDict) => Promise<ISendEventResponse>;
    updatePendingEventStatus: (room: Room | null, event: MatrixEvent, status: EventStatus) => void;
}
export declare function queueOrSendEvent({ scheduler, room, event, queryOpts, sendEventHttpRequest, updatePendingEventStatus, }: SendExecutionArgs): Promise<ISendEventResponse>;
export {};
//# sourceMappingURL=client-send-execution.d.ts.map