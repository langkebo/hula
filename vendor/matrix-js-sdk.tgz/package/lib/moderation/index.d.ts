/**
 * Moderation Manager - 审核管理
 *
 * 提供房间与事件的举报、分值更新及扫描器信息查询功能。
 * 对应后端: synapse-rust/src/web/routes/moderation.rs
 *
 * 遵循 D7 契约驱动开发标准，100% 覆盖后端端点并保持类型对齐。
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ReportEventBody {
    reason?: string;
    score?: number;
}
export interface UpdateScoreBody {
    score: number;
}
export interface ScannerInfo {
    enabled: boolean;
    version: string;
    supported_algorithms: string[];
}
/**
 * ModerationManager 处理内容审核与举报流程。
 * 对应后端 `moderation.rs` 中的所有 REST 端点。
 */
export declare class ModerationManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 举报事件
     * 对应 POST /_matrix/client/v3/rooms/{room_id}/report/{event_id}
     *
     * @example
     * ```typescript
     * await client.getModerationManager().reportEvent("!room:example.org", "$eventId", {
     *     reason: "spam",
     *     score: -50,
     * });
     * ```
     */
    reportEvent(roomId: string, eventId: string, body: ReportEventBody): Promise<void>;
    /**
     * 举报房间
     * 对应 POST /_matrix/client/v3/rooms/{room_id}/report
     *
     * @example
     * ```typescript
     * await client.getModerationManager().reportRoom("!room:example.org", {
     *     reason: "spam",
     * });
     * ```
     */
    reportRoom(roomId: string, body: ReportEventBody): Promise<void>;
    /**
     * 更新举报分值
     * 对应 PUT /_matrix/client/v3/rooms/{room_id}/report/{event_id}/score
     */
    updateReportScore(roomId: string, eventId: string, score: number): Promise<void>;
    /**
     * 举报用户
     * 对应 POST /_matrix/client/v3/users/{user_id}/report
     */
    reportUser(userId: string, body: ReportEventBody): Promise<void>;
    /**
     * 获取扫描器信息
     * 对应 GET /_matrix/client/v1/rooms/{room_id}/report/{event_id}/scanner_info
     *
     * @example
     * ```typescript
     * const info = await client.getModerationManager().getScannerInfo("!room:example.org", "$eventId");
     * if (info.enabled) {
     *     console.log(info.version, info.supported_algorithms);
     * }
     * ```
     */
    getScannerInfo(roomId: string, eventId: string): Promise<ScannerInfo>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map