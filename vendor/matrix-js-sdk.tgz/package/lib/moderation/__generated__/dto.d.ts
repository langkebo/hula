/**
 * DTO snippets extracted from the contract doc for `moderation`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface ScannerInfo {
    scanner_id: string;
    scan_result: string;
    confidence: number;
    scanned_at: number;
}
export interface ModerationRequestDto {
    score: number;
    reason: string;
}
export type ModerationResponseDto = Record<string, never>;
export interface ModerationV3RequestDto {
    reason: string;
    description: string;
}
export interface ModerationV3ResponseDto {
    report_id: string;
}
export interface ModerationV3MSC4260RequestDto {
    reason: string;
}
export type ModerationV3MSC4260ResponseDto = Record<string, never>;
//# sourceMappingURL=dto.d.ts.map