import type { MatrixClient } from "./client";
/**
 * Clear any data out of the persistent stores used by the client.
 * Extracted from clearStores to keep client.ts thin.
 */
export declare function clearClientStores(client: MatrixClient, args?: {
    cryptoDatabasePrefix?: string;
}): Promise<void>;
//# sourceMappingURL=client-store-cleanup.d.ts.map