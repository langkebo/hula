/**
 * Profile Manager - 用户资料管理
 *
 * 提供用户资料相关的功能：获取、设置显示名、头像等
 *
 * 优化特性:
 * - LRU 缓存: 用户资料缓存 (200 条, TTL 10 分钟)
 * - 重试机制: 指数退避重试 (继承自 BaseManager)
 * - 监控指标: 请求统计和性能监控 (继承自 BaseManager)
 */
import { MatrixClient } from "../client";
import { type EmptyObject } from "../@types/common";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type ErrorHandlingOptions } from "../error/index.js";
export declare enum ProfileEvent {
    ProfileUpdated = "ProfileUpdated",
    ProfileError = "ProfileError"
}
export interface IProfile {
    displayname?: string;
    avatar_url?: string;
}
export interface IExtendedProfile extends IProfile {
    [key: string]: unknown;
}
interface ProfileManagerEventMap {
    [ProfileEvent.ProfileUpdated]: (userId: string, profile: IProfile) => void;
    [ProfileEvent.ProfileError]: (error: Error) => void;
}
export declare class ProfileManager extends BaseManager<ProfileEvent, ProfileManagerEventMap> {
    private profileCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    private getCachedProfileEntry;
    private setCompleteProfileCache;
    private setProfileFieldCache;
    private getProfileField;
    /**
     * Set profile information
     */
    setProfileInfo(info: "avatar_url", data: {
        avatar_url: string;
    }): Promise<EmptyObject>;
    setProfileInfo(info: "displayname", data: {
        displayname: string;
    }): Promise<EmptyObject>;
    /**
     * Set display name
     *
     * @param name - 显示名称
     * @returns Promise that resolves when the display name is set
     *
     * @example
     * ```typescript
     * // 设置显示名称
     * await profileManager.setDisplayName("Alice");
     *
     * // 监听资料更新事件
     * profileManager.on(ProfileEvent.ProfileUpdated, (userId, profile) => {
     *     console.log(`Profile updated for ${userId}:`, profile);
     * });
     * ```
     *
     * @throws {ValidationError} 如果显示名称为空或过长
     * @throws {ApiError} 如果 API 调用失败
     */
    setDisplayName(name: string): Promise<EmptyObject>;
    /**
     * Set avatar URL
     *
     * @param url - MXC URL of the avatar (e.g., mxc://example.com/abc123)
     * @returns Promise that resolves when the avatar is set
     *
     * @example
     * ```typescript
     * // 上传头像并设置
     * const uploadResponse = await client.uploadContent(file);
     * await profileManager.setAvatarUrl(uploadResponse.content_uri);
     *
     * // 清除头像
     * await profileManager.setAvatarUrl("");
     * ```
     *
     * @throws {ValidationError} 如果 URL 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    setAvatarUrl(url: string): Promise<EmptyObject>;
    /**
     * Get profile information
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @returns 用户资料信息
     *
     * @example
     * ```typescript
     * // 获取用户资料
     * const profile = await profileManager.getProfileInfo("@alice:example.com");
     * console.log("Display name:", profile.displayname);
     * console.log("Avatar URL:", profile.avatar_url);
     *
     * // 使用缓存
     * const cachedProfile = await profileManager.getProfileInfo("@alice:example.com");
     * // 第二次调用会使用缓存（10 分钟 TTL）
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {NotFoundError} 如果用户不存在
     * @throws {ApiError} 如果 API 调用失败
     */
    getProfileInfo(userId: string): Promise<IProfile>;
    /**
     * Get display name
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @param forceRefresh - 是否强制刷新缓存（默认 false）
     * @param options.throwOnError - 是否抛出错误（默认 true）
     * @returns 用户显示名称，如果不存在或出错则返回 null
     *
     * @example
     * ```typescript
     * // 获取显示名称
     * const displayName = await profileManager.getDisplayName("@alice:example.com");
     * console.log("Display name:", displayName);
     *
     * // 强制刷新缓存
     * const freshName = await profileManager.getDisplayName("@alice:example.com", true);
     *
     * // 不抛出错误
     * const name = await profileManager.getDisplayName("@invalid:example.com", false, false);
     * if (!name) {
     *     console.log("User not found or error occurred");
     * }
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败且 throwOnError 为 true
     */
    getDisplayName(userId: string, forceRefresh?: boolean, options?: ErrorHandlingOptions | boolean): Promise<string | null>;
    /**
     * Get avatar URL
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @param forceRefresh - 是否强制刷新缓存（默认 false）
     * @param options.throwOnError - 是否抛出错误（默认 true）
     * @returns MXC URL，如果不存在或出错则返回 null
     *
     * @example
     * ```typescript
     * // 获取头像 URL
     * const avatarUrl = await profileManager.getAvatarUrl("@alice:example.com");
     * if (avatarUrl) {
     *     // 转换为 HTTP URL
     *     const httpUrl = profileManager.getHttpUriForMxc(avatarUrl, 96, 96);
     *     console.log("Avatar HTTP URL:", httpUrl);
     * }
     *
     * // 强制刷新缓存
     * const freshUrl = await profileManager.getAvatarUrl("@alice:example.com", true);
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败且 throwOnError 为 true
     */
    getAvatarUrl(userId: string, forceRefresh?: boolean, options?: ErrorHandlingOptions | boolean): Promise<string | null>;
    /**
     * Helper to get an HTTP URL for a MXC URL
     */
    getHttpUriForMxc(mxcUrl: string, width?: number, height?: number, method?: string, allowDirectLinks?: boolean): string | null;
    mxcUrlToHttp(mxcUrl: string, width?: number, height?: number, method?: string, allowDirectLinks?: boolean, _allowRedirects?: boolean, _ignoreCertificateErrors?: boolean): string | null;
    /**
     * Determine if the server supports extended profiles, as described by MSC4133.
     *
     * @returns `true` if supported, otherwise `false`
     */
    doesServerSupportExtendedProfiles(): Promise<boolean>;
    /**
     * Get the prefix used for extended profile requests.
     */
    private getExtendedProfileRequestPrefix;
    private assertExtendedProfileSupport;
    /**
     * Fetch a user's *extended* profile, which may include additional keys.
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param userId The user ID to fetch the profile of.
     * @returns A set of keys to property values.
     *
     * @throws An error if the server does not support MSC4133.
     * @throws A M_NOT_FOUND error if the profile could not be found.
     */
    getExtendedProfile(userId: string): Promise<IExtendedProfile>;
    /**
     * Fetch a specific key from the user's *extended* profile.
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param userId The user ID to fetch the profile of.
     * @param key The key of the property to fetch.
     * @returns The property value.
     *
     * @throws An error if the server does not support MSC4133.
     * @throws A M_NOT_FOUND error if the key was not set OR the profile could not be found.
     */
    getExtendedProfileProperty(userId: string, key: string): Promise<unknown>;
    /**
     * Set a property on your *extended* profile.
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param key The key of the property to set.
     * @param value The value to set on the property.
     *
     * @throws An error if the server does not support MSC4133 OR the server disallows editing the user profile.
     */
    setExtendedProfileProperty(key: string, value: unknown): Promise<void>;
    /**
     * Delete a property on your *extended* profile.
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param key The key of the property to delete.
     *
     * @throws An error if the server does not support MSC4133 OR the server disallows editing the user profile.
     */
    deleteExtendedProfileProperty(key: string): Promise<void>;
    /**
     * Set a property on an arbitrary user's *extended* profile.
     *
     * Unlike {@link ProfileManager.setExtendedProfileProperty}, this method accepts an
     * arbitrary user ID (rather than using the current user) and sends the raw value as
     * the request body (not wrapped in `{ [key]: value }`).
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param userId The user ID to set the property for.
     * @param key The key of the property to set.
     * @param value The raw value to set.
     *
     * @throws An error if the server does not support MSC4133 OR the server disallows editing the user profile.
     */
    setExtendedProfilePropertyForUser(userId: string, key: string, value: unknown): Promise<void>;
    /**
     * Delete a property on an arbitrary user's *extended* profile.
     *
     * Unlike {@link ProfileManager.deleteExtendedProfileProperty}, this method accepts
     * an arbitrary user ID (rather than using the current user).
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param userId The user ID to delete the property for.
     * @param key The key of the property to delete.
     *
     * @throws An error if the server does not support MSC4133 OR the server disallows editing the user profile.
     */
    deleteExtendedProfilePropertyForUser(userId: string, key: string): Promise<void>;
    /**
     * Update multiple properties on your *extended* profile. This will
     * merge with any existing keys.
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param profile The profile object to merge with the existing profile.
     * @returns The newly merged profile.
     *
     * @throws An error if the server does not support MSC4133 OR the server disallows editing the user profile.
     */
    patchExtendedProfile(profile: IExtendedProfile): Promise<IExtendedProfile>;
    /**
     * Set multiple properties on your *extended* profile. This will completely
     * replace the existing profile, removing any unspecified keys.
     *
     * @see https://github.com/tcpipuk/matrix-spec-proposals/blob/main/proposals/4133-extended-profiles.md
     * @param profile The profile object to set.
     *
     * @throws An error if the server does not support MSC4133 OR the server disallows editing the user profile.
     */
    setExtendedProfile(profile: IExtendedProfile): Promise<void>;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
    clearCache(): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map