export declare const THIRDPARTY_ROUTES_ENTRY_COUNT: 10;
export declare const THIRDPARTY_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 400;
    readonly note: "M_INVALID_PARAM | 参数无效";
}, {
    readonly status: 401;
    readonly note: "M_UNAUTHORIZED | 未认证";
}, {
    readonly status: 404;
    readonly note: "M_NOT_FOUND | 协议不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type ThirdpartyStatusScenario = (typeof THIRDPARTY_ROUTES_STATUS_SCENARIOS)[number];
export declare const THIRDPARTY_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "参数无效";
    readonly httpOrErrcode: "400 / M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "参数无效";
}, {
    readonly scenario: "未认证";
    readonly httpOrErrcode: "401 / M_UNAUTHORIZED";
    readonly sdkErrorType: "AuthError";
    readonly handling: "未认证";
}, {
    readonly scenario: "协议不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "协议不存在";
}];
export type ThirdpartyErrorScenario = (typeof THIRDPARTY_ROUTES_ERROR_SCENARIOS)[number];
export declare const THIRDPARTY_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "参数无效";
}, {
    readonly errcode: "M_UNAUTHORIZED";
    readonly httpStatus: "401";
    readonly note: "未认证";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "协议不存在";
}];
export type ThirdpartyErrcode = (typeof THIRDPARTY_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map