import type { IKeyBackupPath } from "./client-internal-types.ts";
/**
 * 构建 `/room_keys/keys` 系列路径。
 *
 * @param roomId - 房间 ID；给定则按房间取键
 * @param sessionId - 会话 ID；给定（需同时给 roomId）则按会话取键
 * @param version - 备份版本；给定则作为 `version` 查询参数
 */
export declare function makeKeyBackupPath(roomId?: string, sessionId?: string, version?: string): IKeyBackupPath;
//# sourceMappingURL=key-backup-paths.d.ts.map