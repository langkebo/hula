export interface SdkErrorMetadata {
    errorCode?: string;
    traceId?: string;
    userTip?: string;
    retryAfter?: number;
    isRetryable?: boolean;
}
export declare function extractRetryAfter(error: unknown): number | undefined;
export declare function inferUserTip(httpStatus?: number, errcode?: string, retryAfter?: number): string | undefined;
export declare function getSdkErrorMetadata(error: unknown): SdkErrorMetadata;
//# sourceMappingURL=error-normalization.d.ts.map