/**
 * The timezone the user is currently in. The value of this property should
 * match a timezone provided in https://www.iana.org/time-zones.
 *
 * This key was introduced in Matrix v1.16.
 */
export declare const ProfileKeyTimezone = "m.tz";
//# sourceMappingURL=profile-keys.d.ts.map