import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
import type { EmptyObject } from "./@types/common";
import type { IContent } from "./models/event";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function buildRoomUpgradePath(roomId: string): string;
export declare function buildRoomEventReportPath(roomId: string, eventId: string): string;
export declare function buildRoomReportPath(roomId: string): string;
export declare function upgradeRoomRequest(roomId: string, newVersion: string, additionalCreators: string[] | undefined, authedRequest: AuthedRequestFn): Promise<{
    replacement_room: string;
}>;
export declare function getStateEventRequest(roomId: string, eventType: string, stateKey: string, buildStateEventPath: (roomId: string, eventType: string, stateKey?: string) => string, authedRequest: AuthedRequestFn): Promise<IContent>;
export declare function reportEventRequest(roomId: string, eventId: string, score: number, reason: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function reportRoomRequest(roomId: string, reason: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function buildTypingPath(roomId: string, userId: string): string;
export declare function sendTypingRequest(roomId: string, userId: string, isTyping: boolean, timeoutMs: number, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export {};
//# sourceMappingURL=client-room-management-requests.d.ts.map