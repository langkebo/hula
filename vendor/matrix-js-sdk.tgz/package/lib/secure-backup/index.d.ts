/**
 * Secure Backup Manager - 安全备份管理
 *
 * 提供口令驱动的安全备份功能
 * 对应后端: synapse-rust/src/web/routes/e2ee_routes.rs
 *
 * 后端端点:
 * - POST /keys/backup/secure
 * - GET /keys/backup/secure/{backup_id}
 * - DELETE /keys/backup/secure/{backup_id}
 * - POST /keys/backup/secure/{backup_id}/keys
 * - POST /keys/backup/secure/{backup_id}/restore
 * - POST /keys/backup/secure/{backup_id}/verify
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface SecureBackupAuthData {
    public_key?: string;
    signatures?: Record<string, Record<string, string>>;
    [key: string]: unknown;
}
export interface SecureBackupInfo {
    backup_id: string;
    version: string;
    algorithm: string;
    auth_data: SecureBackupAuthData;
    key_count: number;
}
export interface SessionKey {
    room_id: string;
    session_id: string;
    session_key: string;
}
export interface SecureBackupKeysResponse {
    key_count: number;
}
export interface SecureBackupRestoreResponse {
    recovered_keys: number;
    total_keys: number;
}
export interface SecureBackupVerifyResponse {
    valid: boolean;
}
/**
 * @deprecated 服务端托管加密备份，破坏端到端性（ISSUE-6.3）。
 *
 * 本 Manager 把 passphrase 明文上传到后端 `/_matrix/client/v3/keys/backup/secure`，
 * 由服务端 Argon2id 派生密钥并加解密 session keys —— 服务端可解密用户 E2EE 密钥备份，
 * 违反 Matrix 密钥备份的端到端语义。
 *
 * 请改用标准客户端派生流程（CryptoApi）：
 * - 创建备份: `crypto.createRecoveryKeyFromPassphrase(passphrase)` + `crypto.resetKeyBackup()`
 * - 恢复备份: `crypto.restoreKeyBackupWithPassphrase(passphrase)`
 *
 * 标准流程走 `/_matrix/client/v3/room_keys`（服务端只存公钥 + 密文，永不接触口令/私钥）。
 */
export declare class SecureBackupManager extends BaseManager {
    private backupCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 列出所有安全备份
     * GET /_matrix/client/v3/keys/backup/secure
     */
    listSecureBackups(): Promise<Record<string, unknown>>;
    /**
     * 创建安全备份
     * POST /_matrix/client/v3/keys/backup/secure
     *
     * @deprecated passphrase 明文上送服务端（服务端派生密钥），破坏端到端性。
     * 改用 `crypto.createRecoveryKeyFromPassphrase` + `crypto.resetKeyBackup`。
     */
    createSecureBackup(passphrase: string): Promise<SecureBackupInfo>;
    /**
     * 获取安全备份
     * GET /_matrix/client/v3/keys/backup/secure/{backup_id}
     */
    getSecureBackup(backupId: string, forceRefresh?: boolean): Promise<SecureBackupInfo>;
    /**
     * 删除安全备份
     * DELETE /_matrix/client/v3/keys/backup/secure/{backup_id}
     */
    deleteSecureBackup(backupId: string): Promise<void>;
    /**
     * 添加密钥到安全备份
     * POST /_matrix/client/v3/keys/backup/secure/{backup_id}/keys
     *
     * @deprecated passphrase 明文 + 明文 session_keys 上送服务端，服务端派生密钥并加密。
     */
    addKeysToSecureBackup(backupId: string, passphrase: string, sessionKeys: SessionKey[]): Promise<SecureBackupKeysResponse>;
    /**
     * 从安全备份恢复
     * POST /_matrix/client/v3/keys/backup/secure/{backup_id}/restore
     *
     * @deprecated passphrase 明文上送，服务端解密 session keys。
     * 改用 `crypto.restoreKeyBackupWithPassphrase`（客户端解密）。
     */
    restoreFromSecureBackup(backupId: string, passphrase: string): Promise<SecureBackupRestoreResponse>;
    /**
     * 验证安全备份
     * POST /_matrix/client/v3/keys/backup/secure/{backup_id}/verify
     *
     * @deprecated passphrase 明文上送服务端验证。
     */
    verifySecureBackup(backupId: string, passphrase: string): Promise<SecureBackupVerifyResponse>;
    clearCache(): void;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map