import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
import type { EmptyObject } from "./@types/common";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function buildSecureBackupPath(backupId: string): string;
export declare function buildSecureBackupVerifyPath(backupId: string): string;
export declare function buildSecureBackupKeysPath(backupId: string): string;
export declare function buildSecureBackupRestorePath(backupId: string): string;
/** GET /_matrix/vendor/v1/my_rooms */
export declare function getMyRoomsRequest<T>(authedRequest: AuthedRequestFn): Promise<T>;
/** POST /_matrix/vendor/v1/search_rooms */
export declare function searchRoomsRequest<T>(authedRequest: AuthedRequestFn, searchTerm: string, limit?: number): Promise<T>;
/** POST /_matrix/vendor/v1/search_recipients */
export declare function searchRecipientsRequest<T>(authedRequest: AuthedRequestFn, searchTerm: string, limit?: number): Promise<T>;
/** GET /_matrix/client/v1/config/client */
export declare function getClientConfigRequest<T>(authedRequest: AuthedRequestFn): Promise<T>;
/** GET /_matrix/client/v3/login/sso/userinfo */
export declare function getSSOUserInfoRequest<T>(authedRequest: AuthedRequestFn): Promise<T>;
export declare function createSecureBackupRequest<T>(passphrase: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function getSecureBackupRequest<T>(backupId: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function verifySecureBackupPassphraseRequest<T>(backupId: string, passphrase: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function storeSecureBackupKeysRequest<T>(backupId: string, passphrase: string, sessionKeys: unknown[], authedRequest: AuthedRequestFn): Promise<T>;
export declare function restoreSecureBackupRequest<T>(backupId: string, passphrase: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function deleteSecureBackupRequest(backupId: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export {};
//# sourceMappingURL=client-secure-backup-requests.d.ts.map