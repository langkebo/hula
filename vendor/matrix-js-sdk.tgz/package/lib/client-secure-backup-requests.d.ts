import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
import type { EmptyObject } from "./@types/common";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function buildSecureBackupPath(backupId: string): string;
/**
 * 构造「服务端校验备份 passphrase」的路径。
 *
 * ⚠️ 这条路径对应的端点在**本后端恒返 `410 Gone / M_NOT_FOUND`**（服务端 passphrase 校验已移除，
 * 只剩客户端本地校验）。保留它只为与上游 API 形状一致；别在恢复流程里指望它给出 `valid`。
 *
 * @backendUnsupported 410 M_NOT_FOUND
 */
export declare function buildSecureBackupVerifyPath(backupId: string): string;
export declare function buildSecureBackupKeysPath(backupId: string): string;
export declare function buildSecureBackupRestorePath(backupId: string): string;
/** GET /_matrix/vendor/v1/my_rooms */
export declare function getMyRoomsRequest<T>(authedRequest: AuthedRequestFn): Promise<T>;
/** POST /_matrix/vendor/v1/search_rooms */
export declare function searchRoomsRequest<T>(authedRequest: AuthedRequestFn, searchTerm: string, limit?: number): Promise<T>;
/** POST /_matrix/vendor/v1/search_recipients */
export declare function searchRecipientsRequest<T>(authedRequest: AuthedRequestFn, searchTerm: string, limit?: number): Promise<T>;
/** GET /_matrix/client/v1/config/client */
export declare function getClientConfigRequest<T>(authedRequest: AuthedRequestFn): Promise<T>;
/** GET /_matrix/client/v3/login/sso/userinfo */
export declare function getSSOUserInfoRequest<T>(authedRequest: AuthedRequestFn): Promise<T>;
export declare function createSecureBackupRequest<T>(algorithm: string, authData: unknown, authedRequest: AuthedRequestFn): Promise<T>;
export declare function getSecureBackupRequest<T>(backupId: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function verifySecureBackupPassphraseRequest<T>(backupId: string, passphrase: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function storeSecureBackupKeysRequest<T>(backupId: string, sessionKeys: unknown[], authedRequest: AuthedRequestFn): Promise<T>;
export declare function restoreSecureBackupRequest<T>(backupId: string, rooms: string[] | undefined, authedRequest: AuthedRequestFn): Promise<T>;
export declare function deleteSecureBackupRequest(backupId: string, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export {};
//# sourceMappingURL=client-secure-backup-requests.d.ts.map