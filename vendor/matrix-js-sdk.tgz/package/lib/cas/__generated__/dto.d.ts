/**
 * DTO snippets extracted from the contract doc for `cas`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type CasContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map