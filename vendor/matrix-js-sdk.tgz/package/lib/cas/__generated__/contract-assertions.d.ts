export declare const CAS_ROUTES_ENTRY_COUNT: 16;
export declare const CAS_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "服务验证、代理验证或管理查询成功";
}, {
    readonly status: 302;
    readonly note: "登录或登出流程发生重定向";
}, {
    readonly status: 400;
    readonly note: "service、ticket 或管理查询参数不合法";
}, {
    readonly status: 401;
    readonly note: "CAS ticket 无效、过期或缺失";
}, {
    readonly status: 403;
    readonly note: "管理端点权限不足";
}, {
    readonly status: 404;
    readonly note: "目标用户属性或服务配置不存在";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type CasStatusScenario = (typeof CAS_ROUTES_STATUS_SCENARIOS)[number];
export declare const CAS_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "CAS ticket 无效或失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "重新发起 CAS 登录获取新 ticket";
}, {
    readonly scenario: "服务地址或校验参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 service、ticket 等查询参数";
}, {
    readonly scenario: "管理接口越权";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "仅使用具备 CAS 管理权限的账号调用";
}, {
    readonly scenario: "目标用户属性或服务不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "核对用户、服务注册信息后重试";
}];
export type CasErrorScenario = (typeof CAS_ROUTES_ERROR_SCENARIOS)[number];
export declare const CAS_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "CAS ticket 无效、过期或不可复用";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "CAS 请求参数结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "service、ticket 或管理查询参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "当前账号无权访问 CAS 管理接口";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "目标服务配置或用户属性不存在";
}];
export type CasErrcode = (typeof CAS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map