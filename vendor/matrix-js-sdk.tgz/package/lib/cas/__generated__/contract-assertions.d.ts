export declare const CAS_ROUTES_ENTRY_COUNT: 16;
export declare const CAS_ROUTES_STATUS_SCENARIOS: readonly [];
export type CasStatusScenario = (typeof CAS_ROUTES_STATUS_SCENARIOS)[number];
export declare const CAS_ROUTES_ERROR_SCENARIOS: readonly [];
export type CasErrorScenario = (typeof CAS_ROUTES_ERROR_SCENARIOS)[number];
export declare const CAS_ROUTES_ERRCODES: readonly [];
export type CasErrcode = (typeof CAS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map