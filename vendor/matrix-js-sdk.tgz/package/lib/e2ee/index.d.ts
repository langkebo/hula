import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { UploadKeysOptions, UploadKeysResponse, QueryKeysRequest, QueryKeysResponse, ClaimKeysRequest, ClaimKeysResponse, KeyChangesResponse, DeviceListUpdateEntry, DeviceListDeletedEntry, RoomKeyRequestsResponse } from "../device-keys/index";
import type { UploadDeviceSigningRequest } from "./__generated__/dto";
import type { IContent } from "../models/event";
/**
 * E2EEManager — 端到端加密原始端点的薄封装。
 *
 * 对接后端 `synapse-rust/src/web/routes/e2ee_routes.rs`（25 个路由）：
 * 兼容子路由（同时挂在 `/_matrix/client/{r0,v1,v3}`）：
 *   - POST   /keys/upload
 *   - POST   /keys/query
 *   - POST   /keys/claim
 *   - GET    /keys/changes
 *   - POST   /keys/device_list/update
 *   - POST   /keys/signatures
 *   - POST   /keys/signatures/upload
 *   - POST   /keys/device_signing/upload
 *   - GET/POST /room_keys/request
 *   - DELETE /room_keys/request/{request_id}
 *   - GET    /rooms/{room_id}/keys/distribution
 *   - PUT    /sendToDevice/{event_type}/{transaction_id}
 *
 * 仅 v3 暴露：
 *   - POST   /device_verification/request
 *   - POST   /device_verification/respond
 *   - GET    /device_verification/status/{token}
 *   - GET    /device_trust
 *   - GET    /device_trust/{device_id}
 *   - GET    /security/summary
 *   - POST   /keys/backup/secure
 *   - GET/DELETE /keys/backup/secure/{backup_id}
 *   - POST   /keys/backup/secure/{backup_id}/keys
 *   - POST   /keys/backup/secure/{backup_id}/restore
 *   - POST   /keys/backup/secure/{backup_id}/verify
 *
 * ## vodozemac 后端对齐（synapse-rust C-5，2026-06）
 *
 * 后端 Megolm 已收敛到 vodozemac（Phase 1 MegolmProvider ◆ Phase 2 双写
 * PickleFormat::Dual ◆ Phase 3 互操作测试进行中）。
 *
 * SDK 通过 `@matrix-org/matrix-sdk-crypto-wasm`（基于同一 vodozemac 库）
 * 管理客户端 Megolm session。重要兼容性说明：
 *
 * - **session import/export**: SDK 使用 WASM `importRoomKeys()`/`exportRoomKeys()`
 *   导出 Megolm session。后端 vodozemac 格式与此兼容（同一 pickle 格式）。
 *
 * - **m.room_key to-device 事件**: 消息格式由 Matrix 协议规范定义，vodozemac
 *   不改变线格式。
 *
 * - **key backup**: 后端 v10 使用 vodozemac 格式存储备份密钥。
 *   SDK 的 `backup.ts` 通过 WASM `BackupDecryptor` 解密，格式兼容。
 *
 * - **配置**: 后端 `E2EE_USE_VODOZEMAC_MEGOLM` 环境变量控制服务器端路径选择。
 *   SDK 客户端始终使用 vodozemac（WASM），无需额外配置。
 *
 * @remarks
 * 对绝大多数应用：使用 `MatrixClient.initRustCrypto()` 提供的高层 API，
 * 而不是直接调用此 Manager。本 Manager 只为需要绕过 Rust crypto 直接驱动
 * 后端 E2EE 端点的高级集成（管理工具、迁移脚本、契约测试）准备。
 */
export interface KeyAuditEntry {
    id: string;
    created_ts: number;
    [key: string]: unknown;
}
export interface KeyHistoryResponse {
    history: KeyAuditEntry[];
    next_batch: string | null;
}
/**
 * Device-trust / device-verification DTOs.
 *
 * Re-exported from the single authoritative module `src/device-trust/index.ts`.
 * This file used to declare its own copies with wrong wire field names (e.g.
 * `state` for the backend's `status`, `devices_total` for
 * `verified_devices`) and a respond body of `{ token, action }` that the
 * backend silently ignores. Do not re-declare these locally.
 */
export type { TrustLevel, VerificationStatus, VerificationMethod, IDeviceVerificationRequest, IDeviceVerificationResponse, IVerificationStatusResponse, IVerificationRespondResult, IDeviceTrustInfo, IDeviceTrustListResponse, ISecuritySummary, } from "../device-trust/index";
import type { IDeviceVerificationRequest, IDeviceVerificationResponse, IVerificationStatusResponse, IVerificationRespondResult, IDeviceTrustInfo, ISecuritySummary } from "../device-trust/index";
/** @deprecated Use {@link IDeviceVerificationRequest} (same shape). */
export type DeviceVerificationRequestBody = IDeviceVerificationRequest;
/**
 * Body of `POST /device_verification/respond`.
 *
 * The backend (`devices.rs::respond_device_verification`) reads
 * `request_token` (falling back to `token`) and **`approved: boolean`**, which
 * defaults to `false` — an omitted `approved` is a *rejection*. The
 * `action: "accept" | "reject"` form is accepted here only for backward
 * compatibility and is normalised to `approved` before the request is sent.
 */
export interface DeviceVerificationRespondBody {
    request_token?: string;
    token?: string;
    /** Canonical field. When omitted, `action` is consulted, then defaults to `false`. */
    approved?: boolean;
    /** @deprecated Legacy alias, normalised into `approved`. */
    action?: "accept" | "reject";
}
/** @deprecated Use {@link IDeviceVerificationResponse} (same shape). */
export type DeviceVerificationRequestResponse = IDeviceVerificationResponse;
/** @deprecated Use {@link IVerificationRespondResult} (same shape). */
export type DeviceVerificationRespondResponse = IVerificationRespondResult;
/** @deprecated Use {@link IVerificationStatusResponse} (same shape). */
export type DeviceVerificationStatusResponse = IVerificationStatusResponse;
/** @deprecated Use {@link IDeviceTrustInfo} (same shape). */
export type DeviceTrustInfo = IDeviceTrustInfo;
/** @deprecated Use {@link ISecuritySummary} (same shape). */
export type SecuritySummaryResponse = ISecuritySummary;
export type { TrustLevel as DeviceTrustLevel, VerificationStatus as DeviceVerificationStatus, VerificationMethod as DeviceVerificationMethod, } from "../device-trust/index";
export interface SecureBackupInfo {
    backup_id: string;
    algorithm: string;
    /** Algorithm-specific auth data (shape varies by backup algorithm) */
    auth_data: IContent;
    version: string;
    count?: number;
    etag?: string;
}
export interface SecureBackupCreateResponse extends SecureBackupInfo {
}
export interface SecureBackupKeysResponse {
    count: number;
}
export interface SecureBackupRestoreResponse {
    /** Number of keys recovered */
    recovered_keys: number;
    /** Total keys in backup */
    total: number;
}
export interface SecureBackupVerifyResponse {
    valid: boolean;
}
export interface RoomKeyRequestBody {
    room_id: string;
    session_id: string;
    algorithm: string;
    /** Additional key request data (varies by algorithm) */
    body?: IContent;
}
export interface RoomKeyRequestResponse {
    request_id: string;
    room_id: string;
    session_id: string;
    algorithm: string;
    state: "pending" | "accepted" | "cancelled";
}
export interface RoomKeyDistributionResponse {
    room_id: string;
    sessions: Array<{
        session_id: string;
        algorithm: string;
        sender_key?: string;
    }>;
}
export interface SignaturesUploadResponse {
    failures?: Record<string, Record<string, string>>;
}
export interface SecurityBackupCreateBody {
    algorithm?: string;
    /** Algorithm-specific auth data (shape varies by backup algorithm) */
    auth_data?: IContent;
    passphrase?: string;
}
export interface StoreSecureBackupKeysBody {
    passphrase: string;
    session_keys?: Array<{
        session_id: string;
        session_data: IContent;
    }>;
}
export interface RestoreSecureBackupBody {
    passphrase: string;
    rooms?: string[];
    key?: string;
}
export interface VerifySecureBackupPassphraseBody {
    passphrase: string;
}
/** Messages for send-to-device: user_id → device_id → event content // Dynamic: content shape varies by event type */
export type SendToDeviceMessages = Record<string, Record<string, IContent>>;
export interface DeviceSigningUploadResponse {
    failures?: Record<string, Record<string, string>>;
}
export interface SendToDeviceResponse {
    failures?: Record<string, Record<string, string>>;
}
export type SendToDeviceVersion = "v1" | "v3";
export declare class E2EEManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    uploadKeys(body: UploadKeysOptions): Promise<UploadKeysResponse>;
    /**
     * Upload keys for a specific device via path parameter.
     * POST /_matrix/client/v3/keys/upload/{device_id}
     *
     * Same handler as `uploadKeys` but the device_id is taken from the URL
     * instead of the authenticated session.
     */
    uploadKeysToDevice(deviceId: string, body: UploadKeysOptions): Promise<UploadKeysResponse>;
    queryKeys(body: QueryKeysRequest): Promise<QueryKeysResponse>;
    claimKeys(body: ClaimKeysRequest): Promise<ClaimKeysResponse>;
    getKeyChanges(params?: {
        from?: string;
        to?: string;
    }): Promise<KeyChangesResponse>;
    postDeviceListUpdate(body: Array<DeviceListUpdateEntry | DeviceListDeletedEntry>): Promise<void>;
    uploadSignatures(body: Record<string, Record<string, Record<string, string>>>): Promise<SignaturesUploadResponse>;
    /**
     * `/keys/signatures/upload` 与 `/keys/signatures` 是同一 handler 的别名，
     * 后端两条路径都会被路由到 `upload_signatures`，按 SDK 习惯保留两个入口。
     */
    uploadSignaturesAlt(body: Record<string, Record<string, Record<string, string>>>): Promise<SignaturesUploadResponse>;
    /**
     * Upload device signing (cross-signing) keys.
     *
     * Adds client-side validation before sending to the backend:
     * - At least one of `master_key`, `self_signing_key`, `user_signing_key` must be provided
     * - `usage` field (if present) must be a valid array of strings
     * - `user_id` in key objects must match the current authenticated user
     *
     * @param body - The request body containing cross-signing keys to upload
     * @returns The response from the server (empty object on success)
     *
     * @throws {ValidationError} If validation fails before sending the request
     * @throws {ApiError} If the API call fails
     */
    uploadDeviceSigning(body: UploadDeviceSigningRequest): Promise<DeviceSigningUploadResponse>;
    createRoomKeyRequest(body: RoomKeyRequestBody): Promise<RoomKeyRequestResponse>;
    listRoomKeyRequests(): Promise<RoomKeyRequestsResponse>;
    deleteRoomKeyRequest(requestId: string): Promise<void>;
    getRoomKeyDistribution(roomId: string): Promise<RoomKeyDistributionResponse>;
    sendToDevice(eventType: string, transactionId: string, messages: SendToDeviceMessages, version?: SendToDeviceVersion): Promise<SendToDeviceResponse>;
    sendToDeviceV1(eventType: string, transactionId: string, messages: SendToDeviceMessages): Promise<SendToDeviceResponse>;
    /**
     * Request verification of one of the caller's own devices.
     *
     * Delegates to {@link DeviceTrustManager.requestVerification} — the single
     * implementation of the `POST /device_verification/request` contract
     * (`devices.rs::request_device_verification` reads `new_device_id` or
     * `device_id`, plus an optional `method`, and ignores anything else).
     */
    requestDeviceVerification(body: DeviceVerificationRequestBody): Promise<IDeviceVerificationResponse>;
    /**
     * Approve or reject a pending verification request.
     *
     * ⚠️ `approved` is what the backend reads, and it **defaults to `false`**
     * (`devices.rs::respond_device_verification:480`). Posting `{ token, action }`
     * — the shape this method used to forward verbatim — made every "accept"
     * a silent rejection. The legacy `action` field is still accepted from
     * callers and normalised here.
     */
    respondDeviceVerification(body: DeviceVerificationRespondBody): Promise<IVerificationRespondResult>;
    getDeviceVerificationStatus(token: string): Promise<IVerificationStatusResponse>;
    getDeviceTrustList(): Promise<IDeviceTrustInfo[]>;
    getDeviceTrust(deviceId: string): Promise<IDeviceTrustInfo | null>;
    getSecuritySummary(): Promise<ISecuritySummary>;
    /**
     * The single authoritative device-trust implementation lives on
     * `DeviceTrustManager`; reached through the client to avoid a runtime
     * import cycle (`device-trust` → `client`).
     */
    private get trustManager();
    createSecureBackup(body: SecurityBackupCreateBody): Promise<SecureBackupCreateResponse>;
    /**
     * GET /keys/backup/secure — 列出所有安全备份
     * 对应后端 get_secure_backup_list handler
     */
    getSecureBackupList(): Promise<{
        backups: SecureBackupInfo[];
    }>;
    getSecureBackup(backupId: string): Promise<SecureBackupInfo>;
    deleteSecureBackup(backupId: string): Promise<void>;
    storeSecureBackupKeys(backupId: string, body: StoreSecureBackupKeysBody): Promise<SecureBackupKeysResponse>;
    restoreSecureBackup(backupId: string, body: RestoreSecureBackupBody): Promise<SecureBackupRestoreResponse>;
    verifySecureBackupPassphrase(backupId: string, body: VerifySecureBackupPassphraseBody): Promise<SecureBackupVerifyResponse>;
    /**
     * Get key history (audit log) for the current user.
     * GET /_matrix/client/v3/keys/history
     *
     * @param params - Optional pagination parameters.
     * @param params.limit - Maximum number of entries to return (default 100, max 1000).
     * @param params.from - Pagination cursor from a previous response's `next_batch`.
     */
    getKeyHistory(params?: {
        limit?: number;
        from?: string;
    }): Promise<KeyHistoryResponse>;
    private post;
    private postVoid;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map