/** Routes served by the synapse-rust `e2ee` module (mirrored from the backend contract). */
export declare const E2EE_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/keys/changes";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/claim";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_list/update";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_signing/upload";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/query";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/signatures";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/signatures/upload";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/upload";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/room_keys/request";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/room_keys/request";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/room_keys/request/{request_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/keys/distribution";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/sendToDevice/{event_type}/{transaction_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/sendToDevice/{event_type}/{transaction_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/device_trust";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/device_trust/{device_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/device_verification/request";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/device_verification/respond";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/device_verification/status/{token}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/backup/secure";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/backup/secure";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/keys/backup/secure/{backup_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/backup/secure/{backup_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/backup/secure/{backup_id}/keys";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/backup/secure/{backup_id}/restore";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/backup/secure/{backup_id}/verify";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/changes";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/claim";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_list/update";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_signing/upload";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/query";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/signatures";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/signatures/upload";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/upload";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/room_keys/request";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/room_keys/request";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/room_keys/request/{request_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/keys/distribution";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/security/summary";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/sendToDevice/{event_type}/{transaction_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/sendToDevice/{event_type}/{transaction_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/history";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/upload/{device_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/upload/{device_id}";
}];
/** Union of every (method, path) tuple in `E2EE_ROUTES`. */
export type E2eeRoute = (typeof E2EE_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type E2eeMethod = E2eeRoute["method"];
/** Path templates referenced by this module. */
export type E2eePath = E2eeRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type E2eeReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${E2eeReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type E2eePathPattern = E2eeReplaceBraces<E2eePath>;
//# sourceMappingURL=route-table.d.ts.map