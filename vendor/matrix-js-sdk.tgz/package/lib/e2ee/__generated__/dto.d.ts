/**
 * DTO snippets extracted from the contract doc for `e2ee`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface DeviceKeyData {
    user_id?: string;
    device_id?: string;
    algorithms?: string[];
    keys?: Record<string, string>;
    signatures?: Record<string, Record<string, string>>;
}
export interface UploadKeysRequest {
    device_keys?: DeviceKeyData;
    one_time_keys?: Record<string, Record<string, string>>;
}
export interface UploadKeysResponse {
    one_time_key_counts: Record<string, number>;
}
export interface QueryKeysRequest {
    device_keys: Record<string, string[]>;
    timeout?: number;
    token?: string;
}
export interface CrossSigningKey {
    user_id?: string;
    usage?: string[];
    keys?: Record<string, string>;
    signatures?: Record<string, Record<string, string>>;
}
export interface QueryKeysResponse {
    device_keys: Record<string, Record<string, DeviceKeyData>>;
    failures: Record<string, {
        error?: string;
        message?: string;
    }>;
    master_keys: Record<string, CrossSigningKey>;
    self_signing_keys: Record<string, CrossSigningKey>;
    user_signing_keys: Record<string, CrossSigningKey>;
}
export interface ClaimKeysRequest {
    one_time_keys: Record<string, Record<string, string>>;
    timeout?: number;
}
export interface ClaimKeysResponse {
    one_time_keys: Record<string, Record<string, Record<string, Record<string, string>>>>;
    failures: Record<string, {
        error?: string;
        message?: string;
    }>;
}
export interface KeyChangesResponse {
    changed: string[];
    left: string[];
}
export type SendToDeviceMessages = Record<string, Record<string, Record<string, unknown>>>;
export interface SendToDeviceRequest {
    messages: SendToDeviceMessages;
}
export interface UploadSignaturesRequest {
    [userId: string]: Record<string, Record<string, unknown>>;
}
export interface UploadSignaturesResponse {
    failures: Record<string, Record<string, unknown>>;
}
export interface UploadDeviceSigningRequest {
    master_key?: CrossSigningKey;
    self_signing_key?: CrossSigningKey;
    user_signing_key?: CrossSigningKey;
    auth?: {
        type: string;
        session?: string;
        [key: string]: unknown;
    };
}
export interface RoomKeyRequestRequest {
    action: "request" | "cancel_request";
    requesting_device_id: string;
    request_id: string;
    room_id?: string;
    session_id?: string;
    algorithm?: string;
    devices?: Array<{
        user_id: string;
        device_id: string;
    }>;
}
export interface DeviceVerificationRequest {
    new_device_id?: string;
    device_id?: string;
    method?: "sas" | "qr" | "emoji";
}
export interface DeviceVerificationResponse {
    request_token: string;
    token: string;
    status: "pending" | "approved" | "rejected" | "expired" | "not_found";
    expires_at: number;
    methods_available: ("sas" | "qr" | "emoji")[];
}
export interface DeviceVerificationStatusResponse {
    request_token?: string;
    token?: string;
    status: "pending" | "approved" | "rejected" | "expired" | "not_found";
    expires_at?: number;
    methods_available?: ("sas" | "qr" | "emoji")[];
}
export interface DeviceTrustEntry {
    device_id: string;
    trust_level: "verified" | "unverified" | "blocked";
    verified_at?: number;
    verified_by?: string;
}
export interface DeviceTrustListResponse {
    devices: DeviceTrustEntry[];
}
export interface DeviceTrustResponse {
    device_id: string;
    trust_level: "verified" | "unverified" | "blocked";
    verified_at?: number;
    verified_by?: string;
}
export interface SecuritySummaryResponse {
    verified_devices: number;
    unverified_devices: number;
    blocked_devices: number;
    has_cross_signing_master: boolean;
    security_score: number;
    recommendations: string[];
}
export interface SecurityBackupCreateRequest {
    algorithm?: string;
    auth_data?: Record<string, unknown>;
    passphrase?: string;
}
export interface SecurityBackupCreateResponse {
    version: string;
    algorithm: string;
}
export interface SecurityBackupListResponse {
    backups: Array<{
        version: string;
        algorithm: string;
        auth_data?: Record<string, unknown>;
    }>;
}
export interface SecurityBackupGetResponse {
    version: string;
    algorithm: string;
    auth_data?: Record<string, unknown>;
    count?: number;
    etag?: string;
}
export interface SecureBackupStoreKeysRequest {
    keys: Record<string, Record<string, unknown>>;
}
export interface SecureBackupStoreKeysResponse {
    count: number;
    etag: string;
}
export interface SecureBackupRestoreRequest {
    rooms?: string[];
    passphrase?: string;
    key?: string;
}
export interface SecureBackupRestoreResponse {
    recovered_keys: number;
    total_keys: number;
}
export interface SecureBackupVerifyRequest {
    passphrase?: string;
    key?: string;
}
export interface SecureBackupVerifyResponse {
    valid: boolean;
    algorithm?: string;
}
export interface DeviceListUpdateRequest {
    users: string[];
}
export interface DeviceListUpdateResponse {
    changed?: string[];
    left?: string[];
}
export interface RoomKeyDistributionResponse {
    room_id: string;
    devices?: Array<{
        user_id: string;
        device_id: string;
    }>;
    status?: string;
}
//# sourceMappingURL=dto.d.ts.map