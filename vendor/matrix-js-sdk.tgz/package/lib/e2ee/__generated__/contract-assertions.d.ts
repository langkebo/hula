export declare const E2EE_ROUTES_ENTRY_COUNT: 51;
export declare const E2EE_ROUTES_STATUS_SCENARIOS: readonly [];
export type E2eeStatusScenario = (typeof E2EE_ROUTES_STATUS_SCENARIOS)[number];
export declare const E2EE_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "缺少访问令牌";
    readonly httpOrErrcode: "401 / M_MISSING_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "缺少访问令牌";
}, {
    readonly scenario: "无效的访问令牌";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "无效的访问令牌";
}, {
    readonly scenario: "资源不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "资源不存在";
}, {
    readonly scenario: "签名无效";
    readonly httpOrErrcode: "400 / M_INVALID_SIGNATURE";
    readonly sdkErrorType: "ApiError";
    readonly handling: "签名无效";
}];
export type E2eeErrorScenario = (typeof E2EE_ROUTES_ERROR_SCENARIOS)[number];
export declare const E2EE_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_MISSING_TOKEN";
    readonly httpStatus: "401";
    readonly note: "缺少访问令牌";
}, {
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "无效的访问令牌";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "资源不存在";
}, {
    readonly errcode: "M_INVALID_SIGNATURE";
    readonly httpStatus: "400";
    readonly note: "签名无效";
}];
export type E2eeErrcode = (typeof E2EE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map