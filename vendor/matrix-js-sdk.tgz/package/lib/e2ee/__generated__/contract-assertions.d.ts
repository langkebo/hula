export declare const E2EE_ROUTES_ENTRY_COUNT: 55;
export declare const E2EE_ROUTES_STATUS_SCENARIOS: readonly [];
export type E2eeStatusScenario = (typeof E2EE_ROUTES_STATUS_SCENARIOS)[number];
export declare const E2EE_ROUTES_ERROR_SCENARIOS: readonly [];
export type E2eeErrorScenario = (typeof E2EE_ROUTES_ERROR_SCENARIOS)[number];
export declare const E2EE_ROUTES_ERRCODES: readonly [];
export type E2eeErrcode = (typeof E2EE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map