export declare const RENDEZVOUS_ROUTES_ENTRY_COUNT: 6;
export declare const RENDEZVOUS_ROUTES_STATUS_SCENARIOS: readonly [];
export type RendezvousStatusScenario = (typeof RENDEZVOUS_ROUTES_STATUS_SCENARIOS)[number];
export declare const RENDEZVOUS_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "更新为 connected 时缺少访问令牌";
    readonly httpOrErrcode: "401 / M_MISSING_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "更新为 connected 时缺少访问令牌";
}, {
    readonly scenario: "无效的访问令牌";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "无效的访问令牌";
}, {
    readonly scenario: "缺少或提供了错误的 rendezvous key";
    readonly httpOrErrcode: "401 / M_UNAUTHORIZED";
    readonly sdkErrorType: "AuthError";
    readonly handling: "缺少或提供了错误的 rendezvous key";
}, {
    readonly scenario: "已绑定会话被其他用户越权访问";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "已绑定会话被其他用户越权访问";
}, {
    readonly scenario: "会话不存在或已过期";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "会话不存在或已过期";
}, {
    readonly scenario: "会话已过期";
    readonly httpOrErrcode: "410 / M_RENDEZVOUS_EXPIRED";
    readonly sdkErrorType: "ApiError";
    readonly handling: "会话已过期";
}, {
    readonly scenario: "会话已取消";
    readonly httpOrErrcode: "410 / M_RENDEZVOUS_CANCELLED";
    readonly sdkErrorType: "ApiError";
    readonly handling: "会话已取消";
}];
export type RendezvousErrorScenario = (typeof RENDEZVOUS_ROUTES_ERROR_SCENARIOS)[number];
export declare const RENDEZVOUS_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_MISSING_TOKEN";
    readonly httpStatus: "401";
    readonly note: "更新为 connected 时缺少访问令牌";
}, {
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "无效的访问令牌";
}, {
    readonly errcode: "M_UNAUTHORIZED";
    readonly httpStatus: "401";
    readonly note: "缺少或提供了错误的 rendezvous key";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "已绑定会话被其他用户越权访问";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "会话不存在或已过期";
}, {
    readonly errcode: "M_RENDEZVOUS_EXPIRED";
    readonly httpStatus: "410";
    readonly note: "会话已过期";
}, {
    readonly errcode: "M_RENDEZVOUS_CANCELLED";
    readonly httpStatus: "410";
    readonly note: "会话已取消";
}];
export type RendezvousErrcode = (typeof RENDEZVOUS_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map