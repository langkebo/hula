/**
 * Room List Manager - 房间列表管理
 *
 * 提供房间列表相关功能
 */
import { MatrixClient } from "../client";
import { Room } from "../models/room";
export declare class RoomListManager {
    private client;
    constructor(client: MatrixClient);
    getRoomList(): Room[];
    getRooms(): Room[];
    getVisibleRooms(): Room[];
    getDmUserMap(): Record<string, string[]>;
    getRoom(roomId: string): Room | null;
    getMyRooms(): Promise<{
        rooms: Room[];
        total: number;
    }>;
    removeRoom(roomId: string): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map