/**
 * Turn Server Manager - TURN服务器管理
 *
 * 提供TURN服务器信息获取功能
 */
import { MatrixClient } from "../client";
import { type ITurnServer, type ITurnServerResponse } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface TurnServerManagerEvents {
    turn_servers_updated: (data: {
        servers: ITurnServer[];
    }) => void;
    turn_server_expired: () => void;
}
export declare class TurnServerManager extends BaseManager<keyof TurnServerManagerEvents, TurnServerManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getTurnServers(): ITurnServer[];
    getTurnServerConfig(): Promise<ITurnServerResponse>;
    getTurnServerURIs(): Promise<string[]>;
    getTurnServerExpiry(): number;
    /**
     * Check TURN servers and refresh credentials if needed.
     * Emits TurnServers and TurnServersError events on the client.
     * @returns true if credentials are good, undefined if VoIP not supported.
     */
    checkTurnServers(): Promise<boolean | undefined>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map