import { Method } from "./http-api/index.ts";
import type { Body, IRequestOpts } from "./http-api/index.ts";
import { ServerSupport } from "./feature.ts";
import type { QueryDict } from "./utils.ts";
import type { EmptyObject } from "./@types/common.ts";
export declare function buildUserAccountDataPath(userId: string | null, eventType: string): string;
export declare function buildUserAccountDataListPath(userId: string | null): string;
export declare function buildRoomAccountDataPath(userId: string | null, roomId: string, eventType: string): string;
export declare function buildRoomTagsPath(userId: string | null, roomId: string): string;
export declare function buildRoomTagPath(userId: string | null, roomId: string, tagName: string): string;
export declare function buildCreateFilterPath(userId: string | null): string;
export declare function buildFilterPath(userId: string | null, filterId: string): string;
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function setUserAccountDataRequest(userId: string | null, eventType: string, content: Record<string, unknown>, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function getUserAccountDataRequest<T>(userId: string | null, eventType: string, authedRequest: AuthedRequestFn): Promise<T>;
export declare function deleteUserAccountDataRequest(userId: string | null, eventType: string, authedRequest: AuthedRequestFn, requestOpts?: IRequestOpts): Promise<void>;
export declare function selectDeleteAccountDataRequestOptions(serverSupport: ServerSupport | undefined): IRequestOpts | undefined;
export {};
//# sourceMappingURL=client-account-data-requests.d.ts.map