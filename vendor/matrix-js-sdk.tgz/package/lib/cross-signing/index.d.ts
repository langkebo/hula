/**
 * Cross Signing Manager - 交叉签名管理
 *
 * 提供 cross-signing 功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface CrossSigningStatus {
    crossSigningVerified: boolean;
    crossSigningVerifiedBefore: boolean;
    crossSigningTrusted: boolean;
}
export interface CrossSigningKeys {
    masterKey: string | null;
    selfSigningKey: string | null;
    userSigningKey: string | null;
}
export interface UserCrossSigningKeys {
    masterKey: string | null;
    selfSigningKey: string | null;
    userSigningKey: string | null;
    verified: boolean;
}
export interface CrossSigningManagerEvents {
    cross_signing_ready: () => void;
    cross_signing_updated: (data: {
        userId: string;
    }) => void;
    cross_signing_trusted: (data: {
        userId: string;
    }) => void;
}
export declare class CrossSigningManager extends BaseManager<keyof CrossSigningManagerEvents, CrossSigningManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    checkCrossSigningStatus(): Promise<CrossSigningStatus>;
    getCrossSigningKeys(): Promise<CrossSigningKeys>;
    isCrossSigningReady(): Promise<boolean>;
    getUserCrossSigningKeys(userId: string): Promise<UserCrossSigningKeys>;
    checkAndTrustCrossSigning(): Promise<void>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map