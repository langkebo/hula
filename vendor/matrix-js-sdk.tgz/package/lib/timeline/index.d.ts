/**
 * Timeline Manager - 时间线管理
 *
 * 提供时间线相关功能，包括时间线获取、分页等
 */
import { MatrixClient } from "../client";
import { Room } from "../models/room";
import { EventTimeline, Direction } from "../models/event-timeline";
import { EventTimelineSet } from "../models/event-timeline-set";
import { MatrixEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface TimelineManagerEvents {
    timelineFetched: (data: {
        roomId: string;
        eventId: string;
    }) => void;
    timelinePaginated: (data: {
        roomId: string;
        direction: Direction;
    }) => void;
}
export declare class TimelineManager extends BaseManager<keyof TimelineManagerEvents, TimelineManagerEvents> {
    private static SCROLLBACK_DELAY_MS;
    private ongoingScrollbacks;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getTimelineForRoom(roomId: string): EventTimelineSet | null;
    getEventTimelineSync(roomId: string, eventId: string): EventTimeline | null;
    getEventAndComments(eventId: string): {
        event: unknown;
        comments: unknown[];
    } | null;
    peekRoom(roomId: string): Promise<Room | null>;
    stopPeeking(): Promise<void>;
    getEventTimeline(timelineSet: EventTimelineSet, eventId: string): Promise<EventTimeline | null>;
    /**
     * Get an EventTimeline for the latest events in the room. This will just
     * call `/messages` to get the latest message in the room, then use
     * `getEventTimeline(...)` to construct a new timeline from it.
     *
     * @param timelineSet -  The timelineSet to find or add the timeline to
     *
     * @returns Promise which resolves:
     *    {@link EventTimeline} timeline with the latest events in the room
     */
    getLatestTimeline(timelineSet: EventTimelineSet): Promise<EventTimeline | null>;
    /**
     * Scroll back in the timeline for the given room, loading more events
     * from the store and/or server.
     *
     * @param room - The room to scroll back in
     * @param limit - The maximum number of events to pull in. Default: 30.
     * @returns Promise which resolves: Room. If you are at the beginning
     * of the timeline, `Room.oldState.paginationToken` will be
     * `null`.
     */
    scrollback(room: Room, limit?: number): Promise<Room>;
    /**
     * Processes a list of threaded events and adds them to their respective timelines
     * @param room - the room the adds the threaded events
     * @param threadedEvents - an array of the threaded events
     * @param toStartOfTimeline - the direction in which we want to add the events
     */
    processThreadEvents(room: Room, threadedEvents: MatrixEvent[], toStartOfTimeline: boolean): void;
    /**
     * Processes a list of thread roots and creates a thread model
     * @param room - the room to create the threads in
     * @param threadedEvents - an array of thread roots
     * @param toStartOfTimeline - the direction
     * @param supportsThreads - whether threads are supported
     */
    processThreadRoots(room: Room, threadedEvents: MatrixEvent[], toStartOfTimeline: boolean, supportsThreads: boolean): void;
    /**
     * Process beacon events
     * @param room - room the events belong to
     * @param events - timeline events to be processed
     */
    processBeaconEvents(room?: Room, events?: MatrixEvent[]): void;
    /**
     * Calls aggregation functions for event types that are aggregated
     * Polls and location beacons
     * @param room - room the events belong to
     * @param events - timeline events to be processed
     */
    processAggregatedTimelineEvents(room?: Room, events?: MatrixEvent[]): void;
    /**
     * Common logic for processing events received from pagination.
     * @internal
     */
    processPaginationEvents(eventTimeline: EventTimeline, matrixEvents: MatrixEvent[], backwards: boolean, token: string | null, room?: Room, options?: {
        partitionThreads?: boolean;
        processThreadRoots?: boolean;
    }, supportsThreads?: boolean): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map