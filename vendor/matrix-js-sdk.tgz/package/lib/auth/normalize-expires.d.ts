/**
 * ISSUE-05: synapse-rust 的 /login、/refresh、/register 响应携带
 * `expires_in`（秒，OAuth2 习惯），而 SDK 类型契约是 `expires_in_ms`
 * （毫秒）。此前类型注释声称"SDK自动转换"，但全库没有任何转换点——
 * 应用层按契约读 `expires_in_ms` 只能得到 undefined，若误读
 * `expires_in` 则单位错 1000 倍（token 过期后才发现）。
 *
 * 在响应边界做一次显式归一化：缺失 `expires_in_ms` 且存在数值型
 * `expires_in` 时，按秒→毫秒换算补齐。两个字段都在时以 `expires_in_ms`
 * 为准（防止后端未来双写时的不一致）。
 */
export declare function normalizeExpiresInMs<T extends {
    expires_in_ms?: number;
    expires_in?: number;
}>(response: T): T;
//# sourceMappingURL=normalize-expires.d.ts.map