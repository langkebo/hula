/**
 * Auth Manager - 认证管理
 *
 * 提供认证相关功能，包括：
 * - 登录流程管理
 * - 注册流程管理
 * - 登录流程缓存
 * - 统一错误处理
 * - 性能监控
 * - 客户端数据验证
 *
 * 后端实现: synapse-rust/src/web/routes/auth_compat.rs
 * 契约文档: docs/api-contract/auth-enhanced.md
 *
 * 数据约束:
 * - username 最大长度: 255 字符
 * - password 最大长度: 128 字符
 * - device_id 长度: 16 字符（服务器生成）
 */
import { MatrixClient } from "../client";
import { type ILoginFlowsResponse } from "../@types/auth";
import { type RegisterRequest, type RegisterResponse } from "../@types/registration";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IRequestTokenResponse, IRequestMsisdnTokenResponse } from "../client-api-types";
import type { IRefreshTokenResponse } from "../@types/auth";
export interface RegisterFlow {
    stages?: string[];
    type?: string;
}
export interface IAuthParams {
    type?: string;
    session?: string;
    [key: string]: unknown;
}
export interface CaptchaResponse {
    public_key: string;
    challenge?: string;
    html?: string;
}
export interface WhoamiResponse {
    user_id: string;
    device_id?: string;
    is_guest?: boolean;
}
export interface SamlRedirectResponse {
    location: string;
}
export interface VersionsResponse {
    versions: string[];
    unstable_features?: Record<string, boolean>;
}
export interface RegisterFlowsResponse {
    flows: RegisterFlow[];
    params: IAuthParams;
    session?: string;
}
export declare enum AuthEvent {
    LoginFlowUpdated = "LoginFlowUpdated",
    RegisterFlowUpdated = "RegisterFlowUpdated",
    Error = "Error"
}
interface AuthEventMap {
    [AuthEvent.LoginFlowUpdated]: (flows: ILoginFlowsResponse) => void;
    [AuthEvent.RegisterFlowUpdated]: (flows: RegisterFlowsResponse) => void;
    [AuthEvent.Error]: (error: Error) => void;
}
export declare class AuthManager extends BaseManager<AuthEvent, AuthEventMap> {
    private loginFlowCache;
    private registerFlowCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 验证用户名长度
     * @throws {ValidationError} 当用户名过长时
     */
    private validateUsername;
    /**
     * 验证密码长度
     * @throws {ValidationError} 当密码过长时
     */
    private validatePassword;
    /**
     * Check if authenticated
     */
    isAuthenticated(): boolean;
    /**
     * Get auth login type
     */
    getAuthLoginType(): string | undefined;
    /**
     * Set auth payload
     */
    setAuthPayload(payload: unknown): void;
    /**
     * Get fallback text
     */
    getFallbackRetryText(): string;
    /**
     * Set fallback text
     */
    setFallbackRetryText(text: string): void;
    /**
     * Get supported login flows
     *
     * @param forceRefresh - 是否强制刷新缓存（默认 false）
     * @returns 支持的登录流程列表
     *
     * @example
     * ```typescript
     * // 获取支持的登录流程
     * const flows = await authManager.getSupportedLoginFlows();
     * console.log("Supported flows:", flows.flows);
     *
     * // 检查是否支持密码登录
     * const hasPassword = flows.flows?.some(f => f.type === "m.login.password");
     * if (hasPassword) {
     *     console.log("Password login is supported");
     * }
     *
     * // 强制刷新缓存
     * const freshFlows = await authManager.getSupportedLoginFlows(true);
     * ```
     *
     * @throws {ApiError} 如果 API 调用失败
     *
     * 后端实现: synapse-rust/src/web/routes/auth_compat.rs:252-259
     */
    getSupportedLoginFlows(forceRefresh?: boolean): Promise<ILoginFlowsResponse>;
    /**
     * Get supported registration flows
     *
     * 后端实现: synapse-rust/src/web/routes/auth_compat.rs:261-269
     */
    getRegisterFlows(forceRefresh?: boolean): Promise<RegisterFlowsResponse>;
    /**
     * Check if a specific login flow is supported
     *
     * @param flowType - 登录流程类型（如 "m.login.password", "m.login.sso"）
     * @returns 是否支持该登录流程
     *
     * @example
     * ```typescript
     * // 检查是否支持密码登录
     * const hasPassword = await authManager.hasLoginFlow("m.login.password");
     * if (hasPassword) {
     *     console.log("Password login is available");
     * }
     *
     * // 检查是否支持 SSO
     * const hasSSO = await authManager.hasLoginFlow("m.login.sso");
     * ```
     *
     * @throws {ApiError} 如果获取登录流程失败
     */
    hasLoginFlow(flowType: string): Promise<boolean>;
    /**
     * 检查是否支持密码登录
     *
     * @returns 是否支持密码登录
     *
     * @example
     * ```typescript
     * if (await authManager.hasPasswordLogin()) {
     *     // 显示密码登录表单
     *     showPasswordLoginForm();
     * }
     * ```
     */
    hasPasswordLogin(): Promise<boolean>;
    /**
     * 检查是否支持 SSO 登录
     *
     * @returns 是否支持 SSO 或 CAS 登录
     *
     * @example
     * ```typescript
     * if (await authManager.hasSSOLogin()) {
     *     // 显示 SSO 登录按钮
     *     showSSOLoginButton();
     * }
     * ```
     */
    hasSSOLogin(): Promise<boolean>;
    /**
     * Register a user
     *
     * @param username - The desired username (max 255 characters)
     * @param password - The desired password (max 128 characters, min 8 characters)
     * @param sessionId - The session ID from a previous registration attempt
     * @param auth - The auth dictionary
     * @param _bindThreepids - Map of third party IDs to bind
     * @param guestAccessToken - The guest access token to upgrade
     * @param inhibitLogin - Whether to inhibit login
     * @returns Promise which resolves to a RegisterResponse object
     *
     * @example
     * ```typescript
     * // 基本注册
     * const response = await authManager.register(
     *     "alice",
     *     "securePassword123",
     *     null,
     *     { type: "m.login.dummy" }
     * );
     * console.log("Registered:", response.user_id);
     *
     * // 注册前验证输入
     * const usernameCheck = AuthManager.validateUsernameFormat("alice");
     * if (!usernameCheck.valid) {
     *     console.error(usernameCheck.error);
     *     return;
     * }
     *
     * const passwordCheck = AuthManager.validatePasswordFormat("securePassword123");
     * if (!passwordCheck.valid) {
     *     console.error(passwordCheck.error);
     *     return;
     * }
     *
     * // 继续注册流程（带 session）
     * const response = await authManager.register(
     *     "alice",
     *     "securePassword123",
     *     "session_abc123",
     *     { type: "m.login.email.identity", session: "session_abc123" }
     * );
     * ```
     *
     * @throws {ValidationError} 当用户名或密码超过长度限制时
     * @throws {ApiError} 当注册失败时
     *   - M_USER_IN_USE (409): 用户名已被占用
     *   - M_INVALID_USERNAME (400): 用户名不符合规范
     *   - M_WEAK_PASSWORD (400): 密码不满足策略
     *
     * **安全提示**:
     * - 密码最少 8 个字符
     * - 建议使用强密码（包含大小写字母、数字、特殊字符）
     * - 不要在客户端存储明文密码
     * - 使用 HTTPS 传输
     *
     * 后端实现: synapse-rust/src/web/routes/auth_compat.rs:11-65
     */
    register(username: string, password: string, sessionId: string | null, auth: {
        session?: string;
        type: string;
    }, _bindThreepids?: {
        email?: boolean;
        msisdn?: boolean;
    }, guestAccessToken?: string, inhibitLogin?: boolean): Promise<RegisterResponse>;
    /**
     * Register a guest account
     *
     * @param body - JSON HTTP body to provide
     * @returns Promise which resolves to RegisterResponse
     */
    registerGuest(body?: RegisterRequest): Promise<RegisterResponse>;
    /**
     * Clear cache
     */
    clearCache(): void;
    /**
     * Get cache statistics
     */
    getCacheStats(): {
        loginFlows: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        registerFlows: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
    /**
     * 获取数据约束常量
     */
    static getConstraints(): {
        USERNAME_MAX_LENGTH: number;
        PASSWORD_MAX_LENGTH: number;
        DEVICE_ID_LENGTH: number;
    };
    /**
     * 验证用户名格式（客户端验证）
     * @param username - 用户名
     * @returns 验证结果和错误消息
     */
    static validateUsernameFormat(username: string): {
        valid: boolean;
        error?: string;
    };
    /**
     * 验证密码格式（客户端验证）
     * @param password - 密码
     * @returns 验证结果和错误消息
     */
    static validatePasswordFormat(password: string): {
        valid: boolean;
        error?: string;
    };
    /**
     * Get captcha challenge for registration
     * GET /_matrix/client/v3/register/captcha
     */
    getCaptcha(): Promise<CaptchaResponse>;
    /**
     * Get current user info
     * GET /_matrix/client/v3/account/whoami
     */
    whoami(): Promise<WhoamiResponse>;
    /**
     * Logout current session
     * POST /_matrix/client/v3/logout
     */
    logout(): Promise<void>;
    /**
     * Get SAML redirect URL
     * GET /_matrix/client/v3/login/sso/redirect/{idp_id}
     */
    getSamlRedirect(idpId: string): Promise<SamlRedirectResponse>;
    /**
     * Get server versions
     * GET /_matrix/client/versions
     */
    getVersions(): Promise<VersionsResponse>;
    /**
     * Requests an email verification token for the purposes of registration.
     */
    requestRegisterEmailToken(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestTokenResponse>;
    /**
     * Requests a text message verification token for the purposes of registration.
     */
    requestRegisterMsisdnToken(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestMsisdnTokenResponse>;
    /**
     * Requests an email verification token for the purposes of adding a
     * third party identifier to an account.
     */
    requestAdd3pidEmailToken(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestTokenResponse>;
    /**
     * Requests a text message verification token for the purposes of adding a
     * third party identifier to an account.
     */
    requestAdd3pidMsisdnToken(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestMsisdnTokenResponse>;
    /**
     * Check whether a username is available prior to registration.
     * @param username - The username to check the availability of.
     * @returns Promise which resolves to boolean of whether the username is available.
     */
    isUsernameAvailable(username: string): Promise<boolean>;
    /**
     * Make a registration request.
     * @param data - parameters for registration request
     * @param kind - type of user to register. may be "guest"
     * @returns Promise which resolves to the /register response
     */
    registerRequest(data: RegisterRequest, kind?: string): Promise<RegisterResponse>;
    /**
     * Refreshes an access token using a provided refresh token.
     * @param refreshToken - The refresh token.
     * @returns Promise which resolves to the new token.
     */
    refreshToken(refreshToken: string): Promise<IRefreshTokenResponse>;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map