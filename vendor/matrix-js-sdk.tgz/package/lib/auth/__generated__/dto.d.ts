/**
 * DTO snippets extracted from the contract doc for `assembly`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface LoginWellKnown {
    /** Homeserver base URL */
    "m.homeserver"?: {
        base_url: string;
    };
    /** Identity server base URL */
    "m.identity_server"?: {
        base_url: string;
    };
}
export interface LoginResponse {
    user_id: string;
    access_token: string;
    home_server?: string;
    device_id: string;
    refresh_token?: string;
    expires_in_ms?: number;
    well_known?: LoginWellKnown;
}
export interface RegisterResponse {
    user_id: string;
    access_token?: string;
    device_id?: string;
    home_server?: string;
    refresh_token?: string;
    expires_in_ms?: number;
}
export interface WhoamiResponse {
    user_id: string;
    device_id?: string;
    is_guest?: boolean;
}
export interface VersionsResponse {
    versions: string[];
    unstable_features?: Record<string, boolean>;
}
export interface CapabilityInfo {
    enabled?: boolean;
    [key: string]: unknown;
}
export interface CapabilitiesResponse {
    capabilities: Record<string, CapabilityInfo>;
}
export interface ProfileResponse {
    displayname?: string;
    avatar_url?: string;
}
export interface UserDirectorySearchResult {
    user_id: string;
    display_name?: string;
    avatar_url?: string;
}
export interface UserDirectorySearchResponse {
    results: UserDirectorySearchResult[];
    limited: boolean;
}
export interface PublicRoomsChunk {
    room_id: string;
    name?: string;
    topic?: string;
    canonical_alias?: string;
    num_joined_members: number;
    avatar_url?: string;
    world_readable: boolean;
    guest_can_join: boolean;
}
export interface PublicRoomsResponse {
    chunk: PublicRoomsChunk[];
    next_batch?: string;
    total_room_count_estimate?: number;
}
//# sourceMappingURL=dto.d.ts.map