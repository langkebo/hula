/**
 * DTO snippets extracted from the contract doc for `auth`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type AuthJsonValue = string | number | boolean | null | AuthJsonValue[] | {
    [key: string]: AuthJsonValue;
};
export interface LoginFlowItem {
    type: string;
    get_login_token?: boolean;
    identity_providers?: AuthJsonValue[];
}
export interface LoginFlowsResponse {
    flows: LoginFlowItem[];
}
export interface UserIdentifier {
    type: string;
    user?: string;
    medium?: string;
    address?: string;
    country?: string;
    phone?: string;
}
export interface LoginRequest {
    type?: string;
    identifier?: UserIdentifier;
    password?: string;
    token?: string;
    device_id?: string;
    initial_device_display_name?: string;
    refresh_token?: boolean;
}
export interface WellKnownHomeserver {
    "m.homeserver": {
        base_url: string;
    };
}
export interface TokenResponse {
    access_token: string;
    refresh_token: string;
    expires_in: number;
    device_id: string;
    user_id: string;
    well_known: WellKnownHomeserver;
}
export interface LoginTokenResponse {
    login_token: string;
    expires_in_ms: number;
}
export interface RegisterRequest {
    username?: string;
    password?: string;
    device_id?: string;
    initial_device_display_name?: string;
    inhibit_login?: boolean;
    refresh_token?: boolean;
    auth?: AuthJsonValue;
}
export interface RegisterAvailableResponse {
    available: boolean;
}
export interface WhoamiResponse {
    user_id: string;
    device_id?: string | null;
    is_guest: boolean;
}
export interface EnabledCapability {
    enabled: boolean;
}
export interface RoomVersionsCapability {
    default: string;
    available: {
        [version: string]: string;
    };
}
export interface PrivacyCapability {
    server_holds_room_keys: boolean;
}
export interface CapabilitiesBody {
    "m.change_password"?: EnabledCapability;
    "m.room_versions": RoomVersionsCapability;
    "m.set_displayname"?: EnabledCapability;
    "m.set_avatar_url"?: EnabledCapability;
    "m.3pid_changes"?: EnabledCapability;
    "m.room.summary"?: EnabledCapability;
    "m.room.suggested"?: EnabledCapability;
    "m.voice"?: EnabledCapability;
    "m.thread"?: EnabledCapability;
    "m.profile_fields"?: EnabledCapability;
    "m.hula.privacy"?: PrivacyCapability;
}
export interface CapabilitiesResponse {
    capabilities: CapabilitiesBody;
    unstable_features: {
        [feature: string]: boolean;
    };
}
export interface VersionsResponse {
    versions: string[];
    unstable_features: {
        [feature: string]: boolean;
    };
}
export interface ChangePasswordRequest {
    new_password: string;
    logout_devices?: boolean;
    auth?: AuthJsonValue;
}
export type AuthEmptyResponse = {
    [key: string]: never;
};
export interface EmailTokenRequest {
    client_secret: string;
    email: string;
    send_attempt?: number;
    next_link?: string;
}
export interface EmailTokenResponse {
    sid: string;
    submit_url: string;
    expires_in: number;
}
export interface SubmitEmailTokenRequest {
    sid: string;
    client_secret: string;
    token: string;
}
export interface SubmitEmailTokenResponse {
    success: boolean;
}
//# sourceMappingURL=dto.d.ts.map