/**
 * DTO snippets extracted from the contract doc for `auth`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type AuthContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map