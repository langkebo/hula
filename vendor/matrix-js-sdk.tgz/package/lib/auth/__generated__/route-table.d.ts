/** Routes served by the synapse-rust `auth` module (mirrored from the backend contract). */
export declare const AUTH_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/";
}, {
    readonly method: "GET";
    readonly path: "/.well-known/matrix/client";
}, {
    readonly method: "GET";
    readonly path: "/.well-known/matrix/server";
}, {
    readonly method: "GET";
    readonly path: "/.well-known/matrix/support";
}, {
    readonly method: "GET";
    readonly path: "/_health";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/org.matrix.msc2965/auth_metadata";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/unstable/org.matrix.msc3814.v1/dehydrated_device";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/org.matrix.msc3814.v1/dehydrated_device";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/unstable/org.matrix.msc3814.v1/dehydrated_device";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/unstable/org.matrix.msc3814.v1/dehydrated_device/{device_id}/events";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/org.matrix.msc4143/rtc/transports";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/uk.tcpip.msc4133/profile/{user_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/unstable/uk.tcpip.msc4133/profile/{user_id}/{key_name}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/uk.tcpip.msc4133/profile/{user_id}/{key_name}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/unstable/uk.tcpip.msc4133/profile/{user_id}/{key_name}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/account/3pid";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid/add";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid/bind";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid/delete";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid/email/requestToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid/email/submitToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/3pid/unbind";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/deactivate";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/password";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/password/email/requestToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/account/password/email/submitToken";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/account/whoami";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/config/client";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/login/get_qr_code";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/login/qr/confirm";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/login/qr/invalidate";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/login/qr/start";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/login/qr/{transaction_id}/status";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/media/config";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/profile/{user_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/profile/{user_id}/avatar_url";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/profile/{user_id}/avatar_url";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/profile/{user_id}/displayname";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/profile/{user_id}/displayname";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/account/3pid";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid/add";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid/bind";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid/delete";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid/email/requestToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid/email/submitToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/3pid/unbind";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/deactivate";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/password";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/password/email/requestToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/account/password/email/submitToken";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/account/whoami";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/capabilities";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/directory/list/room/{room_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/directory/list/room/{room_id}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/directory/room/{room_alias}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/directory/room/{room_alias}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/directory/room/{room_alias}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/login";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/login";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/logout";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/logout/all";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/media/config";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/profile/{user_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/profile/{user_id}/avatar_url";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/profile/{user_id}/avatar_url";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/profile/{user_id}/displayname";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/profile/{user_id}/displayname";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/publicRooms";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/publicRooms";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules/";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules/global/";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/refresh";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/register";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/register";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/register/available";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/register/email/requestToken";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/register/email/submitToken";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/call/{call_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/send/m.call.answer/{txn_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/send/m.call.candidates/{txn_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/send/m.call.hangup/{txn_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/send/m.call.invite/{txn_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/user_directory/list";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user_directory/profiles/{user_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/user_directory/search";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/versions";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/voip/config";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/voip/turnServer";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/voip/turnServer";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/voip/turnServer/guest";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/versions";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/server_version";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/static/client/login/";
}, {
    readonly method: "GET";
    readonly path: "/health";
}];
/** Union of every (method, path) tuple in `AUTH_ROUTES`. */
export type AuthRoute = (typeof AUTH_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type AuthMethod = AuthRoute["method"];
/** Path templates referenced by this module. */
export type AuthPath = AuthRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type AuthReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${AuthReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type AuthPathPattern = AuthReplaceBraces<AuthPath>;
//# sourceMappingURL=route-table.d.ts.map