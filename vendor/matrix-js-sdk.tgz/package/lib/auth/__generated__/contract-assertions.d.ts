export declare const AUTH_ROUTES_ENTRY_COUNT: 152;
export declare const AUTH_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "参数错误或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "未授权，Token 无效或过期";
}, {
    readonly status: 403;
    readonly note: "禁止访问，权限不足";
}, {
    readonly status: 409;
    readonly note: "冲突，如用户名已被占用";
}, {
    readonly status: 429;
    readonly note: "触发限流";
}];
export type AuthStatusScenario = (typeof AUTH_ROUTES_STATUS_SCENARIOS)[number];
export declare const AUTH_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录或刷新凭据";
}, {
    readonly scenario: "资源冲突";
    readonly httpOrErrcode: "409 / M_USER_IN_USE";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户更换输入（如用户名）";
}, {
    readonly scenario: "参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正请求参数后重试";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底";
}];
export type AuthErrorScenario = (typeof AUTH_ROUTES_ERROR_SCENARIOS)[number];
export declare const AUTH_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_USER_IN_USE";
    readonly httpStatus: "409";
    readonly note: "用户名已被占用";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "请求体结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "参数类型或取值非法";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "触发限流，需延迟重试";
}];
export type AuthErrcode = (typeof AUTH_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map