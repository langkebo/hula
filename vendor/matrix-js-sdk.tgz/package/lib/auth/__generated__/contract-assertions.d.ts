export declare const AUTH_ROUTES_ENTRY_COUNT: 158;
export declare const AUTH_ROUTES_STATUS_SCENARIOS: readonly [];
export type AuthStatusScenario = (typeof AUTH_ROUTES_STATUS_SCENARIOS)[number];
export declare const AUTH_ROUTES_ERROR_SCENARIOS: readonly [];
export type AuthErrorScenario = (typeof AUTH_ROUTES_ERROR_SCENARIOS)[number];
export declare const AUTH_ROUTES_ERRCODES: readonly [];
export type AuthErrcode = (typeof AUTH_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map