/**
 * DTO snippets extracted from the contract doc for `ai-connection`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface AIConnection {
    id: string;
    user_id: string;
    provider: string;
    config: Record<string, unknown> | null;
    is_active: boolean;
    created_ts: number;
    updated_ts: number | null;
}
export interface CreateConnectionOptions {
    provider: string;
    config?: Record<string, unknown>;
}
export interface McpToolCallRequest {
    provider: string;
    tool_name: string;
    arguments: Record<string, unknown>;
}
//# sourceMappingURL=dto.d.ts.map