export declare const AI_CONNECTION_ROUTES_ENTRY_COUNT: 12;
export declare const AI_CONNECTION_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 202;
    readonly note: "修正文档中错误的路径前缀、字段命名与 MCP 请求/响应口径，并补充 SDK 生成路由绑定说明 | 修复长期文档漂移";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}];
export type AiConnectionStatusScenario = (typeof AI_CONNECTION_ROUTES_STATUS_SCENARIOS)[number];
export declare const AI_CONNECTION_ROUTES_ERROR_SCENARIOS: readonly [];
export type AiConnectionErrorScenario = (typeof AI_CONNECTION_ROUTES_ERROR_SCENARIOS)[number];
export declare const AI_CONNECTION_ROUTES_ERRCODES: readonly [];
export type AiConnectionErrcode = (typeof AI_CONNECTION_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map