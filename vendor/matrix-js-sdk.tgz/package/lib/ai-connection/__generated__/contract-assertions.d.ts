export declare const AI_CONNECTION_ROUTES_ENTRY_COUNT: 6;
export declare const AI_CONNECTION_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "查询、创建、删除或 MCP 调用成功";
}, {
    readonly status: 400;
    readonly note: "provider、connection_id、工具参数或请求体非法";
}, {
    readonly status: 401;
    readonly note: "用户 access token 无效或缺失";
}, {
    readonly status: 404;
    readonly note: "指定连接不存在，或 provider / tool_name 不可用";
}, {
    readonly status: 429;
    readonly note: "上游 AI / MCP 服务限流或暂时不可用";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "按 synapse-rust 路由与 SDK 实现修正路径、请求响应示例与覆盖率 | 覆盖率从 0% 修正为 100%，明确无 Matrix 前缀";
}];
export type AiConnectionStatusScenario = (typeof AI_CONNECTION_ROUTES_STATUS_SCENARIOS)[number];
export declare const AI_CONNECTION_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "用户未登录或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "重新登录后再访问 AI Connection 接口";
}, {
    readonly scenario: "provider、tool_name 或请求体非法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 provider、connectionId 或 MCP arguments 后重试";
}, {
    readonly scenario: "目标连接或工具不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新连接列表或工具列表后重试";
}, {
    readonly scenario: "上游 AI / MCP 服务限流";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "按退避策略重试，并避免高频调用";
}];
export type AiConnectionErrorScenario = (typeof AI_CONNECTION_ROUTES_ERROR_SCENARIOS)[number];
export declare const AI_CONNECTION_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "用户 access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "创建连接或调用工具时请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "provider、connection_id、tool_name 或工具参数非法";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "指定连接不存在，或 provider / tool_name 未注册";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "上游 AI / MCP 服务限流或暂时不可用";
}];
export type AiConnectionErrcode = (typeof AI_CONNECTION_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map