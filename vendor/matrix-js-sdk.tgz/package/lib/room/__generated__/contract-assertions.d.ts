export declare const ROOM_ROUTES_ENTRY_COUNT: 137;
export declare const ROOM_ROUTES_STATUS_SCENARIOS: readonly [];
export type RoomStatusScenario = (typeof ROOM_ROUTES_STATUS_SCENARIOS)[number];
export declare const ROOM_ROUTES_ERROR_SCENARIOS: readonly [];
export type RoomErrorScenario = (typeof ROOM_ROUTES_ERROR_SCENARIOS)[number];
export declare const ROOM_ROUTES_ERRCODES: readonly [];
export type RoomErrcode = (typeof ROOM_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map