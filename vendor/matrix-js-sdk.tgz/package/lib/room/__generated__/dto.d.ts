/**
 * DTO snippets extracted from the contract doc for `room`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type RoomContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map