/**
 * DTO snippets extracted from the contract doc for `room`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
import type { IContent } from "../../models/event.ts";
export interface RoomEvent {
    content: IContent;
    type: string;
    event_id: string;
    sender: string;
    origin_server_ts: number;
    room_id?: string;
    unsigned?: Record<string, unknown>;
}
export interface RoomStateEvent extends RoomEvent {
    state_key: string;
    prev_content?: IContent;
}
export interface RoomVersionResponse {
    room_version: string;
}
export interface RoomCapabilitiesResponse {
    capabilities: Record<string, unknown>;
}
export type RoomMembershipValue = "join" | "invite" | "leave" | "ban" | "knock";
export interface RoomMembershipResponse {
    /**
     * `GET /rooms/{roomId}/membership/{userId}` 的响应**只有这一个键，它不是状态事件**。
     * 后端在「查无成员记录」时回 `leave`（200），只有房间不存在或无权查看才是 404。
     * SDK 历史上用 `IStateEvent` 接它 ⇒ `content.membership` 恒 `undefined`，
     * 而单测 mock 照着错类型写 `{event_id, state_key}`、只断言 `toBeDefined()` ⇒ 永远绿（审计 B5-1）。
     */
    membership: RoomMembershipValue;
}
export interface RoomMetadataResponse {
    /**
     * `GET /rooms/{roomId}/metadata` 的响应（14 个键）。两套「有没有值」的语义要分清：
     *
     * - 后端对 `name` / `topic` / `avatar_url` / `canonical_alias` / `creator` / `encryption`
     *   做了 **null 键删除** ⇒ 它们是**可选**的（字段可能不存在）；
     * - 其余键**恒存在但值可能是 `null`**（DB 里是 `Option<T>`，且没被删）⇒ 类型上必须是
     *   `T | null`，写成可选会让人以为"没有这个字段"。
     *
     * 历史声明里的 `guest_access` 后端从不返回，已删除（审计 B5-4）。
     */
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    canonical_alias?: string;
    join_rule?: string | null;
    history_visibility?: string | null;
    creator?: string;
    room_version?: string | null;
    /** 房间加密算法（如 `m.megolm.v1.aes-sha2`）；未加密时该键被删除 */
    encryption?: string;
    is_public?: boolean | null;
    member_count?: number | null;
    created_ts: number;
}
export interface CreateRoomRequest {
    visibility?: "public" | "private";
    room_alias_name?: string;
    name?: string;
    topic?: string;
    room_version?: string;
    power_level_content_override?: IContent;
    preset?: "private_chat" | "trusted_private_chat" | "public_chat";
    initial_state?: Array<{
        type: string;
        state_key?: string;
        content: IContent;
    }>;
    invite?: string[];
    invite_3pid?: Array<{
        id_server: string;
        id_access_token: string;
        medium: string;
        address: string;
    }>;
    creation_content?: IContent;
    is_direct?: boolean;
    predecessor?: {
        room_id: string;
        event_id: string;
    };
    space?: string;
}
export interface CreateRoomResponse {
    room_id: string;
}
export interface JoinRoomRequest {
    third_party_signed?: {
        sender: string;
        mixid: string;
        signed: {
            mxid: string;
            signatures: Record<string, Record<string, string>>;
            token: string;
        };
    };
}
export interface JoinRoomResponse {
    room_id: string;
}
export interface KnockRoomRequest {
    reason?: string;
}
export interface KnockRoomResponse {
    room_id: string;
}
export interface RoomMember {
    display_name?: string;
    avatar_url?: string;
}
export interface GetMembersResponse {
    chunk: RoomStateEvent[];
}
export interface JoinedMembersResponse {
    joined: Record<string, RoomMember>;
}
export interface GetMessagesResponse {
    chunk: RoomEvent[];
    start: string;
    end?: string;
    state?: RoomStateEvent[];
}
export interface SendEventResponse {
    event_id: string;
    room_id?: string;
}
export interface EventContextResponse {
    event: RoomEvent;
    events_before: RoomEvent[];
    events_after: RoomEvent[];
    start: string;
    end: string;
    state: RoomStateEvent[];
}
export interface InviteRequest {
    user_id: string;
    reason?: string;
}
export interface KickRequest {
    user_id: string;
    reason?: string;
}
export interface BanRequest {
    user_id: string;
    reason?: string;
}
export interface UnbanRequest {
    user_id: string;
}
export interface RedactEventRequest {
    reason?: string;
}
export interface UpgradeRoomRequest {
    new_version: string;
    additional_creators?: string[];
}
export interface UpgradeRoomResponse {
    replacement_room: string;
}
export interface ReportRoomRequest {
    reason: string;
}
export interface RoomDirectoryVisibilityResponse {
    visibility: "public" | "private";
}
export interface SetRoomDirectoryVisibilityRequest {
    visibility: "public" | "private";
}
export interface RoomIdForAliasResponse {
    room_id: string;
    servers: string[];
}
export interface CreateAliasRequest {
    room_id: string;
}
export interface LocalAliasesResponse {
    aliases: string[];
}
export interface RoomHierarchyRoom {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    join_rule?: string;
    room_type?: string;
    num_joined_members?: number;
    children_state?: RoomStateEvent[];
}
export interface RoomHierarchyResponse {
    rooms: RoomHierarchyRoom[];
    next_batch?: string;
}
export interface TagMetadata {
    order?: number;
}
export interface TagsResponse {
    tags: Record<string, TagMetadata>;
}
export interface GuestAccessRequest {
    guest_access: "can_join" | "forbidden";
}
//# sourceMappingURL=dto.d.ts.map