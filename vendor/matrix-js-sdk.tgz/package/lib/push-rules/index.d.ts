/**
 * Push Rules Manager - 推送规则管理
 *
 * 提供推送规则相关功能
 */
import { MatrixClient } from "../client";
import { IPushRules } from "../@types/PushRules";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IPushRule {
    rule_id: string;
    default?: boolean;
    enabled?: boolean;
    pattern?: string;
    conditions?: Array<{
        kind: string;
        key?: string;
        pattern?: string;
        is?: string;
    }>;
    actions?: Array<string | Record<string, unknown>>;
}
export interface ISetPushRuleBody {
    pattern?: string;
    conditions?: Array<{
        kind: string;
        key?: string;
        pattern?: string;
        is?: string;
    }>;
    actions?: Array<string | Record<string, unknown>>;
}
export interface PushRulesManagerEvents {
    push_rules_updated: {
        rules: IPushRules;
    };
    push_rule_added: {
        kind: string;
        ruleId: string;
    };
    push_rule_deleted: {
        kind: string;
        ruleId: string;
    };
}
export declare class PushRulesManager extends BaseManager<keyof PushRulesManagerEvents, PushRulesManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getPushRules(): Promise<IPushRules>;
    getPushRule(kind: string, ruleId: string): Promise<IPushRule | null>;
    setPushRule(kind: string, ruleId: string, body: ISetPushRuleBody): Promise<void>;
    deletePushRule(kind: string, ruleId: string): Promise<void>;
    enablePushRule(kind: string, ruleId: string, enabled: boolean): Promise<void>;
    getPushRulesCached(): IPushRules | null;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map