export interface AITool {
    name: string;
    description: string;
    inputSchema: Record<string, unknown>;
}
export interface AINewsItem {
    title: string;
    url: string;
    platform: string;
    publishTime?: string;
    summary?: string;
}
export interface AINewsResult {
    news: AINewsItem[];
    total: number;
}
export interface McpRpcRequest {
    jsonrpc: "2.0";
    method: string;
    params?: {
        name?: string;
        arguments?: Record<string, unknown>;
    };
    id: number | string;
}
export interface McpRpcResponse {
    jsonrpc: "2.0";
    result?: unknown;
    error?: {
        code: number;
        message: string;
    };
    id: number | string;
}
export declare class AIModule {
    private mcpEndpoint;
    private requestId;
    private _isConnected;
    constructor();
    get isConnected(): boolean;
    setEndpoint(endpoint: string): void;
    getEndpoint(): string;
    private callMcp;
    listTools(): Promise<AITool[]>;
    callTool(toolName: string, args?: Record<string, unknown>): Promise<unknown>;
    getLatestNews(platforms?: string[], limit?: number): Promise<AINewsResult>;
    searchNews(keyword: string, limit?: number): Promise<AINewsResult>;
    getTrendingTopics(limit?: number): Promise<unknown[]>;
    getLatestRss(feeds?: string[], limit?: number): Promise<unknown[]>;
    analyzeTopicTrend(topic: string): Promise<unknown>;
    healthCheck(): Promise<boolean>;
}
export declare function getAIModule(): AIModule;
export declare function createAIModule(endpoint?: string): AIModule;
//# sourceMappingURL=index.d.ts.map