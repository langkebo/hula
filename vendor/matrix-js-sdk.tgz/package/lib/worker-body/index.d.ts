import { MatrixClient } from "../client";
import { type IEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface WorkerCommandResponse {
    command_id: string;
    target_worker_id: string;
    command_type: string;
    status: string;
    created_ts: number;
}
export interface WorkerLoadStats {
    cpu_usage?: number;
    memory_usage?: number;
    active_connections?: number;
    request_rate?: number;
    [key: string]: unknown;
}
export interface HeartbeatRequest {
    status: string;
    load_stats?: WorkerLoadStats;
}
export interface HeartbeatResponse {
    status: string;
    [key: string]: unknown;
}
export interface ConnectWorkerResponse {
    status: string;
    [key: string]: unknown;
}
export interface ReplicationPosition {
    worker_id: string;
    stream_name: string;
    position: number | null;
}
export interface WorkerEventsResponse {
    events: IEvent[];
    next_stream_id?: number;
    [key: string]: unknown;
}
export declare class WorkerBodyManager extends BaseManager<string, Record<string, never>> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    private doRequest;
    /** POST /_synapse/worker/v1/workers/{worker_id}/heartbeat */
    heartbeat(workerId: string, req: HeartbeatRequest): Promise<HeartbeatResponse>;
    /** POST /_synapse/worker/v1/workers/{worker_id}/connect */
    connectWorker(workerId: string, address: string): Promise<ConnectWorkerResponse>;
    /** POST /_synapse/worker/v1/workers/{worker_id}/disconnect */
    disconnectWorker(workerId: string): Promise<void>;
    /** GET /_synapse/worker/v1/workers/{worker_id}/commands */
    listPendingCommands(workerId: string, limit?: number): Promise<{
        commands: WorkerCommandResponse[];
    }>;
    /** POST /_synapse/worker/v1/commands/{command_id}/complete */
    completeCommand(commandId: string): Promise<void>;
    /** POST /_synapse/worker/v1/commands/{command_id}/fail */
    failCommand(commandId: string, error: string): Promise<void>;
    /** POST /_synapse/worker/v1/tasks/{task_id}/complete */
    completeTask(taskId: string, result?: unknown): Promise<void>;
    /** POST /_synapse/worker/v1/tasks/{task_id}/fail */
    failTask(taskId: string, error: string): Promise<void>;
    /** GET /_synapse/worker/v1/replication/{worker_id}/position */
    getReplicationPosition(workerId: string, streamName: string): Promise<ReplicationPosition>;
    /** PUT /_synapse/worker/v1/replication/{worker_id}/{stream_name} */
    updateReplicationPosition(workerId: string, streamName: string, position: number): Promise<ReplicationPosition>;
    /** GET /_synapse/worker/v1/events */
    getEvents(streamId?: number): Promise<WorkerEventsResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map