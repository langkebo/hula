/** Routes served by the synapse-rust `worker-body` module (mirrored from the backend contract). */
export declare const WORKER_BODY_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/commands/{command_id}/complete";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/commands/{command_id}/fail";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/events";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/replication/{worker_id}/position";
}, {
    readonly method: "PUT";
    readonly path: "/_synapse/worker/v1/replication/{worker_id}/{stream_name}";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/tasks/{task_id}/complete";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/tasks/{task_id}/fail";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}/commands";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}/connect";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}/disconnect";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/worker/v1/workers/{worker_id}/heartbeat";
}];
/** Union of every (method, path) tuple in `WORKER_BODY_ROUTES`. */
export type WorkerBodyRoute = (typeof WORKER_BODY_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type WorkerBodyMethod = WorkerBodyRoute["method"];
/** Path templates referenced by this module. */
export type WorkerBodyPath = WorkerBodyRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type WorkerBodyReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${WorkerBodyReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type WorkerBodyPathPattern = WorkerBodyReplaceBraces<WorkerBodyPath>;
//# sourceMappingURL=route-table.d.ts.map