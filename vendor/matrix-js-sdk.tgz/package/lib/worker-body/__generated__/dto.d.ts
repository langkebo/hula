/**
 * DTO snippets extracted from the contract doc for `worker_body`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type WorkerBodyContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map