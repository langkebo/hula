export declare const WORKER_BODY_ROUTES_ENTRY_COUNT: 11;
export declare const WORKER_BODY_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "命令完成或失败上报成功";
}, {
    readonly status: 400;
    readonly note: "command_id、请求体或完成结果非法";
}, {
    readonly status: 401;
    readonly note: "replication HTTP 凭据无效或缺失";
}, {
    readonly status: 403;
    readonly note: "当前 worker 凭据无权上报该命令";
}, {
    readonly status: 404;
    readonly note: "目标命令不存在";
}];
export type WorkerBodyStatusScenario = (typeof WORKER_BODY_ROUTES_STATUS_SCENARIOS)[number];
export declare const WORKER_BODY_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "replication 凭据无效或缺失";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "使用正确的 replication HTTP 鉴权重试上报";
}, {
    readonly scenario: "command 上报参数或 body 非法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 command_id、结果体或错误体后重试";
}, {
    readonly scenario: "当前 worker 无权操作该命令";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "检查 worker 身份与 replication 权限配置";
}, {
    readonly scenario: "目标命令不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新命令列表并核对 command_id 后重试";
}];
export type WorkerBodyErrorScenario = (typeof WORKER_BODY_ROUTES_ERROR_SCENARIOS)[number];
export declare const WORKER_BODY_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "replication HTTP 凭据无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "complete / fail 请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "command_id、结果体或错误信息参数非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "当前 worker 无权操作该命令";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "目标命令不存在";
}];
export type WorkerBodyErrcode = (typeof WORKER_BODY_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map