export declare const WORKER_BODY_ROUTES_ENTRY_COUNT: 11;
export declare const WORKER_BODY_ROUTES_STATUS_SCENARIOS: readonly [];
export type WorkerBodyStatusScenario = (typeof WORKER_BODY_ROUTES_STATUS_SCENARIOS)[number];
export declare const WORKER_BODY_ROUTES_ERROR_SCENARIOS: readonly [];
export type WorkerBodyErrorScenario = (typeof WORKER_BODY_ROUTES_ERROR_SCENARIOS)[number];
export declare const WORKER_BODY_ROUTES_ERRCODES: readonly [];
export type WorkerBodyErrcode = (typeof WORKER_BODY_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map