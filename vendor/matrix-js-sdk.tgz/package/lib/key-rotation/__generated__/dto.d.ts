/**
 * DTO snippets extracted from the contract doc for `key_rotation`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface KeyRotationStatus {
    current_key_id: string;
    rotation_period_ms: number;
    last_rotation_ts: number;
    next_rotation_ts: number;
    auto_rotation_enabled: boolean;
}
export interface KeyRotationHistory {
    rotations: Array<{
        key_id: string;
        rotated_at: number;
        reason: string;
        previous_key_id?: string;
    }>;
    next_batch?: string;
}
export interface KeyCheckResponse {
    valid: boolean;
    revoked: boolean;
    expires_at?: number;
}
export interface KeyRotationRequestDto {
    reason: string;
}
export interface KeyRotationResponseDto {
    new_key_id: string;
    rotated_at: number;
}
//# sourceMappingURL=dto.d.ts.map