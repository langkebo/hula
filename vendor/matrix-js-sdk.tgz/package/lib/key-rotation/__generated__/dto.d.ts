/**
 * DTO snippets extracted from the contract doc for `key_rotation`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface KeyRotationStatus {
    /** 是否启用轮换（来自 rotation_status.rotation_enabled） */
    enabled: boolean;
    /** 完整的轮换状态对象（由 rotation_manager.get_rotation_status() 返回） */
    status: Record<string, unknown>;
    /** 用户上次轮换时间戳（毫秒），无记录时为 null */
    user_last_rotation: number | null;
}
export interface RotateKeyResponse {
    /** 操作是否成功 */
    success: boolean;
    /** 结果描述信息 */
    message: string;
    /** 是否产生了新密钥 */
    has_new_key: boolean;
}
export interface KeyRotationHistoryEntry {
    /** 轮换后的新密钥 ID，数据库无记录时为 null */
    key_id: string | null;
    /** 轮换时间戳（毫秒），数据库无记录时为 null */
    rotated_ts: number | null;
}
export interface KeyRotationHistory {
    /** 设备 ID */
    device_id: string;
    /** 轮换记录列表 */
    rotations: KeyRotationHistoryEntry[];
}
export interface RevokeKeyResponse {
    /** 操作是否成功 */
    success: boolean;
    /** 被撤销的密钥数量 */
    revoked: number;
    /** 结果描述信息 */
    message: string;
}
export interface UpdateRotationConfigResponse {
    /** 当前是否启用自动轮换 */
    enabled: boolean;
    /** 当前轮换间隔（毫秒） */
    interval_ms: number;
}
export interface KeyCheckResponse {
    /** 是否需要轮换 */
    needs_rotation: boolean;
    /** 上次轮换时间戳（毫秒），无记录时为 null */
    last_rotation: number | null;
    /** 配置的轮换间隔（毫秒） */
    interval_ms: number;
}
export interface KeyRotationRequestDto {
    key_id: string;
}
//# sourceMappingURL=dto.d.ts.map