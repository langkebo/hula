export declare const KEY_ROTATION_ROUTES_ENTRY_COUNT: 9;
export declare const KEY_ROTATION_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 400;
    readonly note: "M_INVALID_PARAM | 参数无效";
}, {
    readonly status: 401;
    readonly note: "M_UNAUTHORIZED | 未认证";
}, {
    readonly status: 403;
    readonly note: "M_FORBIDDEN | 无权限操作";
}, {
    readonly status: 404;
    readonly note: "M_NOT_FOUND | 密钥不存在";
}, {
    readonly status: 429;
    readonly note: "M_LIMIT_EXCEEDED | 轮换频率过高";
}, {
    readonly status: 202;
    readonly note: "初版 | -";
}, {
    readonly status: 202;
    readonly note: "新增 KeyRotationManager SDK 封装并补齐单元测试 | SDK 封装覆盖率提升至 100%";
}, {
    readonly status: 202;
    readonly note: "修正类型定义以对齐后端实际响应 | 修正所有端点的请求/响应类型";
}];
export type KeyRotationStatusScenario = (typeof KEY_ROTATION_ROUTES_STATUS_SCENARIOS)[number];
export declare const KEY_ROTATION_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "参数无效";
    readonly httpOrErrcode: "400 / M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "参数无效";
}, {
    readonly scenario: "未认证";
    readonly httpOrErrcode: "401 / M_UNAUTHORIZED";
    readonly sdkErrorType: "AuthError";
    readonly handling: "未认证";
}, {
    readonly scenario: "无权限操作";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "无权限操作";
}, {
    readonly scenario: "密钥不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "密钥不存在";
}, {
    readonly scenario: "轮换频率过高";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "轮换频率过高";
}];
export type KeyRotationErrorScenario = (typeof KEY_ROTATION_ROUTES_ERROR_SCENARIOS)[number];
export declare const KEY_ROTATION_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "参数无效";
}, {
    readonly errcode: "M_UNAUTHORIZED";
    readonly httpStatus: "401";
    readonly note: "未认证";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权限操作";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "密钥不存在";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "轮换频率过高";
}];
export type KeyRotationErrcode = (typeof KEY_ROTATION_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map