/** Routes served by the synapse-rust `device` module (mirrored from the backend contract). */
export declare const DEVICE_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/delete_devices";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/devices";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/devices/{device_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/devices/{device_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/devices/{device_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_list_updates";
}];
/** Union of every (method, path) tuple in `DEVICE_ROUTES`. */
export type DeviceRoute = (typeof DEVICE_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type DeviceMethod = DeviceRoute["method"];
/** Path templates referenced by this module. */
export type DevicePath = DeviceRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type DeviceReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${DeviceReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type DevicePathPattern = DeviceReplaceBraces<DevicePath>;
//# sourceMappingURL=route-table.d.ts.map