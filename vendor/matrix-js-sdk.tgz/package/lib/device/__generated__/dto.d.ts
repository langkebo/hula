/**
 * DTO snippets extracted from the contract doc for `device`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type DeviceContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map