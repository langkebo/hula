/**
 * DTO snippets extracted from the contract doc for `device`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface DeviceInfo {
    device_id: string;
    /**
     * 后端为 `Option<String>` ⇒ **没有值时回 `null`**（字段存在），不是缺字段。
     * `GET /devices` 与 `GET /devices/{id}` 都会带上它。
     */
    display_name?: string | null;
    /**
     * **只有 `GET /devices`（列表）会回这个字段**；`GET /devices/{id}` 的响应里没有
     * （后端 `routes/device.rs::get_device` 的 `json!` 只有 `device_id`/`display_name`/`last_seen_ts`）。
     * ⚠️ 上游 Synapse 的单设备端点**会**回它（spec 的 `DeviceInfo` 就有）⇒ SDK 侧有则透传、
     * 没有则不建这个键，两种行为都要能过。
     */
    last_seen_ip?: string | null;
    last_seen_ts?: number | null;
    /**
     * ⚠️ **两个端点都不返回这个字段**（Matrix client-server 的 `DeviceInfo` 里也没有它，
     * 那是 MSC4326 给 appservice 用的）。SDK 用当前会话的 `client.getUserId()` 填充 ——
     * 因为 `device_id` 自 C2 起只在**用户内**唯一，判断「这台是不是我的」只能靠它。
     */
    user_id?: string;
}
export interface DeviceListResponse {
    devices: DeviceInfo[];
}
export interface UpdateDeviceRequest {
    display_name?: string;
}
export interface AuthDict {
    type: string;
    session?: string;
    [key: string]: unknown;
}
export interface DeleteDeviceRequest {
    auth?: AuthDict;
}
export interface DeleteDevicesRequest {
    devices: string[];
    auth?: AuthDict;
}
export interface DeviceData {
    display_name?: string;
    last_seen_ts?: number;
    last_seen_ip?: string;
}
export interface DeviceChange {
    user_id: string;
    device_id: string;
    device_data: DeviceData;
}
export interface DeviceListUpdatesRequest {
    users: string[];
}
export interface DeviceListUpdatesResponse {
    changed: DeviceChange[];
    left: string[];
}
//# sourceMappingURL=dto.d.ts.map