export declare const DEVICE_ROUTES_ENTRY_COUNT: 12;
export declare const DEVICE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "缺少 display_name 或 device_ids/users 格式错误";
}, {
    readonly status: 404;
    readonly note: "设备不存在";
}];
export type DeviceStatusScenario = (typeof DEVICE_ROUTES_STATUS_SCENARIOS)[number];
export declare const DEVICE_ROUTES_ERROR_SCENARIOS: readonly [];
export type DeviceErrorScenario = (typeof DEVICE_ROUTES_ERROR_SCENARIOS)[number];
export declare const DEVICE_ROUTES_ERRCODES: readonly [];
export type DeviceErrcode = (typeof DEVICE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map