import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IAuthData } from "../interactive-auth";
export declare enum DeviceEvent {
    DevicesUpdated = "DevicesUpdated",
    DeviceDeleted = "DeviceDeleted",
    DeviceUpdated = "DeviceUpdated",
    DeviceError = "DeviceError"
}
/**
 * 设备信息接口
 *
 * 后端实现: synapse-rust/src/web/routes/device.rs:60-68
 */
export interface IDevice {
    device_id: string;
    display_name?: string;
    last_seen_ip?: string;
    last_seen_ts?: number;
    user_id?: string;
}
export interface IDeviceUpdateRequest {
    display_name?: string;
}
export interface IDeviceDeleteRequest {
    devices: string[];
    auth?: IAuthDict;
}
export interface IAuthDict {
    type: string;
    session?: string;
    [key: string]: unknown;
}
export interface IDeviceList {
    devices: IDevice[];
}
export interface IDeviceListUpdatesRequest {
    users: string[];
}
export interface IDeviceData {
    display_name?: string;
    last_seen_ts?: number;
    last_seen_ip?: string;
}
export interface IDeviceChange {
    user_id: string;
    device_id: string;
    device_data: IDeviceData;
}
/**
 * 设备列表更新响应
 *
 * 后端实现: synapse-rust/src/web/routes/device.rs:174-199
 */
export interface IDeviceListUpdatesResponse {
    changed: IDeviceChange[];
    left: string[];
}
interface DeviceManagerEventMap {
    [DeviceEvent.DevicesUpdated]: (devices: IDevice[]) => void;
    [DeviceEvent.DeviceDeleted]: (deviceId: string) => void;
    [DeviceEvent.DeviceUpdated]: (device: IDevice) => void;
    [DeviceEvent.DeviceError]: (error: Error) => void;
}
export declare class UIAError extends Error {
    readonly data: IAuthData;
    constructor(data: IAuthData);
}
export declare class DeviceManager extends BaseManager<DeviceEvent, DeviceManagerEventMap> {
    private deviceListCache;
    private deviceCache;
    private currentDeviceId;
    private initialized;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取所有设备
     *
     * @param forceRefresh - 是否强制刷新缓存（默认 false）
     * @returns 设备列表
     *
     * @example
     * ```typescript
     * // 获取所有设备
     * const devices = await deviceManager.getDevices();
     * devices.forEach(device => {
     *     console.log(`Device: ${device.device_id}`);
     *     console.log(`  Name: ${device.display_name}`);
     *     console.log(`  Last seen: ${device.last_seen_ts}`);
     * });
     *
     * // 强制刷新缓存
     * const freshDevices = await deviceManager.getDevices(true);
     * ```
     *
     * @throws {AuthError} 如果认证失败
     * @throws {ApiError} 如果 API 调用失败
     *
     * 后端实现: synapse-rust/src/web/routes/device.rs:49-74
     */
    getDevices(forceRefresh?: boolean): Promise<IDevice[]>;
    /**
     * 获取单个设备
     *
     * @param deviceId - 设备 ID
     * @param forceRefresh - 是否强制刷新
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 设备信息
     *
     * @example
     * ```typescript
     * // 获取设备详情
     * const device = await deviceManager.getDevice("ABCDEFGH");
     * if (device) {
     *     console.log(`Device name: ${device.display_name}`);
     *     console.log(`Last seen: ${new Date(device.last_seen_ts!)}`);
     * }
     *
     * // 不抛出错误
     * const device = await deviceManager.getDevice("INVALID", false, false);
     * if (!device) {
     *     console.log("Device not found");
     * }
     * ```
     *
     * @throws {ValidationError} 如果设备 ID 为空
     * @throws {NotFoundError} 如果设备不存在且 throwOnError 为 true
     * @throws {ApiError} 如果 API 调用失败
     *
     * 后端实现: synapse-rust/src/web/routes/device.rs:77-103
     */
    getDevice(deviceId: string, forceRefresh?: boolean, throwOnError?: boolean): Promise<IDevice | null>;
    /**
     * 更新设备
     *
     * 后端实现: synapse-rust/src/web/routes/device.rs:107-131
     */
    updateDevice(deviceId: string, updates: IDeviceUpdateRequest): Promise<void>;
    setDeviceDetails(deviceId: string, updates: IDeviceUpdateRequest): Promise<void>;
    /**
     * 删除设备
     *
     * @param deviceId - 设备 ID
     * @param authDict - 认证字典（用于 UIA）
     *
     * @example
     * ```typescript
     * // 删除设备
     * try {
     *     await deviceManager.deleteDevice("ABCDEFGH");
     *     console.log("Device deleted successfully");
     * } catch (error) {
     *     if (error instanceof UIAError) {
     *         // 需要用户交互认证
     *         console.log("UIA required:", error.data);
     *         // 提供认证信息后重试
     *         await deviceManager.deleteDevice("ABCDEFGH", {
     *             type: "m.login.password",
     *             session: error.data.session,
     *             user: "@alice:example.com",
     *             password: "password"
     *         });
     *     }
     * }
     * ```
     *
     * @throws {ValidationError} 如果设备 ID 为空
     * @throws {InvalidParamError} 如果尝试删除当前设备
     * @throws {UIAError} 如果需要用户交互认证
     * @throws {ApiError} 如果 API 调用失败
     *
     * 后端实现: synapse-rust/src/web/routes/device.rs:135-153
     */
    deleteDevice(deviceId: string, authDict?: IAuthDict): Promise<void>;
    /**
     * 批量删除设备
     *
     * 后端实现: synapse-rust/src/web/routes/device.rs:157-170
     */
    deleteDevices(request: string[] | IDeviceDeleteRequest): Promise<void>;
    renameDevice(deviceId: string, displayName: string): Promise<void>;
    /**
     * 获取设备列表更新
     *
     * 后端实现: synapse-rust/src/web/routes/device.rs:46-47 (POST /keys/device_list_updates)
     */
    getDeviceListUpdates(users: string[]): Promise<IDeviceListUpdatesResponse>;
    getCurrentDeviceId(): string | null;
    getCurrentDevice(): IDevice | null;
    getCachedDevices(): IDevice[];
    getCachedDevice(deviceId: string): IDevice | null;
    getOtherDevices(): IDevice[];
    /**
     * 清除缓存
     */
    clearCache(): void;
    /**
     * 获取缓存统计
     */
    getCacheStats(): {
        deviceList: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        devices: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
    start(): Promise<void>;
    stop(): void;
    private recordRequest;
    private isRetryableError;
    private getErrorType;
    private emitMetric;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map