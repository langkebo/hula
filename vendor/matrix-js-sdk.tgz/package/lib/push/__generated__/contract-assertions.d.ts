export declare const PUSH_ROUTES_ENTRY_COUNT: 27;
export declare const PUSH_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "请求体不合法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 404;
    readonly note: "规则或通知不存在";
}];
export type PushStatusScenario = (typeof PUSH_ROUTES_STATUS_SCENARIOS)[number];
export declare const PUSH_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "触发登录态恢复流程，不继续提交规则写入";
}, {
    readonly scenario: "规则或通知不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "视为目标已不存在，刷新本地规则快照";
}, {
    readonly scenario: "参数或规则定义非法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 actions/conditions/pattern 后重试";
}, {
    readonly scenario: "无权限修改目标规则";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "终止重试并提示权限不足";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED，5xx";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用指数退避重试";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 处理兜底";
}];
export type PushErrorScenario = (typeof PUSH_ROUTES_ERROR_SCENARIOS)[number];
export declare const PUSH_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "push rule 或 notification 不存在";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权限写入或删除规则";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "参数取值非法或规则字段冲突";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "触发限流";
}];
export type PushErrcode = (typeof PUSH_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map