/** Routes served by the synapse-rust `push` module (mirrored from the backend contract). */
export declare const PUSH_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/notifications";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/notifications/{notification_id}/ack";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushers";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/pushers";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/pushers/set";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules/{scope}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}/actions";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}/enabled";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}/enabled";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/pushers/";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/pushers/";
}];
/** Union of every (method, path) tuple in `PUSH_ROUTES`. */
export type PushRoute = (typeof PUSH_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type PushMethod = PushRoute["method"];
/** Path templates referenced by this module. */
export type PushPath = PushRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type PushReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${PushReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type PushPathPattern = PushReplaceBraces<PushPath>;
//# sourceMappingURL=route-table.d.ts.map