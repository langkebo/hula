/**
 * DTO snippets extracted from the contract doc for `push`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type PushJsonValue = string | number | boolean | null | PushJsonValue[] | {
    [key: string]: PushJsonValue;
};
export type PushRuleAction = string | PushRuleTweak;
export interface PushRuleTweak {
    set_tweak?: string;
    value?: PushJsonValue;
}
export interface PushCondition {
    kind: string;
    key?: string;
    pattern?: string;
    is?: string;
}
export interface PushRule {
    rule_id: string;
    default: boolean;
    enabled: boolean;
    pattern?: string;
    conditions?: PushCondition[];
    actions: PushRuleAction[];
}
export interface PushRuleSet {
    override?: PushRule[];
    content?: PushRule[];
    room?: PushRule[];
    sender?: PushRule[];
    underride?: PushRule[];
}
export interface PushRulesResponse {
    global: {
        [kind: string]: PushRule[];
    };
    devices?: {
        [deviceId: string]: {
            [kind: string]: PushRule[];
        };
    };
}
export type PushRulesByKindResponse = {
    [kind: string]: PushRule[];
};
export type PushRulesByScopeResponse = PushRuleSet;
export type PushRuleResponse = PushRule;
export interface PushRuleEnabledResponse {
    enabled: boolean;
}
export interface SetPushRuleEnabledRequest {
    enabled?: boolean;
}
export interface SetPushRuleEnabledResponse {
    rule_id: string;
    enabled: boolean;
    updated_ts: number;
}
export interface SetPushRuleActionsResponse {
    rule_id: string;
    actions: PushRuleAction[];
    updated_ts: number;
}
export interface SetPushRuleActionsRequest {
    actions: PushRuleAction[];
}
export interface SetPushRuleRequest {
    actions?: PushRuleAction[];
    conditions?: PushCondition[];
    pattern?: string;
}
export interface PushRuleWriteResponse {
    rule_id: string;
    scope: string;
    kind: string;
    created_ts: number;
}
export type PushRuleDeleteResponse = {
    [key: string]: never;
};
export interface PusherItem {
    pushkey: string;
    kind: string;
    app_id: string;
    app_display_name: string;
    device_display_name: string;
    profile_tag?: string;
    lang: string;
    data?: PushJsonValue;
}
export interface PushersResponse {
    pushers: PusherItem[];
}
export interface SetPusherRequest {
    pushkey: string;
    kind: string | null;
    app_id: string;
    app_display_name?: string;
    device_display_name?: string;
    profile_tag?: string;
    lang?: string;
    data?: PushJsonValue;
    append?: boolean;
}
export interface SetPusherResponse {
    pushkey: string;
    kind: string;
    app_id: string;
    created_ts: number;
}
export interface DeletePusherResponse {
    deleted: true;
    pushkey: string;
}
export interface NotificationItem {
    notification_id: number;
    event_id?: string | null;
    room_id?: string | null;
    ts: number;
    profile_tag?: string | null;
    notification_type?: string | null;
    read: boolean;
}
export interface NotificationsResponse {
    notifications: NotificationItem[];
    next_token?: string;
}
export interface AckNotificationResponse {
    notification_id: string;
    is_read: boolean;
    updated_ts: number;
}
//# sourceMappingURL=dto.d.ts.map