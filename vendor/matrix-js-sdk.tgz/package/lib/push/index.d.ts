/**
 * Push Manager - 推送管理
 *
 * 提供推送通知和推送规则管理功能。
 * 对应后端: synapse-rust/src/web/routes/push.rs
 *
 * 遵循 D7 契约驱动开发标准，100% 覆盖后端端点并保持类型对齐。
 */
import { MatrixClient } from "../client";
import { PushRuleKind, PushRuleAction, IPushRule, IPushRules, PushRuleCondition } from "../@types/PushRules";
import { type IEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export type { IPushRules } from "../@types/PushRules";
export { PUSHER_ENABLED } from "../@types/event";
export declare enum PushEvent {
    PushersUpdated = "PushersUpdated",
    PushRulesUpdated = "PushRulesUpdated",
    NotificationReceived = "NotificationReceived",
    PushError = "PushError"
}
export interface IPusher {
    pushkey: string;
    kind: string | null;
    app_id: string;
    app_display_name: string;
    device_display_name: string;
    profile_tag?: string;
    lang: string;
    data?: Record<string, unknown>;
    enabled?: boolean;
    device_id?: string;
}
export interface IPusherRequest {
    pushkey: string;
    kind?: string | null;
    app_id: string;
    app_display_name: string;
    device_display_name: string;
    profile_tag?: string;
    lang: string;
    data?: Record<string, unknown>;
    append?: boolean;
    device_id?: string;
}
export interface ICreatePushRuleRequest {
    actions: PushRuleAction[];
    conditions?: PushRuleCondition[];
    pattern?: string;
    before?: string;
    after?: string;
}
export interface IUpdatePushRuleRequest {
    actions: PushRuleAction[];
    conditions?: PushRuleCondition[];
    pattern?: string;
}
export interface INotification {
    event_id: string;
    room_id: string;
    ts: number;
    profile_tag?: string;
    read: boolean;
    event?: IEvent;
}
export interface INotificationsResponse {
    notifications: INotification[];
    next_token?: string;
}
export interface IPushRuleSet {
    override?: IPushRule[];
    content?: IPushRule[];
    room?: IPushRule[];
    sender?: IPushRule[];
    underride?: IPushRule[];
}
interface PushManagerEventMap {
    [PushEvent.PushersUpdated]: (pushers: IPusher[]) => void;
    [PushEvent.PushRulesUpdated]: (rules: IPushRules) => void;
    [PushEvent.NotificationReceived]: (notification: INotification) => void;
    [PushEvent.PushError]: (error: Error) => void;
}
/**
 * PushManager 处理推送器和推送规则。
 * 对应后端 `push.rs` 中的所有 REST 端点。
 */
export declare class PushManager extends BaseManager<PushEvent, PushManagerEventMap> {
    private pushersCache;
    private pushRulesCache;
    private initialized;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取所有推送器
     * 对应 GET /_matrix/client/v3/pushers
     */
    getPushers(forceRefresh?: boolean): Promise<IPusher[]>;
    /**
     * 设置推送器
     * 对应 POST /_matrix/client/v3/pushers/set
     */
    setPusher(pusher: IPusherRequest): Promise<void>;
    /**
     * 移除推送器
     * 对应 POST /_matrix/client/v3/pushers/set (kind=null)
     */
    removePusher(pushkey: string, appId: string, deviceId?: string): Promise<void>;
    getCachedPushers(): IPusher[];
    /**
     * 获取所有推送规则
     * 对应 GET /_matrix/client/v3/pushrules
     */
    getPushRules(forceRefresh?: boolean): Promise<IPushRules>;
    /**
     * 获取指定作用域的推送规则
     * 对应 GET /_matrix/client/v3/pushrules/{scope}
     */
    getPushRulesByScope(scope: string): Promise<IPushRuleSet>;
    /**
     * 获取指定类型的推送规则
     * 对应 GET /_matrix/client/v3/pushrules/{scope}/{kind}
     */
    getPushRulesByKind(scope: string, kind: PushRuleKind): Promise<IPushRule[]>;
    /**
     * 获取特定推送规则
     * 对应 GET /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}
     */
    getPushRule(scope: string, kind: PushRuleKind, ruleId: string, throwOnError?: boolean): Promise<IPushRule | null>;
    /**
     * 创建推送规则
     * 对应 POST /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}
     */
    createPushRule(scope: string, kind: PushRuleKind, ruleId: string, rule: ICreatePushRuleRequest): Promise<void>;
    /**
     * 更新推送规则
     * 对应 PUT /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}
     */
    updatePushRule(scope: string, kind: PushRuleKind, ruleId: string, rule: IUpdatePushRuleRequest): Promise<void>;
    /**
     * 删除推送规则
     * 对应 DELETE /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}
     */
    deletePushRule(scope: string, kind: PushRuleKind, ruleId: string): Promise<void>;
    /**
     * 获取推送规则是否启用
     * 对应 GET /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}/enabled
     */
    getPushRuleEnabled(scope: string, kind: PushRuleKind, ruleId: string, throwOnError?: boolean): Promise<boolean>;
    /**
     * 设置推送规则是否启用
     * 对应 PUT /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}/enabled
     */
    setPushRuleEnabled(scope: string, kind: PushRuleKind, ruleId: string, enabled: boolean): Promise<void>;
    /**
     * 设置推送规则动作
     * 对应 PUT /_matrix/client/v3/pushrules/{scope}/{kind}/{rule_id}/actions
     */
    setPushRuleActions(scope: string, kind: PushRuleKind, ruleId: string, actions: PushRuleAction[]): Promise<void>;
    getCachedPushRules(): IPushRules | null;
    /**
     * 获取推送通知列表
     * 对应 GET /_matrix/client/v3/notifications
     */
    getNotifications(params?: {
        limit?: number;
        from?: string;
        only?: string;
    }): Promise<INotificationsResponse>;
    /**
     * 确认通知
     * 对应 POST /_matrix/client/v3/notifications/{notification_id}/ack
     */
    ackNotification(notificationId: string, throwOnError?: boolean): Promise<void>;
    /**
     * Get the room-kind push rule associated with a room.
     * @param scope - "global" or device-specific.
     * @param roomId - the id of the room.
     * @returns the rule or undefined.
     */
    getRoomPushRule(scope: "global" | "device", roomId: string): IPushRule | undefined;
    /**
     * Set a room-kind muting push rule in a room.
     * The operation also updates MatrixClient.pushRules at the end.
     * @param scope - "global" or device-specific.
     * @param roomId - the id of the room.
     * @param mute - the mute state.
     * @returns Promise which resolves: result object
     * @returns Rejects: with an error response.
     */
    setRoomMutePushRule(scope: "global" | "device", roomId: string, mute: boolean): Promise<void> | undefined;
    muteRoom(roomId: string): Promise<void>;
    unmuteRoom(roomId: string): Promise<void>;
    isRoomMuted(roomId: string): Promise<boolean>;
    addKeywordHighlight(keyword: string): Promise<void>;
    removeKeywordHighlight(keyword: string): Promise<void>;
    ignoreSender(userId: string): Promise<void>;
    unignoreSender(userId: string): Promise<void>;
    private startPromise;
    start(): Promise<void>;
    stop(): void;
    clearCache(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map