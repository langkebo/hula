import { type WidgetApi } from "matrix-widget-api";
import { MatrixClient, type ICreateClientOpts } from "./client";
import { type ICapabilities } from "./embedded";
import { type CryptoStore } from "./crypto/store/base";
export { extendMatrixClientWithManagers, isManagerExtensionsInitialized, offManagerExtensionsLifecycle, onManagerExtensionsLifecycle, resetManagerExtensions, } from "./manager-extensions";
export type { ManagerExtensionsLifecycleEvent, ManagerExtensionsLifecycleListener, ManagerExtensionsLifecyclePhase, ManagerExtensionsLifecycleStatus, ManagerExtensionsOptions, } from "./manager-extensions";
export * from "./client";
export * from "./serverCapabilities";
export * from "./embedded";
export * from "./http-api/index";
export * from "./autodiscovery";
export * from "./sync-accumulator";
export * from "./errors";
export * from "./base64";
export * from "./models/event";
export * from "./models/room";
export * from "./models/event-timeline";
export * from "./models/event-timeline-set";
export * from "./models/room-member";
export * from "./models/room-state";
export * from "./models/thread";
export * from "./models/typed-event-emitter";
export * from "./models/user";
export * from "./models/device";
export * from "./models/search-result";
export * from "./oidc/index";
export * from "./scheduler";
export * from "./filter";
export * from "./timeline-window";
export * from "./interactive-auth";
export * from "./version";
export * from "./version-support";
export * from "./service-types";
export * from "./store/memory";
export * from "./store/indexeddb";
export * from "./store/ttl";
export * from "./store/stats";
export * from "./store/capacity";
export * from "./crypto/store/memory-crypto-store";
export * from "./crypto/store/localStorage-crypto-store";
export * from "./crypto/store/indexeddb-crypto-store";
export type { OutgoingRoomKeyRequest } from "./crypto/store/base";
export * from "./content-repo";
export type * from "./@types/common";
export type * from "./@types/uia";
export * from "./@types/event";
export * from "./@types/PushRules";
export * from "./@types/partials";
export * from "./@types/requests";
export * from "./@types/search";
export * from "./@types/topic";
export * from "./@types/three-pids";
export * from "./@types/auth";
export type * from "./@types/local_notifications";
export type * from "./@types/registration";
export * from "./@types/read_receipts";
export type * from "./@types/crypto";
export type * from "./@types/IIdentityServerProvider";
export * from "./@types/membership";
export * from "./@types/beacon";
export * from "./@types/location";
export * from "./models/room-summary";
export * from "./models/event-status";
export * from "./models/profile-keys";
export * from "./models/related-relations";
export * from "./runtime-schemas/index";
export type { RoomSummary } from "./client";
export * from "./matrix-managers";
export { MSC4108SignInWithQR } from "./rendezvous/MSC4108SignInWithQR";
export type { ICreateClientOpts } from "./client";
export { PendingEventOrdering } from "./client";
export type { LoginResponse } from "./@types/auth";
export type { IEventRelation } from "./models/event";
export { EventTimeline } from "./models/event-timeline";
export { TimelineWindow } from "./timeline-window";
export { ReceiptType } from "./@types/read_receipts";
export * as ContentHelpers from "./content-helpers";
export * as SecretStorage from "./secret-storage";
export { createNewMatrixCall, CallEvent } from "./web-rtc/call";
export type { MatrixCall } from "./web-rtc/call";
export { GroupCall, GroupCallEvent, GroupCallIntent, GroupCallState, GroupCallType, GroupCallStatsReportEvent, } from "./web-rtc/groupCall";
export { SyncState, SetPresence } from "./sync";
export type { ISyncStateData as SyncStateData } from "./sync";
export type { ISearchResponse as SearchResponse } from "./@types/search";
export type { IDeviceUpdateRequest, IDeviceDeleteRequest } from "./device";
export { SlidingSyncEvent, SlidingSyncState, SlidingSync } from "./sliding-sync";
export type { MSC3575SlidingSyncResponse, MSC3575RoomData, MSC3575List, MSC3575RoomSubscription, MSC3575Filter, } from "./sliding-sync";
export { SlidingSyncSdk } from "./sliding-sync-sdk";
export { MediaHandlerEvent } from "./web-rtc/mediaHandler";
export { CallFeedEvent } from "./web-rtc/callFeed";
export { StatsReport } from "./web-rtc/stats/statsReport";
export { Relations, RelationsEvent } from "./models/relations";
export { TypedEventEmitter } from "./models/typed-event-emitter";
export { LocalStorageErrors, localStorageErrorsEventsEmitter } from "./store/local-storage-events-emitter";
export { IdentityProviderBrand, SSOAction } from "./@types/auth";
export type { ISSOFlow as SSOFlow, LoginFlow } from "./@types/auth";
export type { IHierarchyRelation as HierarchyRelation, IHierarchyRoom as HierarchyRoom } from "./@types/spaces";
export { DebugLogger } from "./logger";
export { TelemetryManager } from "./telemetry/index";
export type { KeyBackupInfo, KeyBackupSession, KeyBackupRoomSessions } from "./crypto-api/keybackup";
export type { MatrixClientExtensionMethods } from "./matrix-client-extensions";
/**
 * Configure a different factory to be used for creating crypto stores
 *
 * @param fac - a function which will return a new `CryptoStore`
 */
export declare function setCryptoStoreFactory(fac: () => CryptoStore): void;
export declare function initializeManagerExtensions(): Promise<void>;
/**
 * Construct a Matrix Client. Similar to {@link MatrixClient}
 * except that the 'request', 'store' and 'scheduler' dependencies are satisfied.
 * @param opts - The configuration options for this client. These configuration
 * options will be passed directly to {@link MatrixClient}.
 *
 * @returns A new matrix client.
 * @see {@link MatrixClient} for the full list of options for
 * `opts`.
 */
export declare function createClient(opts: ICreateClientOpts): MatrixClient;
/**
 * Construct a Matrix Client that works in a widget.
 * This client has a subset of features compared to a full client.
 * It uses the widget-api to communicate with matrix. (widget \<-\> client \<-\> homeserver)
 * @returns A new matrix client with a subset of features.
 * @param opts - The configuration options for this client. These configuration
 * options will be passed directly to {@link MatrixClient}.
 * @param widgetApi - The widget api to use for communication.
 * @param capabilities - The capabilities the widget client will request.
 * @param roomId - The room id the widget is associated with.
 * @param sendContentLoaded - Whether to send a content loaded widget action immediately after initial setup.
 *   Set to `false` if the widget uses `waitForIFrameLoad=true` (in this case the client does not expect a content loaded action at all),
 *   or if the the widget wants to send the `ContentLoaded` action at a later point in time after the initial setup.
 */
export declare function createRoomWidgetClient(widgetApi: WidgetApi, capabilities: ICapabilities, roomId: string, opts: ICreateClientOpts, sendContentLoaded?: boolean): MatrixClient;
//# sourceMappingURL=matrix.d.ts.map