export {};
//# sourceMappingURL=manager-initialization.test.d.ts.map