export interface SendEventPathParams {
    roomId: string;
    eventType: string;
    stateKey?: string | null;
    txnId: string;
    isState: boolean;
    isRedaction: boolean;
    redactsEventId?: string;
}
export declare function buildSendEventPath(params: SendEventPathParams): string;
//# sourceMappingURL=client-send-paths.d.ts.map