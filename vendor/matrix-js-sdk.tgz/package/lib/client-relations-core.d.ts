import { EventType, RelationType } from "./@types/event";
import type { MatrixEvent } from "./models/event";
export interface ProcessRelationEventsParams {
    events: MatrixEvent[];
    originalEvent?: MatrixEvent;
    fetchedEventType: EventType | string | null | undefined;
    requestedEventType?: EventType | string | null;
    relationType: RelationType | string | null;
    decryptEventIfNeeded: (event: MatrixEvent) => Promise<void>;
}
export declare function processRelationEvents({ events, originalEvent, fetchedEventType, requestedEventType, relationType, decryptEventIfNeeded, }: ProcessRelationEventsParams): Promise<MatrixEvent[]>;
//# sourceMappingURL=client-relations-core.d.ts.map