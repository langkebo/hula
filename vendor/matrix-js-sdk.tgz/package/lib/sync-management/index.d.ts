import { MatrixClient } from "../client";
import { Room } from "../models/room";
import { SyncState, type ISyncStateData } from "../sync";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface SyncManagerEvents {
    sync_started: void;
    sync_stopped: void;
    sync_state_changed: {
        state: SyncState;
    };
    sync_error: {
        error: Error;
    };
}
export declare class SyncManager extends BaseManager<keyof SyncManagerEvents, SyncManagerEvents> {
    private syncedLeftRooms;
    private syncLeftRoomsPromise;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getSyncToken(): string | undefined;
    getSyncState(): SyncState | null;
    getSyncStateData(): ISyncStateData | null;
    isSyncing(): boolean;
    getRooms(): Room[];
    getJoinedRooms(): Promise<string[]>;
    getInvitedRooms(): Room[];
    getLeftRooms(): Room[];
    syncLeftRooms(): Promise<Room[]>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map