/**
 * Retention Manager - 消息保留策略管理
 *
 * 对接后端: synapse-rust/src/web/routes/admin/retention.rs
 * 后端提供 (Admin API):
 *   GET  /_synapse/admin/v1/retention/policy              (获取服务器保留策略)
 *   POST /_synapse/admin/v1/retention/policy              (设置服务器保留策略)
 *   GET  /_synapse/admin/v1/retention/policy/{room_id}    (获取房间保留策略)
 *   POST /_synapse/admin/v1/retention/policy/{room_id}    (设置房间保留策略)
 *   POST /_synapse/admin/v1/retention/run                 (执行保留清理)
 *   GET  /_synapse/admin/v1/retention/status              (获取保留状态)
 *
 * 客户端 API (通过 m.room.retention 状态事件):
 *   房间保留策略通过 m.room.retention 状态事件读取
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface RetentionPolicy {
    max_lifetime?: number;
    min_lifetime?: number;
    /** m.room.retention state event field (Matrix spec) */
    expire_on_clients?: boolean;
    /** Admin API field name (synapse-rust retention.rs) */
    is_expire_on_clients?: boolean;
}
export interface RetentionState {
    enabled: boolean;
    policy?: RetentionPolicy;
}
export interface IRetentionRunResult {
    started: boolean;
    room_id?: string;
    scope?: string;
    events_deleted?: number;
    status?: string;
    completed_ts?: number | null;
}
export interface IRetentionStatus {
    server_policy_enabled: boolean;
    rooms_with_custom_policy: number;
    lifecycle_cleanup_enabled: boolean;
    cleanup_batch_size: number;
    audit_retention_days: number;
    queue_retention_days: number;
    last_run: {
        started_ts: number;
        completed_ts: number | null;
        duration_ms: number | null;
        expired_events_deleted: number;
        expired_beacons_deleted: number;
        expired_uploads_deleted: number;
        expired_audit_events_deleted: number;
        cleanup_queue_items_processed: number;
        cleanup_queue_rows_pruned: number;
        failed_tasks: number;
    } | null;
}
export interface RetentionManagerEvents {
    retentionPolicyUpdated: (data: {
        roomId: string;
        policy: RetentionPolicy;
    }) => void;
    serverPolicyUpdated: (data: {
        policy: RetentionPolicy;
    }) => void;
    retentionRunCompleted: (data: {
        result: IRetentionRunResult;
    }) => void;
    messageExpired: (data: {
        roomId: string;
        eventId: string;
    }) => void;
}
export declare class RetentionManager extends BaseManager<keyof RetentionManagerEvents, RetentionManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getServerRetentionPolicy(): Promise<RetentionPolicy>;
    setServerRetentionPolicy(policy: RetentionPolicy): Promise<RetentionPolicy>;
    getRoomRetentionPolicy(roomId: string): Promise<RetentionPolicy & {
        room_id: string;
    }>;
    setRoomRetentionPolicy(roomId: string, policy: RetentionPolicy): Promise<RetentionPolicy & {
        room_id: string;
    }>;
    runRetention(roomId?: string): Promise<IRetentionRunResult>;
    getRetentionStatus(): Promise<IRetentionStatus>;
    getRoomRetentionState(roomId: string): RetentionState;
    getAllRoomRetentionPolicies(): Record<string, RetentionPolicy>;
    isMessageWithinRetention(roomId: string, timestamp: number): boolean;
    getMessageRemainingLifetime(roomId: string, timestamp: number): number | null;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map