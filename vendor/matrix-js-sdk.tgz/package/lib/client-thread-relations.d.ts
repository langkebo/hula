import type { IContent } from "./models/event.ts";
import type { MatrixEvent } from "./models/event.ts";
interface ThreadLike {
    lastReply(predicate: (ev: MatrixEvent) => boolean): MatrixEvent | null | undefined;
}
export declare function applyThreadRelationIfNeeded(content: IContent, threadId: string | null, relationTypeName: string, getThread: (threadId: string) => ThreadLike | undefined): void;
export {};
//# sourceMappingURL=client-thread-relations.d.ts.map