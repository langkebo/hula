import type { IContextResponse, INotificationsResponse } from "./@types/requests";
import type { IMessagesResponse } from "./client-internal-types";
import { Direction } from "./models/event-timeline";
import type { IEvent, MatrixEvent } from "./models/event";
export type NormalizedContextResponse = IContextResponse & Omit<Required<IContextResponse>, "start" | "end">;
export interface PaginationRequestHolder {
    paginationRequests: Record<Direction, Promise<boolean> | null>;
}
export interface TimelineUnknownStateTarget {
    setUnknownStateEvents(events: MatrixEvent[]): void;
}
export interface TimelineStateHolder {
    getState(dir: Direction): TimelineUnknownStateTarget | null | undefined;
}
export interface PaginationTokenHolder {
    setPaginationToken(token: string | null, dir: Direction): void;
}
export interface PaginateWithRequestParams {
    eventTimeline: PaginationRequestHolder & TimelineStateHolder & PaginationTokenHolder;
    dir: Direction;
    request: Promise<IMessagesResponse>;
    mapper: (e: Partial<IEvent>) => MatrixEvent;
    isSafe: (e: Partial<IEvent>) => boolean;
    onSuccess: (res: IMessagesResponse, matrixEvents: MatrixEvent[]) => void;
}
export declare function normalizeEventContextResponse(res: IContextResponse): NormalizedContextResponse;
export declare function trackPaginationRequest(holder: PaginationRequestHolder, dir: Direction, request: Promise<boolean>): Promise<boolean>;
export declare function mapSafeEvents<TIn, TOut>(events: TIn[], isSafe: (e: TIn) => boolean, mapper: (e: TIn) => TOut): TOut[];
export declare function applyUnknownStateEvents<TStateEvent>(holder: TimelineStateHolder, dir: Direction, stateEvents: TStateEvent[] | undefined, isSafe: (e: TStateEvent) => boolean, mapper: (e: TStateEvent) => MatrixEvent): void;
export declare function stopBackPaginationIfNeeded(holder: PaginationTokenHolder, dir: Direction, backwards: boolean, atEnd: boolean): void;
export declare function paginateTimelineWithRequest({ eventTimeline, dir, request, mapper, isSafe, onSuccess, }: PaginateWithRequestParams): Promise<boolean>;
export interface PaginateNotificationsParams {
    eventTimeline: PaginationRequestHolder & PaginationTokenHolder;
    dir: Direction;
    backwards: boolean;
    request: Promise<INotificationsResponse>;
    onSuccess: (res: INotificationsResponse) => string | null | undefined;
}
export declare function paginateNotificationsWithRequest({ eventTimeline, dir, backwards, request, onSuccess, }: PaginateNotificationsParams): Promise<boolean>;
export declare function mapStateAndChunkFromMessages<TEvent>(res: {
    chunk: TEvent[];
    state?: TEvent[];
}, isSafe: (e: TEvent) => boolean, mapper: (e: TEvent) => MatrixEvent): {
    matrixEvents: MatrixEvent[];
    stateEvents: MatrixEvent[];
};
export declare function deriveBackPaginationTokenFromMessages(res: Pick<IMessagesResponse, "start" | "end" | "chunk">): string | null;
//# sourceMappingURL=client-timeline-core.d.ts.map