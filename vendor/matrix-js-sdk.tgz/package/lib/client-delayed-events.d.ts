export declare function buildUnstableFeaturePrefix(unstableFeatureName: string): string;
export declare function buildDelayedEventsPath(delayId: string | number): string;
/**
 * 专用调度端点路径（2026-10-14 后端新增，上游 19354 推荐形态）：
 * `PUT /rooms/{room_id}/delayed_event/{event_type}/{txn_id}`。
 * 与 `/send` 的 delay query（已标记弃用）相对；body 携带
 * `{ delay_ms, content, state_key? }` 而非把整个 body 当作事件内容。
 */
export declare function buildDedicatedDelayedEventPath(roomId: string, eventType: string, txnId: string): string;
//# sourceMappingURL=client-delayed-events.d.ts.map