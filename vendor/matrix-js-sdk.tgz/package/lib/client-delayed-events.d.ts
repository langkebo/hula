import type { UpdateDelayedEventAction } from "./@types/requests.ts";
import type { QueryDict } from "./utils.ts";
export declare function buildUnstableFeaturePrefix(unstableFeatureName: string): string;
export declare function buildDelayedEventsQuery(status?: "scheduled" | "finalised", delayId?: string | string[], fromToken?: string): QueryDict;
export declare function buildDelayedEventsActionPath(delayId: string, action: UpdateDelayedEventAction): string;
export declare function buildDelayedEventsPath(delayId: string): string;
//# sourceMappingURL=client-delayed-events.d.ts.map