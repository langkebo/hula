export declare function buildUnstableFeaturePrefix(unstableFeatureName: string): string;
export declare function buildDelayedEventsPath(delayId: string | number): string;
//# sourceMappingURL=client-delayed-events.d.ts.map