export * from "./matrix.ts";
type BrowserMatrix = typeof import("./matrix.ts");
declare global {
    var __js_sdk_entrypoint: boolean;
    var matrixcs: BrowserMatrix;
}
//# sourceMappingURL=browser-index.d.ts.map