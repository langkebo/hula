export * from "./matrix";
type BrowserMatrix = typeof import("./matrix");
declare global {
    var __js_sdk_entrypoint: boolean;
    var matrixcs: BrowserMatrix;
}
//# sourceMappingURL=browser-index.d.ts.map