import { MatrixClient } from "../client";
import { EventType } from "../@types/event";
import type { ISendEventResponse } from "../@types/requests";
import type { RoomMessageEventContent } from "../@types/events";
import type { IContent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IImageInfo {
    w?: number;
    h?: number;
    mimetype?: string;
    size?: number;
    thumbnail_url?: string;
    thumbnail_info?: IImageInfo;
}
export interface IEncryptedFileKey {
    alg?: string;
    k?: string;
    ext?: boolean;
    key_ops?: string[];
    [key: string]: unknown;
}
export interface IFileContent {
    body: string;
    filename?: string;
    info?: IImageInfo;
    msgtype: string;
    url?: string;
    file?: {
        url: string;
        key: IEncryptedFileKey;
        iv: string;
        hashes: Record<string, string>;
        v: string;
    };
}
export interface SendingManagerEvents {
    event_sent: {
        roomId: string;
        eventId: string;
    };
    message_sent: {
        roomId: string;
        eventId: string;
    };
    send_failed: {
        roomId: string;
        error: Error;
    };
}
export declare class SendingManager extends BaseManager<keyof SendingManagerEvents, SendingManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * ISSUE-03: 在一次逻辑发送的整个重试生命周期内复用同一 txnId。
     *
     * 此前 txnId 在 `client.sendEvent` 内部每次尝试都重新生成
     * （`ensureTxnId(undefined, makeTxnId)`），弱网/超时重试会产生多条
     * 本地回显与服务端重复消息。现在在进入 `withRetry` 前解析一次，
     * 所有重试尝试共享同一 txnId：服务端按 txnId 幂等去重（后端有
     * 缓存 + DB 唯一约束双保险），本地回显以 txnId 为 key 复用
     * （见 `client-send-lifecycle.ts`）。
     */
    private resolveTxnId;
    sendEvent(roomId: string, eventType: string | EventType, content: IContent, txnId?: string): Promise<ISendEventResponse>;
    sendEvent(roomId: string, threadId: string | null, eventType: string | EventType, content: IContent, txnId?: string): Promise<ISendEventResponse>;
    sendMessage(roomId: string, content: RoomMessageEventContent, txnId?: string): Promise<ISendEventResponse>;
    sendMessage(roomId: string, threadId: string | null, content: RoomMessageEventContent, txnId?: string): Promise<ISendEventResponse>;
    sendTextMessage(roomId: string, text: string, txnId?: string): Promise<ISendEventResponse>;
    sendTextMessage(roomId: string, threadId: string | null, text: string, txnId?: string): Promise<ISendEventResponse>;
    sendHtmlMessage(roomId: string, body: string, html: string): Promise<ISendEventResponse>;
    sendHtmlMessage(roomId: string, threadId: string | null, body: string, html: string): Promise<ISendEventResponse>;
    sendEmote(roomId: string, text: string, txnId?: string): Promise<ISendEventResponse>;
    sendEmote(roomId: string, threadId: string | null, text: string, txnId?: string): Promise<ISendEventResponse>;
    sendNotice(roomId: string, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendNotice(roomId: string, threadId: string | null, body: string, txnId?: string): Promise<ISendEventResponse>;
    sendImage(roomId: string, url: string, info?: IImageInfo, text?: string): Promise<ISendEventResponse>;
    sendImage(roomId: string, threadId: string | null, url: string, info?: IImageInfo, text?: string): Promise<ISendEventResponse>;
    sendFile(roomId: string, content: IFileContent, txnId?: string): Promise<ISendEventResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map