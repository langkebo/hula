export declare enum InvalidCryptoStoreState {
    TooNew = "TOO_NEW"
}
export declare class InvalidCryptoStoreError extends Error {
    readonly reason: InvalidCryptoStoreState;
    static TOO_NEW: InvalidCryptoStoreState;
    constructor(reason: InvalidCryptoStoreState);
}
export declare class KeySignatureUploadError extends Error {
    readonly value: unknown;
    constructor(message: string, value: unknown);
}
export declare class ClientStoppedError extends Error {
    constructor();
}
export declare class UnsupportedDelayedEventsEndpointError extends Error {
    clientEndpoint: "sendDelayedEvent" | "updateDelayedEvent" | "cancelScheduledDelayedEvent" | "restartScheduledDelayedEvent" | "sendScheduledDelayedEvent" | "sendDelayedStateEvent" | "getDelayedEvents";
    constructor(message: string, clientEndpoint: "sendDelayedEvent" | "updateDelayedEvent" | "cancelScheduledDelayedEvent" | "restartScheduledDelayedEvent" | "sendScheduledDelayedEvent" | "sendDelayedStateEvent" | "getDelayedEvents");
}
export declare class UnsupportedStickyEventsEndpointError extends Error {
    clientEndpoint: "sendStickyEvent" | "sendStickyStateEvent";
    constructor(message: string, clientEndpoint: "sendStickyEvent" | "sendStickyStateEvent");
}
/**
 * Base class for SDK errors - D7 Compliant
 */
export declare class SdkError extends Error {
    readonly errorCode?: string;
    readonly traceId?: string;
    readonly userTip?: string;
    readonly retryAfter?: number;
    readonly isRetryable: boolean;
    readonly statusCode: number;
    constructor(message: string, options?: {
        errorCode?: string;
        traceId?: string;
        userTip?: string;
        retryAfter?: number;
        isRetryable?: boolean;
        statusCode?: number;
        cause?: unknown;
    });
}
export declare class AuthError extends SdkError {
    constructor(message: string, cause?: unknown);
}
export declare class NotFoundError extends SdkError {
    constructor(message: string, cause?: unknown);
}
export declare class RetryableError extends SdkError {
    constructor(message: string, cause?: unknown);
}
export declare class ApiError extends SdkError {
    constructor(message: string, errorCode?: string, statusCode?: number, cause?: unknown);
}
export declare class ValidationError extends SdkError {
    constructor(message: string, cause?: unknown);
}
//# sourceMappingURL=errors.d.ts.map