import type { IAuthData } from "./interactive-auth";
export declare enum InvalidCryptoStoreState {
    TooNew = "TOO_NEW"
}
export declare class InvalidCryptoStoreError extends Error {
    readonly reason: InvalidCryptoStoreState;
    static TOO_NEW: InvalidCryptoStoreState;
    constructor(reason: InvalidCryptoStoreState);
}
export declare class KeySignatureUploadError extends Error {
    readonly value: unknown;
    constructor(message: string, value: unknown);
}
export declare class ClientStoppedError extends Error {
    constructor();
}
export declare class UnsupportedDelayedEventsEndpointError extends Error {
    clientEndpoint: "sendDelayedEvent" | "updateDelayedEvent" | "cancelScheduledDelayedEvent" | "restartScheduledDelayedEvent" | "sendScheduledDelayedEvent" | "sendDelayedStateEvent" | "getDelayedEvents";
    constructor(message: string, clientEndpoint: "sendDelayedEvent" | "updateDelayedEvent" | "cancelScheduledDelayedEvent" | "restartScheduledDelayedEvent" | "sendScheduledDelayedEvent" | "sendDelayedStateEvent" | "getDelayedEvents");
}
export declare class UnsupportedStickyEventsEndpointError extends Error {
    clientEndpoint: "sendStickyEvent" | "sendStickyStateEvent";
    constructor(message: string, clientEndpoint: "sendStickyEvent" | "sendStickyStateEvent");
}
/**
 * Base class for SDK errors - D7 Compliant
 */
export declare class SdkError extends Error {
    readonly errorCode?: string;
    readonly traceId?: string;
    readonly userTip?: string;
    readonly retryAfter?: number;
    readonly isRetryable: boolean;
    readonly statusCode: number;
    constructor(message: string, options?: {
        errorCode?: string;
        traceId?: string;
        userTip?: string;
        retryAfter?: number;
        isRetryable?: boolean;
        statusCode?: number;
        cause?: unknown;
    });
}
export declare class AuthError extends SdkError {
    constructor(message: string, cause?: unknown);
}
export declare class UIAError extends SdkError {
    readonly data: IAuthData;
    constructor(data: IAuthData, cause?: unknown);
}
export declare class NotFoundError extends SdkError {
    constructor(message: string, cause?: unknown);
}
export declare class RetryableError extends SdkError {
    constructor(message: string, cause?: unknown);
    /**
     * Check if this error was due to rate-limiting on the server side.
     *
     * Mirrors {@link HTTPError.isRateLimitError} for unified error handling
     * after {@link BaseManager.normalizeError} converts HTTPError to SdkError.
     *
     * @returns Whether this error is due to rate-limiting (HTTP 429 or M_LIMIT_EXCEEDED).
     */
    isRateLimitError(): boolean;
}
export declare class ApiError extends SdkError {
    constructor(message: string, errorCode?: string, statusCode?: number, cause?: unknown);
}
export declare class ValidationError extends SdkError {
    constructor(message: string, cause?: unknown);
}
/**
 * Invalid parameter error.
 *
 * Kept as a distinct class for API ergonomics, but extends {@link ValidationError}
 * so generic validation callers and `instanceof ValidationError` checks continue
 * to work after the 2026 validator unification.
 */
export declare class InvalidParamError extends ValidationError {
    constructor(message: string, cause?: unknown);
}
//# sourceMappingURL=errors.d.ts.map