export declare const INVITE_LINK_ROUTES_ENTRY_COUNT: 2;
export declare const INVITE_LINK_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 404;
    readonly note: "token 不存在 | 链接无效";
}, {
    readonly status: 400;
    readonly note: "token 已过期 | 邀请已过期，请重新索取";
}, {
    readonly status: 403;
    readonly note: "token 已被使用过 | 邀请已被领取";
}];
export type InviteLinkStatusScenario = (typeof INVITE_LINK_ROUTES_STATUS_SCENARIOS)[number];
export declare const INVITE_LINK_ROUTES_ERROR_SCENARIOS: readonly [];
export type InviteLinkErrorScenario = (typeof INVITE_LINK_ROUTES_ERROR_SCENARIOS)[number];
export declare const INVITE_LINK_ROUTES_ERRCODES: readonly [];
export type InviteLinkErrcode = (typeof INVITE_LINK_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map