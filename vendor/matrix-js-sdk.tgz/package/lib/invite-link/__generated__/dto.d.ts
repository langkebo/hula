/**
 * DTO snippets extracted from the contract doc for `invite-link`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface OneTimeInviteCreated {
    /** 明文令牌，仅此一次返回 */
    token: string;
    /** 过期时刻（毫秒时间戳） */
    expires_at: number;
    /** 可直接分享的兑换链接 */
    deep_link: string;
}
export interface OneTimeInviteClaimed {
    room_id: string;
    /** 后端可能返回 null（未设别名） */
    room_alias: string | null;
}
//# sourceMappingURL=dto.d.ts.map