/**
 * Room State Manager - 房间状态管理
 *
 * 提供房间状态获取、设置等功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IContent } from "../models/event";
export interface IStateEvent {
    type: string;
    state_key: string;
    content: IContent;
    sender: string;
    event_id: string;
    origin_server_ts: number;
}
export interface ISendStateEventResponse {
    event_id: string;
}
export interface IEncryptionConfig {
    [key: string]: unknown;
    algorithm: string;
    rotation_period_ms?: number;
    rotation_period_msgs?: number;
}
export interface RoomStateManagerEvents {
    state_event_sent: {
        roomId: string;
        eventType: string;
        stateKey: string;
    };
    state_updated: {
        roomId: string;
    };
}
export declare class RoomStateManager extends BaseManager<keyof RoomStateManagerEvents, RoomStateManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    roomState(roomId: string, eventType?: string): Promise<IStateEvent[]>;
    getStateEvents(roomId: string, eventType?: string, stateKey?: string): Promise<IStateEvent | IStateEvent[]>;
    getAllStateEvents(roomId: string): Promise<IStateEvent[]>;
    getStateEventsByType(roomId: string, eventType: string): Promise<IStateEvent[]>;
    sendStateEvent(roomId: string, eventType: string, content: IContent, stateKey?: string): Promise<ISendStateEventResponse>;
    getRoomEncryption(roomId: string): Promise<IEncryptionConfig | null>;
    setRoomEncryption(roomId: string, config: IEncryptionConfig): Promise<ISendStateEventResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map