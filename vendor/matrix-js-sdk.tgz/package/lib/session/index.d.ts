/**
 * Session Manager - 会话管理
 *
 * 提供登录、登出、会话管理等功能
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
import { type EmptyObject } from "../@types/common";
export declare class SessionManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Logout
     */
    logout(stopClient?: boolean): Promise<EmptyObject>;
    /**
     * Deactivate account
     */
    deactivateAccount(): Promise<{
        id_server_unbind_result: string;
    }>;
    /**
     * Get access token
     */
    getAccessToken(): string | null;
    /**
     * Check if logged in
     */
    isLoggedIn(): boolean;
    /**
     * Get session ID
     */
    getSessionId(): string | null;
    /**
     * Who am I
     */
    whoami(): Promise<unknown>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map