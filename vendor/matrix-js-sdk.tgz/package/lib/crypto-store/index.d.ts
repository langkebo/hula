/**
 * Crypto Store Manager - 加密存储管理
 *
 * 提供加密存储相关功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface CryptoStoreInfo {
    type: string;
    exists: boolean;
}
export interface CryptoStoreManagerEvents {
    store_created: void;
    store_deleted: void;
    store_ready: void;
}
export declare class CryptoStoreManager extends BaseManager<keyof CryptoStoreManagerEvents, CryptoStoreManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getCryptoStore(): unknown;
    setCryptoStore(store: unknown): void;
    deleteCryptoStore(): Promise<void>;
    isCryptoStoreReady(): boolean;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map