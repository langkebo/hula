/**
 * Room Settings Manager - 房间设置管理
 *
 * 提供房间设置相关功能
 */
import { MatrixClient } from "../client";
import type { ISendEventResponse } from "../@types/requests";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface RoomSettingsManagerEvents {
    room_name_changed: {
        roomId: string;
        name: string;
    };
    room_topic_changed: {
        roomId: string;
        topic: string;
    };
    room_avatar_changed: {
        roomId: string;
        avatarUrl: string;
    };
    room_history_visibility_changed: {
        roomId: string;
        visibility: string;
    };
    room_guest_access_changed: {
        roomId: string;
        allow: boolean;
    };
    room_join_rule_changed: {
        roomId: string;
        joinRule: string;
    };
}
export declare class RoomSettingsManager extends BaseManager<keyof RoomSettingsManagerEvents, RoomSettingsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getRoomName(roomId: string): string;
    setRoomName(roomId: string, name: string): Promise<ISendEventResponse>;
    getRoomTopic(roomId: string): string;
    setRoomTopic(roomId: string, topic: string): Promise<ISendEventResponse>;
    getRoomAvatarUrl(roomId: string): string;
    setRoomAvatar(roomId: string, avatarUrl: string): Promise<void>;
    getRoomHistoryVisibility(roomId: string): string;
    setRoomHistoryVisibility(roomId: string, visibility: string): Promise<void>;
    getRoomGuestAccess(roomId: string): string;
    setRoomGuestAccess(roomId: string, allow: boolean | string): Promise<void>;
    getRoomJoinRule(roomId: string): string;
    setRoomJoinRule(roomId: string, joinRule: string): Promise<void>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map