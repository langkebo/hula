/**
 * Lifecycle Manager - 生命周期管理
 *
 * 提供客户端生命周期相关功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IClientOptions {
    baseUrl?: string;
    idBaseUrl?: string;
    accessToken?: string;
    userId?: string;
    deviceId?: string;
    sessionStore?: unknown;
    store?: unknown;
    scheduler?: unknown;
    cryptoStore?: unknown;
    verificationMethods?: string[];
}
export interface LifecycleManagerEvents {
    client_started: void;
    client_stopped: void;
    client_reset: void;
    client_terminated: void;
}
export declare class LifecycleManager extends BaseManager<keyof LifecycleManagerEvents, LifecycleManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    startClient(): Promise<void>;
    stopClient(): Promise<void>;
    isClientRunning(): boolean;
    exit(code?: number): Promise<void>;
    terminate(): void;
    reset(): Promise<void>;
    prepare(clientOptions?: IClientOptions): Promise<void>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map