import type { EmptyObject } from "./@types/common";
import type { MatrixClient } from "./client";
import type { MatrixEvent } from "./models/event";
import { ReceiptType } from "./@types/read_receipts";
import type { Room } from "./models/room";
/**
 * Receipt body data sent with a read receipt request.
 * May contain arbitrary keys like `thread_id` or `hidden`.
 */
export type ReceiptBody = Record<string, unknown>;
export interface SendReceiptOptions {
    event: MatrixEvent;
    receiptType: ReceiptType;
    body?: ReceiptBody;
    unthreaded: boolean;
    isGuest: boolean;
    supportsThreads: boolean;
    userId: string | null;
}
export declare function buildReceiptPath(event: MatrixEvent, receiptType: ReceiptType): string;
export declare function buildReceiptBody(body: ReceiptBody | undefined, event: MatrixEvent, unthreaded: boolean, supportsThreads: boolean): ReceiptBody | undefined;
export declare function sendReceiptRequest(client: MatrixClient, options: SendReceiptOptions): Promise<EmptyObject>;
export interface SetRoomReadMarkersOptions {
    roomId: string;
    rmEventId: string;
    rrEventId?: string;
    rpEventId?: string;
    /**
     * MSC4446: when true, the server allows the `m.fully_read` marker to move
     * backwards to an earlier event (instead of enforcing monotonic forward
     * movement). Defaults to false (monotonic) when omitted.
     */
    allowBackward?: boolean;
}
export interface ReadMarkersBody {
    "m.fully_read": string;
    "m.read"?: string;
    "m.read.private"?: string;
    /** MSC4446: backward read marker flag. */
    allow_backward?: boolean;
}
export declare function setRoomReadMarkersHttpRequest(client: MatrixClient, options: SetRoomReadMarkersOptions): Promise<EmptyObject>;
export interface SetRoomReadMarkersFullOptions {
    roomId: string;
    rmEventId: string;
    rrEvent?: MatrixEvent;
    rpEvent?: MatrixEvent;
    userId: string;
}
export declare function setRoomReadMarkersWithLocalEcho(_client: MatrixClient, room: Room | null, options: SetRoomReadMarkersFullOptions, httpHandler: (roomId: string, rmEventId: string, rrEventId?: string, rpEventId?: string) => Promise<EmptyObject>): Promise<EmptyObject>;
//# sourceMappingURL=client-receipt-requests.d.ts.map