import type { EmptyObject } from "./@types/common";
import type { MatrixClient } from "./client";
import type { MatrixEvent } from "./models/event";
import { ReceiptType } from "./@types/read_receipts";
import type { Room } from "./models/room";
export interface SendReceiptOptions {
    event: MatrixEvent;
    receiptType: ReceiptType;
    body?: Record<string, unknown>;
    unthreaded: boolean;
    isGuest: boolean;
    supportsThreads: boolean;
    userId: string | null;
}
export declare function buildReceiptPath(event: MatrixEvent, receiptType: ReceiptType): string;
export declare function buildReceiptBody(body: Record<string, unknown> | undefined, // Dynamic: receipt body may contain arbitrary keys like thread_id
event: MatrixEvent, unthreaded: boolean, supportsThreads: boolean): Record<string, unknown> | undefined;
export declare function sendReceiptRequest(client: MatrixClient, options: SendReceiptOptions): Promise<EmptyObject>;
export interface SetRoomReadMarkersOptions {
    roomId: string;
    rmEventId: string;
    rrEventId?: string;
    rpEventId?: string;
}
export interface ReadMarkersBody {
    "m.fully_read": string;
    "m.read"?: string;
    "m.read.private"?: string;
}
export declare function setRoomReadMarkersHttpRequest(client: MatrixClient, options: SetRoomReadMarkersOptions): Promise<EmptyObject>;
export interface SetRoomReadMarkersFullOptions {
    roomId: string;
    rmEventId: string;
    rrEvent?: MatrixEvent;
    rpEvent?: MatrixEvent;
    userId: string;
}
export declare function setRoomReadMarkersWithLocalEcho(_client: MatrixClient, room: Room | null, options: SetRoomReadMarkersFullOptions, httpHandler: (roomId: string, rmEventId: string, rrEventId?: string, rpEventId?: string) => Promise<EmptyObject>): Promise<EmptyObject>;
//# sourceMappingURL=client-receipt-requests.d.ts.map