import { MatrixClient } from "../../client";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import type { IBlacklistEntry } from "./federation-blacklist-types";
export declare enum FederationBlacklistEvent {
    BlacklistUpdated = "BlacklistUpdated",
    BlacklistError = "BlacklistError"
}
interface FederationBlacklistEventMap {
    [FederationBlacklistEvent.BlacklistUpdated]: (blacklist: IBlacklistEntry[]) => void;
    [FederationBlacklistEvent.BlacklistError]: (error: Error) => void;
}
export declare class FederationBlacklistManager extends BaseManager<FederationBlacklistEvent, FederationBlacklistEventMap> {
    private blacklist;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取联邦黑名单
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 黑名单列表
     */
    getBlacklist(throwOnError?: boolean): Promise<IBlacklistEntry[]>;
    addToBlacklist(serverName: string, reason?: string): Promise<void>;
    removeFromBlacklist(serverName: string): Promise<void>;
    isBlacklisted(serverName: string): Promise<boolean>;
    getCachedBlacklist(): IBlacklistEntry[];
    clearCache(): void;
}
export {};
//# sourceMappingURL=federation-blacklist-manager.d.ts.map