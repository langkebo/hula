/**
 * Federation Blacklist Sub-Manager Types - 联邦黑名单子管理器类型
 */
export interface IBlacklistEntry {
    serverName: string;
    reason?: string;
    addedAt: number;
    addedBy?: string;
}
//# sourceMappingURL=federation-blacklist-types.d.ts.map