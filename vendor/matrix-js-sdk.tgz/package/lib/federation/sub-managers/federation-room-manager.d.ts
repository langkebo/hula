import { MatrixClient } from "../../client";
import { BaseManager, type ManagerOpts, type RequestSpec } from "../../managers/base-manager";
import type { IFederationHierarchyResponse, IFederationRoomEventResponse, IFederationEventAuthResponse, IFederationJoiningRulesResponse, IFederationRoomAuthResponse, IFederationStateResponse, IFederationStateIdsResponse, IFederationMembersResponse, IFederationJoinedMembersResponse, IFederationEventDetailResponse, IFederationMediaDownloadResponse, IFederationMediaThumbnailResponse, IFederationBackfillResponse } from "./federation-room-types";
export declare enum FederationRoomEvent {
    FederationError = "FederationError"
}
interface FederationRoomEventMap {
    [FederationRoomEvent.FederationError]: (error: Error) => void;
}
export declare class FederationRoomManager extends BaseManager<FederationRoomEvent, FederationRoomEventMap> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Federation 端点（`/_matrix/federation/v1/*`、`/_synapse/federation/v1/*`）
     * 是 server-to-server 接口，不需要用户 access token。
     *
     * 当 `prefix === ""` 时自动走 `client.http.request`（不带 token）；
     * admin 端点（`prefix === AdminPrefix.V1`）仍走默认的 `authedRequest`。
     */
    protected request<T>(spec: RequestSpec): Promise<T>;
    /**
     * 通过联邦获取房间层级
     * @param roomId - 房间 ID
     */
    getHierarchy(roomId: string): Promise<IFederationHierarchyResponse>;
    /**
     * 通过联邦获取房间事件
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     */
    getRoomEvent(roomId: string, eventId: string): Promise<IFederationRoomEventResponse>;
    /**
     * 通过联邦下载远端媒体
     * @param serverName - 远端 server name
     * @param mediaId - 媒体 ID
     */
    downloadMedia(serverName: string, mediaId: string): Promise<IFederationMediaDownloadResponse>;
    /**
     * 通过联邦获取远端媒体缩略图
     * @param serverName - 远端 server name
     * @param mediaId - 媒体 ID
     */
    getMediaThumbnail(serverName: string, mediaId: string): Promise<IFederationMediaThumbnailResponse>;
    /**
     * 获取事件授权链
     *
     * 对应 GET /_synapse/federation/v1/event_auth
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @param eventId - 事件 ID (e.g., "$event:example.com")
     * @returns 事件授权链
     *
     * @example
     * ```typescript
     * const authChain = await manager.getEventAuth("!room:example.com", "$event:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID or event ID is empty
     * @throws {Error} If the request fails
     */
    getEventAuth(roomId: string, eventId: string): Promise<IFederationEventAuthResponse>;
    /**
     * 获取房间加入规则
     *
     * 对应 GET /_synapse/federation/v1/get_joining_rules/{room_id}
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @returns 房间加入规则
     *
     * @example
     * ```typescript
     * const rules = await manager.getJoiningRules("!room:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    getJoiningRules(roomId: string): Promise<IFederationJoiningRulesResponse>;
    /**
     * 获取房间联邦授权
     *
     * 对应 GET /_synapse/federation/v1/room_auth/{room_id}
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @returns 房间联邦授权信息
     *
     * @example
     * ```typescript
     * const auth = await manager.getRoomAuth("!room:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    getRoomAuth(roomId: string): Promise<IFederationRoomAuthResponse>;
    /**
     * 通过联邦获取房间状态
     *
     * 对应 GET /_matrix/federation/v1/state/{room_id}
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @returns 房间状态
     *
     * @example
     * ```typescript
     * const state = await manager.getState("!room:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    getState(roomId: string): Promise<IFederationStateResponse>;
    /**
     * 通过联邦获取房间状态 ID 列表
     *
     * 对应 GET /_matrix/federation/v1/state_ids/{room_id}
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @returns 房间状态 ID 列表
     *
     * @example
     * ```typescript
     * const stateIds = await manager.getStateIds("!room:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    getStateIds(roomId: string): Promise<IFederationStateIdsResponse>;
    /**
     * 通过联邦获取房间成员列表
     *
     * 对应 GET /_matrix/federation/v1/members/{room_id}
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @returns 成员列表
     *
     * @example
     * ```typescript
     * const members = await manager.getMembers("!room:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    getMembers(roomId: string): Promise<IFederationMembersResponse>;
    /**
     * 通过联邦获取房间已加入成员列表
     *
     * 对应 GET /_matrix/federation/v1/members/{room_id}/joined
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @returns 已加入成员列表
     *
     * @example
     * ```typescript
     * const joinedMembers = await manager.getJoinedMembers("!room:example.com");
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    getJoinedMembers(roomId: string): Promise<IFederationJoinedMembersResponse>;
    /**
     * 通过联邦获取事件
     *
     * 对应 GET /_matrix/federation/v1/event/{event_id}
     *
     * @param eventId - 事件 ID (e.g., "$event:example.com")
     * @returns 事件数据
     *
     * @example
     * ```typescript
     * const event = await manager.getEvent("$event:example.com");
     * ```
     *
     * @throws {ValidationError} If event ID is empty
     * @throws {Error} If the request fails
     */
    getEvent(eventId: string): Promise<IFederationEventDetailResponse>;
    /**
     * 通过联邦回填房间历史
     *
     * 对应 GET /_matrix/federation/v1/backfill/{room_id}
     *
     * @param roomId - 房间 ID (e.g., "!room:example.com")
     * @param opts - 可选参数
     * @param opts.limit - 最大事件数量
     * @param opts.from - 起始事件 ID
     * @returns 回填结果
     *
     * @example
     * ```typescript
     * const result = await manager.backfillRoom("!room:example.com", { limit: 10 });
     * ```
     *
     * @throws {ValidationError} If room ID is empty
     * @throws {Error} If the request fails
     */
    backfillRoom(roomId: string, opts?: {
        limit?: number;
        from?: string;
    }): Promise<IFederationBackfillResponse>;
}
export {};
//# sourceMappingURL=federation-room-manager.d.ts.map