import { MatrixClient } from "../../client";
import { BaseManager, type ManagerOpts, type RequestSpec } from "../../managers/base-manager";
import type { IUserProfile } from "../../user-directory/index";
export declare enum FederationQueryEvent {
    FederationError = "FederationError"
}
interface FederationQueryEventMap {
    [FederationQueryEvent.FederationError]: (error: Error) => void;
}
export declare class FederationQueryManager extends BaseManager<FederationQueryEvent, FederationQueryEventMap> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Federation 端点（`/_matrix/federation/v1/*`、`/_synapse/federation/v1/*`）
     * 是 server-to-server 接口，不需要用户 access token。
     *
     * 当 `prefix === ""` 时自动走 `client.http.request`（不带 token）；
     * admin 端点（`prefix === AdminPrefix.V1`）仍走默认的 `authedRequest`。
     */
    protected request<T>(spec: RequestSpec): Promise<T>;
    /**
     * 通过联邦查询用户资料
     * @param userId - 用户 ID
     */
    queryProfile(userId: string): Promise<IUserProfile>;
    /**
     * 通过联邦查询房间别名
     * @param roomAlias - 房间别名
     */
    queryDirectory(roomAlias: string): Promise<{
        room_id: string;
        servers: string[];
    }>;
    /**
     * 通过联邦查询目的地
     * @param destination - 目标 server name
     */
    queryDestination(destination: string): Promise<unknown>;
    /**
     * 查询联邦授权
     *
     * 对应 GET /_synapse/federation/v1/query/auth
     *
     * @returns 联邦授权信息
     *
     * @example
     * ```typescript
     * const auth = await manager.queryAuth();
     * ```
     *
     * @throws {Error} If the request fails
     */
    queryAuth(): Promise<unknown>;
    /**
     * 获取联邦发现信息
     */
    getFederationInfo(): Promise<unknown>;
    getPublicRoomsOnServer(serverName: string, limit?: number, since?: string): Promise<{
        chunk: unknown[];
        next_batch?: string;
        prev_batch?: string;
    }>;
}
export {};
//# sourceMappingURL=federation-query-manager.d.ts.map