import { MatrixClient } from "../../client";
import { BaseManager, type ManagerOpts, type RequestSpec } from "../../managers/base-manager";
import type { IFederationServer, IFederationStatus } from "./federation-server-types";
export declare enum FederationServerEvent {
    ServerAdded = "ServerAdded",
    ServerRemoved = "ServerRemoved",
    FederationError = "FederationError"
}
interface FederationServerEventMap {
    [FederationServerEvent.ServerAdded]: (serverName: string) => void;
    [FederationServerEvent.ServerRemoved]: (serverName: string) => void;
    [FederationServerEvent.FederationError]: (error: Error) => void;
}
export declare class FederationServerManager extends BaseManager<FederationServerEvent, FederationServerEventMap> {
    private serverCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Federation 端点（`/_matrix/federation/v1/*`、`/_synapse/federation/v1/*`）
     * 是 server-to-server 接口，不需要用户 access token。
     *
     * 当 `prefix === ""` 时自动走 `client.http.request`（不带 token）；
     * admin 端点（`prefix === AdminPrefix.V1`）仍走默认的 `authedRequest`。
     */
    protected request<T>(spec: RequestSpec): Promise<T>;
    /**
     * 获取服务器状态
     *
     * @param serverName - 服务器名称
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器状态
     */
    getServerStatus(serverName: string, throwOnError?: boolean): Promise<IFederationStatus | null>;
    /**
     * 获取联邦目的地列表
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 目的地列表
     */
    getFederationDestinations(throwOnError?: boolean): Promise<IFederationServer[]>;
    disconnectServer(serverName: string): Promise<void>;
    reconnectServer(serverName: string): Promise<void>;
    /**
     * 获取服务器版本
     *
     * @param serverName - 服务器名称
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器版本
     */
    getServerVersion(serverName: string, throwOnError?: boolean): Promise<{
        version: string;
    } | null>;
    getCachedServer(serverName: string): IFederationServer | null;
    getCachedServers(): IFederationServer[];
    clearCache(): void;
}
export {};
//# sourceMappingURL=federation-server-manager.d.ts.map