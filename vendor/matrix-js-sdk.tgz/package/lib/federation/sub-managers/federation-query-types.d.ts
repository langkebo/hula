/**
 * Federation Query Sub-Manager Types - 联邦查询子管理器类型
 */
import type { IUserProfile } from "../../user-directory/index";
export interface IQueryDirectoryResult {
    room_id: string;
    servers: string[];
}
export type { IUserProfile };
//# sourceMappingURL=federation-query-types.d.ts.map