/**
 * Federation Server Sub-Manager Types - 联邦服务器子管理器类型
 */
export interface IFederationServer {
    serverName: string;
    addedAt?: number;
    reason?: string;
}
export interface IFederationStatus {
    online: boolean;
    lastSuccessfulConnect?: number;
    latency?: number;
}
//# sourceMappingURL=federation-server-types.d.ts.map