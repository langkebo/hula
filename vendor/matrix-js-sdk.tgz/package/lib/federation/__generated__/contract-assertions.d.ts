export declare const FEDERATION_ROUTES_ENTRY_COUNT: 52;
export declare const FEDERATION_ROUTES_STATUS_SCENARIOS: readonly [];
export type FederationStatusScenario = (typeof FEDERATION_ROUTES_STATUS_SCENARIOS)[number];
export declare const FEDERATION_ROUTES_ERROR_SCENARIOS: readonly [];
export type FederationErrorScenario = (typeof FEDERATION_ROUTES_ERROR_SCENARIOS)[number];
export declare const FEDERATION_ROUTES_ERRCODES: readonly [];
export type FederationErrcode = (typeof FEDERATION_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map