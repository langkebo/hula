export declare const FEDERATION_ROUTES_ENTRY_COUNT: 52;
export declare const FEDERATION_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 401;
    readonly note: "联邦签名认证失败";
}, {
    readonly status: 404;
    readonly note: "房间、事件、媒体或资源不存在";
}];
export type FederationStatusScenario = (typeof FEDERATION_ROUTES_STATUS_SCENARIOS)[number];
export declare const FEDERATION_ROUTES_ERROR_SCENARIOS: readonly [];
export type FederationErrorScenario = (typeof FEDERATION_ROUTES_ERROR_SCENARIOS)[number];
export declare const FEDERATION_ROUTES_ERRCODES: readonly [];
export type FederationErrcode = (typeof FEDERATION_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map