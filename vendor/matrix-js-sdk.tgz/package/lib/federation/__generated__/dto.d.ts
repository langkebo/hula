/**
 * DTO snippets extracted from the contract doc for `federation`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
import type { ISignatures } from "../../@types/signed.ts";
export type FederationJsonValue = string | number | boolean | null | FederationJsonValue[] | {
    [key: string]: FederationJsonValue;
};
export interface VerifyKey {
    key: string;
}
export interface SignedServerKey {
    server_name: string;
    valid_until_ts: number;
    verify_keys: {
        [keyId: string]: VerifyKey;
    };
    old_verify_keys?: {
        [keyId: string]: VerifyKey & {
            expired_ts: number;
        };
    };
    signatures?: ISignatures;
}
export interface ServerKeysQueryResponse {
    server_keys: SignedServerKey[];
}
export interface FederationVersionResponse {
    server: {
        name: string;
        version: string;
    };
}
export interface FederationDiscoveryResponse {
    version: string;
    server_name: string;
    capabilities: {
        "m.change_password": boolean;
        "m.room_versions": FederationJsonValue;
    };
}
export interface OpenIdUserInfoResponse {
    sub: string;
}
export interface FederationPublicRoomsChunkItem {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    num_joined_members: number;
    world_readable: boolean;
    guest_can_join: boolean;
}
export interface FederationPublicRoomsResponse {
    chunk: FederationPublicRoomsChunkItem[];
    total_room_count_estimate: number;
    next_batch?: string;
}
export interface DirectoryQueryResponse {
    room_id: string;
    servers: string[];
}
export interface DestinationQueryResponse {
    server_name: string;
    destination: string;
    retry_last_ts: number;
    retry_interval_ms: number;
    capabilities: FederationJsonValue;
}
export interface ProfileQueryResponse {
    displayname?: string;
    avatar_url?: string;
}
export interface TimestampToEventResponse {
    event_id: string | null;
    origin_server_ts: number;
}
export interface FederationStateResponse {
    room_id: string;
    origin: string;
    pdus: FederationJsonValue[];
    auth_chain: FederationJsonValue[];
}
export interface FederationStateIdsResponse {
    room_id: string;
    origin: string;
    pdu_ids: string[];
    auth_chain_ids: string[];
}
export interface FederationBackfillResponse {
    origin: string;
    origin_server_ts: number;
    pdus: FederationJsonValue[];
    auth_chain: FederationJsonValue[];
}
export interface FederationRoomAuthResponse {
    room_id: string;
    auth_chain: FederationJsonValue[];
}
export interface FederationEventAuthResponse {
    auth_chain: FederationJsonValue[];
}
export interface FederationMissingEventsResponse {
    events: FederationJsonValue[];
}
export interface FederationKeysClaimResponse {
    one_time_keys: {
        [userId: string]: {
            [deviceId: string]: {
                [keyName: string]: FederationJsonValue;
            };
        };
    };
    failures: {
        [serverName: string]: FederationJsonValue;
    };
}
export interface FederationKeysQueryResponse {
    device_keys: {
        [userId: string]: {
            [deviceId: string]: FederationJsonValue;
        };
    };
    master_keys?: {
        [userId: string]: FederationJsonValue;
    };
    self_signing_keys?: {
        [userId: string]: FederationJsonValue;
    };
    user_signing_keys?: {
        [userId: string]: FederationJsonValue;
    };
    failures: {
        [serverName: string]: FederationJsonValue;
    };
}
//# sourceMappingURL=dto.d.ts.map