/**
 * Federation Manager - 联邦管理（门面）
 *
 * 本文件已拆分为 4 个 sub-manager，调用方应直接使用 sub-manager：
 * - `fed.blacklist.*`：黑名单 CRUD
 * - `fed.server.*`：服务器状态/连接
 * - `fed.query.*`：联邦查询
 * - `fed.room.*`：联邦房间/事件/状态
 *
 * FederationManager 仅保留未迁移方法（claimKeys/queryKeys 等）及生命周期管理。
 *
 * ## 后端对齐说明（synapse-rust v10，2026-06）
 *
 * - **C-1 X-Matrix 时间戳校验**: 后端已实现 ±30s 滑动窗口 + nonce 缓存校验。
 *   当通过本 manager 代理 federation 请求时，后端会自动处理 `X-Matrix-Origin` /
 *   `X-Matrix-Timestamp` 请求头，SDK 客户端无需额外设置。
 *
 * - **C-2 Canonical JSON 修复**: 后端已修复 U+2028 (行分隔符) / U+2029 (段落分隔符) /
 *   U+FFFD (替换字符) 的转义处理。SDK 端 JSON 序列化保持不变。
 *
 * - **M_SERVER_NOT_TRUSTED**: 当目标服务器不在信任列表中时，后端返回此错误
 *   (HTTP 502)。调用方可通过 `MatrixError.isServerNotTrustedError()` 检测。
 */
import { BaseManager, type ManagerOpts, type RequestSpec } from "../managers/base-manager";
import { MatrixClient } from "../client";
import { type IEvent } from "../models/event";
import { FederationBlacklistManager } from "./sub-managers/federation-blacklist-manager";
import { FederationServerManager } from "./sub-managers/federation-server-manager";
import { FederationQueryManager } from "./sub-managers/federation-query-manager";
import { FederationRoomManager } from "./sub-managers/federation-room-manager";
import type { IBlacklistEntry } from "./sub-managers/federation-blacklist-types";
import type { IFederationServer, IFederationStatus } from "./sub-managers/federation-server-types";
export declare enum FederationEvent {
    BlacklistUpdated = "BlacklistUpdated",
    ServerAdded = "ServerAdded",
    ServerRemoved = "ServerRemoved",
    FederationError = "FederationError"
}
export type { IBlacklistEntry, IFederationServer, IFederationStatus };
interface FederationManagerEventMap {
    [FederationEvent.BlacklistUpdated]: (blacklist: IBlacklistEntry[]) => void;
    [FederationEvent.ServerAdded]: (serverName: string) => void;
    [FederationEvent.ServerRemoved]: (serverName: string) => void;
    [FederationEvent.FederationError]: (error: Error) => void;
}
export declare class FederationManager extends BaseManager<FederationEvent, FederationManagerEventMap> {
    readonly blacklist: FederationBlacklistManager;
    readonly server: FederationServerManager;
    readonly query: FederationQueryManager;
    readonly room: FederationRoomManager;
    private initialized;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 将 4 个 sub-manager 的事件转发到顶层 FederationEvent，保证旧监听者继续工作。
     */
    private forwardSubManagerEvents;
    /**
     * Federation 端点（`/_matrix/federation/v1/*`、`/_synapse/federation/v1/*`）
     * 是 server-to-server 接口，不需要用户 access token。
     *
     * 当 `prefix === ""` 时自动走 `client.http.request`（不带 token）；
     * admin 端点（`prefix === AdminPrefix.V1`）仍走默认的 `authedRequest`。
     *
     * 注意：本类仍保留 claimKeys/queryKeys/uploadKeys/cloneKey/backfillRoom 等
     * 未迁移方法，因此需要保留此 request 覆盖。
     */
    protected request<T>(spec: RequestSpec): Promise<T>;
    /**
     * 申领联邦密钥
     *
     * 对应 POST /_synapse/federation/v1/keys/claim
     *
     * @param body - 申领密钥请求体
     * @returns 申领密钥响应
     *
     * @example
     * ```typescript
     * const result = await manager.claimKeys({
     *   one_time_keys: { "@user:example.com": { "device_id": "signed_curve25519" } },
     * });
     * ```
     *
     * @throws {ValidationError} If body is empty
     * @throws {Error} If the request fails
     */
    claimKeys(body: Record<string, unknown>): Promise<unknown>;
    /**
     * 查询联邦密钥
     *
     * 对应 POST /_synapse/federation/v1/keys/query
     *
     * @param body - 查询密钥请求体
     * @returns 查询密钥响应
     *
     * @example
     * ```typescript
     * const result = await manager.queryKeys({
     *   device_keys: { "@user:example.com": ["*"] },
     * });
     * ```
     *
     * @throws {ValidationError} If body is empty
     * @throws {Error} If the request fails
     */
    queryKeys(body: Record<string, unknown>): Promise<unknown>;
    /**
     * 上传联邦密钥
     *
     * 对应 POST /_synapse/federation/v1/keys/upload
     *
     * @param body - 上传密钥请求体
     * @returns 上传密钥响应
     *
     * @example
     * ```typescript
     * const result = await manager.uploadKeys({
     *   device_keys: { user_id: "@user:example.com", device_id: "DEVICE", keys: {} },
     *   one_time_keys: {},
     * });
     * ```
     *
     * @throws {ValidationError} If body is empty
     * @throws {Error} If the request fails
     */
    uploadKeys(body: Record<string, unknown>): Promise<unknown>;
    /**
     * 克隆联邦密钥（v2）
     *
     * 对应 POST /_synapse/federation/v2/key/clone
     *
     * @param body - 克隆密钥请求体
     * @returns 克隆密钥响应
     *
     * @example
     * ```typescript
     * const result = await manager.cloneKey({
     *   server_name: "example.com",
     *   key_id: "ed25519:0",
     * });
     * ```
     *
     * @throws {ValidationError} If body is empty
     * @throws {Error} If the request fails
     */
    cloneKey(body: Record<string, unknown>): Promise<unknown>;
    /**
     * Canonical JSON 序列化：将 U+2028（行分隔符）、U+2029（段落分隔符）、
     * U+FFFD（替换字符）转义为对应的 JSON 转义序列，确保与后端 C-2 修复对齐。
     *
     * 注意：在 JSON.stringify 之后替换，避免 replacer 导致的双重转义问题。
     */
    static toCanonicalJson(value: unknown): string;
    /**
     * 发送联邦事件（使用 Canonical JSON 序列化，对齐后端 C-2 修复）
     * 对应 PUT /_matrix/federation/v1/send/{txnId}
     */
    sendFederationEvent(txnId: string, event: IEvent): Promise<void>;
    clearCache(): void;
    start(): Promise<void>;
    stop(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map