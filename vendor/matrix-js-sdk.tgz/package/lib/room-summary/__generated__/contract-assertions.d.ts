export declare const ROOM_SUMMARY_ROUTES_ENTRY_COUNT: 23;
export declare const ROOM_SUMMARY_ROUTES_STATUS_SCENARIOS: readonly [];
export type RoomSummaryStatusScenario = (typeof ROOM_SUMMARY_ROUTES_STATUS_SCENARIOS)[number];
export declare const ROOM_SUMMARY_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "触发登录态恢复，不重试写入类接口";
}, {
    readonly scenario: "房间或摘要不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "视为目标缺失，触发重建或跳过";
}, {
    readonly scenario: "请求参数或摘要结构非法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正 payload 后重试";
}, {
    readonly scenario: "无权限访问摘要";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "终止重试并提示权限不足";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED，5xx";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "指数退避重试读写请求";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 统一处理";
}];
export type RoomSummaryErrorScenario = (typeof ROOM_SUMMARY_ROUTES_ERROR_SCENARIOS)[number];
export declare const ROOM_SUMMARY_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "room summary 或成员摘要不存在";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权限读取或更新目标摘要";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "path/query/body 参数非法";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "触发限流";
}];
export type RoomSummaryErrcode = (typeof ROOM_SUMMARY_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map