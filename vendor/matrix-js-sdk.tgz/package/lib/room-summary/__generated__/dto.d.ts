/**
 * DTO snippets extracted from the contract doc for `room-summary`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type RoomSummaryJsonValue = string | number | boolean | null | RoomSummaryJsonValue[] | {
    [key: string]: RoomSummaryJsonValue;
};
export interface RoomSummaryHeroItem {
    user_id: string;
    display_name?: string;
    avatar_url?: string;
}
export interface RoomSummaryResponse {
    room_id: string;
    room_type?: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    canonical_alias?: string;
    join_rule: string;
    history_visibility: string;
    guest_access: string;
    is_direct: boolean;
    is_space: boolean;
    is_encrypted: boolean;
    member_count: number;
    joined_member_count: number;
    invited_member_count: number;
    heroes: RoomSummaryHeroItem[];
    last_event_ts?: number;
    last_message_ts?: number;
    allowed_room_ids?: string[];
}
export interface CreateRoomSummaryRequest {
    room_id: string;
    room_type?: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    canonical_alias?: string;
    join_rule?: string;
    history_visibility?: string;
    guest_access?: string;
    is_direct?: boolean;
    is_space?: boolean;
}
export interface UpdateRoomSummaryRequest {
    name?: string;
    topic?: string;
    avatar_url?: string;
}
export interface RoomSummaryMemberItem {
    user_id: string;
    display_name?: string;
    avatar_url?: string;
    membership: string;
    is_hero: boolean;
}
export interface CreateRoomSummaryMemberRequest {
    room_id: string;
    user_id: string;
    display_name?: string;
    avatar_url?: string;
    membership: string;
    is_hero?: boolean;
    last_active_ts?: number;
}
export interface UpdateRoomSummaryMemberRequest {
    display_name?: string;
    avatar_url?: string;
    membership?: string;
}
export interface RoomSummaryStateResponse {
    event_type: string;
    state_key: string;
    event_id?: string;
    content: RoomSummaryJsonValue;
}
export interface UpdateRoomSummaryStateRequest {
    event_id?: string;
    content: RoomSummaryJsonValue;
}
export interface RoomSummaryStatsResponse {
    room_id: string;
    total_events: number;
    total_state_events: number;
    total_messages: number;
    total_media: number;
    /**
     * 后端注释明写：**占位值**，尚未真正计算，回落到最后存储值（无行时为 0）。
     * 形状兼容保留，消费方不要据此做容量判断。
     */
    storage_size: number;
}
export interface RecalculateHeroesResponse {
    heroes: string[];
}
export interface ClearUnreadSummaryResponse {
    user_id: string;
    room_id: string;
    unread_notifications: number;
    unread_highlight: number;
}
export interface RoomSummaryListResponse {
    summaries: RoomSummaryResponse[];
    rooms: RoomSummaryResponse[];
    chunk: RoomSummaryResponse[];
    next_batch?: string;
}
export interface RoomSummaryBatchRequest {
    rooms: string[];
    suggested_only?: boolean;
}
export interface RoomSummaryBatchResponse {
    rooms: RoomSummaryResponse[];
    events: RoomSummaryJsonValue[];
    total_room_count_estimate: number;
    next_batch?: string;
}
//# sourceMappingURL=dto.d.ts.map