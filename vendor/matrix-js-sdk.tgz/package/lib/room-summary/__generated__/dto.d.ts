/**
 * DTO snippets extracted from the contract doc for `room_summary`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type RoomSummaryContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map