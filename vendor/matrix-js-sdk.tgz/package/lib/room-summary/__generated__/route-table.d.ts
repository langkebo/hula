/** Routes served by the synapse-rust `room-summary` module (mirrored from the backend contract). */
export declare const ROOM_SUMMARY_ROUTES: readonly [{
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/heroes/recalculate";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/members";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/members";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/members/{user_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/members/{user_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/state";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/state/{event_type}/{state_key}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/state/{event_type}/{state_key}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/stats";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/stats/recalculate";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/sync";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/summary/unread/clear";
}, {
    readonly method: "GET";
    readonly path: "/_synapse/room_summary/v1/summaries";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/room_summary/v1/summaries";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/room_summary/v1/summaries/batch";
}, {
    readonly method: "POST";
    readonly path: "/_synapse/room_summary/v1/updates/process";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/summary";
}];
/** Union of every (method, path) tuple in `ROOM_SUMMARY_ROUTES`. */
export type RoomSummaryRoute = (typeof ROOM_SUMMARY_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type RoomSummaryMethod = RoomSummaryRoute["method"];
/** Path templates referenced by this module. */
export type RoomSummaryPath = RoomSummaryRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type RoomSummaryReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${RoomSummaryReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type RoomSummaryPathPattern = RoomSummaryReplaceBraces<RoomSummaryPath>;
//# sourceMappingURL=route-table.d.ts.map