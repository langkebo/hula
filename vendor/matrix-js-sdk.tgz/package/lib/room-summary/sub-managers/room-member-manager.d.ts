import { MatrixClient } from "../../client";
import { LRUCache } from "../../utils/lru-cache";
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import type { RoomSummaryMember, RoomMembersRecentResult } from "../types";
export declare enum RoomSummaryMemberEvent {
    MembersUpdated = "MembersUpdated"
}
export interface RoomSummaryMemberEventMap {
    [RoomSummaryMemberEvent.MembersUpdated]: (roomId: string, members: RoomSummaryMember[]) => void;
}
export declare class RoomSummaryMemberManager extends RoomSummaryBaseManager<RoomSummaryMemberEvent, RoomSummaryMemberEventMap> {
    private readonly memberCache;
    constructor(client: MatrixClient, memberCache: LRUCache<RoomSummaryMember[]>, onError?: RoomSummaryErrorCallback);
    private summaryMembersPath;
    private summaryMemberPath;
    /**
     * 获取房间成员列表摘要
     *
     * @param roomId - 房间 ID
     * @param forceRefresh - 是否强制刷新缓存
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 成员列表
     */
    getRoomSummaryMembers(roomId: string, forceRefresh?: boolean, throwOnError?: boolean): Promise<RoomSummaryMember[]>;
    /**
     * 写入房间成员列表
     *
     * @param roomId - 房间 ID
     * @param members - 成员列表
     * @returns 写入后的成员列表
     */
    writeSummaryMembers(roomId: string, members: RoomSummaryMember[]): Promise<RoomSummaryMember[]>;
    /**
     * 更新单个成员信息
     *
     * @param roomId - 房间 ID
     * @param userId - 用户 ID
     * @param member - 成员数据
     * @returns 更新后的成员数据
     */
    updateSummaryMember(roomId: string, userId: string, member: Partial<RoomSummaryMember>): Promise<RoomSummaryMember>;
    /**
     * 删除单个成员
     *
     * @param roomId - 房间 ID
     * @param userId - 用户 ID
     */
    deleteSummaryMember(roomId: string, userId: string): Promise<void>;
    /**
     * 获取最近成员变更
     *
     * @param roomId - 房间 ID
     * @param options - 查询选项
     * @returns 最近成员变更结果
     */
    getRoomMembersRecent(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<RoomMembersRecentResult>;
    /**
     * 获取缓存的成员列表
     *
     * @param roomId - 房间 ID
     * @returns 缓存的成员列表，如无缓存则返回空数组
     */
    getCachedMembers(roomId: string): RoomSummaryMember[];
    /**
     * 处理错误
     */
    private handleError;
}
//# sourceMappingURL=room-member-manager.d.ts.map