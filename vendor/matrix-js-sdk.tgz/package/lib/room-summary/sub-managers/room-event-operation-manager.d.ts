import { MatrixClient } from "../../client";
import type { IContent } from "../../models/event";
import { LRUCache } from "../../utils/lru-cache";
/** 翻译事件请求体 */
export interface TranslateEventBody {
    target_lang?: string;
    source_lang?: string;
    text?: string;
    [key: string]: unknown;
}
/** 转换事件请求体 */
export interface ConvertEventBody {
    format?: string;
    [key: string]: unknown;
}
/** 签名事件请求体 */
export interface SignEventBody {
    key_id?: string;
    [key: string]: unknown;
}
/** 验证事件请求体 */
export interface VerifyEventBody {
    signature?: string;
    [key: string]: unknown;
}
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import type { RoomSummary, RoomNotificationsResult, RoomCapabilities, RoomSyncResult, RoomAccountDataResult, RoomInvitesResult, RoomReceiptsResult, TimelineResult, UnreadCountResult, RoomMetadata, RetentionPolicy, ExternalId, RoomSpace, EventPerspective, RoomPermissionsResult, RoomResolveResult, RoomMessageQueueResult, RoomServiceTypesResult, RoomReducedEventsResult, RoomRenderedResult, RoomFragmentsResult, RoomDeviceResult, RoomEventUrlResult, RoomTranslateResult, TranslateResult, RoomConvertResult, RoomSignResult, RoomVerifyResult, TurnServerConfig, StickyEvent, RoomVaultDataResult, UpdateSummaryBody, SyncSummaryResult, ProcessUpdatesResult } from "../types";
/**
 * Room Event Operation Manager - 房间事件操作
 *
 * 处理通知、能力、同步、账户数据、邀请、回执、时间线、未读计数、
 * 元数据、vault 数据、保留策略、外部 ID、空间、事件视角、权限、
 * 解析、消息队列、服务类型、降采样事件、渲染、片段、设备、
 * 事件 URL、翻译、转换、签名、验证、TURN 服务器、sticky events、
 * power levels 等操作。
 * 无缓存、无事件。
 */
export declare class RoomSummaryEventOperationManager extends RoomSummaryBaseManager {
    private readonly onCacheInvalidation?;
    private readonly summaryCache?;
    private readonly onSummaryUpdated?;
    constructor(client: MatrixClient, onCacheInvalidation?: (roomId: string) => void, onError?: RoomSummaryErrorCallback, summaryCache?: LRUCache<RoomSummary>, onSummaryUpdated?: (roomId: string, summary: RoomSummary) => void);
    /**
     * 获取房间通知列表
     *
     * @param roomId - 房间 ID
     * @param options - 分页选项
     */
    getRoomNotifications(roomId: string, options?: {
        from?: string;
        limit?: number;
        only?: string;
    }): Promise<RoomNotificationsResult>;
    /**
     * 获取房间能力
     *
     * @param roomId - 房间 ID
     */
    getRoomCapabilities(roomId: string): Promise<RoomCapabilities>;
    /**
     * 获取房间级同步结果
     *
     * @param roomId - 房间 ID
     * @param options - 同步选项
     */
    getRoomSync(roomId: string, options?: {
        since?: string;
        timeout_ms?: number;
        filter?: string;
    }): Promise<RoomSyncResult>;
    /**
     * 获取房间 account data
     *
     * @param roomId - 房间 ID
     * @param type - 数据类型
     */
    getRoomAccountData(roomId: string, type: string): Promise<RoomAccountDataResult>;
    /**
     * 设置房间 account data
     *
     * @param roomId - 房间 ID
     * @param type - 数据类型
     * @param content - 数据内容
     */
    setRoomAccountDataV3(roomId: string, type: string, content: IContent): Promise<RoomAccountDataResult>;
    /**
     * 获取房间邀请列表
     *
     * @param roomId - 房间 ID
     */
    getRoomInvites(roomId: string): Promise<RoomInvitesResult>;
    /**
     * 获取房间回执
     *
     * @param roomId - 房间 ID
     * @param receiptType - 回执类型
     * @param eventId - 事件 ID
     */
    getRoomReceipts(roomId: string, receiptType: string, eventId: string): Promise<RoomReceiptsResult>;
    /**
     * 获取房间时间线
     *
     * @param roomId - 房间 ID
     * @param options - 时间线选项
     */
    getRoomTimeline(roomId: string, options?: {
        from?: string;
        to?: string;
        dir?: "f" | "b";
        limit?: number;
        filter?: string;
    }): Promise<TimelineResult>;
    /**
     * 获取房间未读计数
     *
     * @param roomId - 房间 ID
     */
    getRoomUnreadCount(roomId: string): Promise<UnreadCountResult>;
    /**
     * 获取房间元数据
     *
     * @param roomId - 房间 ID
     */
    getRoomMetadata(roomId: string): Promise<RoomMetadata>;
    /**
     * 获取房间 vault 数据
     *
     * @param roomId - 房间 ID
     */
    getRoomVaultData(roomId: string): Promise<RoomVaultDataResult | null>;
    /**
     * 设置房间 vault 数据
     *
     * @param roomId - 房间 ID
     * @param data - vault 数据
     */
    setRoomVaultData(roomId: string, data: IContent): Promise<void>;
    /**
     * 获取房间 retention 策略
     *
     * @param roomId - 房间 ID
     */
    getRoomRetention(roomId: string): Promise<RetentionPolicy | null>;
    /**
     * 获取房间外部关联 ID
     *
     * @param roomId - 房间 ID
     */
    getRoomExternalIds(roomId: string): Promise<ExternalId[]>;
    /**
     * 获取房间所属的 space 列表
     *
     * @param roomId - 房间 ID
     */
    getRoomSpaces(roomId: string): Promise<RoomSpace[]>;
    /**
     * 获取房间事件视角数据
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param options - 可选参数
     */
    getRoomEventPerspective(roomId: string, eventId: string, options?: {
        room_version?: string;
    }): Promise<EventPerspective>;
    /**
     * 获取房间权限信息
     *
     * @param roomId - 房间 ID
     */
    getRoomPermissions(roomId: string): Promise<RoomPermissionsResult>;
    /**
     * 获取房间解析信息
     *
     * @param roomId - 房间 ID
     */
    getRoomResolve(roomId: string): Promise<RoomResolveResult>;
    /**
     * 获取房间消息队列
     *
     * @param roomId - 房间 ID
     * @param options - 查询选项
     */
    getRoomMessageQueue(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<RoomMessageQueueResult>;
    /**
     * 获取房间服务类型
     *
     * @param roomId - 房间 ID
     */
    getRoomServiceTypes(roomId: string): Promise<RoomServiceTypesResult>;
    /**
     * 获取房间降采样事件
     *
     * @param roomId - 房间 ID
     */
    getRoomReducedEvents(roomId: string): Promise<RoomReducedEventsResult>;
    /**
     * 获取房间渲染结果
     *
     * @param roomId - 房间 ID
     */
    getRoomRendered(roomId: string): Promise<RoomRenderedResult>;
    /**
     * 获取指定用户的房间片段
     *
     * @param roomId - 房间 ID
     * @param userId - 用户 ID
     */
    getRoomFragments(roomId: string, userId: string): Promise<RoomFragmentsResult>;
    /**
     * 获取房间设备视图
     *
     * @param roomId - 房间 ID
     * @param deviceId - 设备 ID
     */
    getRoomDevice(roomId: string, deviceId: string): Promise<RoomDeviceResult>;
    /**
     * 获取房间事件的可访问 URL
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     */
    getRoomEventUrl(roomId: string, eventId: string): Promise<RoomEventUrlResult>;
    /**
     * 翻译房间事件
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param body - 翻译请求体，支持以下字段：
     *   - `target_lang`: 目标语言代码（如 "en", "zh", "ja"），默认使用后端配置
     *   - `source_lang`: 源语言代码（可选，不指定则自动检测）
     *   - `text`: 待翻译文本（可选，不指定则使用事件 body）
     */
    translateRoomEvent(roomId: string, eventId: string, body?: TranslateEventBody): Promise<RoomTranslateResult>;
    /**
     * 转换房间事件
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param body - 转换请求体
     */
    convertRoomEvent(roomId: string, eventId: string, body?: ConvertEventBody): Promise<RoomConvertResult>;
    /**
     * 签名房间事件
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param body - 签名请求体
     */
    signRoomEvent(roomId: string, eventId: string, body?: SignEventBody): Promise<RoomSignResult>;
    /**
     * 验证房间事件
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param body - 验证请求体
     */
    verifyRoomEvent(roomId: string, eventId: string, body?: VerifyEventBody): Promise<RoomVerifyResult>;
    /**
     * 获取房间 TURN 服务器配置
     *
     * @param roomId - 房间 ID
     */
    getRoomTurnServer(roomId: string): Promise<TurnServerConfig>;
    /**
     * 获取房间防截屏设置
     *
     * GET /_matrix/client/v3/rooms/{roomId}/anti_screenshot
     *
     * @param roomId - 房间 ID
     * @returns 防截屏设置 { enabled: boolean }
     */
    getAntiScreenshot(roomId: string): Promise<{
        enabled: boolean;
    }>;
    /**
     * 设置房间防截屏
     *
     * PUT /_matrix/client/v3/rooms/{roomId}/anti_screenshot
     *
     * @param roomId - 房间 ID
     * @param enabled - 是否启用防截屏
     */
    setAntiScreenshot(roomId: string, enabled: boolean): Promise<void>;
    /**
     * 获取 sticky events
     *
     * @param roomId - 房间 ID
     */
    getStickyEvents(roomId: string): Promise<StickyEvent[]>;
    /**
     * 设置 sticky event
     *
     * @param roomId - 房间 ID
     * @param eventType - 事件类型
     * @param content - 事件内容
     */
    setStickyEvent(roomId: string, eventType: string, content: IContent): Promise<StickyEvent>;
    /**
     * 删除 sticky event
     *
     * @param roomId - 房间 ID
     * @param eventType - 事件类型
     */
    deleteStickyEvent(roomId: string, eventType: string): Promise<void>;
    /**
     * 获取 m.room.power_levels
     *
     * @param roomId - 房间 ID
     */
    getRoomPowerLevels(roomId: string): Promise<RoomAccountDataResult>;
    translate(content: string, sourceLang?: string, targetLang?: string): Promise<TranslateResult>;
    /**
     * 创建或刷新房间摘要
     *
     * @param roomId - 房间 ID
     * @param body - 请求体
     * @returns 房间摘要，若失败返回 null
     */
    createOrRefreshSummary(roomId: string, body?: IContent): Promise<RoomSummary | null>;
    /**
     * 更新房间摘要
     *
     * @param roomId - 房间 ID
     * @param body - 更新请求体
     * @returns 更新后的房间摘要
     */
    updateSummary(roomId: string, body: UpdateSummaryBody): Promise<RoomSummary | null>;
    /**
     * 删除房间摘要
     *
     * @param roomId - 房间 ID
     */
    deleteSummary(roomId: string): Promise<void>;
    /**
     * 同步房间摘要
     *
     * @param roomId - 房间 ID
     * @param body - 请求体
     * @returns 同步结果
     */
    syncSummary(roomId: string, body?: IContent): Promise<SyncSummaryResult>;
    /**
     * 处理摘要更新
     *
     * @param body - 请求体
     * @returns 处理结果
     */
    processSummaryUpdates(body?: {
        limit?: number;
    }): Promise<ProcessUpdatesResult>;
    private summaryReadPath;
    private internalSummaryPath;
}
//# sourceMappingURL=room-event-operation-manager.d.ts.map