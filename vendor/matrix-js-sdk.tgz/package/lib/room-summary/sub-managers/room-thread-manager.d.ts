import { MatrixClient } from "../../client";
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import type { RoomThreadResult, RoomThreadDetailResult, EventKeysResult } from "../types";
/**
 * Room Thread Sub-Manager - 房间线程操作子管理器
 *
 * 处理线程相关的 API 请求：
 * - getEventKeys: 获取事件签名密钥
 * - getRoomThread: 通过根事件 ID 获取线程
 * - getRoomThreadById: 通过线程 ID 获取线程详情
 */
export declare class RoomSummaryThreadManager extends RoomSummaryBaseManager {
    constructor(client: MatrixClient, onError?: RoomSummaryErrorCallback);
    /**
     * 获取事件的签名密钥
     * GET /_matrix/client/v3/rooms/{roomId}/keys/{eventId}
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @returns 事件密钥结果
     */
    getEventKeys(roomId: string, eventId: string): Promise<EventKeysResult>;
    /**
     * 获取房间线程（通过根事件 ID）
     * GET /_matrix/client/v3/rooms/{roomId}/thread/{eventId}
     *
     * @param roomId - 房间 ID
     * @param eventId - 线程根事件 ID
     * @returns 线程详情，包含根事件、回复和参与者
     */
    getRoomThread(roomId: string, eventId: string): Promise<RoomThreadResult>;
    /**
     * 获取房间线程（通过线程 ID）
     * GET /_matrix/client/v3/rooms/{roomId}/threads/{threadId}
     *
     * @param roomId - 房间 ID
     * @param threadId - 线程 ID
     * @returns 线程详情
     */
    getRoomThreadById(roomId: string, threadId: string): Promise<RoomThreadDetailResult>;
}
//# sourceMappingURL=room-thread-manager.d.ts.map