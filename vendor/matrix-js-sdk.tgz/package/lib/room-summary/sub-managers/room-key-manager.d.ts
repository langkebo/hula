import { MatrixClient } from "../../client";
import type { IContent } from "../../models/event";
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import type { RoomKeyClaimResult, RoomKeyCountResult, RoomKeysVersionResult, RoomForwardKeysResult, EncryptedEventsResult } from "../types";
import type { ClaimKeysRequest } from "../../device-keys/index";
/**
 * Room Key Manager - 房间密钥/加密操作
 *
 * 处理房间密钥申领、计数、版本、转发及加密事件获取等操作。
 * 无缓存、无事件。
 */
export declare class RoomSummaryKeyManager extends RoomSummaryBaseManager {
    constructor(client: MatrixClient, onError?: RoomSummaryErrorCallback);
    /**
     * 申领房间密钥
     *
     * @param roomId - 房间 ID
     * @param body - 申领请求体
     * @returns 申领结果
     */
    claimRoomKeys(roomId: string, body: ClaimKeysRequest): Promise<RoomKeyClaimResult>;
    /**
     * 获取房间密钥计数
     *
     * @param roomId - 房间 ID
     * @returns 密钥计数结果
     */
    getRoomKeyCount(roomId: string): Promise<RoomKeyCountResult>;
    /**
     * 获取房间密钥版本
     *
     * @param roomId - 房间 ID
     * @returns 密钥版本结果
     */
    getRoomKeysVersion(roomId: string): Promise<RoomKeysVersionResult>;
    /**
     * 转发房间密钥
     *
     * @param roomId - 房间 ID
     * @param body - 转发请求体
     * @returns 转发结果
     */
    forwardRoomKeys(roomId: string, body: IContent): Promise<RoomForwardKeysResult>;
    /**
     * 获取加密事件摘要
     *
     * @param roomId - 房间 ID
     * @param options - 查询选项
     * @returns 加密事件结果
     */
    getEncryptedEvents(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<EncryptedEventsResult>;
}
//# sourceMappingURL=room-key-manager.d.ts.map