import { MatrixClient } from "../../client";
import type { IContent } from "../../models/event";
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import type { RoomSummaryOptions, RoomSummary, RoomSearchResult } from "../types";
import type { IPublicRoomsResponse, IPublicRoomsChunkRoom } from "../../client-api-types";
/** 房间搜索请求体 */
export interface RoomSearchBody {
    search_term?: string;
    keys?: string[];
    limit?: number;
    order_by?: string;
    direction?: "f" | "b";
    filter?: IContent;
    [key: string]: unknown;
}
/**
 * Room Search Manager - 房间搜索/发现操作
 *
 * 处理房间层级结构、公共房间搜索、推荐房间、收藏房间、最近房间等操作。
 * 无缓存、无事件。
 */
export declare class RoomSummarySearchManager extends RoomSummaryBaseManager {
    constructor(client: MatrixClient, onError?: RoomSummaryErrorCallback);
    /**
     * 获取房间层级结构（Space 层级）
     *
     * @param roomId - 房间 ID
     * @param options - 选项
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 层级结构
     */
    getRoomHierarchy(roomId: string, options?: RoomSummaryOptions, throwOnError?: boolean): Promise<unknown | null>;
    /**
     * 获取公共房间列表
     *
     * @param server - 服务器名（可选）
     * @param options - 选项
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 公共房间列表
     */
    getPublicRooms(server?: string, options?: {
        limit?: number;
        since?: string;
        query?: string;
    }, throwOnError?: boolean): Promise<IPublicRoomsResponse | null>;
    /**
     * 搜索公共房间
     *
     * @param query - 搜索关键词
     * @param server - 服务器名
     * @param limit - 限制数量
     * @returns 公共房间列表
     */
    searchPublicRooms(query: string, server?: string, limit?: number): Promise<IPublicRoomsChunkRoom[]>;
    /**
     * 获取推荐房间
     *
     * @param server - 服务器名
     * @param limit - 限制数量
     * @returns 推荐公共房间列表
     */
    getRecommendedRooms(server?: string, limit?: number): Promise<IPublicRoomsChunkRoom[]>;
    /**
     * 获取收藏的房间
     *
     * @returns 收藏的房间摘要列表
     */
    getFavoriteRooms(): Promise<RoomSummary[]>;
    /**
     * 获取最近活跃的房间
     *
     * @param limit - 限制数量
     * @returns 最近活跃的房间摘要列表
     */
    getRecentRooms(limit?: number): Promise<RoomSummary[]>;
    /**
     * 搜索房间内容
     *
     * @param roomId - 房间 ID
     * @param body - 搜索请求体
     * @returns 搜索结果
     */
    searchRoom(roomId: string, body: RoomSearchBody): Promise<RoomSearchResult>;
    private handleError;
}
//# sourceMappingURL=room-search-manager.d.ts.map