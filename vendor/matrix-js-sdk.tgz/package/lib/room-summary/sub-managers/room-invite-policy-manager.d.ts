import { MatrixClient } from "../../client";
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import type { InviteBlocklist, InviteAllowlist } from "../types";
/**
 * Room Invite Policy Manager - 房间邀请黑名单/白名单操作
 *
 * 处理邀请阻止列表和允许列表的查询与添加操作。
 * 无缓存、无事件。
 */
export declare class RoomSummaryInvitePolicyManager extends RoomSummaryBaseManager {
    private readonly onCacheInvalidation?;
    constructor(client: MatrixClient, onCacheInvalidation?: (roomId: string) => void, onError?: RoomSummaryErrorCallback);
    /**
     * 获取 invite blocklist
     *
     * @param roomId - 房间 ID
     * @returns 阻止列表
     */
    getInviteBlocklist(roomId: string): Promise<InviteBlocklist>;
    /**
     * 添加到 invite blocklist
     *
     * @param roomId - 房间 ID
     * @param userId - 用户 ID
     */
    addInviteBlocklist(roomId: string, userId: string): Promise<void>;
    /**
     * 获取 invite allowlist
     *
     * @param roomId - 房间 ID
     * @returns 允许列表
     */
    getInviteAllowlist(roomId: string): Promise<InviteAllowlist>;
    /**
     * 添加到 invite allowlist
     *
     * @param roomId - 房间 ID
     * @param userId - 用户 ID
     */
    addInviteAllowlist(roomId: string, userId: string): Promise<void>;
}
//# sourceMappingURL=room-invite-policy-manager.d.ts.map