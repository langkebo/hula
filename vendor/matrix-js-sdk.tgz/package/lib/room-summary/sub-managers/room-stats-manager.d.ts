import { MatrixClient } from "../../client";
import type { RoomStats, HeroesRecalcResult, UnreadClearResult } from "../types";
import type { IContent } from "../../models/event";
import { RoomSummaryBaseManager, type RoomSummaryErrorCallback } from "../room-summary-base-manager";
import { LRUCache } from "../../utils/lru-cache";
export declare enum RoomSummaryStatsEvent {
    StatsUpdated = "StatsUpdated"
}
export interface RoomSummaryStatsEventMap {
    [RoomSummaryStatsEvent.StatsUpdated]: (roomId: string, stats: RoomStats) => void;
}
export declare class RoomSummaryStatsManager extends RoomSummaryBaseManager<RoomSummaryStatsEvent, RoomSummaryStatsEventMap> {
    private readonly statsCache;
    private readonly onCacheInvalidation?;
    constructor(client: MatrixClient, statsCache: LRUCache<RoomStats>, onCacheInvalidation?: (roomId: string) => void, onError?: RoomSummaryErrorCallback);
    private summaryStatsPath;
    getRoomSummaryStats(roomId: string, forceRefresh?: boolean, throwOnError?: boolean): Promise<RoomStats | null>;
    recalculateSummaryStats(roomId: string, body?: IContent): Promise<RoomStats | null>;
    recalculateSummaryHeroes(roomId: string, body?: IContent): Promise<HeroesRecalcResult>;
    clearSummaryUnread(roomId: string, body?: IContent): Promise<UnreadClearResult>;
    getCachedStats(roomId: string): RoomStats | null;
    private handleError;
}
//# sourceMappingURL=room-stats-manager.d.ts.map