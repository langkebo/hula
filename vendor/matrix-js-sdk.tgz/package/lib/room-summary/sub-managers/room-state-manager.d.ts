import { MatrixClient } from "../../client";
import type { IRoomSummaryState, RoomSummaryStateContent } from "../types";
import type { RoomSummaryErrorCallback } from "../room-summary-base-manager";
import { RoomSummaryBaseManager } from "../room-summary-base-manager";
/**
 * Room State Sub-Manager - 房间摘要状态管理
 *
 * 处理房间摘要的 state 相关操作：
 * - 获取房间所有摘要状态
 * - 获取指定事件类型和 state key 的摘要状态
 * - 更新摘要状态
 */
export declare class RoomSummaryStateManager extends RoomSummaryBaseManager {
    constructor(client: MatrixClient, onError?: RoomSummaryErrorCallback);
    private summaryStateCollectionPath;
    private summaryStatePath;
    /**
     * 获取房间所有摘要状态
     *
     * GET /_matrix/client/v3/rooms/{roomId}/summary/state
     *
     * @param roomId - 房间 ID
     * @returns 摘要状态列表
     * @throws {InvalidParamError} 当房间 ID 无效时
     */
    getAllSummaryState(roomId: string): Promise<IRoomSummaryState[]>;
    /**
     * 获取指定事件类型和 state key 的摘要状态
     *
     * GET /_matrix/client/v3/rooms/{roomId}/summary/state/{eventType}/{stateKey}
     *
     * @param roomId - 房间 ID
     * @param eventType - 事件类型
     * @param stateKey - 状态键（默认为空字符串）
     * @returns 摘要状态内容
     * @throws {InvalidParamError} 当房间 ID 或事件类型无效时
     */
    getSummaryState(roomId: string, eventType: string, stateKey?: string): Promise<RoomSummaryStateContent>;
    /**
     * 更新摘要状态
     *
     * PUT /_matrix/client/v3/rooms/{roomId}/summary/state/{eventType}/{stateKey}
     *
     * @param roomId - 房间 ID
     * @param eventType - 事件类型
     * @param stateKey - 状态键
     * @param content - 状态内容
     * @returns 更新后的摘要状态内容
     * @throws {InvalidParamError} 当房间 ID 或事件类型无效时
     */
    updateSummaryState(roomId: string, eventType: string, stateKey: string, content: RoomSummaryStateContent): Promise<RoomSummaryStateContent>;
}
//# sourceMappingURL=room-state-manager.d.ts.map