/**
 * Room Summary Base Manager - Room Summary 子 Manager 的公共基类
 *
 * 扩展 BaseManager，添加：
 * - requestV3：/_matrix/client/v3 前缀请求
 * - requestInternal：/_synapse/room_summary/v1 前缀请求
 * - roomSummaryPath：路径辅助函数
 * - validateRoomId/validateUserId/validateEventType：参数校验
 * - 错误回调：统一错误事件通知
 */
import { Method } from "../http-api/method";
import { type QueryDict } from "../http-api/utils";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export type RoomSummaryErrorCallback = (error: Error) => void;
/**
 * Room Summary 子 Manager 的公共基类
 *
 * 提供 requestV3/requestInternal 请求方法和统一的参数校验。
 */
export declare abstract class RoomSummaryBaseManager<Events extends string = string, EventMap extends Record<Events, any> = Record<Events, any>> extends BaseManager<Events, EventMap> {
    protected readonly onError?: RoomSummaryErrorCallback;
    constructor(client: MatrixClient, onError?: RoomSummaryErrorCallback, opts?: ManagerOpts);
    /**
     * 验证房间 ID 格式（委托到 common/validators）
     */
    protected validateRoomId(roomId: string): void;
    /**
     * 验证用户 ID 格式（委托到 common/validators）
     */
    protected validateUserId(userId: string): void;
    /**
     * 验证事件类型格式（委托到 common/validators）
     */
    protected validateEventType(eventType: string): void;
    /**
     * 构建带 roomId 替换的路径
     */
    protected roomSummaryPath(pathTemplate: string, roomId: string): string;
    /**
     * 发送 v3 前缀请求
     */
    protected requestV3<T>(method: Method, path: string, queryParams?: QueryDict, body?: unknown): Promise<T>;
    /**
     * 发送内部 API 请求
     */
    protected requestInternal<T>(method: Method, path: string, queryParams?: QueryDict, body?: unknown): Promise<T>;
}
//# sourceMappingURL=room-summary-base-manager.d.ts.map