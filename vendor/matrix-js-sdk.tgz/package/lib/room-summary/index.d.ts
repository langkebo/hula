/**
 * Room Summary Manager - 房间摘要管理
 *
 * 采用组合模式，将 30+ 个方法按领域拆分为 8 个子 Manager：
 * - members: 成员管理（成员列表、写入、更新、删除、最近成员）
 * - state: 状态管理（获取全部状态、获取/更新单个状态）
 * - stats: 统计管理（统计信息、重算统计、重算 heroes、清除未读）
 * - threads: 线程管理（线程查询、事件密钥）
 * - search: 搜索/发现（层级、公共房间、推荐、收藏、最近、搜索）
 * - keys: 密钥管理（申领密钥、密钥计数、版本、转发、加密事件）
 * - invitePolicy: 邀请策略（黑名单、白名单）
 * - eventOps: 事件操作（通知、能力、同步、账户数据、时间线、元数据等 30+ 方法）
 *
 * 所有原有方法保持向后兼容（委托到子 Manager）。
 * 推荐使用子 Manager 直接访问：`roomSummaryManager.members.getRoomSummaryMembers(...)`
 *
 * ⚠️ 注意：此模块是 Room Summary 的主要实现
 * 旧的 room-summaries/index.ts 模块已废弃，请使用此模块
 */
export type { RoomSummaryHero, RoomSummaryMember, RoomSummary, RoomSummaryOptions, RoomStats, RoomSummaryStateContent, ClientRoomSummary, IRoomSummaryState, RoomSummaryListResponse, RawRoomSummaryListResponse, NotificationItem, RoomNotificationsResult, RoomCapabilities, RoomSyncResult, TimelineResult, UnreadCountResult, RoomMetadata, RetentionPolicy, RoomPermissionsResult, RoomResolveResult, RoomMessageQueueResult, RoomServiceTypesResult, RoomReducedEventsResult, RoomRenderedResult, RoomFragmentsResult, RoomDeviceResult, RoomEventUrlResult, RoomTranslateResult, TranslateResult, RoomConvertResult, RoomSignResult, RoomVerifyResult, RoomAccountDataResult, RoomInvitesResult, RoomKeyClaimResult, RoomKeyCountResult, RoomKeysVersionResult, RoomMembersRecentResult, RoomReceiptsResult, RoomForwardKeysResult, RoomSearchResult, ExternalId, RoomSpace, EventPerspective, EncryptedEventsResult, EventKeysResult, ThreadReply, ThreadRoot, RoomThreadResult, RoomThreadDetailRoot, RoomThreadDetailReply, RoomThreadSummary, RoomThreadReadReceipt, RoomThreadSubscription, RoomThreadDetailResult, TurnServerConfig, StickyEvent, InviteBlocklist, InviteAllowlist, HeroesRecalcResult, UnreadClearResult, BatchSummaryResponse, BatchSummaryRequest, UpdateSummaryBody, SyncSummaryResult, ProcessUpdatesResult, RoomVaultDataResult, } from "./types";
export { RoomSummaryMemberManager, RoomSummaryMemberEvent } from "./sub-managers/room-member-manager";
export { RoomSummaryStateManager } from "./sub-managers/room-state-manager";
export { RoomSummaryStatsManager, RoomSummaryStatsEvent } from "./sub-managers/room-stats-manager";
export { RoomSummaryThreadManager } from "./sub-managers/room-thread-manager";
export { RoomSummarySearchManager } from "./sub-managers/room-search-manager";
export { RoomSummaryKeyManager } from "./sub-managers/room-key-manager";
export { RoomSummaryInvitePolicyManager } from "./sub-managers/room-invite-policy-manager";
export { RoomSummaryEventOperationManager } from "./sub-managers/room-event-operation-manager";
import { MatrixClient } from "../client";
import { type QueryDict } from "../http-api/utils";
import { BaseManager, type ManagerOpts, type RequestStats } from "../managers/base-manager";
import type { IPublicRoomsChunkRoom, IPublicRoomsResponse } from "../client-api-types";
import type { IContent } from "../models/event";
import type { ClaimKeysRequest } from "../device-keys/index";
import type { RoomSummary, RoomSummaryMember, RoomStats, RoomSummaryStateContent, RoomSummaryListResponse, RoomSummaryOptions, IRoomSummaryState, RoomNotificationsResult, RoomCapabilities, RoomSyncResult, TimelineResult, UnreadCountResult, RoomMetadata, RetentionPolicy, RoomPermissionsResult, RoomResolveResult, RoomMessageQueueResult, RoomServiceTypesResult, RoomReducedEventsResult, RoomRenderedResult, RoomFragmentsResult, RoomDeviceResult, RoomEventUrlResult, RoomTranslateResult, TranslateResult, RoomConvertResult, RoomSignResult, RoomVerifyResult, RoomAccountDataResult, RoomInvitesResult, RoomKeyClaimResult, RoomKeyCountResult, RoomKeysVersionResult, RoomMembersRecentResult, RoomReceiptsResult, RoomForwardKeysResult, RoomSearchResult, ExternalId, RoomSpace, EventPerspective, EncryptedEventsResult, EventKeysResult, RoomThreadResult, RoomThreadDetailResult, TurnServerConfig, StickyEvent, InviteBlocklist, InviteAllowlist, HeroesRecalcResult, UnreadClearResult, BatchSummaryResponse, BatchSummaryRequest, UpdateSummaryBody, SyncSummaryResult, ProcessUpdatesResult, RoomVaultDataResult } from "./types";
import { RoomSummaryMemberManager } from "./sub-managers/room-member-manager";
import { RoomSummaryStateManager } from "./sub-managers/room-state-manager";
import { RoomSummaryStatsManager } from "./sub-managers/room-stats-manager";
import { RoomSummaryThreadManager } from "./sub-managers/room-thread-manager";
import { RoomSummarySearchManager, type RoomSearchBody } from "./sub-managers/room-search-manager";
import { RoomSummaryKeyManager } from "./sub-managers/room-key-manager";
import { RoomSummaryInvitePolicyManager } from "./sub-managers/room-invite-policy-manager";
import { RoomSummaryEventOperationManager, type TranslateEventBody, type ConvertEventBody, type SignEventBody, type VerifyEventBody } from "./sub-managers/room-event-operation-manager";
export declare enum RoomSummaryEvent {
    Updated = "Updated",
    MembersUpdated = "MembersUpdated",
    StatsUpdated = "StatsUpdated",
    Error = "Error"
}
interface RoomSummaryEventMap {
    [RoomSummaryEvent.Updated]: (roomId: string, summary: RoomSummary) => void;
    [RoomSummaryEvent.MembersUpdated]: (roomId: string, members: RoomSummaryMember[]) => void;
    [RoomSummaryEvent.StatsUpdated]: (roomId: string, stats: RoomStats) => void;
    [RoomSummaryEvent.Error]: (error: Error) => void;
}
/**
 * Room Summary Manager - 房间摘要管理
 *
 * 通过组合模式将功能委托到子 Manager，同时保持完全向后兼容。
 *
 * @example
 * ```typescript
 * // 向后兼容：直接在 RoomSummaryManager 上调用方法
 * const members = await roomSummaryManager.getRoomSummaryMembers("!room:server.com");
 *
 * // 推荐新方式：通过子 Manager 访问
 * const members = await roomSummaryManager.members.getRoomSummaryMembers("!room:server.com");
 * const stats = await roomSummaryManager.stats.getRoomSummaryStats("!room:server.com");
 * const thread = await roomSummaryManager.threads.getRoomThread("!room:server.com", "$eventId");
 * ```
 */
export declare class RoomSummaryManager extends BaseManager<RoomSummaryEvent, RoomSummaryEventMap> {
    private summaryCache;
    private memberCache;
    private statsCache;
    readonly members: RoomSummaryMemberManager;
    readonly state: RoomSummaryStateManager;
    readonly stats: RoomSummaryStatsManager;
    readonly threads: RoomSummaryThreadManager;
    readonly search: RoomSummarySearchManager;
    readonly keys: RoomSummaryKeyManager;
    readonly invitePolicy: RoomSummaryInvitePolicyManager;
    readonly eventOps: RoomSummaryEventOperationManager;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 将子 Manager 的事件转发到 RoomSummaryManager
     * 保持 `roomSummaryManager.on(RoomSummaryEvent.MembersUpdated, ...)` 的向后兼容性
     */
    private forwardSubManagerEvents;
    private summaryReadPath;
    private internalSummaryPath;
    /**
     * 获取房间摘要
     */
    getRoomSummary(roomIdOrAlias: string, via?: string[], forceRefresh?: boolean, throwOnError?: boolean): Promise<RoomSummary | null>;
    createOrRefreshSummary(roomId: string, body?: IContent): Promise<RoomSummary | null>;
    updateSummary(roomId: string, body: UpdateSummaryBody): Promise<RoomSummary | null>;
    deleteSummary(roomId: string): Promise<void>;
    syncSummary(roomId: string, body?: IContent): Promise<SyncSummaryResult>;
    listUserSummaries(queryParams?: QueryDict): Promise<RoomSummaryListResponse>;
    createInternalSummary(body: IContent): Promise<RoomSummary>;
    /**
     * Batch-get room summaries by room IDs.
     *
     * Uses the backend `/_synapse/room_summary/v1/summaries/batch` endpoint
     * to fetch multiple summaries in a single HTTP request, avoiding N+1
     * per-room API calls.
     */
    batchGetRoomSummaries(roomIds: string[], options?: {
        suggestedOnly?: boolean;
    }): Promise<RoomSummary[]>;
    /**
     * Batch-get room summaries by room IDs (MSC3266).
     *
     * Uses the backend `/_synapse/room_summary/v1/summaries/batch` endpoint
     * to fetch multiple summaries in a single HTTP request.
     *
     * @param rooms - Array of room IDs to fetch summaries for
     * @param isSuggestedOnly - Whether to only return suggested rooms (default: false)
     * @returns Raw batch response with room summaries
     *
     * @example
     * ```typescript
     * const result = await roomSummaryManager.batchGetSummaries(
     *     ["!room1:server.com", "!room2:server.com"],
     *     true,
     * );
     * ```
     */
    batchGetSummaries(rooms: string[], isSuggestedOnly?: boolean): Promise<BatchSummaryResponse>;
    /**
     * Fetch room summaries in batch (MSC3266 route-surface driven capability).
     *
     * Uses the backend `POST /_synapse/room_summary/v1/summaries/batch` endpoint
     * to fetch multiple summaries in a single HTTP request, returning the raw
     * batch response without converting or caching individual summaries.
     *
     * @param request - Batch fetch request body
     * @param request.rooms - Array of room IDs to fetch summaries for
     * @param request.is_suggested_only - Whether to only return suggested rooms (default: false)
     * @returns Raw batch response with room summaries
     *
     * @example
     * ```typescript
     * const result = await roomSummaryManager.fetchBatchSummaries({
     *     rooms: ["!room1:server.com", "!room2:server.com"],
     *     is_suggested_only: true,
     * });
     * console.log(result.rooms?.length);
     * ```
     *
     * @throws {InvalidParamError} If the request body is missing or `rooms` is empty
     */
    fetchBatchSummaries(request: BatchSummaryRequest): Promise<BatchSummaryResponse>;
    processSummaryUpdates(body?: {
        limit?: number;
    }): Promise<ProcessUpdatesResult>;
    clearCache(roomId?: string): void;
    /**
     * 获取聚合的请求统计（包含顶层及所有子 Manager 的请求）。
     *
     * RoomSummaryManager 是门面：大部分请求由子 Manager 发出，
     * 此方法聚合所有子 Manager 的统计，提供完整的请求视图。
     */
    getRequestStats(): RequestStats;
    /**
     * 重置顶层及所有子 Manager 的请求统计。
     */
    resetRequestStats(): void;
    getCacheStats(): {
        summary: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        members: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        stats: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
    getMetrics(): {
        cache: {
            summary: {
                size: number;
                hitRate: number;
            };
            members: {
                size: number;
                hitRate: number;
            };
            stats: {
                size: number;
                hitRate: number;
            };
        };
        requests: {
            total: number;
            successful: number;
            failed: number;
            retried: number;
        };
    };
    getCachedSummary(roomId: string): RoomSummary | null;
    getCachedMembers(roomId: string): RoomSummaryMember[];
    getCachedStats(roomId: string): RoomStats | null;
    isCached(roomId: string): boolean;
    getRoomSummaryMembers(roomId: string, forceRefresh?: boolean, throwOnError?: boolean): Promise<RoomSummaryMember[]>;
    writeSummaryMembers(roomId: string, members: RoomSummaryMember[]): Promise<RoomSummaryMember[]>;
    updateSummaryMember(roomId: string, userId: string, member: Partial<RoomSummaryMember>): Promise<RoomSummaryMember>;
    deleteSummaryMember(roomId: string, userId: string): Promise<void>;
    getRoomMembersRecent(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<RoomMembersRecentResult>;
    getAllSummaryState(roomId: string): Promise<IRoomSummaryState[]>;
    getSummaryState(roomId: string, eventType: string, stateKey?: string): Promise<RoomSummaryStateContent>;
    updateSummaryState(roomId: string, eventType: string, stateKey: string, content: RoomSummaryStateContent): Promise<RoomSummaryStateContent>;
    getRoomSummaryStats(roomId: string, forceRefresh?: boolean, throwOnError?: boolean): Promise<RoomStats | null>;
    recalculateSummaryStats(roomId: string, body?: IContent): Promise<RoomStats | null>;
    recalculateSummaryHeroes(roomId: string, body?: IContent): Promise<HeroesRecalcResult>;
    clearSummaryUnread(roomId: string, body?: IContent): Promise<UnreadClearResult>;
    getEventKeys(roomId: string, eventId: string): Promise<EventKeysResult>;
    getRoomThread(roomId: string, eventId: string): Promise<RoomThreadResult>;
    getRoomThreadById(roomId: string, threadId: string): Promise<RoomThreadDetailResult>;
    getRoomHierarchy(roomId: string, options?: RoomSummaryOptions, throwOnError?: boolean): Promise<unknown | null>;
    getPublicRooms(server?: string, options?: {
        limit?: number;
        since?: string;
        query?: string;
    }, throwOnError?: boolean): Promise<IPublicRoomsResponse | null>;
    searchPublicRooms(query: string, server?: string, limit?: number): Promise<IPublicRoomsChunkRoom[]>;
    getRecommendedRooms(server?: string, limit?: number): Promise<IPublicRoomsChunkRoom[]>;
    getFavoriteRooms(): Promise<RoomSummary[]>;
    getRecentRooms(limit?: number): Promise<RoomSummary[]>;
    searchRoom(roomId: string, body: RoomSearchBody): Promise<RoomSearchResult>;
    claimRoomKeys(roomId: string, body: ClaimKeysRequest): Promise<RoomKeyClaimResult>;
    getRoomKeyCount(roomId: string): Promise<RoomKeyCountResult>;
    getRoomKeysVersion(roomId: string): Promise<RoomKeysVersionResult>;
    forwardRoomKeys(roomId: string, body: IContent): Promise<RoomForwardKeysResult>;
    getEncryptedEvents(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<EncryptedEventsResult>;
    getInviteBlocklist(roomId: string): Promise<InviteBlocklist>;
    addInviteBlocklist(roomId: string, userId: string): Promise<void>;
    getInviteAllowlist(roomId: string): Promise<InviteAllowlist>;
    addInviteAllowlist(roomId: string, userId: string): Promise<void>;
    getRoomNotifications(roomId: string, options?: {
        from?: string;
        limit?: number;
        only?: string;
    }): Promise<RoomNotificationsResult>;
    getRoomCapabilities(roomId: string): Promise<RoomCapabilities>;
    getRoomSync(roomId: string, options?: {
        since?: string;
        timeout_ms?: number;
        filter?: string;
    }): Promise<RoomSyncResult>;
    getRoomAccountData(roomId: string, type: string): Promise<RoomAccountDataResult>;
    setRoomAccountDataV3(roomId: string, type: string, content: RoomSummaryStateContent): Promise<RoomAccountDataResult>;
    getRoomInvites(roomId: string): Promise<RoomInvitesResult>;
    getRoomReceipts(roomId: string, receiptType: string, eventId: string): Promise<RoomReceiptsResult>;
    getRoomTimeline(roomId: string, options?: {
        from?: string;
        to?: string;
        dir?: "f" | "b";
        limit?: number;
        filter?: string;
    }): Promise<TimelineResult>;
    getRoomUnreadCount(roomId: string): Promise<UnreadCountResult>;
    getRoomMetadata(roomId: string): Promise<RoomMetadata>;
    getRoomVaultData(roomId: string): Promise<RoomVaultDataResult | null>;
    setRoomVaultData(roomId: string, data: IContent): Promise<void>;
    getRoomRetention(roomId: string): Promise<RetentionPolicy | null>;
    getRoomExternalIds(roomId: string): Promise<ExternalId[]>;
    getRoomSpaces(roomId: string): Promise<RoomSpace[]>;
    getRoomEventPerspective(roomId: string, eventId: string, options?: {
        room_version?: string;
    }): Promise<EventPerspective>;
    getRoomPermissions(roomId: string): Promise<RoomPermissionsResult>;
    getRoomResolve(roomId: string): Promise<RoomResolveResult>;
    getRoomMessageQueue(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<RoomMessageQueueResult>;
    getRoomServiceTypes(roomId: string): Promise<RoomServiceTypesResult>;
    getRoomReducedEvents(roomId: string): Promise<RoomReducedEventsResult>;
    getRoomRendered(roomId: string): Promise<RoomRenderedResult>;
    getRoomFragments(roomId: string, userId: string): Promise<RoomFragmentsResult>;
    getRoomDevice(roomId: string, deviceId: string): Promise<RoomDeviceResult>;
    getRoomEventUrl(roomId: string, eventId: string): Promise<RoomEventUrlResult>;
    translateRoomEvent(roomId: string, eventId: string, body?: TranslateEventBody): Promise<RoomTranslateResult>;
    translate(content: string, sourceLang?: string, targetLang?: string): Promise<TranslateResult>;
    convertRoomEvent(roomId: string, eventId: string, body?: ConvertEventBody): Promise<RoomConvertResult>;
    signRoomEvent(roomId: string, eventId: string, body?: SignEventBody): Promise<RoomSignResult>;
    verifyRoomEvent(roomId: string, eventId: string, body?: VerifyEventBody): Promise<RoomVerifyResult>;
    getRoomTurnServer(roomId: string): Promise<TurnServerConfig>;
    getAntiScreenshot(roomId: string): Promise<{
        enabled: boolean;
    }>;
    setAntiScreenshot(roomId: string, enabled: boolean): Promise<void>;
    getStickyEvents(roomId: string): Promise<StickyEvent[]>;
    setStickyEvent(roomId: string, eventType: string, content: RoomSummaryStateContent): Promise<StickyEvent>;
    deleteStickyEvent(roomId: string, eventType: string): Promise<void>;
    getRoomPowerLevels(roomId: string): Promise<RoomAccountDataResult>;
    start(): Promise<void>;
    stop(): void;
    private requestV3;
    private requestInternal;
    /**
     * 转换 client.ts 中的 RoomSummary 到本模块的 RoomSummary
     */
    private convertClientSummary;
}
/**
 * 扩展 MatrixClient 原型
 */
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map