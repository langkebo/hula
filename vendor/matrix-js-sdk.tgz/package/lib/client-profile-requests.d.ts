import { Method } from "./http-api/index.ts";
import type { Body, IRequestOpts } from "./http-api/index.ts";
import type { QueryDict } from "./utils.ts";
import type { EmptyObject } from "./@types/common.ts";
import type { IThreepid } from "./@types/threepids.ts";
import type { IAddThreePidOnlyBody, IBindThreePidBody } from "./@types/requests.ts";
import type { IdServerUnbindResult } from "./@types/partials.ts";
export type ProfileField = "displayname" | "avatar_url";
export declare function selectExtendedProfileRequestPrefix(isVersionSupportedV116: boolean, hasStableMsc4133Feature: boolean): string;
export declare function buildProfilePath(userId: string | null): string;
export declare function buildProfileFieldPath(userId: string | null, field: ProfileField): string;
export declare function buildExtendedProfilePropertyPath(userId: string | null, key: string): string;
export declare function buildDisplayNameBody(displayname: string): {
    displayname: string;
};
export declare function buildAvatarUrlBody(avatarUrl: string): {
    avatar_url: string;
};
export declare function buildExtendedProfilePropertyBody(key: string, value: unknown): Record<string, unknown>;
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function getExtendedProfileRequest(userId: string, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<Record<string, unknown>>;
export declare function getExtendedProfilePropertyRequest(userId: string, key: string, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<unknown>;
export declare function setExtendedProfilePropertyRequest(userId: string | null, key: string, value: unknown, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<void>;
export declare function deleteExtendedProfilePropertyRequest(userId: string | null, key: string, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<void>;
export declare function patchExtendedProfileRequest(userId: string | null, profile: Record<string, unknown>, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<Record<string, unknown>>;
export declare function setExtendedProfileRequest(userId: string | null, profile: Record<string, unknown>, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<void>;
export declare function getThreePidsRequest(authedRequest: AuthedRequestFn): Promise<{
    threepids: IThreepid[];
}>;
export declare function addThreePidOnlyRequest(data: IAddThreePidOnlyBody, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function bindThreePidRequest(data: IBindThreePidBody, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function unbindThreePidRequest(medium: string, address: string, idServer: string | undefined, authedRequest: AuthedRequestFn): Promise<{
    id_server_unbind_result: IdServerUnbindResult;
}>;
export declare function deleteThreePidRequest(medium: string, address: string, authedRequest: AuthedRequestFn): Promise<{
    id_server_unbind_result: IdServerUnbindResult;
}>;
export {};
//# sourceMappingURL=client-profile-requests.d.ts.map