import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
import type { EmptyObject } from "./@types/common";
import type { IThreepid } from "./@types/three-pids";
import type { IAddThreePidOnlyBody, IBindThreePidBody } from "./@types/requests";
import type { IdServerUnbindResult } from "./@types/partials";
import type { IContent } from "./models/event";
import type { IExtendedProfile } from "./profile/index";
export type ProfileField = "displayname" | "avatar_url";
export declare function selectExtendedProfileRequestPrefix(isVersionSupportedV116: boolean, hasStableMsc4133Feature: boolean): string;
export declare function buildProfilePath(userId: string | null): string;
export declare function buildProfileFieldPath(userId: string | null, field: ProfileField): string;
export declare function buildExtendedProfilePropertyPath(userId: string | null, key: string): string;
export declare function buildDisplayNameBody(displayname: string): {
    displayname: string;
};
export declare function buildAvatarUrlBody(avatarUrl: string): {
    avatar_url: string;
};
/**
 * 构造扩展 profile 的写入体。
 *
 * ⚠️ **顶层 `null` 一律拒绝**（后端 `reject_null_profile_value`，对比文档 P2-7）：服务端把
 * `null` 当非法值回 400 `M_BAD_JSON`，因为"值是 null"与"这个键没设置"无法区分。
 * 清空字段必须走 `DELETE /profile/{userId}/{key}`（SDK 的 `deleteExtendedProfileProperty`）。
 *
 * 只拦**顶层**：嵌套对象里的 `null` 是合法 JSON 值，后端用例 `null_value_is_bad_json`
 * 的边界正是"嵌套 null 仍允许"。写成递归校验会把合法的结构化数据拒掉。
 *
 * @param key - 扩展 profile 的键（如 `com.example.foo`）
 * @param value - 要写入的值；顶层 `null` 会抛 {@link ValidationError}
 * @throws {ValidationError} 当 `value` 为 `null` 时
 */
export declare function buildExtendedProfilePropertyBody(key: string, value: unknown): IContent;
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function getExtendedProfileRequest(userId: string, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<IExtendedProfile>;
export declare function getExtendedProfilePropertyRequest(userId: string, key: string, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<unknown>;
export declare function setExtendedProfilePropertyRequest(userId: string | null, key: string, value: unknown, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<void>;
export declare function deleteExtendedProfilePropertyRequest(userId: string | null, key: string, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<void>;
export declare function patchExtendedProfileRequest(userId: string | null, profile: IExtendedProfile, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<IExtendedProfile>;
export declare function setExtendedProfileRequest(userId: string | null, profile: IExtendedProfile, requestPrefix: string, authedRequest: AuthedRequestFn): Promise<void>;
export declare function getThreePidsRequest(authedRequest: AuthedRequestFn): Promise<{
    threepids: IThreepid[];
}>;
export declare function addThreePidOnlyRequest(data: IAddThreePidOnlyBody, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function bindThreePidRequest(data: IBindThreePidBody, authedRequest: AuthedRequestFn): Promise<EmptyObject>;
export declare function unbindThreePidRequest(medium: string, address: string, idServer: string | undefined, authedRequest: AuthedRequestFn): Promise<{
    id_server_unbind_result: IdServerUnbindResult;
}>;
export declare function deleteThreePidRequest(medium: string, address: string, authedRequest: AuthedRequestFn): Promise<{
    id_server_unbind_result: IdServerUnbindResult;
}>;
export {};
//# sourceMappingURL=client-profile-requests.d.ts.map