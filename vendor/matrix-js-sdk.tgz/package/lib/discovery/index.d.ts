/**
 * Discovery Manager - 服务发现与目录管理
 *
 * 提供服务端点发现、房间别名解析、用户目录搜索等功能
 * 对应后端 API:
 * - GET/POST /publicRooms
 * - POST /user_directory/search
 * - POST /user_directory/list
 * - GET /user_directory/profiles/{user_id}
 * - GET/PUT /directory/list/room/{room_id}
 * - GET/PUT/DELETE /directory/room/{room_alias}
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { IRoomDirectoryOptions } from "../@types/requests";
import type { IClientWellKnown, IServerVersions } from "../client-api-types";
export interface UserDirectorySearchResponse {
    results: Array<{
        user_id: string;
        display_name?: string;
        avatar_url?: string;
    }>;
    limited?: boolean;
}
export interface UserDirectoryListResponse {
    users: Array<{
        user_id: string;
        display_name?: string;
        avatar_url?: string;
    }>;
}
export interface UserDirectoryProfile {
    user_id: string;
    display_name?: string;
    avatar_url?: string;
}
export interface RoomVisibilityResponse {
    room_id: string;
    visibility: "public" | "private";
}
export interface RoomAliasListResponse {
    aliases: string[];
}
export interface PublicRoomsResponse {
    chunk: Array<{
        room_id: string;
        name?: string;
        topic?: string;
        avatar_url?: string;
        num_joined_members: number;
        join_rule?: string;
        world_readable?: boolean;
        guest_can_join?: boolean;
    }>;
    next_batch?: string;
    prev_batch?: string;
    total_room_count_estimate?: number;
}
type PublicRoomsFilter = NonNullable<IRoomDirectoryOptions["filter"]>;
export interface ClientWellKnownResponse {
    "m.homeserver": {
        base_url: string;
    };
    "m.identity_server"?: {
        base_url: string;
    };
    [key: string]: unknown;
}
export interface ServerWellKnownResponse {
    "m.server": string;
    [key: string]: unknown;
}
export interface SupportWellKnownResponse {
    admins?: Array<{
        user_id: string;
        role?: string;
    }>;
    support_page?: string;
    [key: string]: unknown;
}
export interface ServerVersionResponse extends IServerVersions {
    [key: string]: unknown;
}
export interface HealthResponse {
    status?: "ok" | "error";
    [key: string]: unknown;
}
export declare class DiscoveryManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getHomeserverUrl(): string;
    getClientWellKnown(): IClientWellKnown | undefined;
    getServerDiscoveryInfo(): Promise<ClientWellKnownResponse>;
    getClientConfig(): Promise<{
        homeserver: {
            base_url: string;
            server_name: string;
        };
        identity_server: {
            base_url: string;
        };
        push: {
            enabled: boolean;
        };
        email: {
            enabled: boolean;
        };
        features: Record<string, boolean>;
        defaults: Record<string, unknown>;
    }>;
    getServerWellKnown(): Promise<ServerWellKnownResponse>;
    getSupportWellKnown(): Promise<SupportWellKnownResponse>;
    getVersions(): Promise<IServerVersions>;
    getMatrixServerVersion(): Promise<ServerVersionResponse>;
    getHealth(): Promise<HealthResponse>;
    getUnderscoreHealth(): Promise<HealthResponse>;
    getRoomIdForAlias(alias: string): Promise<{
        room_id: string;
        servers: string[];
    }>;
    getAliasRoomId(alias: string): Promise<string | null>;
    searchUserDirectory(searchTerm: string, limit?: number): Promise<UserDirectorySearchResponse>;
    listUserDirectory(): Promise<UserDirectoryListResponse>;
    getUserDirectoryProfile(userId: string): Promise<UserDirectoryProfile>;
    getRoomVisibility(roomId: string): Promise<RoomVisibilityResponse>;
    setRoomVisibility(roomId: string, visibility: "public" | "private"): Promise<void>;
    getPublicRooms(limit?: number, since?: string, server?: string): Promise<PublicRoomsResponse>;
    queryPublicRooms(filter: PublicRoomsFilter, limit?: number, since?: string): Promise<PublicRoomsResponse>;
    setRoomAlias(roomId: string, alias: string): Promise<void>;
    getAliasesForRoom(roomId: string): Promise<RoomAliasListResponse>;
    addRoomAliasForRoom(roomId: string, alias: string): Promise<void>;
    deleteRoomAliasForRoom(roomId: string, alias: string): Promise<void>;
    deleteRoomAlias(alias: string): Promise<void>;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map