import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
import { type Direction } from "./models/event-timeline";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function buildRoomHierarchyPath(roomId: string): string;
export declare function buildTimestampToEventPath(roomId: string): string;
export declare function buildRoomHierarchyQuery(limit?: number, maxDepth?: number, suggestedOnly?: boolean, fromToken?: string): QueryDict;
export declare function getRoomHierarchyRequest<T>(roomId: string, limit: number | undefined, maxDepth: number | undefined, suggestedOnly: boolean, fromToken: string | undefined, authedRequest: AuthedRequestFn): Promise<T>;
export declare function timestampToEventRequest<T>(roomId: string, timestamp: number, dir: Direction, authedRequest: AuthedRequestFn): Promise<T>;
export {};
//# sourceMappingURL=client-room-discovery-requests.d.ts.map