import type { IContent } from "./models/event.ts";
import type { IRedactOpts } from "./@types/requests.ts";
import type { ImageInfo } from "./@types/media.ts";
export interface NormalizedSendEventArgs {
    threadId: string | null;
    eventType: string;
    content: IContent;
    txnId: string | undefined;
}
export declare function normalizeSendEventArgs(threadIdOrEventType: string | null, eventTypeOrContent: string | IContent, contentOrTxnId?: IContent | string, txnIdOrVoid?: string, eventIdPrefix?: string): NormalizedSendEventArgs;
export interface NormalizedRedactEventArgs {
    threadId: string | null;
    eventId: string;
    txnId: string | undefined;
    opts: IRedactOpts | undefined;
}
export declare function normalizeRedactEventArgs(threadId: string | null, eventId?: string, txnId?: string | IRedactOpts, opts?: IRedactOpts, eventIdPrefix?: string): NormalizedRedactEventArgs;
export interface NormalizedThreadBodyTxnArgs {
    threadId: string | null;
    body: string;
    txnId: string | undefined;
}
export declare function normalizeThreadBodyTxnArgs(threadId: string | null, body: string, txnId?: string, eventIdPrefix?: string): NormalizedThreadBodyTxnArgs;
export interface NormalizedThreadHtmlArgs {
    threadId: string | null;
    body: string;
    htmlBody: string;
}
export declare function normalizeThreadHtmlArgs(threadId: string | null, body: string, htmlBody?: string, eventIdPrefix?: string): NormalizedThreadHtmlArgs;
export interface NormalizedThreadMediaArgs {
    threadId: string | null;
    url: string;
    info: ImageInfo;
    text: string;
}
export declare function normalizeThreadMediaArgs(threadId: string | null, url?: string | ImageInfo, info?: ImageInfo | string, text?: string, defaultText?: string, eventIdPrefix?: string): NormalizedThreadMediaArgs;
//# sourceMappingURL=client-send-args.d.ts.map