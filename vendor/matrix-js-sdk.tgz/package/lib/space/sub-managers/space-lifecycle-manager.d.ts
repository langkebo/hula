import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import type { MatrixClient } from "../../client";
import { SpaceEvent, type SpaceManagerEventMap } from "../events";
import type { CreateSpaceOptions, UpdateSpaceOptions, Space } from "../types";
import type { SpaceManager } from "../index";
export declare class SpaceLifecycleManager extends BaseManager<SpaceEvent, SpaceManagerEventMap> {
    private parent;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * @internal
     */
    _setParent(parent: SpaceManager): void;
    /**
     * 创建 Space
     *
     * @param options - 创建选项
     * @param options.name - Space 名称
     * @param options.topic - Space 主题（可选）
     * @param options.avatar_url - 头像 URL（可选）
     * @param options.join_rule - 加入规则（可选）
     * @param options.visibility - 可见性（public/private，可选）
     *
     * @example
     * ```typescript
     * // 创建公开 Space
     * const space = await spaceManager.createSpace({
     *     name: "My Public Space",
     *     topic: "A space for everyone",
     *     visibility: "public"
     * });
     * console.log("Created space:", space.space_id);
     *
     * // 创建私有 Space
     * const privateSpace = await spaceManager.createSpace({
     *     name: "Private Team Space",
     *     visibility: "private",
     *     join_rule: "invite"
     * });
     *
     * // 监听 Space 创建事件
     * spaceManager.on(SpaceEvent.SpaceCreated, (space) => {
     *     console.log(`Space created: ${space.name}`);
     * });
     * ```
     *
     * @throws {ValidationError} 如果名称为空或过长
     * @throws {ApiError} 如果 API 调用失败
     */
    createSpace(options: CreateSpaceOptions): Promise<Space>;
    /**
     * 获取 Space 信息
     *
     * @param spaceId - Space ID（格式：!localpart:homeserver）
     * @returns Space 信息
     *
     * @example
     * ```typescript
     * // 获取 Space 信息
     * const space = await spaceManager.getSpace("!abc:example.com");
     * console.log("Space name:", space.name);
     * console.log("Topic:", space.topic);
     * console.log("Members:", space.members);
     *
     * // 使用缓存（第二次调用会使用缓存）
     * const cachedSpace = await spaceManager.getSpace("!abc:example.com");
     * ```
     *
     * @throws {ValidationError} 如果 Space ID 格式无效
     * @throws {NotFoundError} 如果 Space 不存在
     * @throws {ApiError} 如果 API 调用失败
     */
    getSpace(spaceId: string): Promise<Space>;
    updateSpace(spaceId: string, options: UpdateSpaceOptions): Promise<Space>;
    deleteSpace(spaceId: string): Promise<void>;
    private doRequest;
}
//# sourceMappingURL=space-lifecycle-manager.d.ts.map