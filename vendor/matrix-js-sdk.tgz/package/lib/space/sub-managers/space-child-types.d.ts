/**
 * SpaceChildManager 特有类型
 *
 * 子房间相关类型（AddChildOptions / SpaceChild）定义在 `../types.ts`，
 * 此处为 sub-manager 预留类型扩展点。
 */
export {};
//# sourceMappingURL=space-child-types.d.ts.map