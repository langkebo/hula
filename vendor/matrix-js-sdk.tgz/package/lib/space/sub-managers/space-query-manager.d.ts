import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import type { MatrixClient } from "../../client";
import { SpaceEvent, type SpaceManagerEventMap } from "../events";
import type { Space, SpaceListResponse, SpaceQueryOptions, SpaceStatistics } from "../types";
import type { SpaceManager } from "../index";
export declare class SpaceQueryManager extends BaseManager<SpaceEvent, SpaceManagerEventMap> {
    private cache;
    private spaceCache;
    private parent;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * @internal
     */
    _setParent(parent: SpaceManager): void;
    getCachedSpace(spaceId: string): Space | undefined;
    setCachedSpace(spaceId: string, space: Space): void;
    /** 清空所有缓存（供顶层 SpaceManager.clearCache 委托 + 其他 sub-manager 失效缓存调用） */
    clearCache(): void;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
    getPublicSpaces(options?: SpaceQueryOptions): Promise<SpaceListResponse>;
    searchSpaces(query: string, limit?: number): Promise<Space[]>;
    getSpaceStatistics(): Promise<SpaceStatistics>;
    getUserSpaces(forceRefresh?: boolean): Promise<Space[]>;
    getSpaceByRoom(roomId: string): Promise<Space>;
    getRoomParentSpaces(roomId: string, options?: SpaceQueryOptions): Promise<Space[]>;
    isSpace(roomId: string): Promise<boolean>;
    getSpaceStats(spaceId: string): Promise<{
        memberCount: number;
        childCount: number;
    }>;
    private doRequest;
}
//# sourceMappingURL=space-query-manager.d.ts.map