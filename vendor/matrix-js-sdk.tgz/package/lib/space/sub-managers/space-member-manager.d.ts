import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import type { MatrixClient } from "../../client";
import { SpaceEvent, type SpaceManagerEventMap } from "../events";
import type { SpaceMember, SpaceQueryOptions } from "../types";
import type { SpaceManager } from "../index";
type JsonObject = Record<string, unknown>;
export declare class SpaceMemberManager extends BaseManager<SpaceEvent, SpaceManagerEventMap> {
    private parent;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * @internal
     */
    _setParent(parent: SpaceManager): void;
    getSpaceMembers(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceMember[]>;
    inviteToSpace(spaceId: string, userId: string, body?: JsonObject): Promise<void>;
    joinSpace(spaceId: string, body?: JsonObject): Promise<JsonObject>;
    leaveSpace(spaceId: string, body?: JsonObject): Promise<void>;
    private extractMembers;
    private normalizeMember;
    private doRequest;
}
export {};
//# sourceMappingURL=space-member-manager.d.ts.map