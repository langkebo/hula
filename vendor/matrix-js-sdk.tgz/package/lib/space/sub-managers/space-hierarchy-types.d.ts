/**
 * SpaceHierarchyManager 特有类型
 *
 * 层级相关类型（SpaceHierarchy / SpaceHierarchyPage）定义在 `../types.ts`，
 * 此处为 sub-manager 预留类型扩展点。
 */
export {};
//# sourceMappingURL=space-hierarchy-types.d.ts.map