import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import type { MatrixClient } from "../../client";
import { SpaceEvent, type SpaceManagerEventMap } from "../events";
import type { AddChildOptions, Space, SpaceChild, SpaceQueryOptions } from "../types";
import type { SpaceManager } from "../index";
export declare class SpaceChildManager extends BaseManager<SpaceEvent, SpaceManagerEventMap> {
    private parent;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * @internal
     */
    _setParent(parent: SpaceManager): void;
    getSpaceChildren(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceChild[]>;
    /**
     * 添加子房间到 Space
     *
     * @param spaceId - Space ID（格式：!localpart:homeserver）
     * @param options - 添加选项
     * @param options.room_id - 子房间 ID
     * @param options.via_servers - 服务器列表（可选）
     * @param options.order - 排序（可选）
     * @param options.suggested - 是否推荐（可选）
     *
     * @example
     * ```typescript
     * // 添加房间到 Space
     * await spaceManager.addChild("!space:example.com", {
     *     room_id: "!room:example.com"
     * });
     *
     * // 添加推荐房间
     * await spaceManager.addChild("!space:example.com", {
     *     room_id: "!room:example.com",
     *     suggested: true,
     *     order: "01"
     * });
     *
     * // 监听子房间添加事件
     * spaceManager.on(SpaceEvent.ChildAdded, (spaceId, roomId) => {
     *     console.log(`Room ${roomId} added to space ${spaceId}`);
     * });
     * ```
     *
     * @throws {ValidationError} 如果 Space ID 或房间 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    addChild(spaceId: string, options: AddChildOptions): Promise<void>;
    removeChild(spaceId: string, roomId: string): Promise<void>;
    getSpaceRooms(spaceId: string, options?: SpaceQueryOptions): Promise<Space[]>;
    getSpaceState(spaceId: string): Promise<unknown[]>;
    private extractChildren;
    private normalizeChild;
    private doRequest;
}
//# sourceMappingURL=space-child-manager.d.ts.map