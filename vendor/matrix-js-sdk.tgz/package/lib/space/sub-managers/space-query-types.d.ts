/**
 * SpaceQueryManager 特有类型
 *
 * 查询相关类型（SpaceQueryOptions / SpaceListResponse / SpaceStatistics）定义在 `../types.ts`，
 * 此处为 sub-manager 预留类型扩展点。
 */
export {};
//# sourceMappingURL=space-query-types.d.ts.map