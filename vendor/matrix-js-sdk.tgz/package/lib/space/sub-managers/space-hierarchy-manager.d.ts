import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import type { MatrixClient } from "../../client";
import { SpaceEvent, type SpaceManagerEventMap } from "../events";
import type { SpaceHierarchy, SpaceHierarchyPage, SpaceQueryOptions } from "../types";
import type { SpaceManager } from "../index";
type JsonObject = Record<string, unknown>;
export declare class SpaceHierarchyManager extends BaseManager<SpaceEvent, SpaceManagerEventMap> {
    private parent;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * @internal
     */
    _setParent(parent: SpaceManager): void;
    getSpaceHierarchy(spaceId: string): Promise<SpaceHierarchy>;
    getSpaceHierarchyPage(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceHierarchyPage>;
    getSpaceHierarchyV1(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceHierarchyPage>;
    getSpaceSummary(spaceId: string, options?: SpaceQueryOptions): Promise<JsonObject>;
    getSpaceSummaryWithChildren(spaceId: string, options?: SpaceQueryOptions): Promise<JsonObject>;
    getSpaceTreePath(spaceId: string, options?: SpaceQueryOptions): Promise<JsonObject>;
    private doRequest;
}
export {};
//# sourceMappingURL=space-hierarchy-manager.d.ts.map