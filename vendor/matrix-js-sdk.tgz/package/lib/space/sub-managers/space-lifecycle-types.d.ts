/**
 * SpaceLifecycleManager 特有类型
 *
 * CRUD 相关类型（CreateSpaceOptions / UpdateSpaceOptions）定义在 `../types.ts`，
 * 此处为 sub-manager 预留类型扩展点。
 */
export {};
//# sourceMappingURL=space-lifecycle-types.d.ts.map