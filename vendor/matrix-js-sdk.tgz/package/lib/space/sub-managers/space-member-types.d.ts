/**
 * SpaceMemberManager 特有类型
 *
 * 成员相关类型（SpaceMember）定义在 `../types.ts`，
 * 此处为 sub-manager 预留类型扩展点。
 */
export {};
//# sourceMappingURL=space-member-types.d.ts.map