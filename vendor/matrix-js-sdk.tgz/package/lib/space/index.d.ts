/**
 * Space Manager - Space 空间管理（门面层）
 *
 * 契约基线：docs/api-contract/space.md
 *
 * 采用组合模式，将原 SpaceManager 拆分为 5 个 sub-managers：
 * - lifecycle: CRUD（创建、读取、更新、删除）
 * - query: 查询（公共空间、搜索、统计、用户空间、缓存）
 * - child: 子房间管理
 * - member: 成员管理
 * - hierarchy: 层级管理
 *
 * 所有原有方法保持向后兼容（委托到 sub-manager，`@deprecated` 标注迁移路径）。
 * 推荐新代码直接使用 sub-manager：`spaceManager.lifecycle.createSpace(...)`。
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { SpaceEvent, type SpaceManagerEventMap } from "./events";
import type { AddChildOptions, CreateSpaceOptions, Space, SpaceChild, SpaceHierarchy, SpaceHierarchyPage, SpaceListResponse, SpaceManagerMetrics, SpaceMember, SpaceQueryOptions, SpaceStatistics, UpdateSpaceOptions } from "./types";
import { SpaceLifecycleManager } from "./sub-managers/space-lifecycle-manager";
import { SpaceQueryManager } from "./sub-managers/space-query-manager";
import { SpaceChildManager } from "./sub-managers/space-child-manager";
import { SpaceMemberManager } from "./sub-managers/space-member-manager";
import { SpaceHierarchyManager } from "./sub-managers/space-hierarchy-manager";
export { SpaceEvent } from "./events";
export type { SpaceManagerEventMap } from "./events";
export * from "./types";
export { SpaceLifecycleManager } from "./sub-managers/space-lifecycle-manager";
export { SpaceQueryManager } from "./sub-managers/space-query-manager";
export { SpaceChildManager } from "./sub-managers/space-child-manager";
export { SpaceMemberManager } from "./sub-managers/space-member-manager";
export { SpaceHierarchyManager } from "./sub-managers/space-hierarchy-manager";
/**
 * Space Manager - Space 空间管理统一入口
 *
 * 通过组合模式将功能委托到 sub-managers，同时保持完全向后兼容。
 *
 * @example
 * ```typescript
 * // 向后兼容：直接在 SpaceManager 上调用方法
 * const space = await spaceManager.getSpace("!abc:example.com");
 *
 * // 推荐新方式：通过 sub-manager 访问
 * const space = await spaceManager.lifecycle.getSpace("!abc:example.com");
 * const children = await spaceManager.child.getSpaceChildren("!abc:example.com");
 * ```
 */
export declare class SpaceManager extends BaseManager<SpaceEvent, SpaceManagerEventMap> {
    readonly lifecycle: SpaceLifecycleManager;
    readonly query: SpaceQueryManager;
    readonly child: SpaceChildManager;
    readonly member: SpaceMemberManager;
    readonly hierarchy: SpaceHierarchyManager;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 将所有 sub-manager 的 SpaceEvent 转发到顶层 SpaceManager。
     * 由于 sub-manager 和顶层共用 SpaceEvent enum，直接 re-emit 即可。
     */
    private forwardSubManagerEvents;
    getMetrics(): SpaceManagerMetrics;
    clearCache(): void;
    start(): void;
    stop(): void;
    /** @deprecated 使用 `spaceManager.lifecycle.createSpace()` 替代 */
    createSpace(options: CreateSpaceOptions): Promise<Space>;
    /** @deprecated 使用 `spaceManager.lifecycle.getSpace()` 替代 */
    getSpace(spaceId: string): Promise<Space>;
    /** @deprecated 使用 `spaceManager.lifecycle.updateSpace()` 替代 */
    updateSpace(spaceId: string, options: UpdateSpaceOptions): Promise<Space>;
    /** @deprecated 使用 `spaceManager.lifecycle.deleteSpace()` 替代 */
    deleteSpace(spaceId: string): Promise<void>;
    /** @deprecated 使用 `spaceManager.query.getPublicSpaces()` 替代 */
    getPublicSpaces(options?: SpaceQueryOptions): Promise<SpaceListResponse>;
    /** @deprecated 使用 `spaceManager.query.searchSpaces()` 替代 */
    searchSpaces(query: string, limit?: number): Promise<Space[]>;
    /** @deprecated 使用 `spaceManager.query.getSpaceStatistics()` 替代 */
    getSpaceStatistics(): Promise<SpaceStatistics>;
    /** @deprecated 使用 `spaceManager.query.getUserSpaces()` 替代 */
    getUserSpaces(forceRefresh?: boolean): Promise<Space[]>;
    /** @deprecated 使用 `spaceManager.query.getSpaceByRoom()` 替代 */
    getSpaceByRoom(roomId: string): Promise<Space>;
    /** @deprecated 使用 `spaceManager.query.getRoomParentSpaces()` 替代 */
    getRoomParentSpaces(roomId: string, options?: SpaceQueryOptions): Promise<Space[]>;
    /** @deprecated 使用 `spaceManager.query.isSpace()` 替代 */
    isSpace(roomId: string): Promise<boolean>;
    /** @deprecated 使用 `spaceManager.query.getSpaceStats()` 替代 */
    getSpaceStats(spaceId: string): Promise<{
        memberCount: number;
        childCount: number;
    }>;
    /** @deprecated 使用 `spaceManager.child.getSpaceChildren()` 替代 */
    getSpaceChildren(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceChild[]>;
    /** @deprecated 使用 `spaceManager.child.addChild()` 替代 */
    addChild(spaceId: string, options: AddChildOptions): Promise<void>;
    /** @deprecated 使用 `spaceManager.child.removeChild()` 替代 */
    removeChild(spaceId: string, roomId: string): Promise<void>;
    /** @deprecated 使用 `spaceManager.child.getSpaceRooms()` 替代 */
    getSpaceRooms(spaceId: string, options?: SpaceQueryOptions): Promise<Space[]>;
    /** @deprecated 使用 `spaceManager.child.getSpaceState()` 替代 */
    getSpaceState(spaceId: string): Promise<unknown[]>;
    /**
     * Get all state events for a room via the standard Matrix /rooms/{roomId}/state endpoint.
     * Unlike getSpaceState (which uses /spaces/{spaceId}/state), this uses the standard
     * room state endpoint and returns raw state events.
     *
     * @param roomId - The room ID (typically a space room)
     * @returns Array of raw state event objects
     */
    getRoomStateEventsRaw(roomId: string): Promise<Array<Record<string, unknown>>>;
    /** @deprecated 使用 `spaceManager.member.getSpaceMembers()` 替代 */
    getSpaceMembers(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceMember[]>;
    /** @deprecated 使用 `spaceManager.member.inviteToSpace()` 替代 */
    inviteToSpace(spaceId: string, userId: string, body?: Record<string, unknown>): Promise<void>;
    /** @deprecated 使用 `spaceManager.member.joinSpace()` 替代 */
    joinSpace(spaceId: string, body?: Record<string, unknown>): Promise<Record<string, unknown>>;
    /** @deprecated 使用 `spaceManager.member.leaveSpace()` 替代 */
    leaveSpace(spaceId: string, body?: Record<string, unknown>): Promise<void>;
    /** @deprecated 使用 `spaceManager.hierarchy.getSpaceHierarchy()` 替代 */
    getSpaceHierarchy(spaceId: string): Promise<SpaceHierarchy>;
    /** @deprecated 使用 `spaceManager.hierarchy.getSpaceHierarchyPage()` 替代 */
    getSpaceHierarchyPage(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceHierarchyPage>;
    /** @deprecated 使用 `spaceManager.hierarchy.getSpaceHierarchyV1()` 替代 */
    getSpaceHierarchyV1(spaceId: string, options?: SpaceQueryOptions): Promise<SpaceHierarchyPage>;
    /** @deprecated 使用 `spaceManager.hierarchy.getSpaceSummary()` 替代 */
    getSpaceSummary(spaceId: string, options?: SpaceQueryOptions): Promise<Record<string, unknown>>;
    /** @deprecated 使用 `spaceManager.hierarchy.getSpaceSummaryWithChildren()` 替代 */
    getSpaceSummaryWithChildren(spaceId: string, options?: SpaceQueryOptions): Promise<Record<string, unknown>>;
    /** @deprecated 使用 `spaceManager.hierarchy.getSpaceTreePath()` 替代 */
    getSpaceTreePath(spaceId: string, options?: SpaceQueryOptions): Promise<Record<string, unknown>>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map