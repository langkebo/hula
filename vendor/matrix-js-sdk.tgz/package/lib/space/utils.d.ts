/**
 * Space 共享纯函数辅助方法
 *
 * 提取自原 index.ts，被多个 sub-managers 共同消费（避免跨 sub-manager 访问私有方法）。
 */
import type { SpacePathPattern } from "./__generated__/route-table";
import type { Space, SpaceListResponse } from "./types";
type JsonObject = Record<string, unknown>;
export type StripV3<P extends string> = P extends `/_matrix/client/v3${infer Rest}` ? Rest : never;
export declare function sp<P extends StripV3<SpacePathPattern>>(path: P): P;
export declare function spacePath(pathTemplate: string, spaceId: string): string;
export declare function asString(value: unknown): string | undefined;
export declare function asNumber(value: unknown): number | undefined;
export declare function asBoolean(value: unknown): boolean | undefined;
export declare function asStringArray(value: unknown): string[];
export declare function normalizeSpace(space?: JsonObject, fallbackId?: string): Space;
export declare function extractSpaces(response: unknown): Space[];
export declare function normalizeSpaceListResponse(response: SpaceListResponse): SpaceListResponse;
export {};
//# sourceMappingURL=utils.d.ts.map