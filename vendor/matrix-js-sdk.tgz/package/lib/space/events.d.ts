/**
 * Space 事件定义
 *
 * 提取到独立文件以便 sub-managers 导入而不产生循环依赖。
 */
import type { Space } from "./types";
export declare enum SpaceEvent {
    SpaceCreated = "SpaceCreated",
    SpaceUpdated = "SpaceUpdated",
    SpaceDeleted = "SpaceDeleted",
    ChildAdded = "ChildAdded",
    ChildRemoved = "ChildRemoved",
    MemberJoined = "MemberJoined",
    MemberLeft = "MemberLeft",
    SpaceError = "SpaceError"
}
export interface SpaceManagerEventMap {
    [SpaceEvent.SpaceCreated]: (space: Space) => void;
    [SpaceEvent.SpaceUpdated]: (space: Space) => void;
    [SpaceEvent.SpaceDeleted]: (spaceId: string) => void;
    [SpaceEvent.ChildAdded]: (spaceId: string, roomId: string) => void;
    [SpaceEvent.ChildRemoved]: (spaceId: string, roomId: string) => void;
    [SpaceEvent.MemberJoined]: (spaceId: string, userId: string) => void;
    [SpaceEvent.MemberLeft]: (spaceId: string, userId: string) => void;
    [SpaceEvent.SpaceError]: (error: Error) => void;
}
//# sourceMappingURL=events.d.ts.map