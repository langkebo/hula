/**
 * DTO snippets extracted from the contract doc for `space`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type SpaceContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map