/**
 * DTO snippets extracted from the contract doc for `space`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type SpaceJsonValue = string | number | boolean | null | SpaceJsonValue[] | {
    [key: string]: SpaceJsonValue;
};
export interface SpaceResponse {
    space_id: string;
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    creator: string;
    join_rule: string;
    visibility?: string;
    is_public: boolean;
    created_ts: number;
    updated_ts?: number;
    parent_space_id?: string;
}
export interface CreateSpaceRequest {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    join_rule?: string;
    visibility?: string;
    is_public?: boolean;
    parent_space_id?: string;
}
export interface UpdateSpaceRequest {
    name?: string;
    topic?: string;
    avatar_url?: string;
    join_rule?: string;
    visibility?: string;
    is_public?: boolean;
}
export interface SpaceChildItem {
    space_id: string;
    room_id: string;
    via_servers: string[];
    sender: string;
    is_suggested: boolean;
    added_ts: number;
}
export interface AddSpaceChildRequest {
    room_id: string;
    via_servers: string[];
    suggested?: boolean;
}
export interface SpaceMemberItem {
    space_id: string;
    user_id: string;
    membership: string;
    joined_ts: number;
    inviter?: string;
}
export interface InviteSpaceUserRequest {
    user_id: string;
}
export interface SpaceHierarchyRoomItem {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    join_rule: string;
    world_readable: boolean;
    guest_can_join: boolean;
    num_joined_members: number;
    room_type?: string;
    children_state: SpaceJsonValue[];
}
export interface SpaceHierarchyResponse {
    space: SpaceResponse;
    children: SpaceChildItem[];
    members: SpaceMemberItem[];
    rooms: SpaceHierarchyRoomItem[];
}
export interface SpaceListResponse {
    spaces: SpaceResponse[];
    next_batch?: string;
}
export interface SpaceMembersResponse {
    members: SpaceMemberItem[];
    next_batch?: string;
}
export interface SpaceRoomsResponse {
    space_id: string;
    rooms: string[];
    next_batch?: string;
}
export interface SpaceStatisticsItem {
    space_id: string;
    name?: string;
    is_public: boolean;
    child_room_count: number;
    member_count: number;
    created_ts: number;
    updated_ts: number;
}
export interface SpaceSummaryItem {
    id: number;
    space_id: string;
    summary: SpaceJsonValue;
    children_count?: number;
    member_count?: number;
    updated_ts: number;
}
export type SpaceChildListResponse = SpaceChildItem[];
export type SpaceResponseListResponse = SpaceResponse[];
export type SpaceStateResponse = SpaceJsonValue[];
//# sourceMappingURL=dto.d.ts.map