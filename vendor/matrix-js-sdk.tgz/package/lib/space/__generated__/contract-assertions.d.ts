export declare const SPACE_ROUTES_ENTRY_COUNT: 72;
export declare const SPACE_ROUTES_STATUS_SCENARIOS: readonly [];
export type SpaceStatusScenario = (typeof SPACE_ROUTES_STATUS_SCENARIOS)[number];
export declare const SPACE_ROUTES_ERROR_SCENARIOS: readonly [];
export type SpaceErrorScenario = (typeof SPACE_ROUTES_ERROR_SCENARIOS)[number];
export declare const SPACE_ROUTES_ERRCODES: readonly [];
export type SpaceErrcode = (typeof SPACE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map