/** Routes served by the synapse-rust `space` module (mirrored from the backend contract). */
export declare const SPACE_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/spaces";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/public";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/room/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/room/{room_id}/parents";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/search";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/statistics";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/user";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/spaces/{space_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/spaces/{space_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/children";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/children";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/children/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/hierarchy";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/hierarchy/v1";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/invite";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/join";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/leave";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/members";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/rooms";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/state";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/summary";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/summary/with_children";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/spaces/{space_id}/tree_path";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/spaces";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/public";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/room/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/room/{room_id}/parents";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/search";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/statistics";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/user";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/spaces/{space_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/spaces/{space_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/children";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/children";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/children/{room_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/hierarchy";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/hierarchy/v1";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/invite";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/join";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/leave";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/members";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/rooms";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/state";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/summary";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/summary/with_children";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/spaces/{space_id}/tree_path";
}];
/** Union of every (method, path) tuple in `SPACE_ROUTES`. */
export type SpaceRoute = (typeof SPACE_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type SpaceMethod = SpaceRoute["method"];
/** Path templates referenced by this module. */
export type SpacePath = SpaceRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type SpaceReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${SpaceReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type SpacePathPattern = SpaceReplaceBraces<SpacePath>;
//# sourceMappingURL=route-table.d.ts.map