import { type MRoomTopicEventContent } from "./@types/topic";
import { type RoomMessageEventContent } from "./@types/events";
import { type MBeaconInfoEventContent, type MBeaconEventContent } from "./@types/beacon";
/**
 * Generates the content for a HTML Message event
 * @param body - the plaintext body of the message
 * @param htmlBody - the HTML representation of the message
 * @returns
 */
export declare function makeHtmlMessage(body: string, htmlBody: string): RoomMessageEventContent;
/**
 * Generates the content for a HTML Notice event
 * @param body - the plaintext body of the notice
 * @param htmlBody - the HTML representation of the notice
 * @returns
 */
export declare function makeHtmlNotice(body: string, htmlBody: string): RoomMessageEventContent;
/**
 * Generates the content for a HTML Emote event
 * @param body - the plaintext body of the emote
 * @param htmlBody - the HTML representation of the emote
 * @returns
 */
export declare function makeHtmlEmote(body: string, htmlBody: string): RoomMessageEventContent;
/**
 * Generates the content for a Plaintext Message event
 * @param body - the plaintext body of the emote
 * @returns
 */
export declare function makeTextMessage(body: string): RoomMessageEventContent;
/**
 * Generates the content for a Plaintext Notice event
 * @param body - the plaintext body of the notice
 * @returns
 */
export declare function makeNotice(body: string): RoomMessageEventContent;
/**
 * Generates the content for a Plaintext Emote event
 * @param body - the plaintext body of the emote
 * @returns
 */
export declare function makeEmoteMessage(body: string): RoomMessageEventContent;
/**
 * Topic event helpers
 */
export type MakeTopicContent = (topic: string | null | undefined, htmlTopic?: string) => MRoomTopicEventContent;
export declare const makeTopicContent: MakeTopicContent;
export type TopicState = {
    text?: string;
    html?: string;
};
export declare const parseTopicContent: (content: MRoomTopicEventContent) => TopicState;
/**
 * Beacon event helpers
 */
export interface BeaconInfoState {
    description?: string;
    timeout: number;
    live?: boolean;
    timestamp?: number;
    assetType?: string;
}
export interface BeaconLocationState {
    uri?: string;
    description?: string;
    timestamp?: number;
}
export declare const parseBeaconInfoContent: (content: MBeaconInfoEventContent) => BeaconInfoState;
export declare const parseBeaconContent: (content: MBeaconEventContent) => BeaconLocationState;
//# sourceMappingURL=content-helpers.d.ts.map