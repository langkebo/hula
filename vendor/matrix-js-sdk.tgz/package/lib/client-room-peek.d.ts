import type { SyncApi } from "./sync";
import type { Room } from "./models/room";
export declare function beginRoomPeek(roomId: string, limit: number, currentPeekSync: SyncApi | null, createPeekSync: () => SyncApi): {
    nextPeekSync: SyncApi;
    peekPromise: Promise<Room>;
};
export declare function endRoomPeek(currentPeekSync: SyncApi | null): SyncApi | null;
//# sourceMappingURL=client-room-peek.d.ts.map