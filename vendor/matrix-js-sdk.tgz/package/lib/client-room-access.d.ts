import type { ICreateRoomOpts, IGuestAccessOpts } from "./@types/requests";
import { MSC3089TreeSpace } from "./models/MSC3089TreeSpace";
import type { Room } from "./models/room";
import type { User } from "./models/user";
import type { IStore } from "./store";
export declare function setGuestAccessRequest(roomId: string, opts: IGuestAccessOpts, sendGuestAccessState: (roomId: string, allowJoin: boolean) => Promise<unknown>, sendHistoryVisibilityWorldReadable: (roomId: string) => Promise<unknown>): Promise<void>;
export declare function createFileTreeSpaceRequest(name: string, getUserId: () => string | null, createRoom: (opts: ICreateRoomOpts) => Promise<{
    room_id: string;
}>, createTreeSpace: (roomId: string) => MSC3089TreeSpace): Promise<MSC3089TreeSpace>;
export declare function getFileTreeSpaceReference(roomId: string, getRoom: (roomId: string) => Room | null, createTreeSpace: (roomId: string) => MSC3089TreeSpace): MSC3089TreeSpace | null;
/**
 * `MatrixClient.getRoom` 的方法体（2026-10-24 拆域试点）。
 *
 * 语义拆域前后**逐字保持**：`roomId` 为 `undefined` / 空串 ⇒ `null`（不是抛错）。
 * `client.ts` 侧只剩 JSDoc + 一行 `return getRoomImpl(this.store, roomId);` ——
 * JSDoc 必须留在那边（TypeDoc 从 `client.ts` 读）。
 */
export declare function getRoomImpl(store: IStore, roomId: string | undefined): Room | null;
/** `MatrixClient.getUser` 的方法体：不存在返回 `null`。 */
export declare function getUserImpl(store: IStore, userId: string): User | null;
/** `MatrixClient.getUsers` 的方法体：store 空时返回空数组（`Store.getUsers()` 的契约）。 */
export declare function getUsersImpl(store: IStore): User[];
//# sourceMappingURL=client-room-access.d.ts.map