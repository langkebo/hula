import type { ICreateRoomOpts, IGuestAccessOpts } from "./@types/requests.ts";
import { MSC3089TreeSpace } from "./models/MSC3089TreeSpace.ts";
import type { Room } from "./models/room.ts";
export declare function setGuestAccessRequest(roomId: string, opts: IGuestAccessOpts, sendGuestAccessState: (roomId: string, allowJoin: boolean) => Promise<unknown>, sendHistoryVisibilityWorldReadable: (roomId: string) => Promise<unknown>): Promise<void>;
export declare function createFileTreeSpaceRequest(name: string, getUserId: () => string | null, createRoom: (opts: ICreateRoomOpts) => Promise<{
    room_id: string;
}>, createTreeSpace: (roomId: string) => MSC3089TreeSpace): Promise<MSC3089TreeSpace>;
export declare function getFileTreeSpaceReference(roomId: string, getRoom: (roomId: string) => Room | null, createTreeSpace: (roomId: string) => MSC3089TreeSpace): MSC3089TreeSpace | null;
//# sourceMappingURL=client-room-access.d.ts.map