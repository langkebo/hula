import { type IHttpOpts, type MatrixHttpApi } from "./http-api/index";
import { type Logger } from "./logger";
export interface ICapability {
    enabled: boolean;
}
export interface IChangePasswordCapability extends ICapability {
}
export interface IThreadsCapability extends ICapability {
}
export interface IGetLoginTokenCapability extends ICapability {
}
export interface ISetDisplayNameCapability extends ICapability {
}
export interface ISetAvatarUrlCapability extends ICapability {
}
export interface IProfileFieldsCapability extends ICapability {
}
export interface ISsoCapability extends ICapability {
    enabled: boolean;
    providers?: string[];
}
export declare enum RoomVersionStability {
    Stable = "stable",
    Unstable = "unstable"
}
export interface IRoomVersionsCapability {
    default: string;
    available: Record<string, RoomVersionStability>;
}
/**
 * A representation of the capabilities advertised by a homeserver as defined by
 * [Capabilities negotiation](https://spec.matrix.org/v1.6/client-server-api/#get_matrixclientv3capabilities).
 */
export interface Capabilities {
    [key: string]: unknown;
    "m.change_password"?: IChangePasswordCapability;
    "m.room_versions"?: IRoomVersionsCapability;
    "io.element.thread"?: IThreadsCapability;
    "m.get_login_token"?: IGetLoginTokenCapability;
    "org.matrix.msc3882.get_login_token"?: IGetLoginTokenCapability;
    "m.set_displayname"?: ISetDisplayNameCapability;
    "m.set_avatar_url"?: ISetAvatarUrlCapability;
    "uk.tcpip.msc4133.profile_fields"?: IProfileFieldsCapability;
    /**
     * Since Matrix v1.16
     */
    "m.profile_fields"?: IProfileFieldsCapability;
    "m.sso"?: ISsoCapability;
    /** 阅后即焚（burn-after-read feature） */
    "io.hula.burn_after_read"?: ICapability;
    /** 好友系统（friends feature） */
    "io.hula.friends"?: ICapability;
    /** 语音消息扩展（voice-extended feature），与 m.voice 别名等价 */
    "io.hula.voice_extended"?: ICapability;
    /** Matrix 标准语音（与 io.hula.voice_extended 别名等价） */
    "m.voice"?: ICapability;
    /** 不稳定特性集合（unstable features） - 后端返回在顶层 unstable_features */
    unstable_features?: Record<string, boolean>;
}
/**
 * Manages storing and periodically refreshing the server capabilities.
 */
export declare class ServerCapabilities {
    private readonly logger;
    private readonly http;
    private capabilities?;
    /**
     * Top-level `unstable_features` from the `/capabilities` response.
     * Synapse-Rust returns it alongside `capabilities`; stock servers omit it.
     */
    private unstableFeatures?;
    private retryTimeout?;
    private refreshTimeout?;
    /**
     * S-15: Re-entrancy guard. `start()` used to unconditionally kick off `poll()`, so two
     * concurrent callers (e.g. `MatrixClient.startClient()` racing an explicit
     * `fetchServerCapabilities()` caller) spawned two independent self-rescheduling poll chains.
     * Each chain re-arms itself forever, so the duplicate was never collected and every
     * subsequent `stop()` only ever cleared one of them.
     */
    private started;
    constructor(logger: Logger, http: MatrixHttpApi<IHttpOpts & {
        onlyData: true;
    }>);
    /**
     * Starts periodically fetching the server capabilities.
     * Idempotent: calling this while already started is a no-op.
     */
    start(): void;
    /**
     * Stops the service
     */
    stop(): void;
    /**
     * Returns the cached capabilities, or undefined if none are cached.
     * @returns the current capabilities, if any.
     */
    getCachedCapabilities(): Capabilities | undefined;
    /**
     * Fetches the latest server capabilities from the homeserver and returns them, or rejects
     * on failure.
     */
    fetchCapabilities: () => Promise<Capabilities>;
    /**
     * Returns the cached `unstable_features` from the last capabilities fetch,
     * or undefined if none are cached (or the server did not send any).
     *
     * Synapse-Rust 后端在 `/capabilities` 响应顶层返回 `unstable_features`，
     * 包含如 `org.matrix.msc4204`、`io.hula.friends` 等布尔型能力开关。
     */
    getUnstableFeatures(): Record<string, boolean> | undefined;
    /**
     * Checks whether the server advertises a specific unstable feature.
     *
     * Matching is **exact**, against the keys the server actually sent in the
     * top-level `unstable_features` map.
     *
     * The previous implementation guessed the key by string-prefixing the
     * argument (`org.matrix.msc${name}`). That happened to work for keys the
     * server already spells `org.matrix.mscNNNN…`, but produced garbage for
     * every other key: `io.hula.friends` was looked up as
     * `org.matrix.mscio.hula.friends`, `uk.tcpip.msc4133` as
     * `org.matrix.mscuk.tcpip.msc4133`. Of the nine keys the synapse-rust
     * backend emits (`synapse-services/src/capability_governance.rs:451-465`)
     * only five were ever matchable.
     *
     * The real key set is:
     * `io.hula.friends`, `org.matrix.msc3245.voice`,
     * `org.matrix.msc3983.thread`, `org.matrix.msc3886.sliding_sync`,
     * `org.matrix.simplified_msc3575`, `org.matrix.msc4186`,
     * `io.hula.burn_after_read`, `org.matrix.msc4108`, `uk.tcpip.msc4133`.
     *
     * @param name - the exact feature key. A bare MSC number (`"4204"` or
     *   `"msc4204"`) is also accepted and expanded to `org.matrix.msc4204`;
     *   anything else must be passed verbatim.
     * @returns true only when the server sent that key with a `true` value.
     */
    hasUnstableFeature(name: string): boolean;
    private poll;
    private clearTimeouts;
}
//# sourceMappingURL=serverCapabilities.d.ts.map