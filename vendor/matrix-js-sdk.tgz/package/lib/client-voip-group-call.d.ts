import { GroupCall } from "./web-rtc/groupCall";
import type { MatrixClient } from "./client";
import type { GroupCallType, GroupCallIntent, IGroupCallDataChannelOptions } from "./web-rtc/groupCall";
/**
 * Create a new group call for the given room.
 * Extracted from createGroupCall to keep client.ts thin.
 */
export declare function createGroupCallForRoom(client: MatrixClient, roomId: string, type: GroupCallType, isPtt: boolean, intent: GroupCallIntent, dataChannelsEnabled?: boolean, dataChannelOptions?: IGroupCallDataChannelOptions): Promise<GroupCall>;
//# sourceMappingURL=client-voip-group-call.d.ts.map