import { Method, type Body, type IRequestOpts } from "./http-api/index";
import type { IThirdPartyLocation, IThirdPartyUser } from "./client-internal-types";
import type { IProtocol } from "./client-api-types";
import type { QueryDict } from "./utils";
import type { ThirdPartyLocationSearchParams, ThirdPartyUserSearchParams } from "./third-party";
export interface AuthedRequestFn {
    <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, paramOpts?: IRequestOpts): Promise<T>;
}
/**
 * 构造并按协议查询第三方**位置**（内部请求件，`client.getThirdpartyLocation()` 走这里）。
 *
 * ⚠️ **本后端不实现这条端点**：`GET /thirdparty/location/{protocol}` 恒返 `404 M_NOT_FOUND`。
 * 这是纯 URL 构造 + 一次请求，没有降级路径 —— 调用方拿到的一定是错误。
 *
 * @backendUnsupported 404 M_NOT_FOUND
 */
export declare function getThirdpartyLocationRequest(protocol: string, params: ThirdPartyLocationSearchParams | undefined, authedRequest: AuthedRequestFn): Promise<IThirdPartyLocation[]>;
/**
 * 构造并按协议查询第三方**用户**（内部请求件，`client.getThirdpartyUser()` 走这里）。
 *
 * ⚠️ **本后端不实现这条端点**：`GET /thirdparty/user/{protocol}` 恒返 `404 M_NOT_FOUND`。
 *
 * @backendUnsupported 404 M_NOT_FOUND
 */
export declare function getThirdpartyUserRequest(protocol: string, params: ThirdPartyUserSearchParams | undefined, authedRequest: AuthedRequestFn): Promise<IThirdPartyUser[]>;
export declare function getThirdpartyProtocolsRequest(authedRequest: AuthedRequestFn): Promise<{
    [protocol: string]: IProtocol;
}>;
//# sourceMappingURL=client-third-party.d.ts.map