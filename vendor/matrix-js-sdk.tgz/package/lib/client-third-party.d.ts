import { Method, type Body, type IRequestOpts } from "./http-api/index";
import type { IThirdPartyLocation, IThirdPartyUser } from "./client-internal-types";
import type { IProtocol } from "./client-api-types";
import type { QueryDict } from "./utils";
export interface AuthedRequestFn {
    <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, paramOpts?: IRequestOpts): Promise<T>;
}
export declare function getThirdpartyLocationRequest(protocol: string, params: {
    searchFields?: string[];
}, authedRequest: AuthedRequestFn): Promise<IThirdPartyLocation[]>;
export declare function getThirdpartyUserRequest(protocol: string, params: QueryDict | undefined, authedRequest: AuthedRequestFn): Promise<IThirdPartyUser[]>;
export declare function getThirdpartyProtocolsRequest(authedRequest: AuthedRequestFn): Promise<{
    [protocol: string]: IProtocol;
}>;
//# sourceMappingURL=client-third-party.d.ts.map