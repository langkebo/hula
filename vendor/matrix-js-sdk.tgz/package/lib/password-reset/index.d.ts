/**
 * Password Reset Manager - 密码重置管理
 *
 * 提供密码重置相关功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { EmptyObject } from "../@types/common";
import type { IRequestTokenResponse, IRequestMsisdnTokenResponse } from "../client-api-types";
import type { AuthDict } from "../interactive-auth";
export type PasswordResetManagerEvents = Record<"password_reset_token_requested" | "password_changed", ((data: {
    type: "email" | "msisdn";
}) => void) | (() => void)>;
export declare class PasswordResetManager extends BaseManager<keyof PasswordResetManagerEvents, PasswordResetManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    requestPasswordEmailToken(email: string, clientSecret: string, sendAttempt: number, nextLink?: string): Promise<IRequestTokenResponse>;
    requestPasswordMsisdnToken(phoneCountry: string, phoneNumber: string, clientSecret: string, sendAttempt: number, nextLink: string): Promise<IRequestMsisdnTokenResponse>;
    setPassword(authDict: AuthDict, newPassword: string, logoutDevices?: boolean): Promise<EmptyObject>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map