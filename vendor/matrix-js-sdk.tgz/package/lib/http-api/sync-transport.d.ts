import type { Method } from "./method";
import type { Body, IRequestOpts } from "./index";
import type { QueryDict } from "../utils";
/**
 * Minimal transport interface for SyncApi HTTP access.
 * ISSUE-12: SyncApi should not directly access client.http — it should
 * depend on this narrow interface instead, making the network layer
 * replaceable for testing and future transport implementations.
 */
export interface ISyncTransport {
    authedRequest<T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts): Promise<T>;
    request<T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts): Promise<T>;
}
//# sourceMappingURL=sync-transport.d.ts.map