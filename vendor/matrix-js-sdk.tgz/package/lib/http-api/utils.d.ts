export declare function timeoutSignal(ms: number): AbortSignal;
export declare function anySignal(signals: AbortSignal[]): {
    signal: AbortSignal;
    cleanup(): void;
};
/**
 * Attempt to turn an HTTP error response into a Javascript Error.
 *
 * If it is a JSON response, we will parse it into a MatrixError. Otherwise
 * we return a generic Error.
 *
 * @param response - response object
 * @param body - raw body of the response
 * @returns
 */
export declare function parseErrorResponse(response: XMLHttpRequest | Response, body?: string): Error;
/**
 * Retries a network operation run in a callback.
 * @param maxAttempts - maximum attempts to try
 * @param callback - callback that returns a promise of the network operation. If rejected with ConnectionError, it will be retried by calling the callback again.
 * @returns the result of the network operation
 * @throws {@link ConnectionError} If after maxAttempts the callback still throws ConnectionError
 */
export declare function retryNetworkOperation<T>(maxAttempts: number, callback: () => Promise<T>): Promise<T>;
/**
 * Calculate the backoff time for a request retry attempt.
 * This produces wait times of 2, 4, 8, and 16 seconds (30s total) after which we give up. If the
 * failure was due to a rate limited request, the time specified in the error is returned.
 *
 * Returns -1 if the error is not retryable, or if we reach the maximum number of attempts.
 *
 * @param err - The error thrown by the http call
 * @param attempts - The number of attempts made so far, including the one that just failed.
 * @param retryConnectionError - Whether to retry on {@link ConnectionError} (CORS, connection is down, etc.)
 */
export declare function calculateRetryBackoff(err: unknown, attempts: number, retryConnectionError: boolean): number;
export type QueryDict = Record<string, string[] | string | number | boolean | undefined>;
/**
 * Encode a dictionary of query parameters.
 * Omits any undefined/null values.
 * @param params - A dict of key/values to encode e.g.
 * `{"foo": "bar", "baz": "taz"}`
 * @returns The encoded string e.g. foo=bar&baz=taz
 */
export declare function encodeParams(params: QueryDict, urlSearchParams?: URLSearchParams): URLSearchParams;
/**
 * Replace a stable parameter with the unstable naming for params
 */
export declare function replaceParam(stable: string, unstable: string, dict: QueryDict): QueryDict;
/**
 * Encodes a URI according to a set of template variables. Variables will be
 * passed through encodeURIComponent.
 * @param pathTemplate - The path with template variables e.g. '/foo/$bar'.
 * @param variables - The key/value pairs to replace the template
 * variables with. E.g. `{ "$bar": "baz" }`.
 * @returns The result of replacing all template variables e.g. '/foo/baz'.
 */
export declare function encodeUri(pathTemplate: string, variables: Record<string, string | null | undefined>): string;
export declare function ensureNoTrailingSlash(url: string): string;
export declare function ensureNoTrailingSlash(url: undefined): undefined;
export declare function ensureNoTrailingSlash(url?: string): string | undefined;
//# sourceMappingURL=utils.d.ts.map