export declare enum ClientPrefix {
    /**
     * A constant representing the URI path for Client-Server API endpoints versioned at r0 (legacy).
     */
    R0 = "/_matrix/client/r0",
    /**
     * A constant representing the URI path for Client-Server API endpoints versioned at v1.
     */
    V1 = "/_matrix/client/v1",
    /**
     * A constant representing the URI path for Client-Server API endpoints versioned at v3.
     */
    V3 = "/_matrix/client/v3",
    /**
     * A constant representing the URI path for as-yet unspecified Client-Server HTTP APIs.
     */
    Unstable = "/_matrix/client/unstable"
}
export declare enum IdentityPrefix {
    /**
     * URI path for the v2 identity API
     */
    V2 = "/_matrix/identity/v2"
}
export declare enum MediaPrefix {
    /**
     * A constant representing the URI path for Client-Server API Media endpoints versioned at v1.
     */
    V1 = "/_matrix/media/v1",
    /**
     * A constant representing the URI path for Client-Server API Media endpoints versioned at v3.
     */
    V3 = "/_matrix/media/v3"
}
export declare enum AdminPrefix {
    /**
     * A constant representing the URI path for Synapse Admin API endpoints versioned at v1.
     */
    V1 = "/_synapse/admin/v1"
}
/**
 * Vendor prefix for private/non-standard endpoints.
 * ISSUE-13: Private endpoints should not pollute the standard
 * /_matrix/client/v3 namespace. They use /_matrix/vendor/v1 instead.
 */
export declare const VendorPrefix = "/_matrix/vendor/v1";
//# sourceMappingURL=prefix.d.ts.map