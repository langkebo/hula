export declare function assertSecureBaseUrl(baseUrl: string, opts?: {
    allowInsecureDev?: boolean;
}): void;
//# sourceMappingURL=base-url-guard.d.ts.map