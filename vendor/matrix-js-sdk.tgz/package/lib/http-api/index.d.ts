import { FetchHttpApi } from "./fetch";
import { type FileType, type IContentUri, type IHttpOpts, type Upload, type UploadOpts, type UploadResponse } from "./interface";
export * from "./interface";
export * from "./prefix";
export * from "./errors";
export * from "./method";
export * from "./utils";
export * from "./sync-transport";
export declare class MatrixHttpApi<O extends IHttpOpts> extends FetchHttpApi<O> {
    private uploads;
    /**
     * Upload content to the homeserver
     *
     * @param file - The object to upload. On a browser, something that
     *   can be sent to XMLHttpRequest.send (typically a File).  Under node.js,
     *   a Buffer, String or ReadStream.
     *
     * @param opts - options object
     *
     * @returns Promise which resolves to response object, or rejects with an error (usually a MatrixError).
     * @throws May throw a `MatrixSafetyError` if content is deemed unsafe.
     * @see MatrixSafetyError
     */
    uploadContent(file: FileType, opts?: UploadOpts): Promise<UploadResponse>;
    cancelUpload(promise: Promise<UploadResponse>): boolean;
    getCurrentUploads(): Upload[];
    /**
     * Get the content repository url with query parameters.
     * SEC-08: access_token is no longer included in params to prevent URL leakage.
     * Use Authorization header for authenticated media requests instead (ISSUE-09).
     * @returns An object with a 'base', 'path' and 'params' for base URL,
     *          path and query parameters respectively.
     */
    getContentUri(): IContentUri;
}
//# sourceMappingURL=index.d.ts.map