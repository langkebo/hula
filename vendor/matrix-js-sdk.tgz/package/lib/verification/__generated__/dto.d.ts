/**
 * DTO snippets extracted from the contract doc for `verification_routes`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type VerificationContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map