export declare const VERIFICATION_ROUTES_ENTRY_COUNT: 36;
export declare const VERIFICATION_ROUTES_STATUS_SCENARIOS: readonly [];
export type VerificationStatusScenario = (typeof VERIFICATION_ROUTES_STATUS_SCENARIOS)[number];
export declare const VERIFICATION_ROUTES_ERROR_SCENARIOS: readonly [];
export type VerificationErrorScenario = (typeof VERIFICATION_ROUTES_ERROR_SCENARIOS)[number];
export declare const VERIFICATION_ROUTES_ERRCODES: readonly [];
export type VerificationErrcode = (typeof VERIFICATION_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map