/** Routes served by the synapse-rust `verification` module (mirrored from the backend contract). */
export declare const VERIFICATION_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/keys/device_signing/requests";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/keys/device_signing/verify_accept";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_signing/verify_cancel";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_signing/verify_done";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_signing/verify_key_agreement";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_signing/verify_mac";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/device_signing/verify_start";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/qr_code/scan";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/keys/qr_code/show";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/verification/request";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/keys/verification/{transaction_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/keys/verification/{transaction_id}/cancel";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/device_signing/requests";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/keys/device_signing/verify_accept";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_signing/verify_cancel";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_signing/verify_done";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_signing/verify_key_agreement";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_signing/verify_mac";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/device_signing/verify_start";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/qr_code/scan";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/qr_code/show";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/verification/request";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/keys/verification/{transaction_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/keys/verification/{transaction_id}/cancel";
}];
/** Union of every (method, path) tuple in `VERIFICATION_ROUTES`. */
export type VerificationRoute = (typeof VERIFICATION_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type VerificationMethod = VerificationRoute["method"];
/** Path templates referenced by this module. */
export type VerificationPath = VerificationRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type VerificationReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${VerificationReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type VerificationPathPattern = VerificationReplaceBraces<VerificationPath>;
//# sourceMappingURL=route-table.d.ts.map