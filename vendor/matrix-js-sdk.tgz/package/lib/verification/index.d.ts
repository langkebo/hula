import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
type VerificationApiVersion = "v1" | "v3";
/**
 * VerificationManager — 设备/交叉签名互认证
 *
 * 对接后端 `synapse-rust/src/web/routes/verification_routes.rs`：
 *   - POST /keys/device_signing/verify_start
 *   - PUT  /keys/device_signing/verify_accept
 *   - POST /keys/device_signing/verify_key_agreement
 *   - POST /keys/device_signing/verify_mac
 *   - POST /keys/device_signing/verify_done
 *   - POST /keys/device_signing/verify_cancel
 *   - GET  /keys/device_signing/requests
 *   - GET  /keys/qr_code/show
 *   - POST /keys/qr_code/scan
 *
 * 默认使用 `/_matrix/client/v1` 保持兼容；调用方可显式传入 `v3` 使用生成契约中的新版路径。
 */
export interface VerificationStartRequest {
    /** 发起方的 device_id；后端要求字符串 */
    from_device: string;
    /** 目标用户 */
    to_user: string;
    /** 可选：目标 device，省略表示对该用户所有设备 */
    to_device?: string;
    /** 可选：transaction_id，省略时由后端生成 */
    transaction_id?: string;
    /** 可选：method，默认 m.sas.v1 */
    method?: string;
}
export interface VerificationStartResponse {
    transaction_id: string;
    method: string;
    key_agreement_protocol: string[];
    hash: string[];
    short_authentication_string: string[];
}
export interface VerificationAcceptRequest {
    transaction_id: string;
    key_agreement_protocol: string;
    hash: string;
    commitment?: string;
}
export interface VerificationAcceptResponse extends VerificationStartResponse {
    commitment?: string;
}
export interface VerificationKeyAgreementRequest {
    transaction_id: string;
    /** Curve25519 公钥（base64） */
    pubkey: string;
}
export interface VerificationKeyAgreementResponse {
    transaction_id: string;
    confirmed: boolean;
    /** SAS 表征：emoji + decimal 三段，或纯 decimal */
    short_authentication_string: {
        emoji?: string[];
        decimal?: {
            points: number[];
        };
    };
}
export interface VerificationMacRequest {
    transaction_id: string;
    mac: string;
}
export interface VerificationMacResponse {
    transaction_id: string;
    verified: boolean;
}
export interface VerificationDoneRequest {
    transaction_id: string;
    mac: string;
}
export interface VerificationCancelRequest {
    transaction_id: string;
    code: string;
    reason: string;
}
export interface VerificationCancelResponse {
    transaction_id: string;
    state: "cancelled";
    code: string;
    reason: string;
}
export interface VerificationRequestEntry {
    transaction_id: string;
    from_user: string;
    from_device: string;
    to_user: string;
    to_device?: string;
    method: string;
    state: string;
    created_ts: number;
    updated_ts: number;
}
export interface ListVerificationRequestsResponse {
    requests: VerificationRequestEntry[];
}
export interface QrCodeShowResponse {
    transaction_id: string;
    server_name: string;
    user_id: string;
    device_id: string;
    device_ed25519_key: string;
    device_curve25519_key: string;
}
export interface ScanQrCodeRequest {
    transaction_id: string;
    server_name: string;
    user_id: string;
    device_id: string;
    device_ed25519_key: string;
    device_curve25519_key: string;
}
export interface ScanQrCodeResponse {
    transaction_id: string;
    state: "pending" | "verified" | "cancelled";
}
export declare class VerificationManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    startVerification(request: VerificationStartRequest, version?: VerificationApiVersion): Promise<VerificationStartResponse>;
    acceptVerification(request: VerificationAcceptRequest, version?: VerificationApiVersion): Promise<VerificationAcceptResponse>;
    exchangeKeys(request: VerificationKeyAgreementRequest, version?: VerificationApiVersion): Promise<VerificationKeyAgreementResponse>;
    confirmMac(request: VerificationMacRequest, version?: VerificationApiVersion): Promise<VerificationMacResponse>;
    completeVerification(request: VerificationDoneRequest, version?: VerificationApiVersion): Promise<{
        transaction_id: string;
    }>;
    cancelVerification(request: VerificationCancelRequest, version?: VerificationApiVersion): Promise<VerificationCancelResponse>;
    listPendingVerifications(version?: VerificationApiVersion): Promise<ListVerificationRequestsResponse>;
    showQrCode(version?: VerificationApiVersion): Promise<QrCodeShowResponse>;
    scanQrCode(request: ScanQrCodeRequest, version?: VerificationApiVersion): Promise<ScanQrCodeResponse>;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map