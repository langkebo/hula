import type { Body, IRequestOpts } from "./http-api/index";
import { Method } from "./http-api/method";
import type { QueryDict } from "./utils";
import type { SendDelayedEventRequestOpts, SendDelayedEventResponse } from "./@types/requests";
export { buildStateEventPath } from "./client-batch-requests";
interface HttpLike {
    authedRequest<T>(method: Method, path: string, queryParams?: QueryDict, body?: unknown, opts?: IRequestOpts): Promise<T>;
}
export interface DispatchDelayedStateEventRequestArgs {
    roomId: string;
    eventType: string;
    content: Body;
    stateKey?: string;
    delayOpts: SendDelayedEventRequestOpts;
    http: HttpLike;
    requestOpts?: IRequestOpts;
    unstableDelayFeatureName: string;
}
export interface DispatchStateEventRequestArgs {
    roomId: string;
    eventType: string;
    content: Body;
    stateKey?: string;
    http: HttpLike;
    requestOpts?: IRequestOpts;
}
export declare function dispatchStateEventRequest({ roomId, eventType, content, stateKey, http, requestOpts, }: DispatchStateEventRequestArgs): Promise<unknown>;
export declare function dispatchDelayedStateEventRequest({ roomId, eventType, content, stateKey, delayOpts, http, requestOpts, unstableDelayFeatureName, }: DispatchDelayedStateEventRequestArgs): Promise<SendDelayedEventResponse>;
//# sourceMappingURL=client-send-state.d.ts.map