/**
 * User Directory Manager - 用户目录搜索 API 封装
 *
 * 提供用户目录搜索功能，支持按用户 ID 和显示名称模糊匹配
 * 对接后端: synapse-rust/src/web/routes/user_directory.rs
 * API 路径: /_matrix/client/v3/user_directory/search
 *
 * 使用方式:
 * ```typescript
 * const manager = client.getUserDirectoryManager();
 * // 搜索用户
 * const results = await manager.searchUserDirectory({ term: "alice" });
 * ```
 */
import { MatrixClient } from "../client";
import { User } from "../models/user";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IUserDirectorySearchResult {
    results: Array<{
        user_id: string;
        display_name?: string;
        avatar_url?: string;
    }>;
    limited?: boolean;
}
export interface IUserDirectoryListResult {
    users: Array<{
        user_id: string;
        display_name?: string;
        avatar_url?: string;
    }>;
}
export interface IUserDirectoryListPaginatedResult {
    users: Array<{
        user_id: string;
        display_name?: string;
        avatar_url?: string;
    }>;
    next_batch?: string;
}
export interface IUserProfile {
    avatar_url?: string;
    displayname?: string;
}
export declare class UserDirectoryManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    searchUserDirectory(term: string, limit?: number): Promise<IUserDirectorySearchResult>;
    listUserDirectory(): Promise<IUserDirectoryListResult>;
    listUserDirectoryPaginated(limit?: number, since?: string): Promise<IUserDirectoryListPaginatedResult>;
    getProfile(userId: string): Promise<IUserProfile>;
    getUser(userId: string): User | null;
    getUsers(): User[];
    getUserByDisplayName(displayName: string): User | undefined;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map