import { type IEvent, MatrixEvent, MatrixEventEvent } from "./models/event.ts";
import type { QueryDict } from "./utils.ts";
import type { Room } from "./models/room.ts";
interface ReEmitterLike {
    reEmit(target: MatrixEvent, events: MatrixEventEvent[]): void;
}
export declare function ensureTxnId(txnId: string | undefined, makeTxnId: () => string): string;
export declare function createLocalEchoEvent(eventObject: Partial<IEvent>, roomId: string, userId: string, txnId: string): MatrixEvent;
export declare function attachThreadToLocalEvent(localEvent: MatrixEvent, room: Room | null, threadId: string | null): void;
export declare function setupLocalEventReemit(localEvent: MatrixEvent, room: Room | null, reEmitter: ReEmitterLike): void;
export declare function bindPendingRelationTarget(localEvent: MatrixEvent, room: Room | null): void;
export declare function formatSendEventDebugMessage(type: string, roomId: string, txnId: string, isDelayed: boolean, queryDict?: QueryDict): string;
export declare function addPendingEventOrThrow(room: Room | null, localEvent: MatrixEvent, txnId: string): void;
export {};
//# sourceMappingURL=client-send-complete.d.ts.map