import { type Room } from "./models/room";
type RoomLookup = (roomId: string | undefined) => Room | null;
export declare function findPredecessorRoomsForUpgrade(startRoom: Room, getRoom: RoomLookup, verifyLinks: boolean, msc3946ProcessDynamicPredecessor: boolean): Room[];
export declare function findSuccessorRoomsForUpgrade(startRoom: Room, getRoom: RoomLookup, verifyLinks: boolean, msc3946ProcessDynamicPredecessor: boolean): Room[];
export declare function buildRoomUpgradeHistory(roomId: string, getRoom: RoomLookup, verifyLinks: boolean, msc3946ProcessDynamicPredecessor: boolean): Room[];
export declare function selectVisibleRoomsForClient(allRooms: Room[], getRoom: RoomLookup, msc3946ProcessDynamicPredecessor: boolean): Room[];
export {};
//# sourceMappingURL=client-room-upgrade.d.ts.map