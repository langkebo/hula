/**
 * Server Capabilities Manager - 服务器能力管理
 *
 * 提供服务器能力相关功能
 */
import { MatrixClient } from "../client";
import { Preset } from "../@types/partials";
import { FeatureSupport } from "../models/thread";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type Capabilities } from "../serverCapabilities";
import { type IServerVersions } from "../client-api-types";
export declare const SynapseRustFeature: {
    readonly ExtendedProfile: "uk.tcpip.msc4133";
    readonly SlidingSync: "org.matrix.msc3886.sliding_sync";
    readonly DehydratedDevice: "org.matrix.msc3814";
    readonly Widget: "org.matrix.msc4261.widget";
    readonly BurnAfterRead: "io.hula.burn_after_read";
    readonly Friends: "io.hula.friends";
    /**
     * ⚠️ 真实 key 为 `org.matrix.msc3245.voice`（后端 `capability_governance.rs:454`）。
     * 别名 `org.matrix.msc3245` 与 `m.voice` 由服务端在 `/versions` 中保留（:259），
     * 本 SDK 通过 SYNAPSE_RUST_CAPABILITY_ALIASES 兜底匹配。
     */
    readonly Voice: "org.matrix.msc3245.voice";
};
export type SynapseRustFeatureName = (typeof SynapseRustFeature)[keyof typeof SynapseRustFeature];
export interface SynapseRustFeatureDiscoveryClient {
    doesServerAdvertiseSynapseRustFeature?: (feature: SynapseRustFeatureName) => Promise<boolean>;
}
export interface SynapseRustFeatureSupport {
    extendedProfile: boolean;
    slidingSync: boolean;
    dehydratedDevice: boolean;
    widget: boolean;
    burnAfterRead: boolean;
    friends: boolean;
    voice: boolean;
}
export declare function isUnstableFeatureEnabled(versions: IServerVersions | undefined, feature: string): boolean;
export declare function isCapabilityEnabled(capabilities: Capabilities | undefined, capability: string): boolean;
/**
 * Resolve whether the backing server advertises a synapse-rust specific feature.
 *
 * ## `fallback` policy (S-13)
 *
 * `fallback` is what callers get when the capability probe is **unavailable**
 * (an old server without the discovery method) or **throws**. The choice is a
 * product decision per feature, and the fork's rule is:
 *
 * - **fail-closed (`false`)** — the default for features the backend has no
 *   route for: `Voice`, `Widget`,
 *   `DehydratedDevice`. Reporting "supported" would make callers fire requests
 *   at endpoints that answer 404.
 * - **fail-open (`true`)** — only for features the backend is known to serve:
 *   `SlidingSync`, `Friends`. Guessing "unsupported" here would silently
 *   disable working functionality.
 *
 * Do not flip a feature to `true` without confirming a backend route exists
 * (see `synapse-rust/docs/synapse-rust/ROUTE_CONTRACT.md`).
 *
 * @param client - object exposing the optional `doesServerAdvertiseSynapseRustFeature` probe.
 * @param feature - the feature name to probe.
 * @param fallback - value returned when the probe is missing or throws; see the policy above.
 * @param onError - optional callback invoked with the probe error (for logging).
 * @returns whether the feature is advertised.
 */
export declare function doesClientAdvertiseSynapseRustFeature(client: SynapseRustFeatureDiscoveryClient, feature: SynapseRustFeatureName, fallback: boolean, onError?: (error: unknown) => void): Promise<boolean>;
export declare function resolveSynapseRustFeatureSupport(versions: IServerVersions | undefined, capabilities?: Capabilities): SynapseRustFeatureSupport;
export interface ServerCapabilities {
}
export interface ServerCapabilitiesManagerEvents {
    capabilities_updated: {
        capabilities: ServerCapabilities;
    };
    server_version_updated: {
        version: string;
    };
}
export declare class ServerCapabilitiesManager extends BaseManager<keyof ServerCapabilitiesManagerEvents, ServerCapabilitiesManagerEvents> {
    /** Cached capabilities response */
    private cachedCapabilities?;
    /** Timestamp of when the capabilities cache was last fetched */
    private capabilitiesFetchedAt;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getServerCapabilities(): Promise<Capabilities>;
    hasServerSupport(feature: string): boolean;
    getServerVersion(): Promise<string>;
    /**
     * Check if a particular spec version is supported by the server.
     * @param version - The spec version (such as "r0.5.0") to check for.
     * @returns Whether it is supported
     */
    isVersionSupported(version: string): Promise<boolean>;
    /**
     * Query the server to see if it lists support for an unstable feature
     * in the /versions response
     * @param feature - the feature name
     * @returns true if the feature is supported
     */
    doesServerSupportUnstableFeature(feature: string): Promise<boolean>;
    doesServerAdvertiseSynapseRustFeature(feature: SynapseRustFeatureName): Promise<boolean>;
    getSynapseRustFeatureSupport(): Promise<SynapseRustFeatureSupport>;
    /**
     * Query the server to see if it is forcing encryption to be enabled for
     * a given room preset, based on the /versions response.
     * @param presetName - The name of the preset to check.
     * @returns true if the server is forcing encryption
     * for the preset.
     */
    doesServerForceEncryptionForPreset(presetName: Preset): Promise<boolean>;
    doesServerSupportThread(): Promise<{
        threads: FeatureSupport;
        list: FeatureSupport;
        fwdPagination: FeatureSupport;
    }>;
    /**
     * A helper to determine thread support
     * @returns a boolean to determine if threads are enabled
     */
    supportsThreads(): boolean;
    /**
     * A helper to determine intentional mentions support
     * @returns a boolean to determine if intentional mentions are enabled on the server
     * @experimental
     */
    supportsIntentionalMentions(): boolean;
    /**
     * Get if lazy loading members is being used.
     * @returns Whether or not members are lazy loaded by this client
     */
    hasLazyLoadMembersEnabled(): boolean;
    supportsLocation(): boolean;
    /**
     * Get the API versions supported by the server, along with any
     * unstable APIs it supports.
     * Caches the result and builds the feature support map.
     * @returns The server /versions response
     */
    getVersions(): Promise<IServerVersions>;
    /**
     * Gets a set of room IDs in common with another user.
     * Note: This endpoint is unstable (MSC2666).
     * @param userId - The userId to check.
     * @returns Promise which resolves to an array of rooms
     */
    _unstable_getSharedRooms(userId: string): Promise<string[]>;
    /**
     * Returns a set of configured RTC transports supported by the homeserver.
     * Requires homeserver support for MSC4143.
     * @throws A M_NOT_FOUND error if not supported by the homeserver.
     */
    _unstable_getRTCTransports(): Promise<Record<string, unknown>[]>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map