export declare const ADMIN_ROUTES_ENTRY_COUNT: 157;
export declare const ADMIN_ROUTES_STATUS_SCENARIOS: readonly [];
export type AdminStatusScenario = (typeof ADMIN_ROUTES_STATUS_SCENARIOS)[number];
export declare const ADMIN_ROUTES_ERROR_SCENARIOS: readonly [];
export type AdminErrorScenario = (typeof ADMIN_ROUTES_ERROR_SCENARIOS)[number];
export declare const ADMIN_ROUTES_ERRCODES: readonly [];
export type AdminErrcode = (typeof ADMIN_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map