/**
 * DTO snippets extracted from the contract doc for `admin`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface AdminServerInfoDto {
    server_name?: string;
    server_version?: string;
    implementation?: string;
}
export interface AdminServerStatsDto {
    total_users?: number;
    total_rooms?: number;
    daily_active_users?: number;
    monthly_active_users?: number;
    r30_users?: number;
    non_deactivated_user_count?: number;
    non_deactivated_user_count_by_app_service?: Record<string, number>;
    total_messages?: number;
    active_rooms?: number;
    total_members?: number;
    encrypted_rooms?: number;
    daily_messages?: number;
}
export interface AdminServerHealthDto {
    status: "ok" | "error";
    database: "ok" | "error";
}
export interface AdminServerStatusDto {
    db_ok: boolean;
    server_ok: boolean;
    up: boolean;
}
export interface AdminUserAccountDto {
    user_id?: string;
    name?: string;
    displayname?: string;
    avatar_url?: string;
    admin?: boolean;
    deactivated?: boolean;
    creation_ts?: number;
    created_ts?: number;
    user_type?: string;
    is_guest?: boolean;
}
export interface AdminDeviceDto {
    device_id: string;
    display_name?: string;
    last_seen_ip?: string;
    last_seen_ts?: number;
}
export interface AdminRoomInfoDto {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    creator?: string;
    joined_members?: number;
    joined_local_members?: number;
    invited_members?: number;
    version?: string;
    created_ts?: number;
    join_rules?: string;
    public?: boolean;
    guest_access?: string;
    history_visibility?: string;
    state_events?: number;
}
export interface AdminRoomStatsDto {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    member_count?: number;
    message_count?: number;
    last_message_ts?: number;
    is_encrypted?: boolean;
    admin_count?: number;
    created_ts?: number;
}
export interface AdminRegistrationTokenDto {
    token: string;
    uses_allowed?: number;
    pending?: number;
    completed?: number;
    expiry_time?: number;
    created_ts?: number;
}
export interface AdminRegisterResultDto {
    access_token?: string;
    refresh_token?: string;
    expires_in?: number;
    device_id?: string;
    user_id: string;
    home_server?: string;
}
export interface AdminFederationBlacklistEntryDto {
    server_name: string;
    /** 后端键名是 added_at（来自 row.created_ts.unwrap_or(0)），不是 added_ts */
    added_at: number;
    reason: string | null;
}
export interface AdminFederationDestinationDto {
    destination: string;
    retry_last_ts: number | null;
    /** 后端写死 None，恒为 null */
    retry_interval: number | null;
    failure_ts: number | null;
    /** 后端真实字段（上游 Synapse 的 last_successful_stream_ordering 本后端不返回） */
    last_successful_ts: number | null;
    failure_count: number;
    status: string;
    updated_ts: number | null;
}
//# sourceMappingURL=dto.d.ts.map