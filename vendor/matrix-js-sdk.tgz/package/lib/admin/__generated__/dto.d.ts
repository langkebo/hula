/**
 * DTO snippets extracted from the contract doc for `admin`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type AdminContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map