import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { ServerStats, ServerStatus, ServerHealth, ServerInfo, AdminCleanupResponse, ServerNotice, SystemNotificationInfo, SystemNotificationPage, AdminPurgeHistoryResult, AdminShutdownRoomResult, AdminBackupPage, AdminExperimentalFeatures, AdminRegisterResult, AdminServerConfig, AdminInfoResponse, DynamicConfig, AdminRegisterRequest, PurgeHistoryRequest, ShutdownRoomRequest, CleanupRoomsRequest, RestartServerPayload, RestartServerResponse, PurgeRoomResponse, WhoamiResponse } from "../types";
import { MatrixClient } from "../../client";
export declare enum AdminServerEvent {
    ServerStatsUpdated = "ServerStatsUpdated"
}
export interface AdminServerEventMap {
    [AdminServerEvent.ServerStatsUpdated]: (stats: ServerStats) => void;
}
export declare class AdminServerManager extends AdminBaseManager<AdminServerEvent, AdminServerEventMap> {
    private serverStats;
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取当前管理员身份
     * GET /_synapse/admin/v1/whoami
     *
     * @returns 当前管理员身份信息
     */
    whoami(): Promise<WhoamiResponse>;
    /**
     * 获取服务器统计信息
     *
     * @returns 服务器统计信息
     */
    getServerStats(): Promise<ServerStats>;
    /**
     * 获取缓存的服务器统计信息
     *
     * @returns 缓存的服务器统计信息，如果不存在则为 null
     */
    getServerStatsCached(): ServerStats | null;
    /**
     * 获取服务器状态
     *
     * @returns 服务器状态
     */
    getServerStatus(): Promise<ServerStatus>;
    /**
     * 获取服务器健康检查
     *
     * @returns 服务器健康检查结果
     */
    getServerHealth(): Promise<ServerHealth>;
    /**
     * 获取服务器信息
     *
     * @returns 服务器信息
     */
    getServerInfo(): Promise<ServerInfo>;
    /**
     * 清理数据库
     *
     * @param options - 清理选项
     * @returns 清理结果
     */
    cleanupDatabase(options?: {
        room_id?: string;
        min_depth?: number;
        max_depth?: number;
        min_ts?: number;
        max_ts?: number;
        limit?: number;
        delete_local_media?: boolean;
        delete_remote_media?: boolean;
        delete_old_events?: boolean;
        delete_old_rooms?: boolean;
        delete_old_users?: boolean;
    }): Promise<AdminCleanupResponse>;
    /**
     * 获取服务器通知列表
     *
     * @param fromOrLimit - 分页起点或数量限制
     * @param limit - 数量限制
     * @returns 服务器通知列表
     */
    getServerNotices(fromOrLimit?: string | number, limit?: number): Promise<{
        notices: ServerNotice[];
        next_token?: string;
    }>;
    /**
     * 发送服务器通知
     *
     * @param arg1 - 通知内容或用户 ID
     * @param arg2 - 通知类型或通知内容对象
     * @param arg3 - 目标用户列表
     */
    sendServerNotice(arg1: string, arg2?: string | {
        msgtype: string;
        body: string;
        [k: string]: unknown;
    }, arg3?: string[]): Promise<{
        event_id?: string;
    }>;
    /**
     * 删除服务器通知
     *
     * @param notificationId - 通知 ID
     */
    deleteServerNotice(notificationId: string): Promise<void>;
    /**
     * 获取服务器通知详情
     *
     * @param noticeId - 通知 ID
     * @returns 服务器通知详情
     */
    getServerNotice(noticeId: string): Promise<ServerNotice>;
    /**
     * 获取系统通知列表
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 系统通知分页结果
     */
    listNotifications(from?: string, limit?: number): Promise<SystemNotificationPage>;
    /**
     * 创建系统通知
     *
     * @param payload - 通知内容
     * @returns 创建的通知信息
     */
    createNotification(payload: DynamicConfig): Promise<SystemNotificationInfo>;
    /**
     * 获取活跃的系统通知列表
     *
     * @returns 活跃的系统通知列表
     */
    listActiveNotifications(): Promise<SystemNotificationInfo[]>;
    /**
     * 获取系统通知详情
     *
     * @param notificationId - 通知 ID
     * @returns 通知详情
     */
    getNotification(notificationId: string): Promise<SystemNotificationInfo>;
    /**
     * 更新系统通知
     *
     * @param notificationId - 通知 ID
     * @param payload - 更新内容
     * @returns 更新后的通知信息
     */
    updateNotification(notificationId: string, payload: DynamicConfig): Promise<SystemNotificationInfo>;
    /**
     * 停用系统通知
     *
     * @param notificationId - 通知 ID
     */
    deactivateNotification(notificationId: string): Promise<void>;
    /**
     * 删除系统通知
     *
     * @param notificationId - 通知 ID
     */
    deleteNotification(notificationId: string): Promise<void>;
    /**
     * 获取服务器配置
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器配置
     */
    getServerConfig(throwOnError?: boolean): Promise<AdminServerConfig>;
    /**
     * 获取管理员信息
     *
     * @returns 管理员信息
     */
    getAdminInfo(): Promise<AdminInfoResponse>;
    /**
     * 获取服务器版本
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器版本信息
     */
    getServerVersion(throwOnError?: boolean): Promise<{
        server_version: string;
        python_version: string;
    }>;
    /**
     * 获取注册 nonce
     *
     * @returns nonce 字符串
     */
    getRegisterNonce(): Promise<{
        nonce: string;
    }>;
    /**
     * 注册管理员
     *
     * @param payload - 注册信息
     * @returns 注册结果
     */
    registerAdmin(payload: AdminRegisterRequest): Promise<AdminRegisterResult>;
    /**
     * 重启服务器
     *
     * @param payload - 重启选项
     * @returns 重启结果
     */
    restartServer(payload?: RestartServerPayload): Promise<RestartServerResponse>;
    /**
     * 获取备份列表
     *
     * @param options - 查询选项
     * @param options.limit - 返回数量限制（1-500）
     * @param options.offset - 偏移量（>=0）
     * @returns 备份分页结果
     *
     * @throws {ValidationError} 如果 limit 或 offset 参数无效
     */
    listBackups(options?: {
        limit?: number;
        offset?: number;
    }): Promise<AdminBackupPage>;
    /**
     * 获取实验性功能列表
     *
     * @returns 实验性功能信息
     */
    getExperimentalFeatures(): Promise<AdminExperimentalFeatures>;
    /**
     * 清除房间
     *
     * @param payload - 清除选项
     * @returns 清除结果
     */
    purgeRoom(payload: {
        room_id: string;
    }): Promise<PurgeRoomResponse>;
    /**
     * 清除历史消息
     *
     * @param payload - 清除选项
     * @returns 清除结果
     */
    purgeHistory(payload: PurgeHistoryRequest): Promise<AdminPurgeHistoryResult>;
    /**
     * 关闭房间
     *
     * @param payload - 关闭选项
     * @returns 关闭结果
     */
    shutdownRoom(payload: ShutdownRoomRequest): Promise<AdminShutdownRoomResult>;
    /**
     * 清理所有数据
     *
     * @returns 清理结果
     */
    cleanupAll(): Promise<AdminCleanupResponse>;
    /**
     * 清理令牌
     *
     * @returns 清理结果
     */
    cleanupTokens(): Promise<AdminCleanupResponse>;
    /**
     * 清理房间
     *
     * @param payload - 清理选项
     * @returns 清理结果
     */
    cleanupRooms(payload?: CleanupRoomsRequest): Promise<AdminCleanupResponse>;
}
//# sourceMappingURL=admin-server-manager.d.ts.map