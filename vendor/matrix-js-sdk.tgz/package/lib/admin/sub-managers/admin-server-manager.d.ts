import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { CleanupAllRequest, CleanupAllResponse, CleanupRoomsResponse, CleanupTokensResponse } from "./admin-cleanup-manager";
import type { ServerNotification } from "./admin-notification-manager";
import type { ServerStats, ServerStatus, ServerHealth, ServerInfo, ServerNotice, ServerNoticePage, SendServerNoticeResult, SystemNotificationPage, AdminPurgeHistoryResult, AdminShutdownRoomResult, AdminExperimentalFeatures, AdminRegisterResult, AdminServerConfig, AdminInfoResponse, AdminRegisterRequest, PurgeHistoryRequest, ShutdownRoomRequest, CleanupRoomsRequest, RestartServerPayload, RestartServerResponse, PurgeRoomResponse, WhoamiResponse } from "../types";
import type { CreateNotificationRequest, UpdateNotificationRequest } from "./admin-notification-manager";
import { MatrixClient } from "../../client";
export declare enum AdminServerEvent {
    ServerStatsUpdated = "ServerStatsUpdated"
}
export interface AdminServerEventMap {
    [AdminServerEvent.ServerStatsUpdated]: (stats: ServerStats) => void;
}
export declare class AdminServerManager extends AdminBaseManager<AdminServerEvent, AdminServerEventMap> {
    private serverStats;
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取当前管理员身份
     * GET /_synapse/admin/v1/whoami
     *
     * @returns 当前管理员身份信息
     *
     * @example
     * ```typescript
     * const who = await client.getAdminManager().server.whoami();
     * console.log(who.user_id, who.is_admin);
     * ```
     */
    whoami(): Promise<WhoamiResponse>;
    /**
     * 获取服务器统计信息
     *
     * @returns 服务器统计信息
     *
     * @example
     * ```typescript
     * const stats = await client.getAdminManager().server.getServerStats();
     * console.log(stats.total_users, stats.total_rooms);
     * ```
     */
    getServerStats(): Promise<ServerStats>;
    /**
     * 获取缓存的服务器统计信息
     *
     * @returns 缓存的服务器统计信息，如果不存在则为 null
     *
     * @example
     * ```typescript
     * const cached = client.getAdminManager().server.getServerStatsCached();
     * console.log(cached?.total_users);
     * ```
     */
    getServerStatsCached(): ServerStats | null;
    /**
     * 获取服务器状态
     *
     * @returns 服务器状态
     *
     * @example
     * ```typescript
     * const status = await client.getAdminManager().server.getServerStatus();
     * console.log(status.up, status.db_ok);
     * ```
     */
    getServerStatus(): Promise<ServerStatus>;
    /**
     * 获取服务器健康检查
     *
     * @returns 服务器健康检查结果
     *
     * @example
     * ```typescript
     * const health = await client.getAdminManager().server.getServerHealth();
     * console.log(health.status, health.database);
     * ```
     */
    getServerHealth(): Promise<ServerHealth>;
    /**
     * 获取服务器信息
     *
     * @returns 服务器信息
     *
     * @example
     * ```typescript
     * const info = await client.getAdminManager().server.getServerInfo();
     * console.log(info.server_name, info.server_version);
     * ```
     */
    getServerInfo(): Promise<ServerInfo>;
    /**
     * 清理数据库（`POST /_synapse/admin/v1/cleanup/all`）。
     *
     * ⚠️ 2026-10-08 把一个**11 个字段的虚构载荷**收成真实键集：后端
     * `cleanup.rs::cleanup_all` 是 `Json<Value>` + `body.get("min_age_ms")`，
     * **只读这一个键**。原先声明的 `room_id` / `min_depth` / `max_depth` / `min_ts` /
     * `max_ts` / `limit` / `delete_local_media` / `delete_remote_media` /
     * `delete_old_events` / `delete_old_rooms` / `delete_old_users` 全部被静默忽略
     * （调用方以为按房间或时间窗清理，实际是全量）。
     *
     * 与 {@link cleanupAll} 是同一个端点，参数类型统一为 `CleanupAllRequest`。
     *
     * @param options - 清理选项（仅 `min_age_ms` 生效）
     * @returns 清理结果
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().server.cleanupDatabase({ min_age_ms: 86_400_000 });
     * console.log(result.rooms.deleted_empty_rooms);
     * ```
     */
    cleanupDatabase(options?: CleanupAllRequest): Promise<CleanupAllResponse>;
    /**
     * 获取服务器通知列表
     *
     * 后端返回 `{notices, total, next_batch}`。
     *
     * @param fromOrLimit - 分页起点或数量限制
     * @param limit - 数量限制
     * @returns 服务器通知页（含游标）
     *
     * @example
     * ```typescript
     * const page = await client.getAdminManager().server.getServerNotices(50);
     * console.log(page.notices.length, page.next_batch);
     * ```
     */
    getServerNotices(fromOrLimit?: string | number, limit?: number): Promise<ServerNoticePage>;
    /**
     * 发送服务器通知
     *
     * 对应 `POST /_synapse/admin/v1/send_server_notice`。后端 `ServerNoticeRequest`
     * 带 `#[serde(deny_unknown_fields)]`，形状是 **`{user_id, content: {msgtype, body}}`**。
     *
     * ⚠️ 本方法**只支持对象形态**（`arg1` = 用户 id，`arg2` = `{msgtype, body, …}`）。
     * 字符形态（`sendServerNotice("text", "m.text")`）无论怎么拼都凑不出 `user_id`
     * —— 旧实现在那个分支发的是 `{content: "<字符串>", type, target_users}`，
     * 三个键全是未知字段，**必然 400**。现在该分支直接抛出 `ValidationError` 并指路。
     *
     * @param arg1 - 用户 id（对象形态）
     * @param arg2 - 通知内容对象 `{msgtype, body}`
     * @returns 投递结果（`{event_id, room_id, notice_id}`）
     *
     * @throws {ValidationError} 如果未传内容对象（字符串形态已不再支持）
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.sendServerNotice("@alice:example.org", {
     *     msgtype: "m.text",
     *     body: "维护通知",
     * });
     * ```
     */
    sendServerNotice(arg1: string, arg2?: string | {
        msgtype: string;
        body: string;
        [k: string]: unknown;
    }): Promise<SendServerNoticeResult>;
    /**
     * 删除服务器通知
     *
     * @param notificationId - 通知 ID
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.deleteServerNotice("notice-123");
     * ```
     */
    deleteServerNotice(notificationId: string): Promise<void>;
    /**
     * 获取服务器通知详情
     *
     * @param noticeId - 通知 ID
     * @returns 服务器通知详情
     *
     * @throws {ValidationError} 如果 noticeId 为空
     *
     * @example
     * ```typescript
     * const notice = await client.getAdminManager().server.getServerNotice("notice-123");
     * console.log(notice.id, notice.user_id);
     * ```
     */
    getServerNotice(noticeId: string): Promise<ServerNotice>;
    /**
     * 获取系统通知列表
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 系统通知分页结果
     *
     * @example
     * ```typescript
     * const page = await client.getAdminManager().server.listNotifications(undefined, 20);
     * console.log(page.notifications.length);
     * ```
     */
    listNotifications(from?: string, limit?: number): Promise<SystemNotificationPage>;
    /**
     * 创建系统通知（`POST /_synapse/admin/v1/notifications`）。
     *
     * ⚠️ 2026-10-08：签名原来写成 `DynamicConfig`（= `Record<string, unknown>`），
     * 于是"`title` / `content` 必填"这条后端事实在类型上完全消失。改用
     * {@link CreateNotificationRequest}；更完整的通知面请用
     * `adminManager.notifications`（`AdminNotificationManager`）。
     *
     * @param payload - 通知内容（`title` / `content` 必填）
     * @returns 创建的通知信息
     *
     * @example
     * ```typescript
     * const created = await client.getAdminManager().server.createNotification({ title: "维护", content: "今晚 23:00 维护" });
     * console.log(created.id);
     * ```
     */
    createNotification(payload: CreateNotificationRequest): Promise<ServerNotification>;
    /**
     * 获取活跃的系统通知列表
     *
     * ⚠️ 后端 `notification.rs::list_active_notifications` 是 `Ok(Json(json!(notifications)))`
     * —— 顶层就是**数组**。旧实现按 `{notifications: [...]}` 解包，于是 `response.notifications`
     * 恒为 `undefined`，**永远返回空数组**（且因为是"合法地返回空"，调用方看不出异常）。
     *
     * @returns 活跃的系统通知列表
     *
     * @example
     * ```typescript
     * const active = await adminManager.listActiveNotifications();
     * console.log(active.length);
     * ```
     */
    listActiveNotifications(): Promise<ServerNotification[]>;
    /**
     * 获取系统通知详情
     *
     * @param notificationId - 通知 ID
     * @returns 通知详情
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * const notification = await client.getAdminManager().server.getNotification("notice-123");
     * console.log(notification.id, notification.title);
     * ```
     */
    getNotification(notificationId: string): Promise<ServerNotification>;
    /**
     * 更新系统通知
     *
     * @param notificationId - 通知 ID
     * @param payload - 更新内容
     * @returns 更新后的通知信息
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * const updated = await client.getAdminManager().server.updateNotification("notice-123", { title: "已更新" });
     * console.log(updated.id);
     * ```
     */
    updateNotification(notificationId: string, payload: UpdateNotificationRequest): Promise<ServerNotification>;
    /**
     * 停用系统通知
     *
     * @param notificationId - 通知 ID
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.deactivateNotification("notice-123");
     * ```
     */
    deactivateNotification(notificationId: string): Promise<void>;
    /**
     * 删除系统通知
     *
     * @param notificationId - 通知 ID
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.deleteNotification("notice-123");
     * ```
     */
    deleteNotification(notificationId: string): Promise<void>;
    /**
     * 获取服务器配置
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器配置
     *
     * @throws {Error} 当 throwOnError 为 true 且请求失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const config = await client.getAdminManager().server.getServerConfig();
     * console.log(config.server_name);
     * ```
     */
    getServerConfig(throwOnError?: boolean): Promise<AdminServerConfig>;
    /**
     * 获取管理员信息
     *
     * @returns 管理员信息
     *
     * @example
     * ```typescript
     * const info = await client.getAdminManager().server.getAdminInfo();
     * console.log(info.server_name, info.server_version);
     * ```
     */
    getAdminInfo(): Promise<AdminInfoResponse>;
    /**
     * 获取服务器版本
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器版本信息
     *
     * @throws {Error} 当 throwOnError 为 true 且请求失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const version = await client.getAdminManager().server.getServerVersion();
     * console.log(version.server_version);
     * ```
     */
    getServerVersion(throwOnError?: boolean): Promise<{
        server_version: string;
        python_version: string;
    }>;
    /**
     * 获取注册 nonce
     *
     * @returns nonce 字符串
     *
     * @example
     * ```typescript
     * const { nonce } = await client.getAdminManager().server.getRegisterNonce();
     * console.log(nonce);
     * ```
     */
    getRegisterNonce(): Promise<{
        nonce: string;
    }>;
    /**
     * 注册管理员
     *
     * @param payload - 注册信息
     * @returns 注册结果
     *
     * @example
     * ```typescript
     * const { nonce } = await client.getAdminManager().server.getRegisterNonce();
     * const res = await client.getAdminManager().server.registerAdmin({ nonce, username: "alice", password: "s3cret", admin: true, mac: "ABCDEF..." });
     * console.log(res.user_id);
     * ```
     */
    registerAdmin(payload: AdminRegisterRequest): Promise<AdminRegisterResult>;
    /**
     * 重启服务器
     *
     * @param payload - 重启选项
     * @returns 重启结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.restartServer({ timeout_ms: 5000 });
     * console.log(res.restarted);
     * ```
     */
    restartServer(payload?: RestartServerPayload): Promise<RestartServerResponse>;
    /**
     * 获取实验性功能列表
     *
     * @returns 实验性功能信息
     *
     * @example
     * ```typescript
     * const features = await client.getAdminManager().server.getExperimentalFeatures();
     * console.log(features.total);
     * ```
     */
    getExperimentalFeatures(): Promise<AdminExperimentalFeatures>;
    /**
     * 清除房间
     *
     * @param payload - 清除选项
     * @returns 清除结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.purgeRoom({ room_id: "!room:example.org" });
     * console.log(res);
     * ```
     */
    purgeRoom(payload: {
        room_id: string;
    }): Promise<PurgeRoomResponse>;
    /**
     * 清除历史消息
     *
     * @param payload - 清除选项
     * @returns 清除结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.purgeHistory({ room_id: "!room:example.org", purge_up_to_ts: 1_600_000_000_000 });
     * console.log(res.deleted_events);
     * ```
     */
    purgeHistory(payload: PurgeHistoryRequest): Promise<AdminPurgeHistoryResult>;
    /**
     * 关闭房间
     *
     * @param payload - 关闭选项
     * @returns 关闭结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.shutdownRoom({ room_id: "!room:example.org" });
     * console.log(res.closed_room);
     * ```
     */
    shutdownRoom(payload: ShutdownRoomRequest): Promise<AdminShutdownRoomResult>;
    /**
     * 清理所有数据
     *
     * @returns 清理结果
     */
    /**
     * 清理所有数据。
     *
     * ⚠️ 后端 `cleanup.rs::cleanup_all` 用 `Json(body): Json<Value>` 读 `min_age_ms`；
     * **不带请求体会被 axum 以 415 拒绝**（SDK 只在 body 是对象时才设
     * `Content-Type: application/json`）。旧实现打的是无 body 的 POST。
     *
     * @param payload - 可选 `{ min_age_ms }`，省略表示不设最小年龄
     *
     * @example
     * ```typescript
     * await adminManager.cleanupAll({ min_age_ms: 86_400_000 });
     * ```
     */
    cleanupAll(payload?: {
        min_age_ms?: number;
    }): Promise<CleanupAllResponse>;
    /**
     * 清理令牌
     *
     * @returns 清理结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.cleanupTokens();
     * console.log(res.access_tokens_deleted);
     * ```
     */
    cleanupTokens(): Promise<CleanupTokensResponse>;
    /**
     * 清理房间
     *
     * @param payload - 清理选项
     * @returns 清理结果
     *
     * @throws {Error} 当主端点非 404 失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.cleanupRooms({ min_age_ms: 604800000 });
     * console.log(res.deleted_empty_rooms);
     * ```
     */
    cleanupRooms(payload?: CleanupRoomsRequest): Promise<CleanupRoomsResponse>;
}
//# sourceMappingURL=admin-server-manager.d.ts.map