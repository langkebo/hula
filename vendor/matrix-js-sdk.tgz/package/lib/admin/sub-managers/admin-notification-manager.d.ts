import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { MatrixClient } from "../../client";
/**
 * 服务器通知
 *
 * 字段取自后端 `synapse-storage/src/server_notification/models.rs::ServerNotification`（16 个字段）。
 *
 * ⚠️ 原先声明的 `message` / `important` / `sent_ts` / `expired` **四个键后端都不存在**，
 * 而真实的 12 个字段（`title`/`content`/`notification_type`/`priority`/…/`updated_ts`）全部缺失 ——
 * 属"完全不相干"级的不符，不是字段名笔误。
 */
export interface ServerNotification {
    id: number;
    title: string;
    content: string;
    notification_type: string;
    priority: number;
    target_audience: string;
    /** 目标用户 id 列表（后端列类型是 JSON，可能为 `null`） */
    target_user_ids: string[] | null;
    starts_at: number | null;
    expires_at: number | null;
    is_enabled: boolean;
    is_dismissable: boolean;
    action_url: string | null;
    action_text: string | null;
    created_by: string | null;
    created_ts: number;
    updated_ts: number;
}
/**
 * 通知列表响应 —— `GET /_synapse/admin/v1/notifications`
 *
 * ⚠️ 后端只返回 `{notifications, next_batch}`：**没有 `total`**，游标键是 `next_batch`
 * （不是 `next_token`，后者会恒为 `undefined` ⇒ 翻页在第一页就退出）。
 */
export interface NotificationsListResponse {
    notifications: ServerNotification[];
    next_batch: string | null;
}
/**
 * 创建通知请求载荷 —— `POST /_synapse/admin/v1/notifications`
 *
 * 后端 `CreateNotificationRequest` 里 `title` 与 `content` 是**必填**，
 * 其余可选。
 *
 * ⚠️ 原声明的 `{message, important}` 两个键后端都不认识（`title`/`content` 又缺失）
 * ⇒ 该请求**必然 400（missing field）**。
 */
export interface CreateNotificationRequest {
    title: string;
    content: string;
    notification_type?: string;
    priority?: number;
    target_audience?: string;
    target_user_ids?: string[];
    starts_at?: number;
    expires_at?: number;
    is_dismissable?: boolean;
    action_url?: string;
    action_text?: string;
}
/**
 * 更新通知请求载荷 —— `PUT /_synapse/admin/v1/notifications/{id}`
 *
 * 与创建同字段集，但**全部可选**；后端带 `deny_unknown_fields`，
 * 故 `message` / `important` 这类未知字段会直接 400。
 */
export type UpdateNotificationRequest = Partial<CreateNotificationRequest>;
/**
 * 通知分页选项
 *
 * `from` 是后端 `decode_server_notification_cursor` 解析的游标；
 * `audience` 可筛选目标受众。
 */
export interface NotificationPaginationOptions {
    /** 每页限制（后端上限 100，默认 50） */
    limit?: number;
    /** 游标 */
    from?: string;
    /** 目标受众筛选 */
    audience?: string;
}
/**
 * Admin Notification Manager
 *
 * 提供服务器通知管理功能，包括列表、创建、更新、删除和禁用通知。
 */
export declare class AdminNotificationManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取通知列表（支持分页）
     *
     * 后端返回 `{notifications, next_batch}`。
     *
     * @example
     * ```typescript
     * const result = await adminManager.notifications.list({ limit: 10 });
     * console.log(result.notifications.length, result.next_batch);
     * ```
     */
    list(options?: NotificationPaginationOptions): Promise<NotificationsListResponse>;
    /**
     * 获取单个通知
     *
     * ⚠️ 后端 `get_notification` 返回的是**通知对象本身**（`Json(json!(notification))`），
     * 不是 `{notification: {...}}` 包装。原实现读 `res.notification` ⇒ 恒为 `undefined`。
     *
     * @param notificationId - 通知 ID
     * @returns 通知详情
     *
     * @example
     * ```typescript
     * const notif = await client.getAdminManager().notifications.get(12);
     * console.log(notif.title, notif.is_enabled);
     * ```
     *
     * @throws NotFoundError 如果通知不存在
     */
    get(notificationId: number): Promise<ServerNotification>;
    /**
     * 创建新通知
     *
     * 请求体必须是后端 `CreateNotificationRequest` 的形状（`title` / `content` 必填）；
     * 响应是创建出的通知对象本身（不是包装）。
     *
     * @param payload - 通知内容
     * @returns 创建的通知
     *
     * @example
     * ```typescript
     * const notif = await adminManager.notifications.create({
     *     title: "维护通知",
     *     content: "系统将于 02:00 维护",
     *     notification_type: "maintenance",
     *     is_dismissable: true,
     * });
     * console.log(notif.id);
     * ```
     */
    create(payload: CreateNotificationRequest): Promise<ServerNotification>;
    /**
     * 更新通知
     *
     * 响应是更新后的通知对象本身（不是包装）。
     *
     * @param notificationId - 通知 ID
     * @param payload - 更新内容（与创建同字段集，全部可选）
     * @returns 更新后的通知
     *
     * @example
     * ```typescript
     * const notif = await client.getAdminManager().notifications.update(12, { title: "维护通知（已更新）" });
     * console.log(notif.updated_ts);
     * ```
     *
     * @throws NotFoundError 如果通知不存在
     */
    update(notificationId: number, payload: UpdateNotificationRequest): Promise<ServerNotification>;
    /**
     * 删除通知
     *
     * @param notificationId - 通知 ID
     *
     * @example
     * ```typescript
     * await client.getAdminManager().notifications.delete(12);
     * ```
     *
     * @throws NotFoundError 如果通知不存在
     */
    delete(notificationId: number): Promise<void>;
    /**
     * 「停用**全部**通知发送」—— **该语义后端不提供，调用必失败**。
     *
     * 后端只注册了 `PUT /_synapse/admin/v1/notifications/{notification_id}/deactivate`
     * （路径参数是 i64，**按单条**停用，返回 `{is_enabled: false}`）；本方法打的
     * `DELETE /notifications/deactivate` 在后端没有注册。
     *
     * 产品裁决（2026-10-19）：**不补全局停用端点** —— 上游 Synapse 也只有单条停用，
     * 属 SDK 语义错位，不是后端缺口。故 `semantic-mismatch` 豁免**保留**（不再等后端）。
     *
     * 需要停用通知请用 {@link AdminServerManager.deactivateNotification}（按 id）。
     *
     * @deprecated 后端不提供"全局停用"，该方法恒失败；改用 `server.deactivateNotification(id)`。
     */
    deactivate(): Promise<void>;
}
//# sourceMappingURL=admin-notification-manager.d.ts.map