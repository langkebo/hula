import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { MediaInfo, MediaProtectionResponse, MediaUnprotectionResponse, MediaPage, MediaQuotaResponse, MediaQuarantineChangesResponse, UserMediaList } from "../types";
import { MatrixClient } from "../../client";
export declare class AdminMediaManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取媒体列表
     *
     * 对应 `GET /_synapse/admin/v1/media`。后端返回 `{media, total, next_batch}`：
     * 分页游标键是 **`next_batch`**（`null` 表示末页），而 `total` 是**本页条数**。
     *
     * @param fromOrLimit - 分页起点 (string) 或数量限制 (number)
     * @param limitOrFrom - 数量限制 (number) 或分页起点 (string)
     * @returns 媒体列表（含 `next_batch` 游标）
     */
    getMedia(fromOrLimit?: string | number, limitOrFrom?: number | string): Promise<MediaPage>;
    /**
     * 获取媒体详情
     *
     * @param mediaId - 媒体 ID
     * @returns 媒体详情
     */
    getMediaInfo(mediaId: string): Promise<MediaInfo>;
    /**
     * 删除媒体
     *
     * @param mediaId - 媒体 ID
     */
    deleteMedia(mediaId: string): Promise<void>;
    /**
     * 获取媒体配额
     *
     * @returns 媒体配额信息
     */
    getMediaQuota(): Promise<MediaQuotaResponse>;
    /**
     * 隔离媒体
     *
     * 对应 `POST /_synapse/admin/v1/media/quarantine/{server_name}/{media_id}`。
     *
     * **路径形状（重要）**：本后端（synapse-rust `admin/media.rs`）只注册**带 `server_name` 段**的形态。
     * 上游 Synapse 早期废弃的 `POST /media/{media_id}/quarantine` **本后端未注册**——已用
     * `docs/api-contract/generated/route-manifest.all.json`（1159 条、漂移 0）逐条核验，
     * `POST /media/{media_id}/quarantine` 会得到 404。故本方法必须同时给出 `serverName` 与 `mediaId`。
     *
     * @param serverName - 媒体所属服务器名（本地媒体用 `client.getDomain()`）
     * @param mediaId - 媒体 ID
     */
    quarantineMedia(serverName: string, mediaId: string): Promise<void>;
    /**
     * 取消隔离媒体
     *
     * 对应 `POST /_synapse/admin/v1/media/unquarantine/{server_name}/{media_id}`。
     *
     * 路径形状说明同 {@link quarantineMedia}：后端只注册带 `server_name` 段的形态，
     * 上游废弃的 `POST /media/{media_id}/unquarantine` 在本后端**未注册**。
     *
     * @param serverName - 媒体所属服务器名（本地媒体用 `client.getDomain()`）
     * @param mediaId - 媒体 ID
     */
    unquarantineMedia(serverName: string, mediaId: string): Promise<void>;
    /**
     * 保护媒体，阻止其被自动隔离
     *
     * 对应 `POST /_synapse/admin/v1/media/protect/{server_name}/{media_id}`
     * （后端 `admin/media.rs::protect_media`）。
     *
     * @param serverName - 媒体所属服务器名（本地媒体用 `client.getDomain()`）
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `serverName` 或 `mediaId` 为空时
     * @example
     * ```typescript
     * await client.getAdminManager().protectMedia(client.getDomain()!, "abc123");
     * ```
     */
    protectMedia(serverName: string, mediaId: string): Promise<MediaProtectionResponse>;
    /**
     * 按 `media_id` 保护媒体（上游形态，无 `server_name` 段）
     *
     * 对应 `POST /_synapse/admin/v1/media/protect/{media_id}`
     * （后端 `admin/media.rs::protect_media_by_id`，内部用本服务器名补全 `server_name`）。
     *
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `mediaId` 为空时
     * @example
     * ```typescript
     * await client.getAdminManager().protectMediaById("abc123");
     * ```
     */
    protectMediaById(mediaId: string): Promise<MediaProtectionResponse>;
    /**
     * 取消媒体保护
     *
     * 对应 `POST /_synapse/admin/v1/media/unprotect/{media_id}`
     * （后端 `admin/media.rs::unprotect_media_by_id`）。
     * ⚠️ 后端**只注册按 `media_id`** 的形态，没有 `unprotect/{server_name}/{media_id}` 变体。
     *
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `mediaId` 为空时
     * @example
     * ```typescript
     * await client.getAdminManager().unprotectMedia("abc123");
     * ```
     */
    unprotectMedia(mediaId: string): Promise<MediaUnprotectionResponse>;
    /**
     * 清除媒体缓存
     *
     * 对应 `POST /_synapse/admin/v1/purge_media_cache`。
     *
     * ⚠️ **`before_ts` 是 query 参数，不是请求体字段**：后端处理器用
     * `axum::extract::Query` 读它（`admin/media.rs::purge_media_cache`），
     * 读不到时默认 `0`。此前实现把它放在 JSON body 里 ⇒ 参数从未到达服务端，
     * 调用退化成 `before_ts = 0`（即「清理早于 epoch 的媒体」＝**什么都不删**）。
     *
     * @param beforeTs - 清除此时间戳（毫秒）之前访问过的媒体（必须为正整数）
     * @returns 删除的媒体数量
     */
    purgeMediaCache(beforeTs?: number): Promise<{
        deleted: number;
    }>;
    /**
     * 获取媒体隔离变更历史
     *
     * 调用 `GET /_synapse/admin/v1/quarantine_media/{media_id}/changes` 端点，
     * 返回指定媒体的隔离（quarantine / unquarantine）变更记录列表。
     *
     * 后端返回 `{changes, total}`；每个变更条目是
     * `{stream_id, media_id, server_name, change_type, changed_by, created_ts}`。
     * ⚠️ 响应顶层**没有** `media_id`（`mediaId` 由请求路径决定），也**没有**游标
     * （后端只接受 `since` / `limit`，`changes` 之后需自行用最后一条的 `stream_id` 作 `since`）。
     *
     * @param mediaId - 媒体 ID
     * @param options - 可选分页参数
     * @param options.from - 当作 `since` 传给后端的起点 stream_id
     * @param options.limit - 返回条数上限
     * @returns 媒体隔离变更历史
     *
     * @example
     * ```typescript
     * const history = await adminManager.media.getMediaQuarantineChanges("abc123", {
     *     limit: 50,
     * });
     * console.log(history.changes);
     * ```
     *
     * @throws {ValidationError} 如果 mediaId 为空
     */
    getMediaQuarantineChanges(mediaId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<MediaQuarantineChangesResponse>;
    /**
     * 获取用户上传的所有媒体
     *
     * 调用 `GET /_synapse/admin/v1/users/{user_id}/media` 端点，
     * 返回指定用户上传的全部媒体列表。
     *
     * ⚠️ 后端处理器（`admin/media.rs::get_user_media`）**不读 `limit` / `from`，也不返回游标**，
     * 只返回 `{media, total}`。参数保留是为了与上游 Synapse 的签名对齐，但当前后端会忽略它们。
     *
     * @param userId - 用户 MXC ID（如 `@user:example.org`）
     * @param options - 可选分页参数（当前后端忽略）
     * @param options.from - 分页起点 token（后端忽略）
     * @param options.limit - 返回条数上限（后端忽略）
     * @returns 用户媒体列表
     *
     * @example
     * ```typescript
     * const result = await adminManager.media.getUserMedia("@alice:example.org", { limit: 100 });
     * console.log(result.media);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    getUserMedia(userId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<UserMediaList>;
    /**
     * 删除用户上传的所有媒体
     *
     * 调用 `DELETE /_synapse/admin/v1/users/{user_id}/media` 端点，
     * 删除指定用户上传的全部本地媒体。
     *
     * @param userId - 用户 MXC ID（如 `@user:example.org`）
     * @returns 删除的媒体数量
     *
     * @example
     * ```typescript
     * const result = await adminManager.media.deleteUserMedia("@bob:example.org");
     * console.log(`deleted ${result.deleted} media items`);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    deleteUserMedia(userId: string): Promise<{
        deleted: number;
    }>;
}
//# sourceMappingURL=admin-media-manager.d.ts.map