import { AdminBaseManager, type AdminErrorCallback } from "../admin-base-manager";
import type { MediaInfo, MediaQuotaResponse } from "../types";
import { MatrixClient } from "../../client";
export declare class AdminMediaManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback);
    /**
     * 获取媒体列表
     *
     * @param fromOrLimit - 分页起点 (string) 或数量限制 (number)
     * @param limitOrFrom - 数量限制 (number) 或分页起点 (string)
     * @returns 媒体列表
     */
    getMedia(fromOrLimit?: string | number, limitOrFrom?: number | string): Promise<{
        media: MediaInfo[];
        next_token?: string;
    }>;
    /**
     * 获取媒体详情
     *
     * @param mediaId - 媒体 ID
     * @returns 媒体详情
     */
    getMediaInfo(mediaId: string): Promise<MediaInfo>;
    /**
     * 删除媒体
     *
     * @param mediaId - 媒体 ID
     */
    deleteMedia(mediaId: string): Promise<void>;
    /**
     * 获取媒体配额
     *
     * @returns 媒体配额信息
     */
    getMediaQuota(): Promise<MediaQuotaResponse>;
    /**
     * 隔离媒体
     *
     * @param mediaId - 媒体 ID
     */
    quarantineMedia(mediaId: string): Promise<void>;
    /**
     * 取消隔离媒体
     *
     * @param mediaId - 媒体 ID
     */
    unquarantineMedia(mediaId: string): Promise<void>;
    /**
     * 清除媒体缓存
     *
     * @param beforeTs - 清除此时间戳之前的媒体（必须为正整数）
     * @returns 删除的媒体数量
     */
    purgeMediaCache(beforeTs?: number): Promise<{
        deleted: number;
    }>;
}
//# sourceMappingURL=admin-media-manager.d.ts.map