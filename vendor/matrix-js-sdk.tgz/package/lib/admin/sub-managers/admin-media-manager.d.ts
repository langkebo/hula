import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { MediaInfo, MediaProtectionResponse, MediaQuotaResponse, MediaQuarantineChangesResponse, MediaUnprotectionResponse } from "../types";
import { MatrixClient } from "../../client";
export declare class AdminMediaManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取媒体列表
     *
     * @param fromOrLimit - 分页起点 (string) 或数量限制 (number)
     * @param limitOrFrom - 数量限制 (number) 或分页起点 (string)
     * @returns 媒体列表
     */
    getMedia(fromOrLimit?: string | number, limitOrFrom?: number | string): Promise<{
        media: MediaInfo[];
        next_token?: string;
    }>;
    /**
     * 获取媒体详情
     *
     * @param mediaId - 媒体 ID
     * @returns 媒体详情
     */
    getMediaInfo(mediaId: string): Promise<MediaInfo>;
    /**
     * 删除媒体
     *
     * @param mediaId - 媒体 ID
     */
    deleteMedia(mediaId: string): Promise<void>;
    /**
     * 获取媒体配额
     *
     * @returns 媒体配额信息
     */
    getMediaQuota(): Promise<MediaQuotaResponse>;
    /**
     * 隔离媒体
     *
     * ⚠️ **路径形状**：后端 `admin/media.rs` 只注册
     * `POST /_synapse/admin/v1/media/quarantine/{server_name}/{media_id}`；
     * 上游早期形态 `POST /media/{media_id}/quarantine` **未注册**（会 404），故必须给出 `serverName`。
     *
     * @param serverName - 媒体所属服务器名（本地媒体用 `client.getDomain()`）
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `serverName` 或 `mediaId` 为空时
     */
    quarantineMedia(serverName: string, mediaId: string): Promise<void>;
    /**
     * 取消隔离媒体
     *
     * ⚠️ 路径形状同 {@link quarantineMedia}：只有带 `server_name` 的形态存在
     * （`POST /_synapse/admin/v1/media/unquarantine/{server_name}/{media_id}`）。
     *
     * @param serverName - 媒体所属服务器名（本地媒体用 `client.getDomain()`）
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `serverName` 或 `mediaId` 为空时
     */
    unquarantineMedia(serverName: string, mediaId: string): Promise<void>;
    /**
     * 保护媒体，阻止其被自动隔离
     *
     * 对应 `POST /_synapse/admin/v1/media/protect/{server_name}/{media_id}`
     * （后端 `admin/media.rs::protect_media`）。
     *
     * @param serverName - 媒体所属服务器名（本地媒体用 `client.getDomain()`）
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `serverName` 或 `mediaId` 为空时
     * @example
     * ```typescript
     * await client.getAdminManager().protectMedia(client.getDomain()!, "abc123");
     * ```
     */
    protectMedia(serverName: string, mediaId: string): Promise<MediaProtectionResponse>;
    /**
     * 按 `media_id` 保护媒体（上游形态，无 `server_name` 段）
     *
     * 对应 `POST /_synapse/admin/v1/media/protect/{media_id}`。
     *
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `mediaId` 为空时
     * @example
     * ```typescript
     * await client.getAdminManager().protectMediaById("abc123");
     * ```
     */
    protectMediaById(mediaId: string): Promise<MediaProtectionResponse>;
    /**
     * 取消媒体保护
     *
     * 对应 `POST /_synapse/admin/v1/media/unprotect/{media_id}`。
     *
     * @param mediaId - 媒体 ID
     * @throws {ValidationError} `mediaId` 为空时
     * @example
     * ```typescript
     * await client.getAdminManager().unprotectMedia("abc123");
     * ```
     */
    unprotectMedia(mediaId: string): Promise<MediaUnprotectionResponse>;
    /**
     * 清除媒体缓存
     *
     * @param beforeTs - 清除此时间戳之前的媒体（必须为正整数）
     * @returns 删除的媒体数量
     */
    purgeMediaCache(beforeTs?: number): Promise<{
        deleted: number;
    }>;
    /**
     * 获取媒体隔离变更历史
     *
     * 调用 `GET /_synapse/admin/v1/quarantine_media/{media_id}/changes` 端点，
     * 返回指定媒体的隔离（quarantine / unquarantine）变更记录列表。
     *
     * @param mediaId - 媒体 ID
     * @param options - 可选分页参数
     * @param options.from - 分页起点 token
     * @param options.limit - 返回条数上限
     * @returns 媒体隔离变更历史
     *
     * @example
     * ```typescript
     * const history = await adminManager.media.getMediaQuarantineChanges("abc123", {
     *     limit: 50,
     * });
     * console.log(history.changes);
     * ```
     *
     * @throws {ValidationError} 如果 mediaId 为空
     */
    getMediaQuarantineChanges(mediaId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<MediaQuarantineChangesResponse>;
}
//# sourceMappingURL=admin-media-manager.d.ts.map