import { AdminBaseManager, type AdminErrorCallback } from "../admin-base-manager";
import type { DeviceInfo, MediaInfo, AccountStatus, WhoisResponse, UserPusher, PaginatedResponse, AdminAccountDetails, ShadowBanStatus, RateLimitConfig, AdminLoginAsUserRequest, AdminLoginAsUserResponse, BatchCreateUsersRequest, BatchCreateUsersResponse, BatchDeactivateUsersRequest, BatchDeactivateUsersResponse, UpdateAccountDetailsRequest, UpdateAccountDetailsResponse, AdminLogoutResponse, AdminEvictResponse, UserSession, AdminToken, AdminRefreshToken, AdminLogoutRequest, AdminEvictRequest, UserStatsResponse, UserStatsListResponse, UserRoomsResponse, UserNotificationResponse, UserNotificationPayload } from "../types";
import type { ISynapseAdminWhoisResponse, ISynapseAdminDeactivateResponse } from "../../@types/synapse";
import { MatrixClient } from "../../client";
export declare enum AdminUserEvent {
    UserCreated = "UserCreated",
    UserDeactivated = "UserDeactivated",
    UserShadowBanned = "UserShadowBanned",
    UserUnshadowBanned = "UserUnshadowBanned"
}
export interface AdminUserEventMap {
    [AdminUserEvent.UserCreated]: (userId: string, user: AdminAccountDetails) => void;
    [AdminUserEvent.UserDeactivated]: (userId: string) => void;
    [AdminUserEvent.UserShadowBanned]: (userId: string) => void;
    [AdminUserEvent.UserUnshadowBanned]: (userId: string) => void;
}
export declare class AdminUserManager extends AdminBaseManager<AdminUserEvent, AdminUserEventMap> {
    constructor(client: MatrixClient, onError?: AdminErrorCallback);
    /**
     * 获取用户列表（统一分页格式）
     */
    getUsersPaginated(options?: {
        from?: string;
        limit?: number;
    }): Promise<PaginatedResponse<AdminAccountDetails>>;
    /**
     * Get user details
     */
    getUser(userId: string, throwOnError?: boolean): Promise<AdminAccountDetails | null>;
    /**
     * 创建新用户
     */
    createUser(userId: string, options?: {
        password?: string;
        displayname?: string;
        admin?: boolean;
        deactivated?: boolean;
    }): Promise<AdminAccountDetails>;
    deactivateUser(userId: string): Promise<void>;
    deleteUser(userId: string): Promise<void>;
    batchCreateUsers(payload: BatchCreateUsersRequest): Promise<BatchCreateUsersResponse>;
    batchDeactivateUsers(payload: BatchDeactivateUsersRequest): Promise<BatchDeactivateUsersResponse>;
    /**
     * 重置用户密码
     */
    resetPassword(userId: string, newPassword: string): Promise<void>;
    /**
     * 设置用户管理员权限
     */
    setAdmin(userId: string, admin: boolean): Promise<void>;
    /**
     * 获取用户的设备列表
     */
    getUserDevices(userId: string): Promise<DeviceInfo[]>;
    /**
     * 删除用户的设备
     */
    deleteUserDevices(userId: string, deviceIds: string[]): Promise<void>;
    /**
     * 删除用户的单个设备
     */
    deleteUserDevice(userId: string, deviceId: string): Promise<void>;
    getUserTokens(userId: string): Promise<{
        tokens: AdminToken[];
    }>;
    deleteUserToken(userId: string, tokenId: string): Promise<void>;
    getUserRefreshTokens(userId: string): Promise<{
        refresh_tokens: AdminRefreshToken[];
    }>;
    deleteUserRefreshToken(userId: string, tokenId: string): Promise<void>;
    getUserSession(userId: string): Promise<UserSession>;
    getUserRooms(userId: string, from?: string, limit?: number): Promise<UserRoomsResponse>;
    getUserStats(userId: string): Promise<UserStatsResponse>;
    listUserStats(from?: string, limit?: number): Promise<UserStatsListResponse>;
    invalidateUserSession(userId: string): Promise<void>;
    loginAsUser(userId: string, payload?: AdminLoginAsUserRequest): Promise<AdminLoginAsUserResponse>;
    logoutUser(userId: string, payload?: AdminLogoutRequest): Promise<AdminLogoutResponse>;
    evictUser(userId: string, payload?: AdminEvictRequest): Promise<AdminEvictResponse>;
    /**
     * 获取账户状态
     */
    getAccountStatus(userId: string, throwOnError?: boolean): Promise<AccountStatus | null>;
    /**
     * 检查用户是否为管理员
     */
    isAdmin(userId: string, throwOnError?: boolean): Promise<boolean>;
    /**
     * 覆盖用户速率限制（完全禁用限制）
     */
    overrideRateLimit(userId: string): Promise<void>;
    /**
     * 获取用户速率限制覆盖状态
     * 后端 override_ratelimit 端点实际返回与 rate_limit 相同的 {messages_per_second, burst_count} 结构
     */
    getRateLimitOverride(userId: string, throwOnError?: boolean): Promise<RateLimitConfig | null>;
    /**
     * 删除用户速率限制覆盖
     */
    deleteRateLimitOverride(userId: string): Promise<void>;
    shadowBanUser(userId: string): Promise<void>;
    unshadowBanUser(userId: string): Promise<void>;
    getShadowBanStatus(userId: string, throwOnError?: boolean): Promise<ShadowBanStatus | null>;
    getRateLimit(userId: string, throwOnError?: boolean): Promise<RateLimitConfig | null>;
    setRateLimit(userId: string, config: {
        messages_per_second?: number;
        burst_count?: number;
    }): Promise<void>;
    deleteRateLimit(userId: string): Promise<void>;
    getAccountDetails(userId: string): Promise<AdminAccountDetails>;
    updateAccountDetails(userId: string, payload: UpdateAccountDetailsRequest): Promise<UpdateAccountDetailsResponse>;
    /**
     * 获取用户 Whois 信息
     */
    getUserWhois(userId: string): Promise<WhoisResponse>;
    whois(userId: string): Promise<WhoisResponse>;
    whoisByDevice(userId: string, deviceId: string): Promise<WhoisResponse>;
    getUserMedia(userId: string, from?: string, limit?: number): Promise<{
        media: MediaInfo[];
        next_token?: string;
    }>;
    deleteUserMedia(userId: string): Promise<void>;
    getUserNotification(userId: string): Promise<UserNotificationResponse>;
    setUserNotification(userId: string, payload: UserNotificationPayload): Promise<UserNotificationResponse>;
    getUserPushers(userId: string): Promise<{
        pushers: UserPusher[];
    }>;
    deleteUserPusher(userId: string, pushkey: string): Promise<void>;
    blockEventReportUser(userId: string, payload: {
        blocked_until?: number;
        reason?: string;
    }): Promise<void>;
    unblockEventReportUser(userId: string): Promise<void>;
    /**
     * Determines if the current user is an administrator of the Synapse homeserver.
     * Returns false if untrue or the homeserver does not appear to be a Synapse
     * homeserver. <strong>This function is implementation specific and may change
     * as a result.</strong>
     * @param userId - The user ID to check.
     * @returns true if the user appears to be a Synapse administrator.
     */
    isSynapseAdministrator(userId: string): Promise<boolean>;
    /**
     * Performs a whois lookup on a user using Synapse's administrator API.
     * <strong>This function is implementation specific and may change as a
     * result.</strong>
     * @param userId - the User ID to look up.
     * @returns the whois response - see Synapse docs for information.
     */
    whoisSynapseUser(userId: string): Promise<ISynapseAdminWhoisResponse>;
    /**
     * Deactivates a user using Synapse's administrator API. <strong>This
     * function is implementation specific and may change as a result.</strong>
     * @param userId - the User ID to deactivate.
     * @returns the deactivate response - see Synapse docs for information.
     */
    deactivateSynapseUser(userId: string): Promise<ISynapseAdminDeactivateResponse>;
}
//# sourceMappingURL=admin-user-manager.d.ts.map