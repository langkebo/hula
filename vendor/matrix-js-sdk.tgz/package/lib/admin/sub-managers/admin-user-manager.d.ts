import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { DeviceInfo, UserMediaList, AccountStatus, WhoisResponse, UserPusher, PaginatedResponse, AdminAccountDetails, ShadowBanStatus, RateLimitConfig, AdminLoginAsUserRequest, AdminLoginAsUserResponse, BatchCreateUsersRequest, BatchCreateUsersResponse, BatchDeactivateUsersRequest, BatchDeactivateUsersResponse, UpdateAccountDetailsRequest, UpdateAccountDetailsResponse, AdminLogoutResponse, AdminEvictResponse, UserSessionsResponse, InvalidateUserSessionsResponse, UserTokensResponse, UserRefreshTokensResponse, AdminLogoutRequest, AdminEvictRequest, UserStatsResponse, UserStatsListResponse, UserRoomsResponse, UserNotificationResponse, UserNotificationUpdateResponse, UserNotificationPayload } from "../types";
import type { ISynapseAdminWhoisResponse, ISynapseAdminDeactivateResponse } from "../../@types/synapse";
import { MatrixClient } from "../../client";
export declare enum AdminUserEvent {
    UserCreated = "UserCreated",
    UserActivated = "UserActivated",
    UserDeactivated = "UserDeactivated",
    UserShadowBanned = "UserShadowBanned",
    UserUnshadowBanned = "UserUnshadowBanned"
}
export interface AdminUserEventMap {
    [AdminUserEvent.UserCreated]: (userId: string, user: AdminAccountDetails) => void;
    [AdminUserEvent.UserActivated]: (userId: string, user: AdminAccountDetails) => void;
    [AdminUserEvent.UserDeactivated]: (userId: string) => void;
    [AdminUserEvent.UserShadowBanned]: (userId: string) => void;
    [AdminUserEvent.UserUnshadowBanned]: (userId: string) => void;
}
export declare class AdminUserManager extends AdminBaseManager<AdminUserEvent, AdminUserEventMap> {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取用户列表（统一分页格式）
     */
    getUsersPaginated(options?: {
        from?: string;
        limit?: number;
    }): Promise<PaginatedResponse<AdminAccountDetails>>;
    /**
     * Get user details
     */
    getUser(userId: string, throwOnError?: boolean): Promise<AdminAccountDetails | null>;
    /**
     * 通过用户 ID 获取用户详情（getUser 的语义化别名）
     *
     * @param userId - 用户 ID
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 用户详情或 null
     */
    getUserById(userId: string, throwOnError?: boolean): Promise<AdminAccountDetails | null>;
    /**
     * 创建新用户
     */
    createUser(userId: string, options?: {
        password?: string;
        displayname?: string;
        admin?: boolean;
        deactivated?: boolean;
    }): Promise<AdminAccountDetails>;
    /**
     * 重新激活已停用的用户。
     *
     * 走 Admin v2 的 upsert 语义：`PUT /_synapse/admin/v2/users/{userId}` + `{ deactivated: false }`。
     * 与 `deactivateUser()`（v1 `POST .../deactivate`）不是同一条路由，故不能互相替代。
     *
     * @param userId - 目标用户 ID
     * @returns 更新后的用户详情
     */
    activateUser(userId: string): Promise<AdminAccountDetails>;
    deactivateUser(userId: string): Promise<void>;
    deleteUser(userId: string): Promise<void>;
    batchCreateUsers(payload: BatchCreateUsersRequest): Promise<BatchCreateUsersResponse>;
    batchDeactivateUsers(payload: BatchDeactivateUsersRequest): Promise<BatchDeactivateUsersResponse>;
    /**
     * 重置用户密码
     */
    resetPassword(userId: string, newPassword: string): Promise<void>;
    /**
     * 设置用户管理员权限
     */
    setAdmin(userId: string, admin: boolean): Promise<void>;
    /**
     * 获取用户的设备列表
     */
    getUserDevices(userId: string): Promise<DeviceInfo[]>;
    /**
     * 删除用户的单个设备
     */
    deleteUserDevice(userId: string, deviceId: string): Promise<void>;
    /**
     * 列出用户的 access token。
     *
     * 后端 `GET /_synapse/admin/v1/users/{user_id}/tokens` 返回
     * `{tokens: [{id, device_id, created_ts, expires_at, is_revoked}], total}`。
     *
     * @param userId - 用户 id
     *
     * @example
     * ```typescript
     * const { tokens, total } = await adminManager.getUserTokens("@alice:example.org");
     * console.log(total, tokens.map((t) => t.device_id));
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    getUserTokens(userId: string): Promise<UserTokensResponse>;
    /**
     * 删除用户的某个 access token。
     *
     * @param userId - 用户 id
     * @param tokenId - token id（整数，后端 `Path<(UserId, i64)>`）
     *
     * @example
     * ```typescript
     * await adminManager.deleteUserToken("@alice:example.org", "12");
     * ```
     *
     * @throws {ValidationError} 如果 userId 或 tokenId 为空
     */
    deleteUserToken(userId: string, tokenId: string): Promise<void>;
    /**
     * 列出用户的 refresh token。
     *
     * 后端返回 `{refresh_tokens: [{id, device_id, created_ts, expires_at, is_revoked}], total}`。
     *
     * @param userId - 用户 id
     *
     * @example
     * ```typescript
     * const { refresh_tokens, total } = await adminManager.getUserRefreshTokens("@alice:example.org");
     * console.log(total, refresh_tokens);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    getUserRefreshTokens(userId: string): Promise<UserRefreshTokensResponse>;
    /**
     * 删除用户的某个 refresh token。
     *
     * @param userId - 用户 id
     * @param tokenId - token id
     *
     * @example
     * ```typescript
     * await adminManager.deleteUserRefreshToken("@alice:example.org", "12");
     * ```
     *
     * @throws {ValidationError} 如果 userId 或 tokenId 为空
     */
    deleteUserRefreshToken(userId: string, tokenId: string): Promise<void>;
    /**
     * 获取用户的会话（设备）列表。
     *
     * ⚠️ 后端 `GET /_synapse/admin/v1/user_sessions/{user_id}` 返回**包装对象**
     * `{user_id, sessions: [{session_id, device_id, display_name, last_seen_ts, last_seen_ip}], total}`；
     * 旧实现把包装对象当成 `UserSession` 直接返回，于是 `session_id` / `device_id` 恒为 `undefined`。
     *
     * @param userId - 用户 id
     *
     * @example
     * ```typescript
     * const page = await adminManager.getUserSession("@alice:example.org");
     * console.log(page.total, page.sessions.map((s) => s.session_id));
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    getUserSession(userId: string): Promise<UserSessionsResponse>;
    /**
     * 列出用户加入的房间（分页）。
     *
     * 后端返回 `{joined_rooms, total, next_batch}`。
     *
     * @param userId - 用户 id
     * @param from - 分页游标
     * @param limit - 每页条数
     *
     * @example
     * ```typescript
     * const page = await adminManager.getUserRooms("@alice:example.org", undefined, 50);
     * console.log(page.total, page.joined_rooms);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    getUserRooms(userId: string, from?: string, limit?: number): Promise<UserRoomsResponse>;
    /**
     * 获取单个用户的统计。
     *
     * @param userId - 用户 id
     *
     * @example
     * ```typescript
     * const stats = await adminManager.getUserStats("@alice:example.org");
     * console.log(stats.rooms_joined, stats.messages_sent);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    getUserStats(userId: string): Promise<UserStatsResponse>;
    /**
     * 获取全站用户统计汇总（不分页）。
     *
     * @example
     * ```typescript
     * const stats = await adminManager.listUserStats();
     * console.log(stats.total_users, stats.active_users);
     * ```
     */
    listUserStats(): Promise<UserStatsListResponse>;
    /**
     * 使某用户的全部会话失效。
     *
     * 后端返回 `{invalidated, sessions_removed}`；旧实现声明 `void` 并丢弃。
     *
     * @param userId - 用户 id
     *
     * @example
     * ```typescript
     * const result = await adminManager.invalidateUserSession("@alice:example.org");
     * console.log(result.sessions_removed);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    invalidateUserSession(userId: string): Promise<InvalidateUserSessionsResponse>;
    /**
     * 以某用户身份登录（管理端互登录）。
     *
     * ⚠️ **`payload` 后端不读**：`user.rs::login_as_user` 的签名里没有 `Json` 提取器，
     * device_id 由后端随机生成、`is_admin` 取自目标用户。参数保留仅为向后兼容，
     * 已在 `admin-response-contract-ledger.json` 登记为待决项。
     *
     * @param userId - 目标用户 id
     * @param payload - **被后端忽略**；见上方说明
     *
     * @example
     * ```typescript
     * const { access_token, device_id } = await adminManager.loginAsUser("@alice:example.org");
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    loginAsUser(userId: string, payload?: AdminLoginAsUserRequest): Promise<AdminLoginAsUserResponse>;
    /**
     * 登出某用户的会话。
     *
     * ⚠️⚠️ **会登出该用户的「全部」设备**：后端 `user.rs::logout_user_devices` 调
     * `token_auth.logout_all(user_id)`，**既不读请求体、也不支持按设备筛选**。
     * 传 `{ devices: [...] }` 会造成"只登出了这些设备"的错觉，而实际是全部登出。
     * 参数保留仅为向后兼容，已在 `admin-response-contract-ledger.json` 登记为待决项。
     *
     * @param userId - 用户 id
     * @param payload - **被后端忽略，且不会缩小登出范围**；见上方说明
     *
     * @example
     * ```typescript
     * const { devices_deleted } = await adminManager.logoutUser("@alice:example.org");
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    logoutUser(userId: string, payload?: AdminLogoutRequest): Promise<AdminLogoutResponse>;
    /**
     * 把用户从其加入的全部房间中逐出。
     *
     * ⚠️ **`payload` 后端不读**：`user.rs::evict_user` 的签名里没有 `Json` 提取器，
     * 也就没有"逐出原因"这条链路。参数保留仅为向后兼容。
     *
     * @param userId - 用户 id
     * @param payload - **被后端忽略**；见上方说明
     *
     * @example
     * ```typescript
     * const result = await adminManager.evictUser("@alice:example.org");
     * console.log(result.rooms_evicted, result.failures);
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    evictUser(userId: string, payload?: AdminEvictRequest): Promise<AdminEvictResponse>;
    /**
     * 获取账户状态
     */
    getAccountStatus(userId: string, throwOnError?: boolean): Promise<AccountStatus | null>;
    /**
     * 检查用户是否为管理员
     */
    isAdmin(userId: string, throwOnError?: boolean): Promise<boolean>;
    /**
     * 设置用户的速率限制覆盖（`POST /users/{user_id}/override_ratelimit`）。
     *
     * ⚠️ 后端 `security.rs::set_user_override_rate_limit` 走
     * `Json<RateLimitRequest>`（字段 `{messages_per_second, burst_count}`，带
     * `#[serde(deny_unknown_fields)]`）。**没有请求体时 axum 会以 415 拒绝**
     * （SDK 只在 body 是对象时才设 `Content-Type: application/json`）——
     * 旧实现就是这个形态，调用必失败。
     *
     * 覆盖是"另设一套限额"，**不是**禁用限制；省略字段时后端用默认值
     * （`messages_per_second = 5.0`、`burst_count = 10`）。要移除覆盖请用
     * {@link deleteRateLimitOverride}。
     *
     * @param userId - 用户 id
     * @param config - 覆盖用的限额；省略时按后端默认值
     *
     * @example
     * ```typescript
     * await adminManager.overrideRateLimit("@alice:example.org", { messages_per_second: 2, burst_count: 5 });
     * ```
     *
     * @throws {ValidationError} 如果 userId 为空
     */
    overrideRateLimit(userId: string, config?: RateLimitConfig): Promise<RateLimitConfig>;
    /**
     * 获取用户速率限制覆盖状态
     * 后端 override_ratelimit 端点实际返回与 rate_limit 相同的 {messages_per_second, burst_count} 结构
     */
    getRateLimitOverride(userId: string, throwOnError?: boolean): Promise<RateLimitConfig | null>;
    /**
     * 删除用户速率限制覆盖
     */
    deleteRateLimitOverride(userId: string): Promise<void>;
    shadowBanUser(userId: string): Promise<void>;
    unshadowBanUser(userId: string): Promise<void>;
    getShadowBanStatus(userId: string, throwOnError?: boolean): Promise<ShadowBanStatus | null>;
    getRateLimit(userId: string, throwOnError?: boolean): Promise<RateLimitConfig | null>;
    setRateLimit(userId: string, config: {
        messages_per_second?: number;
        burst_count?: number;
    }): Promise<void>;
    deleteRateLimit(userId: string): Promise<void>;
    getAccountDetails(userId: string): Promise<AdminAccountDetails>;
    updateAccountDetails(userId: string, payload: UpdateAccountDetailsRequest): Promise<UpdateAccountDetailsResponse>;
    /**
     * 获取用户 Whois 信息
     */
    getUserWhois(userId: string): Promise<WhoisResponse>;
    whois(userId: string): Promise<WhoisResponse>;
    whoisByDevice(userId: string, deviceId: string): Promise<WhoisResponse>;
    /**
     * 获取用户上传的媒体列表
     *
     * ⚠️ 后端（`admin/media.rs::get_user_media`）只返回 `{media, total}`：既不读 `limit` / `from`，
     * 也不返回分页游标（原先声明的 `next_token` 后端从不返回，恒为 `undefined`）。
     * 与 `AdminMediaManager.getUserMedia` 是同一端点的两条入口。
     *
     * @param userId - 用户 MXC ID（如 `@alice:example.org`）
     * @param from - 分页起点（当前后端忽略）
     * @param limit - 返回条数上限（当前后端忽略）
     * @returns 用户的媒体列表与条数
     *
     * @example
     * ```typescript
     * const { media, total } = await adminManager.getUserMedia("@alice:example.org");
     * console.log(`${total} 个媒体`, media.map((m) => m.media_id));
     * ```
     */
    getUserMedia(userId: string, from?: string, limit?: number): Promise<UserMediaList>;
    deleteUserMedia(userId: string): Promise<void>;
    getUserNotification(userId: string): Promise<UserNotificationResponse>;
    /**
     * 设置用户的通知开关
     *
     * ⚠️ GET 与 PUT 在后端用的是**不同的键**：GET 返回 `{enabled}`，PUT 收/发 `{is_enabled}`
     * （`UserNotificationRequest` 带 `deny_unknown_fields`）。本方法接收对调用方更自然的
     * `{enabled}` 并映射为线上字段 `{is_enabled}`；返回值用后端的 `{is_enabled}`。
     *
     * @example
     * ```typescript
     * const { is_enabled } = await adminManager.setUserNotification("@alice:example.org", { enabled: false });
     * console.log(is_enabled);
     * ```
     */
    setUserNotification(userId: string, payload: UserNotificationPayload): Promise<UserNotificationUpdateResponse>;
    /**
     * 列出用户的 pusher
     *
     * 后端返回 `{pushers, total}`（原先只声明并返回了 `pushers`，丢掉了 `total`）。
     *
     * @example
     * ```typescript
     * const { pushers, total } = await adminManager.getUserPushers("@alice:example.org");
     * console.log(total, pushers.map((p) => p.pushkey));
     * ```
     */
    getUserPushers(userId: string): Promise<{
        pushers: UserPusher[];
        total: number;
    }>;
    deleteUserPusher(userId: string, pushkey: string): Promise<void>;
    /**
     * 按事件举报限流记录封锁用户（`POST /_synapse/admin/v1/event_reports/rate_limit/{user_id}/block`）。
     *
     * ⚠️ `blocked_until` 与 `reason` 都是**必填**：后端 `event_report.rs::BlockUserBody`
     * 声明的是 `pub blocked_until: i64` / `pub reason: String`（都不是 `Option`），
     * 且带 `deny_unknown_fields`。此前声明成可选 ⇒ 省略任一个都会得到 422。
     *
     * @param userId - 用户 ID
     * @param payload - `blocked_until`（毫秒时间戳，必填）与 `reason`（必填）
     * @example
     * ```typescript
     * await adminManager.blockEventReportUser("@spammer:example.org", {
     *     blocked_until: Date.now() + 86400_000,
     *     reason: "repeat report abuse",
     * });
     * ```
     */
    blockEventReportUser(userId: string, payload: {
        blocked_until: number;
        reason: string;
    }): Promise<void>;
    unblockEventReportUser(userId: string): Promise<void>;
    /**
     * Determines if the current user is an administrator of the Synapse homeserver.
     * Returns false if untrue or the homeserver does not appear to be a Synapse
     * homeserver. <strong>This function is implementation specific and may change
     * as a result.</strong>
     * @param userId - The user ID to check.
     * @returns true if the user appears to be a Synapse administrator.
     */
    isSynapseAdministrator(userId: string): Promise<boolean>;
    /**
     * Performs a whois lookup on a user using Synapse's administrator API.
     * <strong>This function is implementation specific and may change as a
     * result.</strong>
     * @param userId - the User ID to look up.
     * @returns the whois response - see Synapse docs for information.
     */
    whoisSynapseUser(userId: string): Promise<ISynapseAdminWhoisResponse>;
    /**
     * Deactivates a user using Synapse's administrator API. <strong>This
     * function is implementation specific and may change as a result.</strong>
     * @param userId - the User ID to deactivate.
     * @returns the deactivate response - see Synapse docs for information.
     */
    deactivateSynapseUser(userId: string): Promise<ISynapseAdminDeactivateResponse>;
}
//# sourceMappingURL=admin-user-manager.d.ts.map