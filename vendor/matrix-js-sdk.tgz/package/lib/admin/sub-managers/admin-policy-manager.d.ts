import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { MatrixClient } from "../../client";
/**
 * 策略服务器状态
 */
export interface PolicyServerStatus {
    /** 策略服务器是否启用 */
    enabled: boolean;
    /** 策略服务器端点 URL */
    endpoint: string | null;
    /** 失败模式："fail_open" 或 "fail_closed" */
    fail_mode: "fail_open" | "fail_closed";
}
/**
 * 策略检查请求
 */
export interface PolicyCheckRequest {
    /** 房间 ID，例如 !room:example.com */
    room_id: string;
    /** 执行动作的用户 ID，例如 @alice:example.com */
    user_id: string;
    /** 执行的动作："create", "join", "invite", "send" */
    action: "create" | "join" | "invite" | "send";
}
/**
 * 策略检查响应
 */
export interface PolicyCheckResponse {
    /** 是否允许操作 */
    allowed: boolean;
    /** 结果："allow" 或 "deny" */
    result: "allow" | "deny";
    /** 拒绝原因（仅在 allowed: false 时存在） */
    reason?: string;
}
/**
 * Admin Policy Manager
 *
 * 提供策略服务器（Content Moderation Server）管理功能。
 * 依据 MSC4284，用于查询策略服务器状态和触发实时策略检查。
 */
export declare class AdminPolicyManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取策略服务器状态
     *
     * 返回策略服务器的启用状态、端点 URL 和失败模式。
     *
     * @returns 策略服务器状态
     *
     * @example
     * ```typescript
     * const status = await adminManager.policy.getStatus();
     * if (status.enabled) {
     *     console.log(`Policy server at ${status.endpoint}`);
     * }
     * ```
     */
    getStatus(): Promise<PolicyServerStatus>;
    /**
     * 触发策略检查
     *
     * 同步调用策略服务器检查指定 (room_id, user_id, action) 的授权。
     * 注意：此方法会阻塞调用，直到策略服务器响应。
     *
     * @param request - 策略检查请求
     * @returns 策略检查结果
     *
     * @throws BadRequestError 如果请求参数无效
     *
     * @example
     * ```typescript
     * const result = await adminManager.policy.check({
     *     room_id: "!room:example.com",
     *     user_id: "@alice:example.com",
     *     action: "join"
     * });
     * if (!result.allowed) {
     *     console.log(`Denied: ${result.reason}`);
     * }
     * ```
     */
    check(request: PolicyCheckRequest): Promise<PolicyCheckResponse>;
}
//# sourceMappingURL=admin-policy-manager.d.ts.map