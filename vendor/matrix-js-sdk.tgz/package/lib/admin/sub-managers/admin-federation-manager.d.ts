import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { FederationBlacklistEntry, FederationDestination, AdminFederationDestinationDetail, FederationAdmissionResult, PendingFederationList, AdminFederationCache, AdminFederationDestinationRooms, FederationResolveResponse, FederationRewriteResponse } from "../types";
import type { MatrixClient } from "../../client";
export declare class AdminFederationManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取联邦黑名单列表
     *
     * @returns 联邦黑名单列表
     */
    getFederationBlacklist(): Promise<FederationBlacklistEntry[]>;
    /**
     * 添加到联邦黑名单
     *
     * @param serverName - 服务器名称
     * @param reason - 原因
     */
    addFederationBlacklistEntry(serverName: string, reason?: string): Promise<void>;
    /**
     * 从联邦黑名单移除
     *
     * @param serverName - 服务器名称
     */
    removeFederationBlacklistEntry(serverName: string): Promise<void>;
    /**
     * 获取联邦目的地列表
     *
     * @returns 联邦目的地列表
     */
    getFederationDestinations(): Promise<FederationDestination[]>;
    /**
     * 获取联邦目的地详情
     *
     * @param serverName - 服务器名称
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 目的地详情或 null
     */
    getFederationDestination(serverName: string, throwOnError?: boolean): Promise<AdminFederationDestinationDetail | null>;
    /**
     * 断开联邦连接
     *
     * @param serverName - 服务器名称
     */
    disconnectFederation(serverName: string): Promise<void>;
    /**
     * 重置联邦连接（委托给 disconnectFederation）
     *
     * @param serverName - 服务器名称
     */
    resetFederationConnection(serverName: string): Promise<void>;
    /**
     * 重置联邦目的地（尝试 /reset，404 时回退到 /reset_connection）
     *
     * @param serverName - 服务器名称
     */
    resetFederationDestination(serverName: string): Promise<void>;
    /**
     * 获取联邦目的地的房间列表
     *
     * @param serverName - 服务器名称
     * @param options - 分页选项
     * @returns 房间列表
     */
    getFederationDestinationRooms(serverName: string, options?: {
        from?: number;
        limit?: number;
    }): Promise<AdminFederationDestinationRooms>;
    /**
     * 删除联邦目的地
     *
     * @param serverName - 服务器名称
     */
    deleteFederationDestination(serverName: string): Promise<void>;
    /**
     * 获取联邦缓存信息
     * 对接: GET /_synapse/admin/v1/federation/cache
     */
    getFederationCache(): Promise<AdminFederationCache>;
    /**
     * 清除联邦缓存
     * 对接: POST /_synapse/admin/v1/federation/cache/clear
     */
    clearFederationCache(): Promise<void>;
    /**
     * 删除联邦缓存中的指定条目
     * 对接: DELETE /_synapse/admin/v1/federation/cache/{key}
     *
     * @param key - 缓存条目的键
     */
    deleteFederationCacheEntry(key: string): Promise<void>;
    /**
     * 获取联邦准入列表
     *
     * @returns 联邦准入列表
     */
    getFederationAdmissionList(): Promise<FederationAdmissionResult[]>;
    /**
     * 获取待处理联邦服务器列表
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 待处理联邦服务器列表
     */
    getPendingFederationServers(from?: string, limit?: number): Promise<PendingFederationList>;
    /**
     * 解析联邦服务器
     *
     * @param serverName - 服务器名称
     * @returns 解析结果
     */
    resolveFederation(serverName: string): Promise<FederationResolveResponse>;
    /**
     * 重写联邦服务器
     *
     * @param from - 源服务器名称
     * @param to - 目标服务器名称
     * @returns 重写结果
     */
    rewriteFederation(from: string, to: string): Promise<FederationRewriteResponse>;
    /**
     * 确认联邦
     *
     * @param payload - 确认载荷
     * @returns 确认结果
     */
    confirmFederation(payload: {
        server_name?: string;
        action?: string;
        reason?: string;
    }): Promise<FederationAdmissionResult>;
    /**
     * 添加到联邦黑名单（按服务器名称路径）
     *
     * @param serverName - 服务器名称
     * @param reason - 原因
     */
    addToFederationBlacklist(serverName: string, reason?: string): Promise<void>;
    /**
     * 从联邦黑名单移除（委托给 removeFederationBlacklistEntry）
     *
     * @param serverName - 服务器名称
     */
    removeFromFederationBlacklist(serverName: string): Promise<void>;
}
//# sourceMappingURL=admin-federation-manager.d.ts.map