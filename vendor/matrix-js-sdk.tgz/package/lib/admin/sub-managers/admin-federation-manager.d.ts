import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { FederationBlacklistPage, FederationDestination, AdminFederationDestinationDetail, FederationAdmissionResult, PendingFederationList, PendingFederationServer, AdminFederationCache, AdminFederationDestinationRooms, FederationResolveResponse, FederationRewriteResponse } from "../types";
import type { MatrixClient } from "../../client";
export declare class AdminFederationManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取联邦黑名单列表
     *
     * 对应 `GET /_synapse/admin/v1/federation/blacklist`，后端返回
     * `{blacklist, total, next_batch}`（游标键是 `next_batch`，`total` 是本页条数）。
     *
     * @param options - 可选分页参数
     * @returns 黑名单页（含游标）
     */
    getFederationBlacklist(options?: {
        from?: string;
        limit?: number;
    }): Promise<FederationBlacklistPage>;
    /**
     * 添加到联邦黑名单
     *
     * @param serverName - 服务器名称
     * @param reason - 原因
     */
    addFederationBlacklistEntry(serverName: string, reason?: string): Promise<void>;
    /**
     * 从联邦黑名单移除
     *
     * @param serverName - 服务器名称
     */
    removeFederationBlacklistEntry(serverName: string): Promise<void>;
    /**
     * 获取联邦目的地列表
     *
     * @returns 联邦目的地列表
     */
    getFederationDestinations(): Promise<FederationDestination[]>;
    /**
     * 获取联邦目的地详情
     *
     * @param serverName - 服务器名称
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 目的地详情或 null
     */
    getFederationDestination(serverName: string, throwOnError?: boolean): Promise<AdminFederationDestinationDetail | null>;
    /**
     * 断开联邦连接
     *
     * @param serverName - 服务器名称
     */
    disconnectFederation(serverName: string): Promise<void>;
    /**
     * 重置联邦连接（委托给 disconnectFederation）
     *
     * @param serverName - 服务器名称
     */
    resetFederationConnection(serverName: string): Promise<void>;
    /**
     * 重置联邦目的地（尝试 /reset，404 时回退到 /reset_connection）
     *
     * @param serverName - 服务器名称
     */
    resetFederationDestination(serverName: string): Promise<void>;
    /**
     * 获取联邦目的地的房间列表
     *
     * @param serverName - 服务器名称
     * @param options - 分页选项
     * @returns 房间列表
     */
    getFederationDestinationRooms(serverName: string, options?: {
        from?: number;
        limit?: number;
    }): Promise<AdminFederationDestinationRooms>;
    /**
     * 删除联邦目的地
     *
     * @param serverName - 服务器名称
     */
    deleteFederationDestination(serverName: string): Promise<void>;
    /**
     * 获取联邦缓存信息
     *
     * 对应 `GET /_synapse/admin/v1/federation/cache`，后端返回 `{cache, total}`。
     * ⚠️ 列表键是 `cache`（不是 `entries`）。
     */
    getFederationCache(): Promise<AdminFederationCache>;
    /**
     * 清除联邦缓存
     * 对接: POST /_synapse/admin/v1/federation/cache/clear
     */
    clearFederationCache(): Promise<void>;
    /**
     * 删除联邦缓存中的指定条目
     * 对接: DELETE /_synapse/admin/v1/federation/cache/{key}
     *
     * @param key - 缓存条目的键
     */
    deleteFederationCacheEntry(key: string): Promise<void>;
    /**
     * 获取待处理联邦服务器列表（审批队列）
     *
     * 对应 `GET /_synapse/admin/v1/federation/pending`，后端返回 `{servers, total, limit, next_batch}`。
     *
     * ⚠️ 旧实现读的是 `admissions` / `pending` 两个**后端从不返回**的键 ⇒ 恒返回 `[]`
     * （与 {@link getPendingFederationServers} 打同一端点、但取错键）。
     */
    getFederationAdmissionList(): Promise<PendingFederationServer[]>;
    /**
     * 获取待处理联邦服务器列表
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 待处理联邦服务器列表
     */
    getPendingFederationServers(from?: string, limit?: number): Promise<PendingFederationList>;
    /**
     * 解析联邦服务器
     *
     * @param serverName - 服务器名称
     * @returns 解析结果
     */
    resolveFederation(serverName: string): Promise<FederationResolveResponse>;
    /**
     * 重写联邦服务器
     *
     * @param from - 源服务器名称
     * @param to - 目标服务器名称
     * @returns 重写结果
     */
    rewriteFederation(from: string, to: string): Promise<FederationRewriteResponse>;
    /**
     * 确认联邦准入
     *
     * 对应 `POST /_synapse/admin/v1/federation/confirm`。后端 `ConfirmRequest`
     * 带 `#[serde(deny_unknown_fields)]`，字段是 **`{server_name, accept}`**。
     *
     * ⚠️ 旧签名收 `{server_name?, action?, reason?}` —— `accept` 缺失 + `action`/`reason`
     * 是未知字段 ⇒ 该请求**必然 400**（`deny_unknown_fields` 连多余字段都不放过）。
     *
     * @param serverName - 待确认的服务器名
     * @param accept - `true` 接受、`false` 拒绝
     * @returns 准入结果
     *
     * @throws {ValidationError} 如果 serverName 为空
     */
    confirmFederation(serverName: string, accept: boolean): Promise<FederationAdmissionResult>;
    /**
     * 添加到联邦黑名单（按服务器名称路径）
     *
     * @param serverName - 服务器名称
     * @param reason - 原因
     */
    addToFederationBlacklist(serverName: string, reason?: string): Promise<void>;
    /**
     * 从联邦黑名单移除（委托给 removeFederationBlacklistEntry）
     *
     * @param serverName - 服务器名称
     */
    removeFromFederationBlacklist(serverName: string): Promise<void>;
}
//# sourceMappingURL=admin-federation-manager.d.ts.map