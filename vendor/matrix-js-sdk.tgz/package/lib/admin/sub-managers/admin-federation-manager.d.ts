import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { FederationBlacklistPage, FederationDestination, AdminFederationDestinationDetail, FederationAdmissionResult, PendingFederationList, PendingFederationServer, AdminFederationCache, AdminFederationDestinationRooms, FederationResolveResponse, FederationRewriteResponse } from "../types";
import type { MatrixClient } from "../../client";
export declare class AdminFederationManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取联邦黑名单列表
     *
     * 对应 `GET /_synapse/admin/v1/federation/blacklist`，后端返回
     * `{blacklist, total, next_batch}`（游标键是 `next_batch`，`total` 是本页条数）。
     *
     * @param options - 可选分页参数
     * @returns 黑名单页（含游标）
     *
     * @example
     * ```typescript
     * const page = await client.getAdminManager().federation.getFederationBlacklist({ limit: 50 });
     * console.log(page.blacklist.length);
     * ```
     */
    getFederationBlacklist(options?: {
        from?: string;
        limit?: number;
    }): Promise<FederationBlacklistPage>;
    /**
     * 添加到联邦黑名单
     *
     * @param serverName - 服务器名称
     * @param reason - 原因
     *
     * @throws {ValidationError} 如果 serverName 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.addFederationBlacklistEntry("evil.example.org", "spam");
     * ```
     */
    addFederationBlacklistEntry(serverName: string, reason?: string): Promise<void>;
    /**
     * 从联邦黑名单移除
     *
     * @param serverName - 服务器名称
     *
     * @throws {ValidationError} 如果 serverName 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.removeFederationBlacklistEntry("evil.example.org");
     * ```
     */
    removeFederationBlacklistEntry(serverName: string): Promise<void>;
    /**
     * 获取联邦目的地列表
     *
     * @returns 联邦目的地列表
     *
     * @example
     * ```typescript
     * const destinations = await client.getAdminManager().federation.getFederationDestinations();
     * console.log(destinations.length);
     * ```
     */
    getFederationDestinations(): Promise<FederationDestination[]>;
    /**
     * 获取联邦目的地详情
     *
     * @param serverName - 服务器名称
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 目的地详情或 null
     *
     * @throws {Error} 当 throwOnError 为 true 且请求失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const detail = await client.getAdminManager().federation.getFederationDestination("matrix.org");
     * console.log(detail?.failure_count);
     * ```
     */
    getFederationDestination(serverName: string, throwOnError?: boolean): Promise<AdminFederationDestinationDetail | null>;
    /**
     * 断开联邦连接
     *
     * @param serverName - 服务器名称
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.disconnectFederation("matrix.org");
     * ```
     */
    disconnectFederation(serverName: string): Promise<void>;
    /**
     * 重置联邦连接（委托给 disconnectFederation）
     *
     * @param serverName - 服务器名称
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.resetFederationConnection("matrix.org");
     * ```
     */
    resetFederationConnection(serverName: string): Promise<void>;
    /**
     * 重置联邦目的地（尝试 /reset，404 时回退到 /reset_connection）
     *
     * @param serverName - 服务器名称
     *
     * @throws {ValidationError} 如果 serverName 为空
     * @throws {Error} 当两个端点均失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.resetFederationDestination("matrix.org");
     * ```
     */
    resetFederationDestination(serverName: string): Promise<void>;
    /**
     * 获取联邦目的地的房间列表
     *
     * @param serverName - 服务器名称
     * @param options - 分页选项
     * @returns 房间列表
     *
     * @example
     * ```typescript
     * const rooms = await client.getAdminManager().federation.getFederationDestinationRooms("matrix.org", { limit: 20 });
     * console.log(rooms.total);
     * ```
     */
    getFederationDestinationRooms(serverName: string, options?: {
        from?: number;
        limit?: number;
    }): Promise<AdminFederationDestinationRooms>;
    /**
     * 删除联邦目的地
     *
     * @param serverName - 服务器名称
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.deleteFederationDestination("matrix.org");
     * ```
     */
    deleteFederationDestination(serverName: string): Promise<void>;
    /**
     * 获取联邦缓存信息
     *
     * 对应 `GET /_synapse/admin/v1/federation/cache`，后端返回 `{cache, total}`。
     * ⚠️ 列表键是 `cache`（不是 `entries`）。
     *
     * @example
     * ```typescript
     * const cache = await client.getAdminManager().federation.getFederationCache();
     * console.log(cache.total);
     * ```
     */
    getFederationCache(): Promise<AdminFederationCache>;
    /**
     * 清除联邦缓存
     * 对接: POST /_synapse/admin/v1/federation/cache/clear
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.clearFederationCache();
     * ```
     */
    clearFederationCache(): Promise<void>;
    /**
     * 删除联邦缓存中的指定条目
     * 对接: DELETE /_synapse/admin/v1/federation/cache/{key}
     *
     * @param key - 缓存条目的键
     *
     * @throws {ValidationError} 如果 key 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.deleteFederationCacheEntry("my-cache-key");
     * ```
     */
    deleteFederationCacheEntry(key: string): Promise<void>;
    /**
     * 获取待处理联邦服务器列表（审批队列）
     *
     * 对应 `GET /_synapse/admin/v1/federation/pending`，后端返回 `{servers, total, limit, next_batch}`。
     *
     * ⚠️ 旧实现读的是 `admissions` / `pending` 两个**后端从不返回**的键 ⇒ 恒返回 `[]`
     * （与 {@link getPendingFederationServers} 打同一端点、但取错键）。
     *
     * @example
     * ```typescript
     * const servers = await client.getAdminManager().federation.getFederationAdmissionList();
     * console.log(servers.length);
     * ```
     */
    getFederationAdmissionList(): Promise<PendingFederationServer[]>;
    /**
     * 获取待处理联邦服务器列表
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 待处理联邦服务器列表
     *
     * @example
     * ```typescript
     * const page = await client.getAdminManager().federation.getPendingFederationServers(undefined, 50);
     * console.log(page.servers.length, page.next_batch);
     * ```
     */
    getPendingFederationServers(from?: string, limit?: number): Promise<PendingFederationList>;
    /**
     * 解析联邦服务器
     *
     * @param serverName - 服务器名称
     * @returns 解析结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().federation.resolveFederation("matrix.org");
     * console.log(res.resolved);
     * ```
     */
    resolveFederation(serverName: string): Promise<FederationResolveResponse>;
    /**
     * 重写联邦服务器
     *
     * @param from - 源服务器名称
     * @param to - 目标服务器名称
     * @returns 重写结果
     *
     * @throws {ValidationError} 如果 from 或 to 为空
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().federation.rewriteFederation("old.example.org", "new.example.org");
     * console.log(res);
     * ```
     */
    rewriteFederation(from: string, to: string): Promise<FederationRewriteResponse>;
    /**
     * 确认联邦准入
     *
     * 对应 `POST /_synapse/admin/v1/federation/confirm`。后端 `ConfirmRequest`
     * 带 `#[serde(deny_unknown_fields)]`，字段是 **`{server_name, accept}`**。
     *
     * ⚠️ 旧签名收 `{server_name?, action?, reason?}` —— `accept` 缺失 + `action`/`reason`
     * 是未知字段 ⇒ 该请求**必然 400**（`deny_unknown_fields` 连多余字段都不放过）。
     *
     * @param serverName - 待确认的服务器名
     * @param accept - `true` 接受、`false` 拒绝
     * @returns 准入结果
     *
     * @throws {ValidationError} 如果 serverName 为空
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().federation.confirmFederation("remote.example.org", true);
     * console.log(res.status);
     * ```
     */
    confirmFederation(serverName: string, accept: boolean): Promise<FederationAdmissionResult>;
    /**
     * 添加到联邦黑名单（按服务器名称路径）
     *
     * @param serverName - 服务器名称
     * @param reason - 原因
     *
     * @throws {ValidationError} 如果 serverName 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.addToFederationBlacklist("evil.example.org", "spam");
     * ```
     */
    addToFederationBlacklist(serverName: string, reason?: string): Promise<void>;
    /**
     * 从联邦黑名单移除（委托给 removeFederationBlacklistEntry）
     *
     * @param serverName - 服务器名称
     *
     * @example
     * ```typescript
     * await client.getAdminManager().federation.removeFromFederationBlacklist("evil.example.org");
     * ```
     */
    removeFromFederationBlacklist(serverName: string): Promise<void>;
}
//# sourceMappingURL=admin-federation-manager.d.ts.map