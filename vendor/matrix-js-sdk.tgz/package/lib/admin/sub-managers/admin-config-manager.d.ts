import { AdminBaseManager, type AdminErrorCallback } from "../admin-base-manager";
import type { RetentionPolicy, RoomRetentionPolicy, RetentionRunResult, RetentionStatus, FeatureFlagTarget, FeatureFlag, FeatureFlagPage, RegistrationToken, AuditEvent, AuditEventPage, AdminModuleInfo, AdminModulePage, AdminModuleLogPage, AdminAccountValidityInfo, AdminPasswordAuthProvider, AdminPasswordAuthProviderPage, AdminPresenceRoute, AdminPresenceRoutePage, AdminMediaCallback, AdminMediaCallbackPage, AdminRateLimitCallback, AdminRateLimitCallbackPage, AdminAccountDataCallback, AdminAccountDataCallbackPage, AdminInviteList, AdminJitsiConfig, AdminReport, AdminReportPage, DynamicConfig, FeatureFlagUpdatePayload, AuditEventCreateRequest, AccountValidityRequest, AccountValidityRenewRequest, ThirdPartyRuleCheckPayload, ThirdPartyRuleCheckResult, SpamCheckResult, ThirdPartyRuleResult } from "../types";
import type { MatrixClient } from "../../client";
export declare class AdminConfigManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback);
    getRetentionPolicy(): Promise<RetentionPolicy>;
    setRetentionPolicy(policy: {
        max_lifetime?: number | null;
        min_lifetime?: number | null;
        expire_on_clients?: boolean;
    }): Promise<RetentionPolicy>;
    getRoomRetentionPolicy(roomId: string): Promise<RoomRetentionPolicy>;
    setRoomRetentionPolicy(roomId: string, policy: {
        max_lifetime?: number | null;
        min_lifetime?: number | null;
        expire_on_clients?: boolean;
    }): Promise<RoomRetentionPolicy>;
    runRetention(options?: {
        room_id?: string;
        scope?: "all" | "room";
    }): Promise<RetentionRunResult>;
    getRetentionStatus(): Promise<RetentionStatus>;
    getFeatureFlags(): Promise<FeatureFlagPage>;
    getFeatureFlag(flagKey: string): Promise<FeatureFlag>;
    setFeatureFlag(flagKey: string, targetScope: string, rolloutPercent: number, expiresAt: number | null, reason: string, targets: FeatureFlagTarget[]): Promise<FeatureFlag>;
    deleteFeatureFlag(flagKey: string): Promise<void>;
    listFeatureFlags(options?: Record<string, string | number | undefined>): Promise<FeatureFlagPage>;
    updateFeatureFlag(flagId: string, payload: FeatureFlagUpdatePayload): Promise<FeatureFlag>;
    listModules(options?: {
        limit?: number;
        from?: string;
    }): Promise<AdminModulePage>;
    listModulesByType(moduleType: string): Promise<AdminModulePage>;
    updateModuleConfig(moduleId: string, config: DynamicConfig): Promise<AdminModuleInfo>;
    setModuleEnabled(moduleId: string, isEnabled: boolean): Promise<AdminModuleInfo>;
    getModuleLogs(moduleId: string, options?: {
        limit?: number;
        from?: number;
    }): Promise<AdminModuleLogPage>;
    checkModuleThirdPartyRule(payload: ThirdPartyRuleCheckPayload): Promise<ThirdPartyRuleCheckResult>;
    getModuleSpamCheckResult(eventId: string): Promise<SpamCheckResult>;
    listModuleSpamChecksBySender(sender: string, options?: {
        limit?: number;
    }): Promise<SpamCheckResult[]>;
    getModuleThirdPartyRuleResults(eventId: string): Promise<ThirdPartyRuleResult[]>;
    listReports(options?: {
        from?: string;
        limit?: number;
    }): Promise<AdminReportPage>;
    getReport(reportId: string): Promise<AdminReport>;
    deleteReport(reportId: string): Promise<void>;
    listAuditEvents(options?: Record<string, string | number | undefined>): Promise<AuditEventPage>;
    getAuditEvent(eventId: string): Promise<AuditEvent>;
    createAuditEvent(payload: AuditEventCreateRequest): Promise<AuditEvent>;
    getRegistrationTokens(): Promise<RegistrationToken[]>;
    createRegistrationToken(tokenOrPayload: string | {
        token: string;
        uses_allowed?: number;
        expiry_ts?: number;
    }, usesAllowed?: number, expiryTs?: number): Promise<RegistrationToken>;
    deleteRegistrationToken(token: string): Promise<void>;
    updateRegistrationToken(token: string, payload: {
        uses_allowed?: number;
        expiry_ts?: number;
    }): Promise<void>;
    getRegistrationToken(token: string): Promise<RegistrationToken>;
    createAccountValidity(payload: AccountValidityRequest): Promise<AdminAccountValidityInfo>;
    getAccountValidity(userId: string): Promise<AdminAccountValidityInfo>;
    renewAccountValidity(userId: string, payload: AccountValidityRenewRequest): Promise<AdminAccountValidityInfo>;
    listPasswordAuthProviders(): Promise<AdminPasswordAuthProviderPage>;
    createPasswordAuthProvider(payload: DynamicConfig): Promise<AdminPasswordAuthProvider>;
    listPresenceRoutes(): Promise<AdminPresenceRoutePage>;
    createPresenceRoute(payload: DynamicConfig): Promise<AdminPresenceRoute>;
    listMediaCallbacks(): Promise<AdminMediaCallbackPage>;
    listMediaCallbacksByType(callbackType: string): Promise<AdminMediaCallbackPage>;
    createMediaCallback(payload: DynamicConfig): Promise<AdminMediaCallback>;
    listRateLimitCallbacks(): Promise<AdminRateLimitCallbackPage>;
    createRateLimitCallback(payload: DynamicConfig): Promise<AdminRateLimitCallback>;
    listAccountDataCallbacks(): Promise<AdminAccountDataCallbackPage>;
    createAccountDataCallback(payload: DynamicConfig): Promise<AdminAccountDataCallback>;
    getInviteAllowlist(): Promise<AdminInviteList>;
    getInviteBlocklist(): Promise<AdminInviteList>;
    getJitsiConfig(): Promise<AdminJitsiConfig>;
    acknowledgeTelemetryAlert(alertId: string): Promise<void>;
}
//# sourceMappingURL=admin-config-manager.d.ts.map