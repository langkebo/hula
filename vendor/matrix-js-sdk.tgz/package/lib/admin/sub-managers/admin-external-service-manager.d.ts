import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { MatrixClient } from "../../client";
/**
 * 后端外部服务对象（字段与 `external_service.rs` 对齐）。
 */
export interface BackendExternalService {
    as_id: string;
    service_type: string;
    service_id: string;
    display_name: string;
    is_enabled: boolean;
    is_healthy: boolean;
    created_ts: number;
}
/**
 * 后端外部服务健康状态（字段与 `external_service.rs` 对齐）。
 */
export interface BackendExternalServiceHealth {
    service_id: string;
    service_type: string;
    is_healthy: boolean;
    last_check_ts: number | null;
    last_success_ts: number | null;
    last_error: string | null;
    consecutive_failures: number;
}
/**
 * 注册外部服务的请求载荷。
 */
export interface RegisterExternalServicePayload {
    service_type: string;
    service_id: string;
    display_name: string;
    webhook_url?: string;
    api_key?: string;
    config?: Record<string, unknown>;
}
/**
 * 更新外部服务的请求载荷（所有字段可选）。
 */
export interface UpdateExternalServicePayload {
    webhook_url?: string;
    api_key?: string;
    config?: Record<string, unknown>;
    is_enabled?: boolean;
}
/**
 * 健康检查触发结果。
 */
export interface HealthCheckResult {
    as_id: string;
    is_healthy: boolean;
}
/**
 * Admin External Service Manager
 *
 * 提供外部服务的 CRUD 与健康检查功能，使用后端字段格式。
 */
export declare class AdminExternalServiceManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 列出外部服务。
     *
     * @param serviceType - 可选服务类型过滤；传 "all" 或省略则不过滤
     * @returns 外部服务列表
     */
    listServices(serviceType?: string): Promise<BackendExternalService[]>;
    /**
     * 注册外部服务。
     *
     * @param payload - 服务注册信息
     * @returns 创建后的外部服务对象
     */
    registerService(payload: RegisterExternalServicePayload): Promise<BackendExternalService>;
    /**
     * 更新外部服务。
     *
     * @param asId - 外部服务的 as_id
     * @param payload - 更新字段
     * @returns 更新后的外部服务对象
     */
    updateService(asId: string, payload: UpdateExternalServicePayload): Promise<BackendExternalService>;
    /**
     * 删除外部服务。
     *
     * @param asId - 外部服务的 as_id
     */
    deleteService(asId: string): Promise<void>;
    /**
     * 获取所有外部服务的健康状态。
     *
     * @returns 健康状态列表
     */
    getAllHealth(): Promise<BackendExternalServiceHealth[]>;
    /**
     * 获取指定外部服务的健康状态。
     *
     * @param asId - 外部服务的 as_id
     * @returns 健康状态；若服务不存在返回 null
     */
    getServiceHealth(asId: string): Promise<BackendExternalServiceHealth | null>;
    /**
     * 触发指定外部服务的健康检查。
     *
     * @param asId - 外部服务的 as_id
     * @returns 健康检查结果
     */
    checkServiceHealth(asId: string): Promise<HealthCheckResult>;
}
//# sourceMappingURL=admin-external-service-manager.d.ts.map