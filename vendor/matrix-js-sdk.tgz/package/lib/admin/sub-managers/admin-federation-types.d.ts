/**
 * 联邦黑名单条目
 *
 * 键取自后端 `federation.rs::get_blacklist` 的内联 `json!`（3 键）。
 * ⚠️ 时间戳键是 **`added_at`**（值来自 `row.created_ts.unwrap_or(0)`），
 * 不是 `added_ts` —— 原声明读的是后者，恒为 `undefined`。
 */
export interface FederationBlacklistEntry {
    server_name: string;
    /** 加入黑名单的时间（毫秒）；后端缺 `created_ts` 时回填 `0` */
    added_at: number;
    reason: string | null;
}
/**
 * `GET /_synapse/admin/v1/federation/blacklist` 的响应壳
 *
 * 后端返回 `{blacklist, total, next_batch}`；`total` 是**本页条数**
 * （处理器写的是 `list.len()`），游标键是 `next_batch`（`null` 表示末页）。
 */
export interface FederationBlacklistPage {
    blacklist: FederationBlacklistEntry[];
    /** 本页条数（后端语义；非全局总数） */
    total: number;
    next_batch: string | null;
}
/**
 * 联邦目的地（列表与详情同形状）
 *
 * 键取自后端 `admin_federation_service::map_destination_row` → `DestinationInfo`（8 键）。
 * ⚠️ 原先声明的 `last_successful_stream_ordering` 后端**不返回**（那是上游 Synapse 的字段）；
 * 真实键是 `last_successful_ts` 与 `failure_count`。
 * ⚠️ `retry_interval` 在后端被写死为 `None`，因而**恒为 `null`**。
 */
export interface FederationDestination {
    destination: string;
    retry_last_ts: number | null;
    /** 后端当前恒为 `null`（`map_destination_row` 里写死 `None`） */
    retry_interval: number | null;
    failure_ts: number | null;
    last_successful_ts: number | null;
    /** 连续失败次数 */
    failure_count: number;
    /** `"active"` / `"rejected"` / …（后端默认 `"active"`） */
    status: string;
    updated_ts: number | null;
}
/** 单个联邦目的地的详细信息（`GET /federation/destinations/{destination}`）—— 与列表项同形状 */
export type AdminFederationDestinationDetail = FederationDestination;
/**
 * `GET /_synapse/admin/v1/federation/destinations` 的响应包络。
 *
 * 具名而不再在泛型实参里写内联对象字面量 —— 后者让契约工具判不出线格式，
 * 响应直接落 `inline-type-arg` 覆盖桶（无法逐字段比对）。
 *
 * ⚠️ 2026-10-19 具名后立刻被门禁抓出**漏声明三个键**：后端
 * `admin/federation.rs:174-179` 返回 `{destinations, total, total_count, next_batch}`，
 * 而 SDK 原先只声明了 `destinations`（`total` / `total_count` 是同一数值，
 * `next_batch` 为 `Option<String>` ⇒ 可为 null）。
 */
export interface AdminFederationDestinationsResponse {
    destinations: FederationDestination[];
    total: number;
    /** 后端把 `total` 又回显了一份（历史字段名），与 `total` 恒等 */
    total_count: number;
    next_batch: string | null;
}
/**
 * `GET /_synapse/admin/v1/federation/destinations/{destination}/rooms`
 *
 * ⚠️ `rooms` 是 **room id 字符串数组**（后端 `get_destination_rooms` 返回 `Vec<String>`），
 * 不是对象数组。原先声明的 `AdminFederationDestinationRoom`（`{room_id, stream_ordering, …}`）
 * 纯属虚构，已删除。
 *
 * 后端 `admin/federation.rs` 返回 `{rooms, total, next_batch}`（`total` 是全局总数），
 * 游标键是 `next_batch`（`null` 表示末页）。
 */
export interface AdminFederationDestinationRooms {
    rooms: string[];
    /** 符合过滤条件的房间总数（非本页条数） */
    total: number;
    next_batch: string | null;
}
/** `POST /_synapse/admin/v1/federation/confirm` 的响应 */
export interface FederationAdmissionResult {
    server_name: string;
    status: string;
    previous_status: string;
    updated_ts: number | null;
    confirmed_by: string;
}
/**
 * 待处理联邦服务器
 *
 * 键取自后端 `admin_federation_service::list_pending_federation` → `PendingFederationInfo`（6 键）；
 * `status` 是处理器显式写死的 `"pending"`。
 */
export interface PendingFederationServer {
    server_name: string;
    failure_count: number;
    last_failed_connect_at: number | null;
    last_successful_connect_at: number | null;
    status: "pending";
    updated_ts: number | null;
}
/**
 * `GET /_synapse/admin/v1/federation/pending` 的响应
 *
 * 后端返回 `{servers, total, limit, next_batch}`。
 * ⚠️ 原先声明的 `offset` 后端**不返回**（`offset` 分页已被显式拒绝并返回 400）；
 * 真实游标键是 `next_batch`。
 */
export interface PendingFederationList {
    servers: PendingFederationServer[];
    total: number;
    /** 后端回显生效的 limit */
    limit: number;
    next_batch: string | null;
}
/**
 * 联邦缓存条目
 *
 * 键取自后端 `admin_federation_service::map_cache_entry` → `FederationCacheEntry`（3 键）。
 * ⚠️ 原先声明的 `size` / `last_access_ts` 后端**不返回**；真实键是 `expiry_ts`。
 */
export interface AdminFederationCacheEntry {
    key: string;
    /** 缓存值（后端从 TEXT 反序列化，失败或空时为 `null`） */
    value: unknown;
    expiry_ts: number | null;
}
/**
 * `GET /_synapse/admin/v1/federation/cache` 的响应
 *
 * ⚠️ 列表键是 **`cache`**（不是 `entries`）—— 原声明读 `entries`，恒为 `undefined`。
 * `total` 是条目数。
 */
export interface AdminFederationCache {
    cache: AdminFederationCacheEntry[];
    total: number;
}
/** Response for POST /federation/resolve — federation resolve result */
export interface FederationResolveResponse {
    server_name: string;
    resolved: boolean;
    blacklisted: boolean;
    in_destinations: boolean;
    resolved_by?: string;
}
/** Response for POST /federation/rewrite — federation rewrite result */
export interface FederationRewriteResponse {
    from: string;
    to: string;
    rewritten: boolean;
    rooms_affected: number;
    rewritten_by?: string;
}
//# sourceMappingURL=admin-federation-types.d.ts.map