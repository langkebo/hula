import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { MatrixClient } from "../../client";
/** `GET /push/config` 的响应；`config` 里的密钥值已打码（形如 `****abcd`）。 */
export interface PushConfigResponse {
    /** `config_key` → `config_value`（密钥类只保留末 4 位）。 */
    config: Record<string, string>;
    /** 当前已完成初始化的 provider 名称。 */
    initialized_providers: string[];
    /** 后端支持的配置键（仅 `GET` 返回；`PUT` 不返回）。 */
    supported_keys?: string[];
}
/** `PUT /push/config` 的响应（与 GET 同形，但没有 `supported_keys`）。 */
export interface PushConfigUpdateResponse {
    config: Record<string, string>;
    initialized_providers: string[];
}
/**
 * `PUT /push/config` 的请求体。
 *
 * 值为 `string` 表示写入，`null` 表示删除该键（后端语义：空字符串会被当成"未配置"，
 * 想彻底删掉一行只能传 `null`）。
 */
export interface PushConfigPatchRequest {
    config: Record<string, string | null>;
}
/** `POST /push/process` 的响应。 */
export interface PushProcessQueueResponse {
    /** 本次处理的推送条数。 */
    processed: number;
    /** 后端生成的说明文案（可直接展示给运维）。 */
    message: string;
}
/** `POST /push/cleanup` 的响应。 */
export interface PushCleanupLogsResponse {
    /** 本次清理的日志条数。 */
    cleaned: number;
    /** 后端生成的说明文案。 */
    message: string;
}
/**
 * 推送服务运维管理
 *
 * @example
 * ```typescript
 * const push = client.getAdminManager().push;
 * const { config, initialized_providers } = await push.getConfig();
 * await push.setConfig({ apns_topic: "im.example.app", apns_key: null });
 * await push.processQueue(200);
 * await push.cleanupLogs(7);
 * ```
 */
export declare class AdminPushManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 读取推送 provider 配置
     *
     * 注意：密钥类配置会被后端掩码（只留末 4 位），因此**不要**把这里的返回值原样回写给
     * {@link setConfig} —— 那会把掩码值当成真实密钥写库。
     *
     * 对应 `GET /_synapse/admin/v1/push/config`。
     *
     * @example
     * ```typescript
     * const cfg = await client.getAdminManager().push.getConfig();
     * console.log(cfg.initialized_providers);
     * ```
     */
    getConfig(): Promise<PushConfigResponse>;
    /**
     * 增量修改推送 provider 配置
     *
     * 后端会**立即重建 provider**，不需要重启 homeserver。只传要改的键；传 `null` 删除。
     *
     * @param patch - `{ config: { <key>: <value> | null } }`；未知键由后端拒绝（400）
     *
     * 对应 `PUT /_synapse/admin/v1/push/config`。
     *
     * @example
     * ```typescript
     * // 设置一个键、删除另一个键
     * await push.setConfig({ config: { apns_topic: "im.example.app", apns_key: null } });
     * ```
     */
    setConfig(patch: PushConfigPatchRequest): Promise<PushConfigUpdateResponse>;
    /**
     * 手动推进一次推送发送队列
     *
     * @param batchSize - 本次最多处理多少条；后端 clamp 到 `1..500`，缺省 100
     *
     * 对应 `POST /_synapse/admin/v1/push/process?batch_size=N`。
     *
     * 注意：`batch_size` 在 **query string**，不是 body。
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().push.processQueue(200);
     * console.log(result.processed);
     * ```
     */
    processQueue(batchSize?: number): Promise<PushProcessQueueResponse>;
    /**
     * 清理历史推送发送日志
     *
     * @param days - 保留最近多少天的日志；后端 clamp 到 `1..200`，缺省 30
     *
     * 对应 `POST /_synapse/admin/v1/push/cleanup?days=N`。
     *
     * 注意：`days` 在 **query string**，不是 body。
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().push.cleanupLogs(7);
     * console.log(result.deleted);
     * ```
     */
    cleanupLogs(days?: number): Promise<PushCleanupLogsResponse>;
}
//# sourceMappingURL=admin-push-manager.d.ts.map