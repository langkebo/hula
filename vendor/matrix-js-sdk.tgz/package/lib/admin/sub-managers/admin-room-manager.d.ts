import { AdminBaseManager, type AdminErrorCallback } from "../admin-base-manager";
import type { RoomInfo, RoomStateEvent, RoomMessage, RoomStats, SpaceInfo, SpacePage, SpaceUser, SpaceRoom, PaginatedResponse, AdminAccountDetails, AdminRoomVersionResponse, AdminRoomBlockStatus, AdminEventContext, AdminForwardExtremity, AdminTokenSync, AdminRoomSearchResult, AdminRoomListings, AdminReport, AdminReportPage, AdminPurgeHistoryResult, RoomSearchPayload, RoomDeletePayload, PurgeHistoryPayload, AdminReasonPayload, AdminBanKickPayload, AdminMakeRoomAdminPayload, RoomEventSearchPayload, SpaceStats } from "../types";
import type { MatrixClient } from "../../client";
export declare enum AdminRoomEvent {
    RoomDeleted = "RoomDeleted",
    RoomBlocked = "RoomBlocked"
}
export interface AdminRoomEventMap {
    [AdminRoomEvent.RoomDeleted]: (roomId: string) => void;
    [AdminRoomEvent.RoomBlocked]: (roomId: string, blocked: boolean) => void;
}
export declare class AdminRoomManager extends AdminBaseManager<AdminRoomEvent, AdminRoomEventMap> {
    constructor(client: MatrixClient, onError?: AdminErrorCallback);
    /**
     * 获取房间列表（支持分页）
     *
    /**
     * 获取房间列表（统一分页格式）
     *
     * @param options - 查询选项
     * @param options.from - 分页起点 token
     * @param options.limit - 返回房间数量限制
     * @param options.search - 房间名称或别名搜索关键词
     * @param options.order_by - 排序字段 (e.g., "name", "joined_members")
     * @param options.sort_order - 排序顺序 ("asc" 或 "desc")
     * @returns 统一格式的分页响应
     */
    getRoomsPaginated(options?: {
        from?: string;
        limit?: number;
        search?: string;
        order_by?: string;
        sort_order?: "asc" | "desc";
    }): Promise<PaginatedResponse<RoomInfo>>;
    searchRooms(options?: Record<string, string | number | boolean | undefined>): Promise<AdminRoomSearchResult>;
    searchRoomsPost(payload: RoomSearchPayload): Promise<AdminRoomSearchResult>;
    /**
     * 获取房间详情
     *
     * @param roomId - 房间 ID
     * @returns 房间详情
     */
    getRoom(roomId: string, throwOnError?: boolean): Promise<RoomInfo | null>;
    /**
     * 删除房间
     *
     * @param roomId - 房间 ID
     * @param block - 是否阻止未来的加入
     * @param purge - 是否从数据库中清除房间
     * @param reason - 删除原因
     */
    deleteRoom(roomId: string, blockOrOptions?: boolean | {
        block?: boolean;
        purge?: boolean;
        force_purge?: boolean;
        reason?: string;
    }, purge?: boolean, reason?: string): Promise<void>;
    deleteRoomAdmin(roomId: string, payload?: RoomDeletePayload): Promise<void>;
    purgeRoomHistory(roomId: string, payload?: PurgeHistoryPayload): Promise<AdminPurgeHistoryResult>;
    /**
     * 封锁/解封房间
     *
     * @param roomId - 房间 ID
     * @param block - 是否封锁房间
     * @param reason - 原因
     */
    blockRoom(roomId: string, block: boolean, reason?: string): Promise<void>;
    unblockRoom(roomId: string, payload?: AdminReasonPayload): Promise<void>;
    /**
     * 获取房间成员列表
     *
     * @param roomId - 房间 ID
     * @returns 房间成员列表
     */
    getRoomMembers(roomId: string): Promise<AdminAccountDetails[]>;
    addRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    removeRoomMember(roomId: string, userId: string): Promise<void>;
    banRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    kickRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    unbanRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    banRoom(roomId: string, payload: AdminBanKickPayload): Promise<void>;
    kickRoom(roomId: string, payload: AdminBanKickPayload): Promise<void>;
    makeRoomAdmin(roomId: string, payload: AdminMakeRoomAdminPayload): Promise<void>;
    /**
     * 获取房间状态事件
     *
     * @param roomId - 房间 ID
     * @returns 房间状态事件列表
     */
    getRoomState(roomId: string): Promise<{
        state: RoomStateEvent[];
    }>;
    /**
     * 获取房间消息
     *
     * @param roomId - 房间 ID
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 房间消息列表
     */
    getRoomMessages(roomId: string, optionsOrFrom?: string | {
        from?: string;
        limit?: number;
        dir?: "b" | "f" | string;
    }, limit?: number): Promise<{
        chunk: RoomMessage[];
        start?: string;
        end?: string;
    }>;
    /**
     * 删除房间消息
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param reason - 删除原因
     */
    deleteRoomMessage(roomId: string, eventId: string, reason?: string): Promise<void>;
    getRoomAliases(roomId: string): Promise<{
        aliases: string[];
    }>;
    getRoomVersion(roomId: string): Promise<AdminRoomVersionResponse>;
    getRoomBlockStatus(roomId: string): Promise<AdminRoomBlockStatus>;
    getRoomEventContext(roomId: string, eventId: string): Promise<AdminEventContext>;
    getRoomForwardExtremities(roomId: string): Promise<AdminForwardExtremity[]>;
    getRoomTokenSync(roomId: string): Promise<AdminTokenSync>;
    searchRoomEvents(roomId: string, payload: RoomEventSearchPayload): Promise<AdminRoomSearchResult>;
    getRoomListings(roomId: string): Promise<AdminRoomListings>;
    setRoomPublicListing(roomId: string): Promise<void>;
    deleteRoomPublicListing(roomId: string): Promise<void>;
    /**
     * 获取房间统计信息
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 房间统计信息列表
     */
    getRoomStats(from?: string, limit?: number): Promise<RoomStats[]>;
    getRoomStatsByRoom(roomId: string): Promise<RoomStats>;
    joinRoom(roomId: string, userId: string): Promise<void>;
    listReports(options?: {
        from?: string;
        limit?: number;
    }): Promise<AdminReportPage>;
    getReport(reportId: string): Promise<AdminReport>;
    deleteReport(reportId: string): Promise<void>;
    listRoomReports(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<AdminReportPage>;
    getRoomReport(roomId: string, reportId: string): Promise<AdminReport>;
    getSpace(spaceId: string): Promise<SpaceInfo>;
    listSpaces(from?: string, limit?: number): Promise<SpacePage>;
    deleteSpace(spaceId: string): Promise<void>;
    getSpaceRooms(spaceId: string, from?: string, limit?: number): Promise<{
        rooms: SpaceRoom[];
        next_batch?: string;
    }>;
    getSpaceStats(spaceId: string): Promise<SpaceStats>;
    getSpaceUsers(spaceId: string, from?: string, limit?: number): Promise<{
        users: SpaceUser[];
        next_batch?: string;
    }>;
}
//# sourceMappingURL=admin-room-manager.d.ts.map