import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import type { RoomInfo, RoomStateEvent, RoomMessagePage, RoomStats, RoomStatsOverview, AdminRoomMemberPage, SpaceInfo, SpacePage, SpaceRoomsResponse, SpaceUsersResponse, PaginatedResponse, AdminRoomVersionResponse, AdminRoomBlockStatus, AdminEventContext, AdminRoomForwardExtremities, AdminTokenSync, AdminRoomEventSearchPage, AdminRoomSearchPage, AdminRoomListings, AdminRoomRedactPayload, AdminRoomRedactResult, AdminReport, AdminReportPage, AdminPurgeHistoryResult, RoomSearchPayload, RoomDeletePayload, PurgeHistoryPayload, AdminReasonPayload, AdminBanKickPayload, AdminMakeRoomAdminPayload, RoomEventSearchPayload, SpaceStats } from "../types";
import type { MatrixClient } from "../../client";
export declare enum AdminRoomEvent {
    RoomDeleted = "RoomDeleted",
    RoomBlocked = "RoomBlocked"
}
export interface AdminRoomEventMap {
    [AdminRoomEvent.RoomDeleted]: (roomId: string) => void;
    [AdminRoomEvent.RoomBlocked]: (roomId: string, blocked: boolean) => void;
}
export declare class AdminRoomManager extends AdminBaseManager<AdminRoomEvent, AdminRoomEventMap> {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取房间列表（支持分页）
     *
    /**
     * 获取房间列表（统一分页格式）
     *
     * @param options - 查询选项
     * @param options.from - 分页起点 token
     * @param options.limit - 返回房间数量限制
     * @param options.search - 房间名称或别名搜索关键词
     * @param options.order_by - 排序字段 (e.g., "name", "joined_members")
     * @param options.sort_order - 排序顺序 ("asc" 或 "desc")
     * @returns 统一格式的分页响应
     */
    getRoomsPaginated(options?: {
        from?: string;
        limit?: number;
        search?: string;
        order_by?: string;
        sort_order?: "asc" | "desc";
    }): Promise<PaginatedResponse<RoomInfo>>;
    searchRooms(options?: Record<string, string | number | boolean | undefined>): Promise<AdminRoomSearchPage>;
    searchRoomsPost(payload: RoomSearchPayload): Promise<AdminRoomSearchPage>;
    /**
     * 获取房间详情
     *
     * @param roomId - 房间 ID
     * @returns 房间详情
     */
    getRoom(roomId: string, throwOnError?: boolean): Promise<RoomInfo | null>;
    /**
     * 删除房间（`DELETE /_synapse/admin/v1/rooms/{room_id}`）。
     *
     * ⚠️ 2026-10-08 对照后端 `admin/room/mod.rs::delete_room`：该处理器**只收 `Path(room_id)`，
     * 连 `Json` 提取器都没有** ⇒ 这里传的整个 body（`block` / `purge` / `force_purge` / `reason`）
     * 会被**静默丢弃**，`purge: true` **不会**清除历史。要真 purge 请另外调
     * {@link purgeRoomHistory}（`POST /rooms/{room_id}/purge_history`）。
     *
     * 注：`POST /_synapse/admin/v1/rooms/{room_id}/delete` 与 `DELETE` 是同**一个**处理器，
     * 所以 {@link deleteRoomAdmin} 的 body 同样无效。参数保留是为了不破坏公开 API
     * （删参数属产品决策，已登记在 `admin-response-contract-ledger.json` 的 deviations）。
     *
     * @param roomId - 房间 ID
     * @param blockOrOptions.block - 后端忽略
     * @param purge - 后端忽略（不会 purge）
     * @param reason - 后端忽略
     * @example
     * ```typescript
     * await adminManager.deleteRoom("!spam:example.com");
     * // 需要真正清除历史时：
     * await adminManager.purgeRoomHistory("!spam:example.com", { purge_up_to_ts: Date.now() });
     * ```
     */
    deleteRoom(roomId: string, blockOrOptions?: boolean | {
        block?: boolean;
        purge?: boolean;
        force_purge?: boolean;
        reason?: string;
    }, purge?: boolean, reason?: string): Promise<void>;
    /**
     * 删除房间（`payload` 被后端忽略）。
     *
     * ⚠️ 2026-10-09 修正：此前打 `POST /_synapse/admin/v1/rooms/{room_id}/delete`
     * （自称 "v1 兼容端点"），但后端 ledger 里**从来没有**这个路径 ⇒ 每次调用必然 404。
     * 后端注册的是 RESTful 的 `DELETE /_synapse/admin/v1/rooms/{room_id}`（与
     * {@link deleteRoom} 同一个处理器 `delete_room`，无 `Json` 提取器）
     * ⇒ `payload` 里的 `purge` / `force_purge` / `block` / `reason` 一律被忽略。
     *
     * @param roomId - 房间 ID
     * @param payload - 后端忽略（仅为不破坏公开 API 而保留）
     */
    deleteRoomAdmin(roomId: string, payload?: RoomDeletePayload): Promise<void>;
    purgeRoomHistory(roomId: string, payload?: PurgeHistoryPayload): Promise<AdminPurgeHistoryResult>;
    /**
     * 封锁/解封房间
     *
     * @param roomId - 房间 ID
     * @param block - 是否封锁房间
     * @param reason - 原因
     */
    blockRoom(roomId: string, block: boolean, reason?: string): Promise<void>;
    unblockRoom(roomId: string, payload?: AdminReasonPayload): Promise<void>;
    /**
     * 获取房间成员
     *
     * 对应 `GET /_synapse/admin/v1/rooms/{room_id}/members`。后端返回
     * `{members: [{user_id, displayname, avatar_url, membership}], total, next_batch}`。
     *
     * ⚠️ 此前声明/返回的是 `AdminAccountDetails[]`（账号对象的字段集），与真实成员条目完全不同；
     * 且 `total` / `next_batch` 被静默丢弃。
     *
     * @param roomId - 房间 ID
     * @param options - 可选分页参数
     * @example
     * ```typescript
     * const page = await adminManager.getRoomMembers("!room:example.org", { limit: 100 });
     * console.log(`${page.members.length}/${page.total}`, page.next_batch);
     * ```
     */
    getRoomMembers(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<AdminRoomMemberPage>;
    addRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    removeRoomMember(roomId: string, userId: string): Promise<void>;
    banRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    kickRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    unbanRoomMember(roomId: string, userId: string, payload?: AdminReasonPayload): Promise<void>;
    banRoom(roomId: string, payload: AdminBanKickPayload): Promise<void>;
    kickRoom(roomId: string, payload: AdminBanKickPayload): Promise<void>;
    makeRoomAdmin(roomId: string, payload: AdminMakeRoomAdminPayload): Promise<void>;
    /**
     * 获取房间状态事件
     *
     * @param roomId - 房间 ID
     * @returns 房间状态事件列表
     */
    getRoomState(roomId: string): Promise<{
        state: RoomStateEvent[];
    }>;
    /**
     * 获取房间消息
     *
     * 后端返回 `{chunk, start, end, next_batch}`；此前实现丢弃了 `next_batch`
     * （`null` 表示末页）。
     *
     * @param roomId - 房间 ID
     * @param optionsOrFrom.from - 分页起点（后端按 `from` 数字解析，解析失败即视为首页）
     * @param limit - 数量限制
     * @returns 消息列表 + 三个游标字段
     * @example
     * ```typescript
     * const page = await adminManager.getRoomMessages("!room:example.org", { limit: 50, dir: "b" });
     * console.log(page.chunk.length, page.next_batch);
     * ```
     */
    getRoomMessages(roomId: string, optionsOrFrom?: string | {
        from?: string;
        limit?: number;
        dir?: "b" | "f" | string;
    }, limit?: number): Promise<RoomMessagePage>;
    /**
     * 删除房间消息
     *
     * @param roomId - 房间 ID
     * @param eventId - 事件 ID
     * @param reason - 删除原因
     */
    deleteRoomMessage(roomId: string, eventId: string, reason?: string): Promise<void>;
    /**
     * 批量撤回房间内的事件（管理端，按时间范围过滤）。
     *
     * 对应后端 `POST /_matrix/client/v3/admin/room/{room_id}/redact`（模块 `admin::room`），
     * 语义与 Element Synapse 的同名管理端点一致：撤回 `origin_server_ts` 落在
     * `(after_ts, before_ts)` 区间内的事件，单次上限 `limit` 条。
     *
     * 与 {@link deleteRoomMessage} 的分工：后者按单个 `event_id` 精确删除，
     * 本方法按时间范围批量撤回。
     *
     * 注意：该端点的前缀是 **C-S v3** 命名空间下的 `admin/` 子路径，
     * 不是 `/_synapse/admin/v1`，所以必须显式传 `prefix`，不能走 `this.adminRequest`
     * （它把前缀写死为 `AdminPrefix.V1`）。
     *
     * @param roomId - 房间 ID
     * @param payload - 时间范围 / 条数 / 原因过滤条件，全部可选
     * @returns 实际被撤回的事件条数
     * @example
     * ```typescript
     * const { redacted } = await client
     *     .getAdminManager()
     *     .rooms.redactRoomEvents("!room:example.org", { before_ts: Date.now(), limit: 500 });
     * ```
     */
    redactRoomEvents(roomId: string, payload?: AdminRoomRedactPayload): Promise<AdminRoomRedactResult>;
    getRoomAliases(roomId: string): Promise<{
        aliases: string[];
    }>;
    getRoomVersion(roomId: string): Promise<AdminRoomVersionResponse>;
    getRoomBlockStatus(roomId: string): Promise<AdminRoomBlockStatus>;
    getRoomEventContext(roomId: string, eventId: string): Promise<AdminEventContext>;
    /**
     * 获取房间的前向极点数
     *
     * ⚠️ 对应 `GET /_synapse/admin/v1/rooms/{room_id}/forward_extremities`，
     * 后端返回 `{room_id, forward_extremities: <整数>}` —— **不是极点的对象数组**。
     * 原先声明成 `AdminForwardExtremity[]` 与真实响应毫无关系。
     * @example
     * ```typescript
     * const { forward_extremities } = await adminManager.getRoomForwardExtremities("!room:example.org");
     * console.log(`前向极点数: ${forward_extremities}`);
     * ```
     */
    getRoomForwardExtremities(roomId: string): Promise<AdminRoomForwardExtremities>;
    getRoomTokenSync(roomId: string): Promise<AdminTokenSync>;
    searchRoomEvents(roomId: string, payload: RoomEventSearchPayload): Promise<AdminRoomEventSearchPage>;
    getRoomListings(roomId: string): Promise<AdminRoomListings>;
    setRoomPublicListing(roomId: string): Promise<void>;
    deleteRoomPublicListing(roomId: string): Promise<void>;
    /**
     * 获取房间统计**总览**
     *
     * ⚠️ 对应 `GET /_synapse/admin/v1/room_stats`，后端返回的是**单个概览对象**
     * `{total_rooms, encrypted_rooms, public_rooms, total_messages, total_members,
     * active_rooms, average_messages_per_room}` —— **不是房间数组**，
     * 而且该端点**不读 `from` / `limit`**（参数仅为与旧签名兼容而保留）。
     * 原先实现按 `response.rooms` 取值，运行时恒得到空数组。
     *
     * @param from - 已废弃：后端不读该参数
     * @param limit - 已废弃：后端不读该参数
     * @returns 全局房间统计概览
     * @example
     * ```typescript
     * const overview = await adminManager.getRoomStats();
     * console.log(`房间总数 ${overview.total_rooms}，其中公开 ${overview.public_rooms}`);
     * ```
     */
    getRoomStats(from?: string, limit?: number): Promise<RoomStatsOverview>;
    /** 获取单个房间的统计信息（`GET /room_stats/{room_id}`） */
    getRoomStatsByRoom(roomId: string): Promise<RoomStats>;
    /**
     * 强制把用户加入房间
     *
     * ⚠️ 该路径（`POST /rooms/{room_id}/join`）在后端**不存在**，调用必得 404；
     * 对应的真实端点是 `PUT /rooms/{room_id}/members/{user_id}`
     * （见 {@link addRoomMember}）。此差异已登记在
     * `scripts/quality/path-contract-waivers.json`（`semantic-mismatch`），
     * 保留方法是为了不破坏既有调用方的编译，**新代码请用 `addRoomMember`**。
     * @example
     * ```typescript
     * // 注意：该路径后端未注册（见方法注释），请优先使用 addRoomMember
     * await adminManager.addRoomMember("!room:example.org", "@alice:example.org");
     * ```
     */
    joinRoom(roomId: string, userId: string): Promise<void>;
    /**
     * 列出事件举报
     *
     * 后端返回 `{reports, total}`；翻页游标是**请求侧**的 `since_ts` / `since_id`，
     * 响应里没有 `next_token`。⚠️ 本方法传的 `from` 后端**不读**（静默忽略）。
     * @example
     * ```typescript
     * const page = await adminManager.listReports({ limit: 50 });
     * console.log(`共 ${page.total} 条举报`);
     * ```
     */
    listReports(options?: {
        from?: string;
        limit?: number;
    }): Promise<AdminReportPage>;
    getReport(reportId: string): Promise<AdminReport>;
    deleteReport(reportId: string): Promise<void>;
    listRoomReports(roomId: string, options?: {
        from?: string;
        limit?: number;
    }): Promise<AdminReportPage>;
    getRoomReport(roomId: string, reportId: string): Promise<AdminReport>;
    getSpace(spaceId: string): Promise<SpaceInfo>;
    /**
     * 列出全部 Space
     *
     * 后端返回 `{spaces, total}` —— **没有分页游标**，`from` / `limit` 后端不读。
     * @example
     * ```typescript
     * const page = await adminManager.listSpaces();
     * console.log(page.spaces.map((s) => s.space_id));
     * ```
     */
    listSpaces(from?: string, limit?: number): Promise<SpacePage>;
    deleteSpace(spaceId: string): Promise<void>;
    /**
     * 列出 Space 的子房间
     *
     * ⚠️ 后端返回 `{rooms: string[], total}` —— `rooms` 是 **room id 字符串数组**，
     * 不是对象数组；也没有分页游标。
     * @example
     * ```typescript
     * const { rooms, total } = await adminManager.getSpaceRooms("!space:example.org");
     * console.log(total, rooms);
     * ```
     */
    getSpaceRooms(spaceId: string, from?: string, limit?: number): Promise<SpaceRoomsResponse>;
    getSpaceStats(spaceId: string): Promise<SpaceStats>;
    /**
     * 列出 Space 的成员
     *
     * ⚠️ 后端返回 `{users: string[], total}` —— `users` 是 **user id 字符串数组**，
     * 不是对象数组；也没有分页游标。
     * @example
     * ```typescript
     * const { users, total } = await adminManager.getSpaceUsers("!space:example.org");
     * console.log(total, users);
     * ```
     */
    getSpaceUsers(spaceId: string, from?: string, limit?: number): Promise<SpaceUsersResponse>;
}
//# sourceMappingURL=admin-room-manager.d.ts.map