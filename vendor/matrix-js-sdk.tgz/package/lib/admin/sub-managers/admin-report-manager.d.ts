import { AdminBaseManager, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { MatrixClient } from "../../client";
/**
 * 事件举报
 */
export interface EventReport {
    /** 举报 ID */
    id: number;
    /** 房间 ID */
    room_id: string;
    /** 事件 ID */
    event_id: string;
    /** 举报者用户 ID */
    user_id: string;
    /** 被举报用户 ID */
    reported_user_id: string | null;
    /** 举报原因 */
    reason: string | null;
    /** 事件内容描述 */
    content: string | null;
    /** 举报状态 */
    status: string;
    /** 评分（-100 ~ 100） */
    score: number | null;
    /** 接收时间戳（毫秒） */
    received_ts: number;
}
/**
 * 举报列表响应
 */
export interface ReportsListResponse {
    /** 举报列表 */
    reports: EventReport[];
    /** 总数 */
    total: number;
}
/**
 * 举报分页选项
 */
export interface ReportPaginationOptions {
    /** 每页限制 */
    limit?: number;
    /** 自从分数（用于游标分页） */
    since_score?: number;
    /** 自从时间戳 */
    since_ts?: number;
    /** 自从 ID */
    since_id?: number;
}
/**
 * Admin Report Manager
 *
 * 提供事件举报管理功能，包括列表、详情和删除。
 */
export declare class AdminReportManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * 获取所有举报列表
     *
     * @param options - 分页选项
     * @returns 举报列表
     *
     * @example
     * ```typescript
     * const result = await adminManager.reports.listAll({ limit: 50 });
     * console.log(result.reports.length, 'reports');
     * ```
     */
    listAll(options?: ReportPaginationOptions): Promise<ReportsListResponse>;
    /**
     * 获取单个举报详情
     *
     * @param reportId - 举报 ID
     * @returns 举报详情
     *
     * @example
     * ```typescript
     * const report = await client.getAdminManager().reports.get(42);
     * console.log(report.room_id, report.reason);
     * ```
     *
     * @throws NotFoundError 如果举报不存在
     */
    get(reportId: number): Promise<EventReport>;
    /**
     * 删除举报
     *
     * @param reportId - 举报 ID
     *
     * @example
     * ```typescript
     * await client.getAdminManager().reports.delete(42);
     * ```
     *
     * @throws NotFoundError 如果举报不存在
     */
    delete(reportId: number): Promise<void>;
    /**
     * 获取房间的举报列表
     *
     * @param roomId - 房间 ID
     * @param options - 分页选项
     * @returns 举报列表
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().reports.getByRoom("!room:example.org", { limit: 20 });
     * console.log(result.total, result.reports.length);
     * ```
     *
     * @throws NotFoundError 如果房间不存在
     */
    getByRoom(roomId: string, options?: ReportPaginationOptions): Promise<ReportsListResponse>;
    /**
     * 获取房间内的单个举报详情
     *
     * @param roomId - 房间 ID
     * @param reportId - 举报 ID
     * @returns 举报详情
     *
     * @example
     * ```typescript
     * const report = await client.getAdminManager().reports.getRoomReport("!room:example.org", 42);
     * console.log(report.event_id, report.status);
     * ```
     *
     * @throws NotFoundError 如果举报或房间不存在
     */
    getRoomReport(roomId: string, reportId: number): Promise<EventReport>;
    /**
     * 删除房间的举报
     *
     * @param roomId - 房间 ID
     * @param reportId - 举报 ID
     *
     * @example
     * ```typescript
     * await client.getAdminManager().reports.deleteRoomReport("!room:example.org", 42);
     * ```
     *
     * @throws NotFoundError 如果举报或房间不存在
     */
    deleteRoomReport(roomId: string, reportId: number): Promise<void>;
}
//# sourceMappingURL=admin-report-manager.d.ts.map