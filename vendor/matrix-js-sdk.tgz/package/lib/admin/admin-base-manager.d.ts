/**
 * Admin Base Manager - Admin 子 Manager 的公共基类
 *
 * 扩展 BaseManager，添加：
 * - v2Request：/_synapse/admin 前缀请求（无版本号）
 * - 错误回调：统一错误事件通知
 * - 路径辅助函数：ap/apu
 */
import { Method } from "../http-api/method";
import type { IContent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export type { ManagerOpts };
export type AdminErrorCallback = (error: Error) => void;
type StripAdminPath<P extends string> = P extends `/_synapse/admin${infer Rest}` ? Rest : never;
/**
 * 类型安全的 Admin 路径断言函数
 * 用于已知符合 AdminPathPattern 的路径字面量
 */
export declare function ap<P extends StripAdminPath<string>>(path: P): P;
/**
 * 无类型断言的 Admin 路径函数
 * 用于动态拼接的路径
 */
export declare function apu(path: string): string;
/**
 * Admin 子 Manager 的公共基类
 *
 * 提供 adminRequest（继承自 BaseManager）和 v2Request，
 * 以及统一的错误回调机制。
 */
export declare abstract class AdminBaseManager<Events extends string = string, EventMap extends Record<Events, any> = Record<Events, any>> extends BaseManager<Events, EventMap> {
    private readonly onError?;
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts);
    /**
     * Admin v1 请求（带错误回调和事件发射）
     *
     * 覆盖 BaseManager.adminRequest，添加错误回调通知。
     * 所有子 Manager 的 admin 请求都应通过此方法发送。
     */
    protected adminRequest<T>(method: Method, path: string, queryParams?: Record<string, string | string[]>, body?: object, label?: string): Promise<T>;
    /**
     * Admin v2 请求（/_synapse/admin 前缀，无版本号）
     *
     * 用于 v2 API 端点，如 GET /_synapse/admin/v2/users
     */
    protected v2Request<T>(method: Method, path: string, queryParams?: Record<string, string | string[]>, body?: IContent, label?: string): Promise<T>;
}
//# sourceMappingURL=admin-base-manager.d.ts.map