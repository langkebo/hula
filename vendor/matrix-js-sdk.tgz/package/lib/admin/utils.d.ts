/**
 * Utility functions for Admin API
 */
/**
 * Build pagination query parameters
 *
 * Re-exported from common utilities. Accepts (limit, from, to, dir) order.
 *
 * @param limit - Number of items to return
 * @param from - Pagination start token
 * @returns Query parameters object
 *
 * @example
 * ```typescript
 * const params = buildPaginationParams(50, "token123");
 * // { limit: "50", from: "token123" }
 * ```
 */
import { buildPaginationParams } from "../common/pagination";
export { buildPaginationParams };
/**
 * Build search query parameters
 *
 * @param searchTerm - Search term
 * @param from - Pagination start token
 * @param limit - Number of items to return
 * @returns Query parameters object
 *
 * @example
 * ```typescript
 * const params = buildSearchParams("alice", "token123", 50);
 * // { search_term: "alice", from: "token123", limit: "50" }
 * ```
 */
export declare function buildSearchParams(searchTerm?: string, from?: string, limit?: number): Record<string, string>;
/**
 * Check if query parameters object is empty
 *
 * @param params - Query parameters object
 * @returns True if empty, false otherwise
 */
export declare function hasQueryParams(params: Record<string, string>): boolean;
/**
 * Build query parameters object, returning undefined if empty
 *
 * @param params - Query parameters object
 * @returns Query parameters or undefined if empty
 */
export declare function buildQueryParams(params: Record<string, string>): Record<string, string> | undefined;
//# sourceMappingURL=utils.d.ts.map