import { validateUserId, validateRoomId, validateLimit } from "../common/validators";
export { validateUserId, validateRoomId, validateLimit };
/**
 * Admin-specific validators.
 *
 * Shared validators ({@link validateUserId}, {@link validateRoomId},
 * {@link validateLimit}) are re-exported from this module for convenience.
 * Non-admin code should import directly from `../common/validators`.
 */
export declare class AdminValidators {
    private static readonly ROOM_ID_REGEX;
    static validateUserId: typeof validateUserId;
    static validateRoomId: typeof validateRoomId;
    static validateLimit: typeof validateLimit;
    static validateSpaceId(spaceId: string): void;
    static validateServerName(serverName: string): void;
}
//# sourceMappingURL=validators.d.ts.map