/**
 * Admin types — barrel re-export
 *
 * All admin types are now organized by sub-manager domain:
 * - admin-user-types.ts: user management, accounts, sessions, tokens, pagination
 * - admin-room-types.ts: room management, events, spaces, reports
 * - admin-server-types.ts: server management, stats, notifications, media quota
 * - admin-federation-types.ts: federation management, destinations, cache
 * - admin-config-types.ts: configuration, retention, feature flags, modules, SAML
 */
export * from "./sub-managers/admin-user-types";
export * from "./sub-managers/admin-room-types";
export * from "./sub-managers/admin-server-types";
export * from "./sub-managers/admin-federation-types";
export * from "./sub-managers/admin-config-types";
//# sourceMappingURL=types.d.ts.map