import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { LRUCache } from "../utils/lru-cache";
import type { Room } from "../models/room";
import type { IContent } from "../models/event";
import { DMEvent, type DirectMessageManagerEventMap } from "./events";
import { DmRoomListManager } from "./sub-managers/dm-room-list-manager";
import { DmRoomCreationManager } from "./sub-managers/dm-room-creation-manager";
import { DmRoomOperationManager } from "./sub-managers/dm-room-operation-manager";
import type { DmRoomInfo, IDirectRoomsMap, DmPartnerResponse, DmRoomCheckResponse } from "./sub-managers/dm-room-list-types";
import type { CreateDmOptions, CreateDmRoomResponse, CreateDmRoomOptions, UpdateDirectRoomResponse, UpdateDirectRoomOptions } from "./sub-managers/dm-room-creation-types";
export { DMEvent } from "./events";
export type { DirectMessageManagerEventMap } from "./events";
export type { DmRoomInfo, IDirectRoomsMap, DirectRoomsResponse, DmRoomCheckResponse, DmPartnerResponse, } from "./sub-managers/dm-room-list-types";
export type { CreateDmOptions, CreateDmRoomResponse, CreateDmRoomOptions, UpdateDirectRoomResponse, UpdateDirectRoomOptions, } from "./sub-managers/dm-room-creation-types";
export { DmRoomListManager } from "./sub-managers/dm-room-list-manager";
export { DmRoomCreationManager } from "./sub-managers/dm-room-creation-manager";
export { DmRoomOperationManager } from "./sub-managers/dm-room-operation-manager";
/**
 * Direct Message Manager - 私信管理统一入口
 *
 * 通过组合模式将功能委托到 sub-managers，同时保持完全向后兼容。
 * 推荐新代码直接使用 sub-manager：`dmManager.creation.createDm(...)`。
 */
export declare class DirectMessageManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    readonly list: DmRoomListManager;
    readonly creation: DmRoomCreationManager;
    readonly operation: DmRoomOperationManager;
    private isInitialized;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /** 将所有 sub-manager 的 DMEvent 转发到顶层（共用 DMEvent enum，直接 re-emit）。 */
    private forwardSubManagerEvents;
    /** @deprecated 使用 `dmManager.list.dmRoomsCache` 替代 */
    get dmRoomsCache(): LRUCache<DmRoomInfo>;
    /** @deprecated 使用 `dmManager.list.userDmMapCache` 替代 */
    get userDmMapCache(): LRUCache<string>;
    private startPromise;
    /** 初始化 DM 管理器 */
    start(): Promise<void>;
    /** 停止 DM 管理器 */
    stop(): void;
    /** 获取缓存统计 */
    getCacheStats(): {
        dmRooms: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        userDmMap: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
    /** @deprecated 使用 `dmManager.creation.createDm()` 替代 */
    createDm(options: CreateDmOptions | string[]): Promise<string>;
    /** @deprecated 使用 `dmManager.creation.setDmRoom()` 替代 */
    setDmRoom(roomId: string, userId: string): Promise<void>;
    /** @deprecated 使用 `dmManager.creation.removeDmRoom()` 替代 */
    removeDmRoom(roomId: string, userId: string): Promise<void>;
    /** @deprecated 使用 `dmManager.creation.createDmRoomDetailed()` 替代 */
    createDmRoomDetailed(userId: string, options?: CreateDmRoomOptions): Promise<CreateDmRoomResponse>;
    /** @deprecated 使用 `dmManager.creation.createDmRoom()` 替代 */
    createDmRoom(userId: string, options?: CreateDmRoomOptions): Promise<string>;
    /** @deprecated 使用 `dmManager.creation.updateDirectRoom()` 替代 */
    updateDirectRoom(roomId: string, userIds: string[]): Promise<UpdateDirectRoomResponse>;
    /** @deprecated 使用 `dmManager.creation.updateDirectRoom()` 替代 */
    updateDirectRoom(roomId: string, options: UpdateDirectRoomOptions): Promise<UpdateDirectRoomResponse>;
    /** @deprecated 使用 `dmManager.list.getDMRooms()` 替代 */
    getDMRooms(): Promise<DmRoomInfo[]>;
    /** @deprecated 使用 `dmManager.list.getDirectRoomsByUserSync()` 替代 */
    getDirectRoomsByUserSync(): IDirectRoomsMap;
    /** @deprecated 使用 `dmManager.list.getDmForUser()` 替代 */
    getDmForUser(userId: string): Promise<string | null>;
    /** @deprecated 使用 `dmManager.list.getDirectRoomsByUser()` 替代 */
    getDirectRoomsByUser(): Promise<IDirectRoomsMap>;
    /** @deprecated 使用 `dmManager.list.getDmRoomInfo()` 替代 */
    getDmRoomInfo(roomId: string): Promise<DmRoomInfo | null>;
    /** @deprecated 使用 `dmManager.list.getCachedDmRooms()` 替代 */
    getCachedDmRooms(): DmRoomInfo[];
    /** @deprecated 使用 `dmManager.list.getCachedDmForUser()` 替代 */
    getCachedDmForUser(userId: string): string | null;
    /** @deprecated 使用 `dmManager.list.getDmRoomInfos()` 替代 */
    getDmRoomInfos(): Promise<DmRoomInfo[]>;
    /** @deprecated 使用 `dmManager.list.checkRoomIsDm()` 替代 */
    checkRoomIsDm(roomId: string): Promise<boolean>;
    /** @deprecated 使用 `dmManager.list.getDmPartner()` 替代 */
    getDmPartner(roomId: string): Promise<string | null>;
    /** @deprecated 使用 `dmManager.list.getDmRoomsByUserIds()` 替代 */
    getDmRoomsByUserIds(userIds: string[]): Promise<Room[]>;
    /** @deprecated 使用 `dmManager.list.getDmRoom()` 替代 */
    getDmRoom(roomId: string, throwOnError?: boolean): Promise<Room | null>;
    /** @deprecated 使用 `dmManager.list.getDirectRoomsFromServer()` 替代 */
    getDirectRoomsFromServer(): Promise<IDirectRoomsMap>;
    /** @deprecated 使用 `dmManager.list.isDmRoomFromServer()` 替代 */
    isDmRoomFromServer(roomId: string, throwOnError?: boolean): Promise<boolean>;
    /** @deprecated 使用 `dmManager.list.getDmPartnerFromServer()` 替代 */
    getDmPartnerFromServer(roomId: string, throwOnError?: boolean): Promise<DmPartnerResponse | null>;
    /** 获取房间 DM 原始信息（GET /_matrix/client/v3/rooms/{room_id}/dm）。 */
    getRoomDm(roomId: string): Promise<DmRoomCheckResponse>;
    /** 设置房间为 DM 关系（PUT /_matrix/client/v3/direct/{room_id}）。 */
    setDirect(roomId: string): Promise<void>;
    /** @deprecated 使用 `dmManager.operation.leaveDm()` 替代 */
    leaveDm(roomId: string): Promise<void>;
    /** @deprecated 使用 `dmManager.operation.markDmAsRead()` 替代 */
    markDmAsRead(roomId: string): Promise<void>;
    /** @deprecated 使用 `dmManager.operation.sendDmMessage()` 替代 */
    sendDmMessage(roomId: string, content: string | IContent): Promise<string>;
}
/**
 * 扩展 MatrixClient 原型
 */
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map