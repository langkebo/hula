import { MatrixClient } from "../../client";
import type { Room } from "../../models/room";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import { LRUCache } from "../../utils/lru-cache";
import { DMEvent, type DirectMessageManagerEventMap } from "../events";
import type { DmRoomInfo, IDirectRoomsMap, DmRoomCheckResponse, DmPartnerResponse } from "./dm-room-list-types";
export declare class DmRoomListManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    readonly dmRoomsCache: LRUCache<DmRoomInfo>;
    readonly userDmMapCache: LRUCache<string>;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取当前用户的所有 DM 房间
     *
     * ⚠️ 注意：m.direct 是用户级别的 account data，不是房间级别
     * 正确做法是读取 client.getAccountData(EventType.Direct)
     *
     * 优先使用 m.direct 映射获取 DM，如果映射为空或不完整，
     * 会回退到扫描所有房间来识别 DM 房间
     *
     * 后端实现: synapse-rust/src/web/routes/dm.rs:268-281
     *
     * @returns DM 房间信息列表
     */
    getDMRooms(): Promise<DmRoomInfo[]>;
    /**
     * 通过扫描房间来获取 DM 房间（回退机制）
     *
     * 当 m.direct 映射不可用时使用
     */
    private getDMRoomsFromRoomScan;
    /**
     * 构建 DM 房间信息
     *
     * @param room - 房间对象
     * @param dmPartner - DM 伙伴用户 ID（可选，如果不传则从 m.direct 推断）
     * @returns DM 房间信息
     */
    private buildDmRoomInfo;
    /**
     * 从 m.direct 获取 DM 伙伴用户 ID
     *
     * ⚠️ m.direct 是用户级别的 account data，格式为 { [userId]: [roomId, ...] }
     *
     * @param roomId - 房间 ID
     * @returns DM 伙伴用户 ID 或 null
     */
    private getDmPartnerFromDirect;
    /**
     * 同步获取 m.direct 映射（从缓存）
     *
     * ⚠️ 这是同步方法，直接从 account data 缓存读取
     * 如果缓存未更新，可能返回过时数据
     *
     * @returns m.direct 映射 { [userId]: [roomId, ...] }
     */
    getDirectRoomsByUserSync(): IDirectRoomsMap;
    /**
     * 获取用户的 DM 房间
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @returns DM 房间 ID 或 null
     *
     * @example
     * ```typescript
     * // 获取与用户的 DM 房间
     * const roomId = await dmManager.getDmForUser("@alice:example.com");
     * if (roomId) {
     *     console.log("DM room:", roomId);
     *     // 发送消息
     *     await dmManager.sendDmMessage(roomId, "Hello!");
     * } else {
     *     console.log("No DM room exists");
     *     // 创建新的 DM
     *     const newRoomId = await dmManager.createDm(["@alice:example.com"]);
     * }
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    getDmForUser(userId: string): Promise<string | null>;
    /**
     * 获取用户级别的 m.direct 映射
     *
     * ⚠️ m.direct 是用户级别的 account data，不是房间级别
     * 正确: client.getAccountData(EventType.Direct)
     *
     * @returns m.direct 映射 { [userId]: [roomId, ...] }
     */
    getDirectRoomsByUser(): Promise<IDirectRoomsMap>;
    /**
     * 获取 DM 房间信息
     *
     * @param roomId - 房间 ID
     * @returns DM 房间信息
     */
    getDmRoomInfo(roomId: string): Promise<DmRoomInfo | null>;
    /**
     * 获取缓存的 DM 房间列表
     */
    getCachedDmRooms(): DmRoomInfo[];
    /**
     * 获取缓存的用户 DM 房间 ID
     */
    getCachedDmForUser(userId: string): string | null;
    /**
     * 获取所有 DM 房间信息（使用缓存）
     */
    getDmRoomInfos(): Promise<DmRoomInfo[]>;
    /**
     * 检查房间是否为 DM
     *
     * ⚠️ 判断逻辑：
     * 1. 首先检查 m.direct 映射中是否包含此房间
     * 2. m.direct 是用户级别的 account data
     *
     * @param roomId - 房间 ID
     * @returns 是否为 DM 房间
     */
    checkRoomIsDm(roomId: string): Promise<boolean>;
    /**
     * 获取 DM 伙伴用户 ID
     *
     * ⚠️ 从 m.direct 映射中获取 DM 伙伴
     *
     * @param roomId - 房间 ID
     * @returns 伙伴用户 ID 或 null
     */
    getDmPartner(roomId: string): Promise<string | null>;
    /**
     * 根据用户 ID 列表获取 DM 房间
     *
     * @param userIds - 用户 ID 列表
     * @returns 匹配的 DM 房间列表
     */
    getDmRoomsByUserIds(userIds: string[]): Promise<Room[]>;
    /**
     * 获取 DM 房间对象
     *
     * @param roomId - 房间 ID
     * @returns Room 对象或 null
     */
    getDmRoom(roomId: string, throwOnError?: boolean): Promise<Room | null>;
    /**
     * 从服务器获取 m.direct 映射
     *
     * 后端实现: GET /_matrix/client/v3/direct
     *
     * @returns m.direct 映射 { [userId]: [roomId, ...] }
     */
    getDirectRoomsFromServer(): Promise<IDirectRoomsMap>;
    /**
     * 检查房间是否为 DM 房间（从服务器获取）
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时使用兼容 fallback）
     * @returns 是否为 DM 房间
     */
    /**
     * 获取房间 DM 原始信息（synapse-rust 私有端点）。
     * GET /_matrix/client/v3/rooms/{room_id}/dm
     *
     * 与 `isDmRoomFromServer` 区别：本方法返回后端原始 `DmRoomCheckResponse`，
     * 供调用方自行解析（如实提取伙伴、权限等）；`isDmRoomFromServer` 仅收敛为是否为 DM 的布尔。
     *
     * @param roomId - 房间 ID
     * @returns 后端原始 DM 检查响应
     */
    getRoomDm(roomId: string): Promise<DmRoomCheckResponse>;
    /**
     * 检查房间是否为 DM 房间（从服务器获取）。
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时使用兼容 fallback）
     * @returns 是否为 DM 房间
     */
    isDmRoomFromServer(roomId: string, throwOnError?: boolean): Promise<boolean>;
    /**
     * 获取 DM 伙伴（从服务器获取）
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时使用兼容 fallback）
     * @returns 伙伴信息
     */
    getDmPartnerFromServer(roomId: string, throwOnError?: boolean): Promise<DmPartnerResponse | null>;
    /**
     * 设置房间为 DM 关系（synapse-rust 私有端点）。
     * PUT /_matrix/client/v3/direct/{room_id}
     */
    setDirect(roomId: string): Promise<void>;
    /** 清空缓存（供顶层 DirectMessageManager.stop() 委托） */
    clearCache(): void;
    /** 返回缓存统计（供顶层 DirectMessageManager.getCacheStats() 委托） */
    getCacheStats(): {
        dmRooms: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        userDmMap: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
}
//# sourceMappingURL=dm-room-list-manager.d.ts.map