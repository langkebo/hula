import { MatrixClient } from "../../client";
import type { Room } from "../../models/room";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import { LRUCache } from "../../utils/lru-cache";
import { DMEvent, type DirectMessageManagerEventMap } from "../events";
import type { DmRoomInfo, IDirectRoomsMap, DmRoomCheckResponse, DmPartnerResponse } from "./dm-room-list-types";
export declare class DmRoomListManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    readonly dmRoomsCache: LRUCache<DmRoomInfo>;
    readonly userDmMapCache: LRUCache<string>;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取当前用户的所有 DM 房间
     *
     * ⚠️ 注意：m.direct 是用户级别的 account data，不是房间级别
     * 正确做法是读取 client.getAccountData(EventType.Direct)
     *
     * 优先使用 m.direct 映射获取 DM，如果映射为空或不完整，
     * 会回退到扫描所有房间来识别 DM 房间
     *
     * 后端实现: synapse-rust/src/web/routes/dm.rs:268-281
     *
     * @returns DM 房间信息列表
     * @throws {Error} 当 m.direct 读取或房间扫描失败时抛出
     * @example
     * const rooms = await client.getDirectMessageManager().list.getDMRooms();
     * console.log("DM 房间数量:", rooms.length);
     */
    getDMRooms(): Promise<DmRoomInfo[]>;
    /**
     * 通过扫描房间来获取 DM 房间（回退机制）
     *
     * 当 m.direct 映射不可用时使用
     */
    private getDMRoomsFromRoomScan;
    /**
     * 构建 DM 房间信息
     *
     * @param room - 房间对象
     * @param dmPartner - DM 伙伴用户 ID（可选，如果不传则从 m.direct 推断）
     * @returns DM 房间信息
     */
    private buildDmRoomInfo;
    /**
     * 从 m.direct 获取 DM 伙伴用户 ID
     *
     * ⚠️ m.direct 是用户级别的 account data，格式为 { [userId]: [roomId, ...] }
     *
     * @param roomId - 房间 ID
     * @returns DM 伙伴用户 ID 或 null
     */
    private getDmPartnerFromDirect;
    /**
     * 同步获取 m.direct 映射（从缓存）
     *
     * ⚠️ 这是同步方法，直接从 account data 缓存读取
     * 如果缓存未更新，可能返回过时数据
     *
     * @returns m.direct 映射 { [userId]: [roomId, ...] }
     * @throws {Error} 当账户数据读取失败时抛出
     * @example
     * const dmMap = client.getDirectMessageManager().list.getDirectRoomsByUserSync();
     * console.log("DM 用户:", Object.keys(dmMap));
     */
    getDirectRoomsByUserSync(): IDirectRoomsMap;
    /**
     * 获取用户的 DM 房间
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @returns DM 房间 ID 或 null
     *
     * @example
     * ```typescript
     * // 获取与用户的 DM 房间
     * const roomId = await dmManager.getDmForUser("@alice:example.com");
     * if (roomId) {
     *     console.log("DM room:", roomId);
     *     // 发送消息
     *     await dmManager.sendDmMessage(roomId, "Hello!");
     * } else {
     *     console.log("No DM room exists");
     *     // 创建新的 DM
     *     const newRoomId = await dmManager.createDm(["@alice:example.com"]);
     * }
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    getDmForUser(userId: string): Promise<string | null>;
    /**
     * 获取用户级别的 m.direct 映射
     *
     * ⚠️ m.direct 是用户级别的 account data，不是房间级别
     * 正确: client.getAccountData(EventType.Direct)
     *
     * @returns m.direct 映射 { [userId]: [roomId, ...] }
     * @throws {Error} 当 m.direct 账户数据读取失败时抛出
     * @example
     * const dmMap = await client.getDirectMessageManager().list.getDirectRoomsByUser();
     * console.log(dmMap["@alice:example.com"]);
     */
    getDirectRoomsByUser(): Promise<IDirectRoomsMap>;
    /**
     * 获取 DM 房间信息
     *
     * @param roomId - 房间 ID
     * @returns DM 房间信息
     * @throws {Error} 当 DM 房间信息构建失败时抛出
     * @example
     * const info = await client.getDirectMessageManager().list.getDmRoomInfo("!room:example.com");
     * if (info) console.log(info.lastMessage?.content);
     */
    getDmRoomInfo(roomId: string): Promise<DmRoomInfo | null>;
    /**
     * 获取缓存的 DM 房间列表。
     *
     * @example
     * const rooms = client.getDirectMessageManager().list.getCachedDmRooms();
     * console.log("缓存 DM 房间数量:", rooms.length);
     */
    getCachedDmRooms(): DmRoomInfo[];
    /**
     * 获取缓存的用户 DM 房间 ID。
     *
     * @example
     * const roomId = client.getDirectMessageManager().list.getCachedDmForUser("@alice:example.com");
     * if (roomId) console.log("缓存的 DM 房间:", roomId);
     */
    getCachedDmForUser(userId: string): string | null;
    /**
     * 获取所有 DM 房间信息（使用缓存）。
     *
     * @example
     * const infos = await client.getDirectMessageManager().list.getDmRoomInfos();
     * console.log(infos.map((info) => info.roomId));
     */
    getDmRoomInfos(): Promise<DmRoomInfo[]>;
    /**
     * 检查房间是否为 DM
     *
     * ⚠️ 判断逻辑：
     * 1. 首先检查 m.direct 映射中是否包含此房间
     * 2. m.direct 是用户级别的 account data
     *
     * @param roomId - 房间 ID
     * @returns 是否为 DM 房间
     * @example
     * const isDm = await client.getDirectMessageManager().list.checkRoomIsDm("!room:example.com");
     * console.log("是否为 DM:", isDm);
     */
    checkRoomIsDm(roomId: string): Promise<boolean>;
    /**
     * 获取 DM 伙伴用户 ID
     *
     * ⚠️ 从 m.direct 映射中获取 DM 伙伴
     *
     * @param roomId - 房间 ID
     * @returns 伙伴用户 ID 或 null
     * @example
     * const partner = await client.getDirectMessageManager().list.getDmPartner("!room:example.com");
     * if (partner) console.log("DM 伙伴:", partner);
     */
    getDmPartner(roomId: string): Promise<string | null>;
    /**
     * 根据用户 ID 列表获取 DM 房间
     *
     * @param userIds - 用户 ID 列表
     * @returns 匹配的 DM 房间列表
     * @throws {Error} 当 m.direct 读取失败时抛出
     * @example
     * const rooms = await client.getDirectMessageManager().list.getDmRoomsByUserIds([
     *     "@alice:example.com",
     *     "@bob:example.com",
     * ]);
     * console.log("匹配的 DM 房间数量:", rooms.length);
     */
    getDmRoomsByUserIds(userIds: string[]): Promise<Room[]>;
    /**
     * 获取 DM 房间对象
     *
     * @param roomId - 房间 ID
     * @returns Room 对象或 null
     * @throws {Error} 当 throwOnError 为 true 且房间不存在时抛出
     * @example
     * const room = await client.getDirectMessageManager().list.getDmRoom("!room:example.com");
     * if (room) console.log(room.name);
     */
    getDmRoom(roomId: string, throwOnError?: boolean): Promise<Room | null>;
    /**
     * 从服务器获取 m.direct 映射
     *
     * 后端实现: GET /_matrix/client/v3/direct
     *
     * @returns m.direct 映射 { [userId]: [roomId, ...] }
     * @throws {Error} 当服务器请求失败时抛出
     * @example
     * const dmMap = await client.getDirectMessageManager().list.getDirectRoomsFromServer();
     * console.log("服务器 m.direct 映射:", dmMap);
     */
    getDirectRoomsFromServer(): Promise<IDirectRoomsMap>;
    /**
     * 检查房间是否为 DM 房间（从服务器获取）
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时使用兼容 fallback）
     * @returns 是否为 DM 房间
     */
    /**
     * 获取房间 DM 原始信息（synapse-rust 私有端点）。
     * GET /_matrix/client/v3/rooms/{room_id}/dm
     *
     * 与 `isDmRoomFromServer` 区别：本方法返回后端原始 `DmRoomCheckResponse`，
     * 供调用方自行解析（如实提取伙伴、权限等）；`isDmRoomFromServer` 仅收敛为是否为 DM 的布尔。
     *
     * @param roomId - 房间 ID
     * @returns 后端原始 DM 检查响应
     * @throws {ValidationError} 当房间 ID 为空时抛出
     * @example
     * const check = await client.getDirectMessageManager().list.getRoomDm("!room:example.com");
     * console.log("是否 DM:", check["m.direct"]);
     */
    getRoomDm(roomId: string): Promise<DmRoomCheckResponse>;
    /**
     * 检查房间是否为 DM 房间（从服务器获取）。
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时使用兼容 fallback）
     * @returns 是否为 DM 房间
     * @throws {ValidationError} 当房间 ID 为空时抛出
     * @example
     * const isDm = await client.getDirectMessageManager().list.isDmRoomFromServer("!room:example.com");
     * console.log("服务器判定为 DM:", isDm);
     */
    isDmRoomFromServer(roomId: string, throwOnError?: boolean): Promise<boolean>;
    /**
     * 获取 DM 伙伴（从服务器获取）
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时使用兼容 fallback）
     * @returns 伙伴信息
     * @throws {ValidationError} 当房间 ID 为空时抛出
     * @example
     * const partner = await client.getDirectMessageManager().list.getDmPartnerFromServer("!room:example.com");
     * if (partner) console.log("伙伴信息:", partner);
     */
    getDmPartnerFromServer(roomId: string, throwOnError?: boolean): Promise<DmPartnerResponse | null>;
    /**
     * 设置房间为 DM 关系（synapse-rust 私有端点）。
     * PUT /_matrix/client/v3/direct/{room_id}
     *
     * @throws {ValidationError} 当房间 ID 为空时抛出
     * @example
     * await client.getDirectMessageManager().list.setDirect("!room:example.com");
     */
    setDirect(roomId: string): Promise<void>;
    /**
     * 清空缓存（供顶层 DirectMessageManager.stop() 委托）。
     *
     * @example
     * client.getDirectMessageManager().list.clearCache();
     */
    clearCache(): void;
    /**
     * 返回缓存统计（供顶层 DirectMessageManager.getCacheStats() 委托）。
     *
     * @example
     * const stats = client.getDirectMessageManager().list.getCacheStats();
     * console.log("DM 房间缓存命中率:", stats.dmRooms.hitRate);
     */
    getCacheStats(): {
        dmRooms: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
        userDmMap: {
            size: number;
            hits: number;
            misses: number;
            hitRate: number;
        };
    };
}
//# sourceMappingURL=dm-room-list-manager.d.ts.map