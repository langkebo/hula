/**
 * DmRoomOperationManager 类型定义
 *
 * operation sub-manager 特有类型。当前仅有 sendDmMessage 使用的 EventIdResponse。
 */
/**
 * `client.sendEvent()` 的响应类型（内部使用）。
 */
export interface EventIdResponse {
    event_id: string;
}
//# sourceMappingURL=dm-room-operation-types.d.ts.map