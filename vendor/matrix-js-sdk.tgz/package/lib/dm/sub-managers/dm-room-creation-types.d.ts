/**
 * DmRoomCreationManager 类型定义
 *
 * 创建 DM 房间、更新 m.direct 映射相关的请求/响应类型。
 */
import type { IContent } from "../../models/event";
import type { IDirectRoomsMap } from "./dm-room-list-types";
export interface CreateDmOptions {
    userIds: string[];
    invite?: boolean;
    name?: string;
    topic?: string;
    isEncrypted?: boolean;
}
export interface CreateDmRoomResponse {
    room_id: string;
}
export interface CreateDmRoomOptions {
    name?: string;
    topic?: string;
    invite?: string[];
    visibility?: "private" | "public";
}
export interface UpdateDirectRoomResponse {
    room_id: string;
    users: string[];
    direct_map: IDirectRoomsMap;
    updated_ts: number;
}
export interface UpdateDirectRoomOptions {
    userIds?: string[];
    content?: IContent;
}
/**
 * `client.createRoom()` 的响应类型（内部使用）。
 */
export interface ICreateRoomResponse {
    room_id: string;
}
//# sourceMappingURL=dm-room-creation-types.d.ts.map