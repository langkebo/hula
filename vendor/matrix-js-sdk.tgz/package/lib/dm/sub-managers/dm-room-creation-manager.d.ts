import { MatrixClient } from "../../client";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import { DMEvent, type DirectMessageManagerEventMap } from "../events";
import type { DmRoomListManager } from "./dm-room-list-manager";
import type { CreateDmOptions, CreateDmRoomResponse, CreateDmRoomOptions, UpdateDirectRoomResponse, UpdateDirectRoomOptions } from "./dm-room-creation-types";
export declare class DmRoomCreationManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    private readonly listManager;
    constructor(client: MatrixClient, listManager: DmRoomListManager, opts?: ManagerOpts);
    /**
     * 创建私信房间
     *
     * @param options - 创建选项或用户 ID 数组
     * @returns 新创建的 DM 房间 ID
     *
     * @example
     * ```typescript
     * // 简单创建（使用用户 ID 数组）
     * const roomId = await dmManager.createDm(["@alice:example.com"]);
     * console.log("Created DM room:", roomId);
     *
     * // 使用完整选项
     * const roomId = await dmManager.createDm({
     *     userIds: ["@alice:example.com"],
     *     name: "Chat with Alice",
     *     topic: "Private conversation",
     *     isEncrypted: true
     * });
     *
     * // 创建群聊 DM
     * const roomId = await dmManager.createDm({
     *     userIds: ["@alice:example.com", "@bob:example.com"],
     *     name: "Group Chat"
     * });
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {InvalidParamError} 如果未提供用户 ID
     * @throws {ApiError} 如果 API 调用失败
     *
     * 后端实现: synapse-rust/src/web/routes/dm.rs:204-266
     */
    createDm(options: CreateDmOptions | string[]): Promise<string>;
    /**
     * 设置 DM 房间（更新 m.direct）
     *
     * @param roomId - 房间 ID
     * @param userId - DM 伙伴用户 ID
     */
    setDmRoom(roomId: string, userId: string): Promise<void>;
    /**
     * 移除 DM 房间关联
     *
     * @param roomId - 房间 ID
     * @param userId - DM 伙伴用户 ID
     */
    removeDmRoom(roomId: string, userId: string): Promise<void>;
    /**
     * 创建 DM 房间 (专用 API 封装)
     *
     * 后端实现: POST /_matrix/client/v3/create_dm
     *
     * @param userId - 对端用户 ID
     * @param options - 可选配置
     * @returns 后端原始响应
     */
    createDmRoomDetailed(userId: string, options?: CreateDmRoomOptions): Promise<CreateDmRoomResponse>;
    /**
     * 创建 DM 房间 (专用 API 封装)
     *
     * 后端实现: POST /_matrix/client/v3/create_dm
     *
     * @param userId - 对端用户 ID
     * @param options - 可选配置
     * @returns 新创建的 DM 房间 ID
     */
    createDmRoom(userId: string, options?: CreateDmRoomOptions): Promise<string>;
    updateDirectRoom(roomId: string, userIds: string[]): Promise<UpdateDirectRoomResponse>;
    updateDirectRoom(roomId: string, options: UpdateDirectRoomOptions): Promise<UpdateDirectRoomResponse>;
}
//# sourceMappingURL=dm-room-creation-manager.d.ts.map