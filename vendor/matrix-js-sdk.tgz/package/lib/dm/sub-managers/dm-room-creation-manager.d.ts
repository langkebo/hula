import { MatrixClient } from "../../client";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import { DMEvent, type DirectMessageManagerEventMap } from "../events";
import type { DmRoomListManager } from "./dm-room-list-manager";
import type { CreateDmOptions, CreateDmRoomResponse, CreateDmRoomOptions, UpdateDirectRoomResponse, UpdateDirectRoomOptions } from "./dm-room-creation-types";
export declare class DmRoomCreationManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    private readonly listManager;
    constructor(client: MatrixClient, listManager: DmRoomListManager, opts?: ManagerOpts);
    /**
     * 创建私信房间
     *
     * @param options - 创建选项或用户 ID 数组
     * @returns 新创建的 DM 房间 ID
     *
     * @example
     * ```typescript
     * // 简单创建（使用用户 ID 数组）
     * const roomId = await dmManager.createDm(["@alice:example.com"]);
     * console.log("Created DM room:", roomId);
     *
     * // 使用完整选项
     * const roomId = await dmManager.createDm({
     *     userIds: ["@alice:example.com"],
     *     name: "Chat with Alice",
     *     topic: "Private conversation",
     *     isEncrypted: true
     * });
     *
     * // 创建群聊 DM
     * const roomId = await dmManager.createDm({
     *     userIds: ["@alice:example.com", "@bob:example.com"],
     *     name: "Group Chat"
     * });
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {InvalidParamError} 如果未提供用户 ID
     * @throws {ApiError} 如果 API 调用失败
     *
     * 后端实现: synapse-rust/src/web/routes/dm.rs:204-266
     */
    createDm(options: CreateDmOptions | string[]): Promise<string>;
    /**
     * 设置 DM 房间（更新 m.direct）
     *
     * @param roomId - 房间 ID
     * @param userId - DM 伙伴用户 ID
     * @throws {ValidationError} 当 roomId 或 userId 为空时抛出
     * @example
     * await client.getDirectMessageManager().creation.setDmRoom("!room:example.com", "@alice:example.com");
     */
    setDmRoom(roomId: string, userId: string): Promise<void>;
    /**
     * 移除 DM 房间关联
     *
     * @param roomId - 房间 ID
     * @param userId - DM 伙伴用户 ID
     * @throws {ValidationError} 当 roomId 或 userId 为空时抛出
     * @example
     * await client.getDirectMessageManager().creation.removeDmRoom("!room:example.com", "@alice:example.com");
     */
    removeDmRoom(roomId: string, userId: string): Promise<void>;
    /**
     * 创建 DM 房间 (专用 API 封装)
     *
     * 后端实现: POST /_matrix/client/v3/create_dm
     *
     * @param userId - 对端用户 ID
     * @param options - 可选配置
     * @returns 后端原始响应
     * @throws {ValidationError} 当 userId 为空或格式无效时抛出
     * @example
     * const response = await client.getDirectMessageManager().creation.createDmRoomDetailed(
     *     "@alice:example.com",
     *     { name: "Chat with Alice" },
     * );
     * console.log("新房间:", response.room_id);
     */
    createDmRoomDetailed(userId: string, options?: CreateDmRoomOptions): Promise<CreateDmRoomResponse>;
    /**
     * 创建 DM 房间 (专用 API 封装)
     *
     * 后端实现: POST /_matrix/client/v3/create_dm
     *
     * @param userId - 对端用户 ID
     * @param options - 可选配置
     * @returns 新创建的 DM 房间 ID
     * @throws {Error} 当创建 DM 房间失败时抛出
     * @example
     * const roomId = await client.getDirectMessageManager().creation.createDmRoom("@alice:example.com");
     * console.log("新 DM 房间:", roomId);
     */
    createDmRoom(userId: string, options?: CreateDmRoomOptions): Promise<string>;
    /**
     * 更新房间的 DM 关系（synapse-rust 私有端点）。
     * PUT /_matrix/client/v3/direct/{room_id}
     *
     * @param roomId - 房间 ID
     * @param userIds - DM 伙伴用户 ID 列表，或包含 userIds / content 的配置对象
     * @returns 后端更新的 DM 关系响应
     * @throws {ValidationError} 当 roomId 为空或用户 ID 格式无效时抛出
     * @example
     * const result = await client.getDirectMessageManager().creation.updateDirectRoom(
     *     "!room:example.com",
     *     ["@alice:example.com"],
     * );
     * console.log("更新结果:", result);
     */
    updateDirectRoom(roomId: string, userIds: string[]): Promise<UpdateDirectRoomResponse>;
    updateDirectRoom(roomId: string, options: UpdateDirectRoomOptions): Promise<UpdateDirectRoomResponse>;
}
//# sourceMappingURL=dm-room-creation-manager.d.ts.map