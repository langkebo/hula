import { MatrixClient } from "../../client";
import type { IContent } from "../../models/event";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import { DMEvent, type DirectMessageManagerEventMap } from "../events";
import type { DmRoomListManager } from "./dm-room-list-manager";
export declare class DmRoomOperationManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    private readonly listManager;
    constructor(client: MatrixClient, listManager: DmRoomListManager, opts?: ManagerOpts);
    /**
     * 离开 DM 房间
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     *
     * @example
     * ```typescript
     * // 离开 DM 房间
     * await dmManager.leaveDm("!abc:example.com");
     * console.log("Left DM room");
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    leaveDm(roomId: string): Promise<void>;
    /**
     * 标记 DM 为已读
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     *
     * @example
     * ```typescript
     * // 标记 DM 为已读
     * await dmManager.markDmAsRead("!abc:example.com");
     * console.log("DM marked as read");
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    markDmAsRead(roomId: string): Promise<void>;
    /**
     * 发送 DM 消息
     *
     * @param roomId - 房间 ID
     * @param content - 消息内容（字符串或对象）
     * @returns 发送的事件 ID
     */
    sendDmMessage(roomId: string, content: string | IContent): Promise<string>;
}
//# sourceMappingURL=dm-room-operation-manager.d.ts.map