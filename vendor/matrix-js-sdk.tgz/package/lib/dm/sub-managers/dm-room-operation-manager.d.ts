import { MatrixClient } from "../../client";
import type { IContent } from "../../models/event";
import { BaseManager, type ManagerOpts } from "../../managers/base-manager";
import { DMEvent, type DirectMessageManagerEventMap } from "../events";
import type { DmRoomListManager } from "./dm-room-list-manager";
export declare class DmRoomOperationManager extends BaseManager<DMEvent, DirectMessageManagerEventMap> {
    private readonly listManager;
    constructor(client: MatrixClient, listManager: DmRoomListManager, opts?: ManagerOpts);
    /**
     * 离开 DM 房间
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     *
     * @example
     * ```typescript
     * // 离开 DM 房间
     * await dmManager.leaveDm("!abc:example.com");
     * console.log("Left DM room");
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    leaveDm(roomId: string): Promise<void>;
    /**
     * 标记 DM 为已读
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     *
     * @example
     * ```typescript
     * // 标记 DM 为已读
     * await dmManager.markDmAsRead("!abc:example.com");
     * console.log("DM marked as read");
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    markDmAsRead(roomId: string): Promise<void>;
    /**
     * 发送 DM 消息
     *
     * 传字符串时会自动包装成 `{ msgtype: "m.text", body }`；传对象则原样发送（可用于图片、
     * 自定义事件类型等）。它等价于 `sendEvent(roomId, m.room.message, content)`，只是省掉了
     * 内容包装。
     *
     * @param roomId - 房间 ID（必须是 DM 房间；本方法不做 DM 归属校验）。
     * @param content - 字符串（文本）或完整的 `m.room.message` 内容对象。
     * @returns 发送的事件 ID。
     *
     * @example
     * ```typescript
     * // 纯文本
     * const eventId = await client.getDirectMessageManager().operation.sendDmMessage(roomId, "hi bob");
     *
     * // 自定义内容
     * await client.getDirectMessageManager().operation.sendDmMessage(roomId, {
     *     msgtype: "m.image",
     *     body: "diagram.png",
     *     url: contentUri,
     * });
     * ```
     *
     * @throws {InvalidParamError} 当 `roomId` 为空。
     * @throws {SdkError} 发送失败时抛出（无权限、房间不存在等）。
     */
    sendDmMessage(roomId: string, content: string | IContent): Promise<string>;
}
//# sourceMappingURL=dm-room-operation-manager.d.ts.map