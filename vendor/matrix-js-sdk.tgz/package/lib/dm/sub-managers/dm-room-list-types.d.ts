/**
 * DmRoomListManager 类型定义
 *
 * DM 房间查询、缓存、服务器查询相关的类型。list manager 持有 dmRoomsCache，
 * 因此 DmRoomInfo（缓存值类型）定义在此处，供 creation/operation sub-manager 引用。
 */
export interface DmRoomInfo {
    roomId: string;
    inviter?: string;
    invitees: string[];
    name?: string;
    avatarUrl?: string;
    lastMessage?: {
        content: string;
        timestamp: number;
        sender: string;
    };
    unreadCount?: number;
}
export interface IDirectRoomsMap {
    [userId: string]: string[];
}
export interface DirectRoomsResponse {
    rooms: IDirectRoomsMap;
}
export interface DmRoomCheckResponse {
    room_id: string;
    "m.direct": boolean;
}
export interface DmPartnerResponse {
    room_id: string;
    user_id: string;
    display_name: string;
    avatar_url: string;
}
/**
 * 「是否 DM」判定的来源（S-1）。
 *
 * - `m.direct`：用户 account data 里明确登记过 —— 与后端 `check_room_dm` 同源，
 *   可以据此做私密会话/标签等产品行为。
 * - `two-member-heuristic`：本地按「2 个 joined 成员」猜的。普通 1:1 群也会命中，
 *   后端并不认，**不能作为任何安全判断依据**，只可用于 UI 兜底。
 * - `none`：两个口径都不认为是 DM。
 */
export type DmClassificationSource = "m.direct" | "two-member-heuristic" | "none";
export interface DmClassificationOptions {
    /**
     * 是否允许「2 人房即 DM」启发式，默认 `false`。
     *
     * 历史默认是 `true`，会造成同一房间前端当私聊、后端当群（S-1）。
     * 需要兜底的 UI 显式开启，并检查 `classifyRoomAsDm` 返回的 `source`。
     */
    allowTwoMemberHeuristic?: boolean;
}
//# sourceMappingURL=dm-room-list-types.d.ts.map