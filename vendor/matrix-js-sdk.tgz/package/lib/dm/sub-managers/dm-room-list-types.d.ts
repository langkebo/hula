/**
 * DmRoomListManager 类型定义
 *
 * DM 房间查询、缓存、服务器查询相关的类型。list manager 持有 dmRoomsCache，
 * 因此 DmRoomInfo（缓存值类型）定义在此处，供 creation/operation sub-manager 引用。
 */
export interface DmRoomInfo {
    roomId: string;
    inviter?: string;
    invitees: string[];
    name?: string;
    avatarUrl?: string;
    lastMessage?: {
        content: string;
        timestamp: number;
        sender: string;
    };
    unreadCount?: number;
}
export interface IDirectRoomsMap {
    [userId: string]: string[];
}
export interface DirectRoomsResponse {
    rooms: IDirectRoomsMap;
}
export interface DmRoomCheckResponse {
    room_id: string;
    "m.direct": boolean;
}
export interface DmPartnerResponse {
    room_id: string;
    user_id: string;
    display_name: string;
    avatar_url: string;
}
//# sourceMappingURL=dm-room-list-types.d.ts.map