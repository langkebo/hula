/**
 * DirectMessage 事件定义
 *
 * 提取到独立文件以便 sub-managers 导入而不产生循环依赖。
 */
export declare enum DMEvent {
    DMCreated = "DMCreated",
    DMLeft = "DMLeft",
    DMUpdated = "DMUpdated",
    ListUpdated = "ListUpdated"
}
export interface DirectMessageManagerEventMap {
    [DMEvent.DMCreated]: (roomId: string, userIds: string[]) => void;
    [DMEvent.DMLeft]: (roomId: string) => void;
    [DMEvent.DMUpdated]: (roomId: string) => void;
    [DMEvent.ListUpdated]: () => void;
}
//# sourceMappingURL=events.d.ts.map