export declare const DM_ROUTES_ENTRY_COUNT: 8;
export declare const DM_ROUTES_STATUS_SCENARIOS: readonly [];
export type DmStatusScenario = (typeof DM_ROUTES_STATUS_SCENARIOS)[number];
export declare const DM_ROUTES_ERROR_SCENARIOS: readonly [];
export type DmErrorScenario = (typeof DM_ROUTES_ERROR_SCENARIOS)[number];
export declare const DM_ROUTES_ERRCODES: readonly [];
export type DmErrcode = (typeof DM_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map