export declare const DM_ROUTES_ENTRY_COUNT: 8;
export declare const DM_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "请求参数不合法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 404;
    readonly note: "房间不是私聊或找不到对端用户";
}];
export type DmStatusScenario = (typeof DM_ROUTES_STATUS_SCENARIOS)[number];
export declare const DM_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录或刷新凭据，不重试业务请求";
}, {
    readonly scenario: "目标资源不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "视为业务态失败，提示房间或用户不存在";
}, {
    readonly scenario: "参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正请求参数后重试";
}, {
    readonly scenario: "限流或短暂服务异常";
    readonly httpOrErrcode: "429 / M_LIMIT_EXCEEDED，5xx";
    readonly sdkErrorType: "RetryableError";
    readonly handling: "使用退避重试，保留幂等保护";
}, {
    readonly scenario: "其他 API 错误";
    readonly httpOrErrcode: "其他 4xx/5xx";
    readonly sdkErrorType: "ApiError";
    readonly handling: "按 code 与 statusCode 做兜底分支";
}];
export type DmErrorScenario = (typeof DM_ROUTES_ERROR_SCENARIOS)[number];
export declare const DM_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "私聊房间、对端用户或映射记录不存在";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "请求体结构不符合接口要求";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "参数类型或取值非法";
}, {
    readonly errcode: "M_LIMIT_EXCEEDED";
    readonly httpStatus: "429";
    readonly note: "触发限流，需延迟重试";
}];
export type DmErrcode = (typeof DM_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map