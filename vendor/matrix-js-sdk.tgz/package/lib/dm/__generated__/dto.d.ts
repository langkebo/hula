/**
 * DTO snippets extracted from the contract doc for `dm`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type DmContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map