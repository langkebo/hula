import { type SyncApiOptions } from "./sync";
import type { MatrixClient } from "./client";
import type { IStartClientOpts } from "./client-config-types";
export declare const TURN_CHECK_INTERVAL: number;
/**
 * Detect server capabilities and configure thread support.
 * Extracted from startClient to keep client.ts thin.
 */
export declare function detectServerCapabilities(client: MatrixClient): Promise<void>;
/**
 * Build sync API options for this client, suitable for passing into the SyncApi constructor.
 */
export declare function buildSyncApiOptions(client: MatrixClient): SyncApiOptions;
/**
 * Start all client lifecycle services (TURN polling, sync, well-known, queues).
 * Extracted from startClient to keep client.ts thin.
 */
export declare function startClientLifecycleServices(client: MatrixClient, opts: IStartClientOpts): Promise<void>;
//# sourceMappingURL=client-lifecycle-start.d.ts.map