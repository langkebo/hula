/**
 * Security Manager - 安全模块
 *
 * 提供账户安全相关功能，包括账户状态查询、登录失败记录等
 * 注意: 这些是客户端可用的安全功能，不涉及管理员操作
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface AccountStatus {
    locked: boolean;
    suspended: boolean;
    verified: boolean;
}
export interface LoginFailure {
    timestamp: number;
    ip: string;
    userAgent?: string;
}
export interface LoginFailuresResponse {
    failures: LoginFailure[];
}
export declare class SecurityManager extends BaseManager {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取用户账户状态
     * 对应 API: GET /_synapse/admin/v1/account_status/{user_id}
     */
    getAccountStatus(userId: string): Promise<AccountStatus | null>;
    /**
     * 检查账户是否被锁定
     */
    isAccountLocked(userId: string): Promise<boolean>;
    /**
     * 检查账户是否被暂停
     */
    isAccountSuspended(userId: string): Promise<boolean>;
    /**
     * 获取登录失败记录
     * 对应 API: GET /_synapse/admin/v1/login/failures
     */
    listLoginFailures(): Promise<LoginFailure[]>;
    /**
     * 检查当前客户端会话是否安全
     */
    checkSessionSecurity(): Promise<{
        isSecure: boolean;
        issues: string[];
    }>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map