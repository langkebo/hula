/**
 * DTO snippets extracted from the contract doc for `presence`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type PresenceContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map