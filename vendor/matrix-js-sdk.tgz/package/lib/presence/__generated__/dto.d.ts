/**
 * DTO snippets extracted from the contract doc for `presence`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type PresenceState = "online" | "offline" | "unavailable" | "away" | "busy";
export interface PresenceUserState {
    presence: PresenceState;
    status_msg?: string;
    last_active_ago?: number;
    currently_active?: boolean;
}
export interface PresenceUser {
    user_id: string;
    presence: PresenceState;
    status_msg?: string;
    last_active_ago?: number;
    currently_active?: boolean;
}
export interface SetPresenceRequest {
    presence: PresenceState;
    status_msg?: string;
}
export type GetPresenceResponse = PresenceUserState;
export interface PresenceListResponse {
    presences: PresenceUser[];
}
export interface SubscribePresenceRequest {
    subscribe: string[];
}
export interface UnsubscribePresenceRequest {
    unsubscribe: string[];
}
//# sourceMappingURL=dto.d.ts.map