export declare const PRESENCE_ROUTES_ENTRY_COUNT: 11;
export declare const PRESENCE_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "presence 状态值不合法或消息过长";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "尝试读取/修改其他用户状态，或读取他人订阅表";
}, {
    readonly status: 404;
    readonly note: "GET /presence/{user_id}/status 的目标用户不存在";
}];
export type PresenceStatusScenario = (typeof PRESENCE_ROUTES_STATUS_SCENARIOS)[number];
export declare const PRESENCE_ROUTES_ERROR_SCENARIOS: readonly [];
export type PresenceErrorScenario = (typeof PRESENCE_ROUTES_ERROR_SCENARIOS)[number];
export declare const PRESENCE_ROUTES_ERRCODES: readonly [];
export type PresenceErrcode = (typeof PRESENCE_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map