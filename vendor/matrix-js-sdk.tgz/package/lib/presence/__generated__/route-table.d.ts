/** Routes served by the synapse-rust `presence` module (mirrored from the backend contract). */
export declare const PRESENCE_ROUTES: readonly [{
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/presence/{user_id}/status";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/presence/{user_id}/status";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v1/presence/{user_id}/status";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/presence/list";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/presence/list/{user_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/presence/{user_id}/status";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/presence/{user_id}/status";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/presence/{user_id}/status";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/presence/list";
}];
/** Union of every (method, path) tuple in `PRESENCE_ROUTES`. */
export type PresenceRoute = (typeof PRESENCE_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type PresenceMethod = PresenceRoute["method"];
/** Path templates referenced by this module. */
export type PresencePath = PresenceRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type PresenceReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${PresenceReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type PresencePathPattern = PresenceReplaceBraces<PresencePath>;
//# sourceMappingURL=route-table.d.ts.map