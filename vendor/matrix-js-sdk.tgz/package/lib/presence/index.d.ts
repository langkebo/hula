/**
 * Presence Manager - 在线状态管理
 *
 * 提供用户在线状态的设置、查询、订阅功能
 * 对应后端: synapse-rust/src/web/routes/presence.rs
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export declare enum PresenceEvent {
    PresenceUpdated = "PresenceUpdated",
    PresenceListUpdated = "PresenceListUpdated",
    PresenceError = "PresenceError"
}
export type PresenceState = "online" | "offline" | "unavailable" | "away" | "busy";
export interface IPresenceState {
    presence: PresenceState;
    status_msg?: string;
    last_active_ago?: number;
    currently_active?: boolean;
}
export interface IPresenceEvent {
    user_id: string;
    presence: PresenceState;
    status_msg?: string;
    last_active_ago?: number;
    currently_active?: boolean;
}
export interface IPresenceList {
    presences: IPresenceEvent[];
}
interface PresenceManagerEventMap {
    [PresenceEvent.PresenceUpdated]: (userId: string, presence: IPresenceState) => void;
    [PresenceEvent.PresenceListUpdated]: (presences: IPresenceEvent[]) => void;
    [PresenceEvent.PresenceError]: (error: Error) => void;
}
export declare class PresenceManager extends BaseManager<PresenceEvent, PresenceManagerEventMap> {
    private presenceCache;
    private subscribedUsers;
    private initialized;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getPresences(userIds: string[]): Promise<Map<string, IPresenceState>>;
    /**
     * 设置当前用户的在线状态
     *
     * @param state - 在线状态（online, offline, unavailable, busy）
     * @param statusMsg - 状态消息（可选）
     *
     * @example
     * ```typescript
     * // 设置为在线
     * await presenceManager.setPresence("online");
     *
     * // 设置为忙碌并添加状态消息
     * await presenceManager.setPresence("busy", "In a meeting");
     *
     * // 设置为离线
     * await presenceManager.setPresence("offline");
     *
     * // 监听在线状态更新
     * presenceManager.on(PresenceEvent.PresenceUpdated, (userId, presence) => {
     *     console.log(`${userId} is now ${presence.presence}`);
     * });
     * ```
     *
     * @throws {ValidationError} 如果状态值无效
     * @throws {AuthError} 如果用户未登录
     * @throws {ApiError} 如果 API 调用失败
     */
    setPresence(state: PresenceState, statusMsg?: string): Promise<void>;
    /**
     * POST variant of setPresence.
     * Convenience method that uses POST instead of PUT for the same endpoint.
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @param state - 在线状态（online, offline, unavailable, away, busy）
     * @param statusMsg - 状态消息（可选）
     */
    postPresence(userId: string, state: PresenceState, statusMsg?: string): Promise<void>;
    /**
     * 获取用户在线状态
     *
     * @param userId - 用户 ID（格式：@localpart:homeserver）
     * @param forceFetch - 是否强制从服务器获取（默认 false，使用缓存）
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 用户在线状态，如果不存在或出错则返回 null
     *
     * @example
     * ```typescript
     * // 获取用户在线状态
     * const presence = await presenceManager.getPresence("@alice:example.com");
     * if (presence) {
     *     console.log("Status:", presence.presence);
     *     console.log("Message:", presence.status_msg);
     *     console.log("Last active:", presence.last_active_ago, "ms ago");
     * }
     *
     * // 强制刷新（不使用缓存）
     * const freshPresence = await presenceManager.getPresence("@alice:example.com", true);
     *
     * // 不抛出错误
     * const presence = await presenceManager.getPresence("@bob:example.com", false, false);
     * if (!presence) {
     *     console.log("User not found or offline");
     * }
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {NotFoundError} 如果用户不存在且 throwOnError 为 true
     * @throws {ApiError} 如果 API 调用失败
     */
    getPresence(userId: string, forceFetch?: boolean, throwOnError?: boolean): Promise<IPresenceState | null>;
    /**
     * 订阅用户在线状态
     *
     * @param userIds - 用户 ID 列表
     *
     * @example
     * ```typescript
     * // 订阅多个用户的在线状态
     * await presenceManager.subscribe([
     *     "@alice:example.com",
     *     "@bob:example.com"
     * ]);
     *
     * // 监听在线状态变化
     * presenceManager.on(PresenceEvent.PresenceChanged, (userId, state) => {
     *     console.log(`${userId} is now ${state.presence}`);
     * });
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 列表为空或格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    subscribe(userIds: string[]): Promise<void>;
    /**
     * 取消订阅用户在线状态
     *
     * @param userIds - 用户 ID 列表
     *
     * @example
     * ```typescript
     * // 取消订阅用户的在线状态
     * await presenceManager.unsubscribe([
     *     "@alice:example.com",
     *     "@bob:example.com"
     * ]);
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 列表为空或格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    unsubscribe(userIds: string[]): Promise<void>;
    /**
     * 获取在线状态列表
     *
     * @param targetUserId - 目标用户 ID（可选）
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 在线状态列表
     *
     * @example
     * ```typescript
     * // 获取所有订阅的用户在线状态
     * const presences = await presenceManager.getPresenceList();
     * presences.forEach(p => {
     *     console.log(`${p.user_id}: ${p.presence}`);
     * });
     *
     * // 获取特定用户的在线状态列表
     * const presences = await presenceManager.getPresenceList("@alice:example.com");
     *
     * // 监听在线状态列表更新
     * presenceManager.on(PresenceEvent.PresenceListUpdated, (presences) => {
     *     console.log(`Received ${presences.length} presence updates`);
     * });
     * ```
     *
     * @throws {ValidationError} 如果用户 ID 格式无效
     * @throws {ApiError} 如果 API 调用失败
     */
    getPresenceList(targetUserId?: string, throwOnError?: boolean): Promise<IPresenceEvent[]>;
    /**
     * 根据用户 ID 列表获取在线状态
     *
     * @param userIds - 用户 ID 列表
     * @param throwOnError - 是否抛出错误（默认 true，传 false 时保留兼容 fallback）
     * @returns 在线状态列表
     */
    getPresenceListByIds(userIds: string[], throwOnError?: boolean): Promise<IPresenceEvent[]>;
    getSubscribedUsers(): string[];
    isSubscribed(userId: string): boolean;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
    clearCache(): void;
    getCachedPresence(userId: string): IPresenceState | null;
    getCachedPresences(): Map<string, IPresenceState>;
    subscribeToPresence(userIds: string[]): Promise<void>;
    /**
     * Update the presence list by subscribing and/or unsubscribing users in a single request.
     * Returns the current presence states of subscribed users.
     *
     * @param subscribe - User IDs to subscribe to (optional)
     * @param unsubscribe - User IDs to unsubscribe from (optional)
     * @returns The presence list response with current presence states
     *
     * @throws {InvalidParamError} If both subscribe and unsubscribe are empty/missing
     * @throws {ApiError} If the API call fails
     */
    updatePresenceList(subscribe?: string[], unsubscribe?: string[]): Promise<IPresenceList>;
    unsubscribeFromPresence(userIds: string[]): Promise<void>;
    getSubscribedPresence(): Promise<IPresenceEvent[]>;
    /**
     * 清除状态消息
     *
     * @example
     * ```typescript
     * // 清除状态消息，保持当前在线状态
     * await presenceManager.clearStatusMessage();
     * ```
     */
    clearStatusMessage(): Promise<void>;
    /**
     * 设置为在线状态
     *
     * @param status - 状态消息（可选）
     *
     * @example
     * ```typescript
     * // 设置为在线
     * await presenceManager.setOnline();
     *
     * // 设置为在线并附带状态消息
     * await presenceManager.setOnline("Working on project");
     * ```
     */
    setOnline(status?: string): Promise<void>;
    /**
     * 设置为离线状态
     *
     * @param status - 状态消息（可选）
     *
     * @example
     * ```typescript
     * // 设置为离线
     * await presenceManager.setOffline();
     *
     * // 设置为离线并附带状态消息
     * await presenceManager.setOffline("Away from keyboard");
     * ```
     */
    setOffline(status?: string): Promise<void>;
    /**
     * 设置为忙碌状态
     *
     * @param status - 状态消息（可选）
     *
     * @example
     * ```typescript
     * // 设置为忙碌
     * await presenceManager.setUnavailable();
     *
     * // 设置为忙碌并附带状态消息
     * await presenceManager.setUnavailable("In a meeting");
     * ```
     */
    setUnavailable(status?: string): Promise<void>;
    setBusy(status?: string): Promise<void>;
    updatePresenceFromSync(event: IPresenceEvent): void;
    start(): Promise<void>;
    stop(): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map