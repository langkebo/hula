/**
 * Directory Manager - 目录管理
 *
 * 提供公共房间列表、房间目录等功能
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IPublicRoom {
    room_id: string;
    name?: string;
    topic?: string;
    avatar_url?: string;
    aliases?: string[];
    canonical_alias?: string;
    joined_members?: number;
    joined_local_members?: number;
    num_joined_members: number;
    world_readable: boolean;
    guest_can_join: boolean;
}
export interface IPublicRoomsResponse {
    chunk: IPublicRoom[];
    next_batch?: string;
    prev_batch?: string;
    total_room_count_estimate?: number;
}
export interface IRoomAliasResponse {
    room_id: string;
    servers: string[];
}
export interface IRoomAliasesResponse {
    aliases: string[];
}
export interface DirectoryManagerEvents {
    public_rooms_updated: {
        rooms: IPublicRoom[];
    };
    alias_created: {
        alias: string;
        roomId: string;
    };
    alias_deleted: {
        alias: string;
    };
}
export declare class DirectoryManager extends BaseManager<keyof DirectoryManagerEvents, DirectoryManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getPublicRoomsList(opts?: {
        server?: string;
        limit?: number;
        since?: string;
    }): Promise<IPublicRoomsResponse>;
    getPublicRooms(server: string, limit?: number, since?: string): Promise<IPublicRoomsResponse>;
    getRoomIdForAlias(alias: string): Promise<IRoomAliasResponse>;
    createRoomAlias(roomId: string, alias: string): Promise<void>;
    deleteRoomAlias(alias: string): Promise<void>;
    getAliasesForRoom(roomId: string): Promise<string[]>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map