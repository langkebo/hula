/**
 * 只在 `startClient()` 生效的选项键。
 *
 * 依据 `IStartClientOpts`（`client-config-types.ts`）；新增 startClient 选项时**必须**同步这里，
 * 否则守卫会漏报。`spec/unit/client-option-guards.spec.ts` 会做键集对比，漏了会红。
 */
export declare const START_CLIENT_ONLY_KEYS: readonly ["initialSyncLimit", "includeArchivedRooms", "resolveInvitesToProfiles", "pendingEventOrdering", "pollTimeout", "filter", "disablePresence", "lazyLoadMembers", "clientWellKnownPollPeriod", "threadSupport", "slidingSync", "pendingEventNotSentTimeoutMs"];
/**
 * 找出被误传给 `createClient()` 的 startClient 选项。
 *
 * 只报告**值不是 `undefined`** 的键：`{ pollTimeout: undefined }` 这种"占位"不该吵人。
 *
 * @param opts - 传给 `createClient()` 的选项对象（任意形状，函数内部按需收窄）
 * @returns 误传的键名（保持 `START_CLIENT_ONLY_KEYS` 的顺序）；没有则返回空数组
 *
 * @example
 * ```typescript
 * findMisplacedSyncOptions({ baseUrl: "https://x", pollTimeout: 3000 });
 * // => ["pollTimeout"]
 * ```
 */
export declare function findMisplacedSyncOptions(opts: unknown): string[];
/**
 * 生成给调用方看的提示文案（纯函数，便于单测断言，不用抓日志）。
 *
 * @param keys - `findMisplacedSyncOptions()` 的结果
 * @returns 一行提示；`keys` 为空时返回 `null`（调用方据此跳过日志）
 */
export declare function buildMisplacedSyncOptionsWarning(keys: readonly string[]): string | null;
//# sourceMappingURL=client-option-guards.d.ts.map