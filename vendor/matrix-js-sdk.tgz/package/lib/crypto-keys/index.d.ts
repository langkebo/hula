/**
 * Crypto Keys Manager - 加密密钥管理
 *
 * 提供密钥上传、下载、认领等功能
 * 对应后端: synapse-rust/src/web/routes/e2ee_routes.rs
 *
 * 后端端点:
 * - POST /keys/upload
 * - POST /keys/query
 * - POST /keys/claim
 * - GET /keys/changes
 * - POST /keys/device_list/update
 * - POST /keys/signatures/upload
 * - POST /keys/device_signing/upload
 * - GET /rooms/{room_id}/keys/distribution
 */
import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { KeySignatures, IUploadKeySignaturesResponse, IDownloadKeyResult, IClaimOTKsResult } from "../client-api-types";
export interface IDeviceKeys {
    user_id: string;
    device_id: string;
    algorithms: string[];
    keys: Record<string, string>;
    signatures?: Record<string, Record<string, string>>;
    unsigned?: {
        device_display_name: string;
        [key: string]: unknown;
    };
}
export interface IOneTimeKey {
    key: string;
    signatures?: Record<string, Record<string, string>>;
}
export interface IKeysUploadRequest {
    device_keys?: IDeviceKeys;
    one_time_keys?: Record<string, IOneTimeKey | string>;
    "org.matrix.msc2732.fallback_keys"?: Record<string, IOneTimeKey | string>;
}
export interface IKeysUploadResponse {
    one_time_key_counts: Record<string, number>;
}
export interface IKeysQueryRequest {
    device_keys: Record<string, string[]>;
    timeout?: number;
    token?: string;
}
export interface IKeysClaimRequest {
    one_time_keys: Record<string, Record<string, string>>;
    timeout?: number;
}
export interface IKeysChangesResponse {
    changed: string[];
    left: string[];
}
export interface IDeviceSigningUploadRequest {
    master_key?: IDeviceKeys;
    self_signing_key?: IDeviceKeys;
}
export interface IRoomKeyDistributionResponse {
    room_id: string;
    algorithm: string;
    session_id: string;
    session_key: string;
}
export declare class CryptoKeysManager extends BaseManager {
    private deviceKeysCache;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    uploadKeys(content: IKeysUploadRequest): Promise<IKeysUploadResponse>;
    queryKeys(userIds: string[], opts?: {
        token?: string;
        timeout?: number;
    }): Promise<IDownloadKeyResult>;
    claimKeys(devices: [string, string][], keyAlgorithm?: string, timeout?: number): Promise<IClaimOTKsResult>;
    getKeysChanges(from: string, to: string): Promise<IKeysChangesResponse>;
    updateDeviceList(): Promise<void>;
    uploadKeySignatures(signatures: KeySignatures): Promise<IUploadKeySignaturesResponse>;
    uploadDeviceSigning(masterKey?: IDeviceKeys, selfSigningKey?: IDeviceKeys): Promise<void>;
    /**
     * 获取房间密钥分发信息
     *
     * @param roomId - 房间 ID
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 分发信息
     */
    getRoomKeyDistribution(roomId: string, throwOnError?: boolean): Promise<IRoomKeyDistributionResponse | null>;
    getDeviceKeysFromCache(userId: string, deviceId: string): IDeviceKeys | undefined;
    clearCache(): void;
    getCacheStats(): {
        size: number;
        hits: number;
        misses: number;
        hitRate: number;
    };
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map