/**
 * The npm package name, including scope. Kept in sync with `package.json`.
 */
export declare const SDK_NAME = "@langkebo/matrix-js-sdk";
/**
 * The version of this SDK build.
 *
 * @returns The version from `package.json` for built artifacts, or
 * `0.0.0-dev+uninjected` when the source is consumed without the Babel
 * injection step.
 *
 * @example
 * ```ts
 * logger.info(`${SDK_NAME} ${getSdkVersion()}`);
 * // "@langkebo/matrix-js-sdk 40.2.0-langkebo.1"
 * ```
 */
export declare function getSdkVersion(): string;
/**
 * Whether the reported version comes from a real build.
 *
 * Useful for tests and diagnostics that must not silently pass on the
 * fallback value.
 */
export declare function isReleaseBuild(): boolean;
/**
 * A `name/version` token suitable for a User-Agent string.
 *
 * **The SDK cannot set the `User-Agent` request header for you.** The Fetch
 * spec lists `User-Agent` as a
 * [forbidden header name](https://fetch.spec.whatwg.org/#forbidden-header-name),
 * so browsers and webviews — including the WKWebView / WebView2 that Tauri
 * renders with — silently discard any attempt to set it from JavaScript.
 *
 * The host application must therefore write this token into the *native*
 * User-Agent instead. On Tauri v2 that is the `userAgent` field of the window
 * config, which maps to `WKWebView.customUserAgent` on macOS and
 * `ICoreWebView2Settings2::put_UserAgent` on Windows.
 *
 * @example
 * ```ts
 * // src-tauri/tauri.conf.json
 * { "app": { "windows": [{ "userAgent": "Tjg/1.0 @langkebo/matrix-js-sdk/40.2.0-langkebo.1" }] } }
 * ```
 *
 * @returns A token of the form `@langkebo/matrix-js-sdk/<version>`.
 */
export declare function getUserAgentToken(): string;
/**
 * Append the SDK's User-Agent token to an existing User-Agent string.
 *
 * Pass the User-Agent your host application already uses so the result keeps
 * the platform/browser tokens that servers and proxies expect, with the SDK
 * identity appended as a trailing product token.
 *
 * @param base - Existing User-Agent, or omitted to get the token alone.
 * @returns `base` followed by the SDK token, space-separated; or just the token
 * when `base` is empty or omitted.
 *
 * @example
 * ```ts
 * buildUserAgent("Tjg/1.0 (Macintosh; Intel Mac OS X 10_15_7)");
 * // "Tjg/1.0 (Macintosh; Intel Mac OS X 10_15_7) @langkebo/matrix-js-sdk/40.2.0-langkebo.1"
 *
 * buildUserAgent();
 * // "@langkebo/matrix-js-sdk/40.2.0-langkebo.1"
 * ```
 */
export declare function buildUserAgent(base?: string): string;
/**
 * Warn once when the runtime User-Agent does not advertise this fork (S-9).
 *
 * `getUserAgentToken()` and `buildUserAgent()` are exported for hosts, but
 * nothing forced anyone to call them — a host that forgot to configure its
 * native User-Agent produced no signal at all, and server access logs could not
 * distinguish this fork from upstream. This turns that silent gap into a single
 * actionable warning at client start-up.
 *
 * Deliberately a no-op outside a browser-like environment: the User-Agent can
 * only be set by the host at the native layer, so checking under Node (tests,
 * SSR, CLI tooling) would only produce noise.
 *
 * @example
 * ```ts
 * // Called from createClient(); hosts need not call it themselves.
 * warnIfUserAgentDoesNotAdvertiseFork();
 * ```
 */
export declare function warnIfUserAgentDoesNotAdvertiseFork(): void;
/**
 * Test-only escape hatch: re-arm {@link warnIfUserAgentDoesNotAdvertiseFork}.
 */
export declare function resetUserAgentCheckForTests(): void;
//# sourceMappingURL=version.d.ts.map