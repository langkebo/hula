/**
 * Room Events Manager - 房间事件管理
 *
 * 提供房间事件相关功能
 */
import { MatrixClient } from "../client";
import { MatrixEvent, type IEvent } from "../models/event";
import { type IEphemeralEventData } from "../ephemeral/index";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface IRoomEventResponse {
    event_id: string;
}
export interface IMessagesResponse {
    start: string;
    end?: string;
    chunk: IEvent[];
    state?: IEvent[];
}
export interface RoomEventsManagerEvents {
    event_fetched: {
        roomId: string;
        eventId: string;
    };
    messages_fetched: {
        roomId: string;
        count: number;
    };
    reaction_sent: {
        roomId: string;
        eventId: string;
        key: string;
    };
}
export declare class RoomEventsManager extends BaseManager<keyof RoomEventsManagerEvents, RoomEventsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getRoomEvents(roomId: string, limit?: number): Promise<MatrixEvent[]>;
    getStateEventsForRoom(roomId: string): Promise<MatrixEvent[]>;
    getTimelineEvents(roomId: string): MatrixEvent[];
    getEphemeralEvents(roomId: string): IEphemeralEventData[];
    hasTimelineEvent(roomId: string, eventId: string): boolean;
    findEventById(roomId: string, eventId: string): MatrixEvent | null;
    getEvent(roomId: string, eventId: string): Promise<IEvent>;
    getMessages(roomId: string, direction: string, limit: number, from?: string): Promise<IMessagesResponse>;
    sendReaction(roomId: string, eventId: string, key: string): Promise<IRoomEventResponse>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map