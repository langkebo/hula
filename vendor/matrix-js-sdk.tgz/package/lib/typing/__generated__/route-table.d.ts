/** Routes served by the synapse-rust `typing` module (mirrored from the backend contract). */
export declare const TYPING_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/typing";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/typing";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/typing/{user_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/typing/{user_id}";
}, {
    readonly method: "PUT";
    readonly path: "/_matrix/client/v3/rooms/{room_id}/typing/{user_id}";
}];
/** Union of every (method, path) tuple in `TYPING_ROUTES`. */
export type TypingRoute = (typeof TYPING_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type TypingMethod = TypingRoute["method"];
/** Path templates referenced by this module. */
export type TypingPath = TypingRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type TypingReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${TypingReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type TypingPathPattern = TypingReplaceBraces<TypingPath>;
//# sourceMappingURL=route-table.d.ts.map