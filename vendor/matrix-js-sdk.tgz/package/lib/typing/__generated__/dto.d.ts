/**
 * DTO snippets extracted from the contract doc for `typing`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export interface TypingResponse {
    user_ids: string[];
}
export interface BatchTypingResponse {
    rooms: {
        [room_id: string]: {
            user_ids: string[];
        };
    };
}
export interface TypingRequestDto {
    typing: boolean;
    timeout: number;
}
export type TypingResponseDto = Record<string, never>;
//# sourceMappingURL=dto.d.ts.map