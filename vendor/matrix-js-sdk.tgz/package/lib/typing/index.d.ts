import { MatrixClient } from "../client";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import type { EmptyObject } from "../@types/common";
/**
 * Typing Manager - 打字提示管理
 *
 * 提供房间内打字状态管理功能
 */
export interface TypingUser {
    userId: string;
    timeout: number;
}
export interface TypingOptions {
    timeout?: number;
}
export declare class TypingManager extends BaseManager {
    private typingTimers;
    private lastTypingSendTime;
    private readonly TYPING_THROTTLE_MS;
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * Send a typing notification to a room.
     * PUT /_matrix/client/v3/rooms/{roomId}/typing/{userId}
     *
     * @param roomId - The room ID
     * @param isTyping - Whether the user is typing
     * @param timeoutMs - The length of time in milliseconds to mark this user as typing
     * @returns Promise which resolves to an empty object if successful
     */
    sendTyping(roomId: string, isTyping: boolean, timeoutMs: number): Promise<EmptyObject>;
    /**
     * POST variant of sendTyping.
     * Convenience method that uses POST instead of PUT for the same endpoint.
     *
     * @param roomId - The room ID
     * @param userId - The user ID
     * @param isTyping - Whether the user is typing
     * @param timeoutMs - The length of time in milliseconds to mark this user as typing
     * @returns Promise which resolves to an empty object if successful
     */
    postTyping(roomId: string, userId: string, isTyping: boolean, timeoutMs?: number): Promise<EmptyObject>;
    /**
     * 开始打字提示
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     * @param options - 选项
     * @param options.timeout - 超时时间（毫秒，默认 30000，与后端 `typing.rs` 默认值一致）
     *
     * @example
     * ```typescript
     * // 开始打字（默认 30 秒超时）
     * await typingManager.startTyping("!abc:example.com");
     *
     * // 自定义超时时间
     * await typingManager.startTyping("!abc:example.com", { timeout: 5000 });
     *
     * // 自动停止打字（超时后）
     * await typingManager.startTyping("!abc:example.com", { timeout: 3000 });
     * // 3 秒后自动停止
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     * @throws {AuthError} 如果用户未登录
     */
    startTyping(roomId: string, options?: TypingOptions): Promise<void>;
    /**
     * 停止打字提示
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     *
     * @example
     * ```typescript
     * // 停止打字
     * await typingManager.stopTyping("!abc:example.com");
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     */
    stopTyping(roomId: string): Promise<void>;
    /**
     * 获取房间内正在打字的用户列表
     *
     * @param roomId - 房间 ID（格式：!localpart:homeserver）
     * @returns 正在打字的用户列表
     *
     * @example
     * ```typescript
     * // 获取正在打字的用户
     * const typingUsers = await typingManager.getTypingUsers("!abc:example.com");
     * typingUsers.forEach(user => {
     *     console.log(`${user.userId} is typing (timeout: ${user.timeout}ms)`);
     * });
     * ```
     *
     * @throws {ValidationError} 如果房间 ID 格式无效
     */
    getTypingUsers(roomId: string): Promise<TypingUser[]>;
    /**
     * 批量获取多个房间的打字状态
     */
    getRoomsTyping(rooms: string[]): Promise<Map<string, TypingUser[]>>;
    /**
     * 检查用户是否正在打字
     */
    isUserTyping(roomId: string, userId: string): Promise<boolean>;
    /**
     * 从服务器拉取房间内正在打字的用户列表（GET /rooms/{room_id}/typing）。
     *
     * 与 `getTypingUsers` 不同，此方法绕过本地 `m.typing` 缓存，直接向后端
     * 发起请求，适用于 sync 还未完成或需要实时数据的场景。
     */
    fetchTypingUsers(roomId: string): Promise<TypingUser[]>;
    /**
     * 查询单个用户是否在某个房间内打字（GET /rooms/{room_id}/typing/{user_id}）。
     */
    fetchUserTyping(roomId: string, userId: string): Promise<boolean>;
    /**
     * 批量查询多个房间的打字状态（POST /rooms/typing）。
     *
     * 返回值为 roomId -> TypingUser[] 的映射。
     */
    fetchRoomsTyping(rooms: string[]): Promise<Map<string, TypingUser[]>>;
    /**
     * 清除所有打字定时器
     */
    clearAllTimers(): void;
    start(): void;
    stop(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map