export declare const WIDGET_ROUTES_ENTRY_COUNT: 18;
export declare const WIDGET_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "widget 与 room 不匹配，或请求体字段不合法";
}, {
    readonly status: 401;
    readonly note: "需认证的 widget / session / 房间级接口缺少或使用无效令牌";
}, {
    readonly status: 403;
    readonly note: "已登录但无 widget 访问权限，或不是房间成员且非管理员";
}, {
    readonly status: 404;
    readonly note: "房间、widget 或 session 不存在";
}, {
    readonly status: 500;
    readonly note: "存储层或 service 层内部错误";
}];
export type WidgetStatusScenario = (typeof WIDGET_ROUTES_STATUS_SCENARIOS)[number];
export declare const WIDGET_ROUTES_ERROR_SCENARIOS: readonly [];
export type WidgetErrorScenario = (typeof WIDGET_ROUTES_ERROR_SCENARIOS)[number];
export declare const WIDGET_ROUTES_ERRCODES: readonly [];
export type WidgetErrcode = (typeof WIDGET_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map