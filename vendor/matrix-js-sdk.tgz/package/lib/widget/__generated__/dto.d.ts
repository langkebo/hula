/**
 * DTO snippets extracted from the contract doc for `widget`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type WidgetContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map