import type { INotificationsResponse, IPaginateOpts, IRelationsResponse } from "./@types/requests";
import type { IMessagesResponse } from "./client-internal-types";
import { Direction, EventTimeline } from "./models/event-timeline";
import type { EventTimelineSet } from "./models/event-timeline-set";
import type { IEvent, MatrixEvent } from "./models/event";
import { type EventMapper } from "./event-mapper";
import type { Room } from "./models/room";
import { type Filter } from "./filter";
import { type ThreadFilterType } from "./models/thread";
interface PaginationDeps {
    notifTimelineSet: EventTimelineSet | null;
    getRoom: (roomId: string) => Room | null;
    createMessagesRequest: (roomId: string, fromToken: string | null, limit: number | undefined, dir: Direction, timelineFilter?: Filter) => Promise<IMessagesResponse>;
    createThreadListMessagesRequest: (roomId: string, fromToken: string | null, limit: number | undefined, dir: Direction, threadListType: ThreadFilterType, timelineFilter?: Filter) => Promise<IMessagesResponse>;
    fetchRelations: (roomId: string, eventId: string, relationType: string | null, eventType: string | null, opts: {
        dir: Direction;
        limit?: number;
        from?: string;
        recurse?: boolean;
    }) => Promise<IRelationsResponse>;
    fetchRoomEvent: (roomId: string, eventId: string) => Promise<Partial<IEvent>>;
    getEventMapper: () => EventMapper;
    getPushDetailsForEvent: (event: MatrixEvent, forceRecalculate: boolean) => void;
    processPaginationEvents: (eventTimeline: EventTimeline, events: MatrixEvent[], backwards: boolean, token: string | null, room: Room | undefined, options?: {
        partitionThreads?: boolean;
        processThreadRoots?: boolean;
    }) => void;
    requestNotifications: (params: Record<string, string>) => Promise<INotificationsResponse>;
    canSupportRelationsRecursion: boolean;
}
export declare function paginateEventTimelineRequest(eventTimeline: EventTimeline, opts: IPaginateOpts, deps: PaginationDeps): Promise<boolean>;
export {};
//# sourceMappingURL=client-timeline-pagination.d.ts.map