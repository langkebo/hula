import type { INotificationsResponse, IPaginateOpts, IRelationsResponse } from "./@types/requests.ts";
import type { IMessagesResponse } from "./client-internal-types.ts";
import { Direction, EventTimeline } from "./models/event-timeline.ts";
import type { EventTimelineSet } from "./models/event-timeline-set.ts";
import type { IEvent, MatrixEvent } from "./models/event.ts";
import { type EventMapper } from "./event-mapper.ts";
import type { Room } from "./models/room.ts";
import { type Filter } from "./filter.ts";
import { type ThreadFilterType } from "./models/thread.ts";
interface PaginationDeps {
    notifTimelineSet: EventTimelineSet | null;
    getRoom: (roomId: string) => Room | null;
    createMessagesRequest: (roomId: string, fromToken: string | null, limit: number | undefined, dir: Direction, timelineFilter?: Filter) => Promise<IMessagesResponse>;
    createThreadListMessagesRequest: (roomId: string, fromToken: string | null, limit: number | undefined, dir: Direction, threadListType: ThreadFilterType, timelineFilter?: Filter) => Promise<IMessagesResponse>;
    fetchRelations: (roomId: string, eventId: string, relationType: string | null, eventType: string | null, opts: {
        dir: Direction;
        limit?: number;
        from?: string;
        recurse?: boolean;
    }) => Promise<IRelationsResponse>;
    fetchRoomEvent: (roomId: string, eventId: string) => Promise<Partial<IEvent>>;
    getEventMapper: () => EventMapper;
    getPushDetailsForEvent: (event: MatrixEvent, forceRecalculate: boolean) => void;
    processPaginationEvents: (eventTimeline: EventTimeline, events: MatrixEvent[], backwards: boolean, token: string | null, room: Room | undefined, options?: {
        partitionThreads?: boolean;
        processThreadRoots?: boolean;
    }) => void;
    requestNotifications: (params: Record<string, string>) => Promise<INotificationsResponse>;
    canSupportRelationsRecursion: boolean;
}
export declare function paginateEventTimelineRequest(eventTimeline: EventTimeline, opts: IPaginateOpts, deps: PaginationDeps): Promise<boolean>;
export {};
//# sourceMappingURL=client-timeline-pagination.d.ts.map