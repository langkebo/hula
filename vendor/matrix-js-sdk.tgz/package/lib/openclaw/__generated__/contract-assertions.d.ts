export declare const OPENCLAW_ROUTES_ENTRY_COUNT: 23;
export declare const OPENCLAW_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 400;
    readonly note: "OpenClaw 动作参数或请求体格式非法";
}, {
    readonly status: 401;
    readonly note: "Token 无效或缺失";
}, {
    readonly status: 403;
    readonly note: "当前账号无权执行 OpenClaw 动作";
}, {
    readonly status: 404;
    readonly note: "OpenClaw 配置或目标动作资源不存在";
}];
export type OpenclawStatusScenario = (typeof OPENCLAW_ROUTES_STATUS_SCENARIOS)[number];
export declare const OPENCLAW_ROUTES_ERROR_SCENARIOS: readonly [{
    readonly scenario: "未认证或 token 失效";
    readonly httpOrErrcode: "401 / M_UNKNOWN_TOKEN";
    readonly sdkErrorType: "AuthError";
    readonly handling: "引导重新登录";
}, {
    readonly scenario: "OpenClaw 请求参数不合法";
    readonly httpOrErrcode: "400 / M_BAD_JSON M_INVALID_PARAM";
    readonly sdkErrorType: "ApiError";
    readonly handling: "修正动作类型、payload 或请求体后重试";
}, {
    readonly scenario: "权限不足";
    readonly httpOrErrcode: "403 / M_FORBIDDEN";
    readonly sdkErrorType: "ApiError";
    readonly handling: "提示用户当前账号无权执行该动作";
}, {
    readonly scenario: "配置或目标资源不存在";
    readonly httpOrErrcode: "404 / M_NOT_FOUND";
    readonly sdkErrorType: "NotFoundError";
    readonly handling: "刷新配置并核对目标资源状态";
}];
export type OpenclawErrorScenario = (typeof OPENCLAW_ROUTES_ERROR_SCENARIOS)[number];
export declare const OPENCLAW_ROUTES_ERRCODES: readonly [{
    readonly errcode: "M_UNKNOWN_TOKEN";
    readonly httpStatus: "401";
    readonly note: "access token 无效、过期或缺失";
}, {
    readonly errcode: "M_BAD_JSON";
    readonly httpStatus: "400";
    readonly note: "OpenClaw 请求体结构不合法";
}, {
    readonly errcode: "M_INVALID_PARAM";
    readonly httpStatus: "400";
    readonly note: "动作参数、payload 或查询字段非法";
}, {
    readonly errcode: "M_FORBIDDEN";
    readonly httpStatus: "403";
    readonly note: "无权读取配置或执行目标动作";
}, {
    readonly errcode: "M_NOT_FOUND";
    readonly httpStatus: "404";
    readonly note: "OpenClaw 配置或目标资源不存在";
}];
export type OpenclawErrcode = (typeof OPENCLAW_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map