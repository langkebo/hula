/**
 * DTO snippets extracted from the contract doc for `openclaw`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type OpenclawContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map