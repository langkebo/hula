/**
 * Sync Accumulator Manager - 同步累积管理
 *
 * 提供同步数据累积相关功能
 */
import { MatrixClient } from "../client";
import { SyncAccumulator, type IJoinedRoom, type IInvitedRoom, type ILeftRoom, type ISyncResponse } from "../sync-accumulator";
import { type IContent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
export interface ISyncAccumulatedData {
    rooms?: {
        join?: Record<string, IJoinedRoom>;
        invite?: Record<string, IInvitedRoom>;
        leave?: Record<string, ILeftRoom>;
    };
    account_data?: Array<{
        type: string;
        content: IContent;
    }>;
    presence?: Array<{
        type: string;
        content: IContent;
    }>;
}
export interface SyncAccumulatorManagerEvents {
    data_accumulated: {
        rooms: number;
    };
    accumulator_reset: void;
}
export declare class SyncAccumulatorManager extends BaseManager<keyof SyncAccumulatorManagerEvents, SyncAccumulatorManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    getSyncAccumulator(): SyncAccumulator | null;
    setSyncAccumulator(accumulator: SyncAccumulator): void;
    accumulateSyncData(data: ISyncResponse): Promise<void>;
    getAccumulatedData(): ISyncAccumulatedData | null;
    resetAccumulator(): void;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map