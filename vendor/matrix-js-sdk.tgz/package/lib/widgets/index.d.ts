import { MatrixClient } from "../client";
import { MatrixEvent } from "../models/event";
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { type WidgetData } from "../matrix-client-extensions";
export interface WidgetMessageData {
    [key: string]: unknown;
}
export interface WidgetInfo {
    id: string;
    type: string;
    url: string;
    name: string;
    /** Dynamic: widget data varies by widget type */
    data?: WidgetMessageData;
}
export interface Widget {
    widget_id: string;
    room_id: string | null;
    user_id: string;
    type: string;
    url: string;
    name: string;
    /** Dynamic: widget data varies by widget type */
    data: WidgetMessageData;
    creator: string;
    active: boolean;
}
export interface WidgetResponse {
    widget: Widget;
}
export interface CreateWidgetBody {
    room_id?: string;
    widget_type: string;
    url: string;
    name: string;
    /** Dynamic: widget data varies by widget type */
    data?: WidgetMessageData;
}
export interface UpdateWidgetBody {
    url?: string;
    name?: string;
    /** Dynamic: widget data varies by widget type */
    data?: WidgetMessageData;
}
/** Response for GET /_matrix/client/v1/widgets/{widgetId}/config */
export interface WidgetConfigResponse {
    widget_id: string;
    room_id: string | null;
    url: string;
    name: string;
    /** Dynamic: widget data varies by widget type */
    data: WidgetMessageData;
    type: string;
}
/** Response for GET /_matrix/client/v1/rooms/{roomId}/widgets/jitsi/config */
export interface WidgetJitsiConfigResponse {
    conf_id: string;
    name: string;
    domain: string;
    app_id: string | null;
    jwt: string | null;
}
/** Response for POST /_matrix/client/v1/widgets/{widgetId}/permissions */
export interface SetWidgetPermissionResponse {
    success: boolean;
    permission_id: number;
}
/** Response for GET /_matrix/client/v1/widgets/{widgetId}/permissions */
export interface GetWidgetPermissionsResponse {
    permissions: WidgetPermissionItem[];
}
/** A single widget permission entry */
export interface WidgetPermissionItem {
    id: number;
    widget_id: string;
    user_id: string;
    permissions: string[];
    created_ts: number;
    updated_ts: number | null;
}
/** A widget session */
export interface WidgetSession {
    session_id: string;
    widget_id: string;
    device_id: string | null;
    created_ts: number;
    expires_ts: number | null;
}
/** Response for POST/GET widget sessions (single session) */
export interface WidgetSessionResponse {
    session: WidgetSession;
}
/** Response for GET /_matrix/client/v1/widgets/{widgetId}/sessions */
export interface WidgetSessionsListResponse {
    sessions: WidgetSession[];
    total: number;
}
export interface WidgetCapabilitiesResponse {
    widget_id: string;
    room_id: string;
    capabilities: string[];
    [key: string]: unknown;
}
export interface UpdateWidgetCapabilitiesBody {
    capabilities: string[];
    [key: string]: unknown;
}
export interface WidgetMessageResponse {
    event_id: string;
    [key: string]: unknown;
}
export interface CreateWidgetV3Body {
    room_id?: string;
    widget_type: string;
    url: string;
    name: string;
    data?: WidgetMessageData;
}
export interface CreateWidgetV3Response {
    widget: Widget;
    [key: string]: unknown;
}
export interface WidgetsManagerEvents {
    widget_added: {
        widgetId: string;
        roomId?: string;
    };
    widget_removed: {
        widgetId: string;
        roomId?: string;
    };
    widget_updated: {
        widgetId: string;
        roomId?: string;
    };
}
/**
 * 旧版 WidgetsManager（历史兼容层）。
 *
 * @deprecated 改用新版 `WidgetManager`（`src/widget/index.ts`）。
 * 新版基于 `__generated__/route-table` 提供类型安全的 widget API，方法命名与后端 route_ledger 一致。
 * 此类仅用于向后兼容既有调用方，后续版本将移除。
 *
 * @see {@link ../widget/index.ts#WidgetManager} 新版 WidgetManager
 */
export declare class WidgetsManager extends BaseManager<keyof WidgetsManagerEvents, WidgetsManagerEvents> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    isSupported(): Promise<boolean>;
    private doRequest;
    private doRequestV3;
    /** POST /_matrix/client/v1/widgets */
    createWidget(body: CreateWidgetBody): Promise<WidgetResponse>;
    /** GET /_matrix/client/v1/widgets/{widget_id} */
    getWidgetById(widgetId: string): Promise<WidgetResponse>;
    /** PUT /_matrix/client/v1/widgets/{widget_id} */
    updateWidget(widgetId: string, body: UpdateWidgetBody): Promise<WidgetResponse>;
    /** DELETE /_matrix/client/v1/widgets/{widget_id} */
    deleteWidget(widgetId: string): Promise<void>;
    /** GET /_matrix/client/v1/widgets/{widget_id}/config */
    getWidgetConfig(widgetId: string): Promise<WidgetConfigResponse>;
    /** GET /_matrix/client/v1/rooms/{room_id}/widgets */
    listRoomWidgets(roomId: string): Promise<{
        widgets: Widget[];
    }>;
    /** GET /_matrix/client/v1/rooms/{room_id}/widgets/jitsi/config */
    getJitsiConfig(roomId: string): Promise<WidgetJitsiConfigResponse>;
    /** POST /_matrix/client/v1/widgets/{widget_id}/permissions */
    setWidgetPermission(widgetId: string, body: {
        user_id: string;
        permissions: string[];
    }): Promise<SetWidgetPermissionResponse>;
    /** GET /_matrix/client/v1/widgets/{widget_id}/permissions */
    getWidgetPermissions(widgetId: string): Promise<GetWidgetPermissionsResponse>;
    /** DELETE /_matrix/client/v1/widgets/{widget_id}/permissions/{user_id} */
    deleteWidgetPermission(widgetId: string, userId: string): Promise<void>;
    /** POST /_matrix/client/v1/widgets/{widget_id}/sessions */
    createWidgetSession(widgetId: string, body?: {
        widget_id?: string;
        device_id?: string;
        expires_in_ms?: number;
    }): Promise<WidgetSessionResponse>;
    /** GET /_matrix/client/v1/widgets/{widget_id}/sessions */
    listWidgetSessions(widgetId: string): Promise<WidgetSessionsListResponse>;
    /** GET /_matrix/client/v1/widgets/sessions/{session_id} */
    getWidgetSession(sessionId: string): Promise<WidgetSessionResponse>;
    /** DELETE /_matrix/client/v1/widgets/sessions/{session_id} */
    terminateWidgetSession(sessionId: string): Promise<void>;
    /** DELETE /_matrix/client/v1/widgets/sessions/{session_id} (alias for terminateWidgetSession) */
    deleteWidgetSession(sessionId: string): Promise<void>;
    /** GET /_matrix/client/v3/rooms/{roomId}/widgets/{widgetId}/capabilities */
    getWidgetCapabilities(roomId: string, widgetId: string): Promise<WidgetCapabilitiesResponse>;
    /** PUT /_matrix/client/v3/rooms/{roomId}/widgets/{widgetId}/capabilities */
    updateWidgetCapabilities(roomId: string, widgetId: string, capabilities: UpdateWidgetCapabilitiesBody): Promise<WidgetCapabilitiesResponse>;
    /** POST /_matrix/client/v3/rooms/{roomId}/widgets/{widgetId}/send */
    sendWidgetMessage(roomId: string, widgetId: string, message: unknown): Promise<WidgetMessageResponse>;
    /** POST /_matrix/client/v3/widgets/create */
    createWidgetV3(body: CreateWidgetV3Body): Promise<CreateWidgetV3Response>;
    getUserWidgets(): Promise<WidgetData>;
    getRoomWidgets(roomId: string): Promise<WidgetData>;
    setUserWidgets(widgets: WidgetData): Promise<void>;
    setRoomWidgets(roomId: string, widgets: WidgetData): Promise<void>;
    getAllWidgetEvents(roomId: string): Promise<MatrixEvent[]>;
}
export declare function extendMatrixClient(): void;
//# sourceMappingURL=index.d.ts.map