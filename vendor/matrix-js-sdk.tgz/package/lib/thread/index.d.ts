/**
 * Thread Manager - 话题/线程管理
 *
 * 提供 Matrix thread（话题/子线程）的创建、查询、管理功能
 * 对应后端: synapse-rust thread 模块
 */
import { BaseManager, type ManagerOpts } from "../managers/base-manager";
import { MatrixClient } from "../client";
export declare enum ThreadEvent {
    ThreadCreated = "ThreadCreated",
    ThreadDeleted = "ThreadDeleted",
    ThreadUpdated = "ThreadUpdated",
    ThreadError = "ThreadError"
}
export interface IThreadReply {
    event_id: string;
    room_id: string;
    thread_id: string;
    sender: string;
    content: Record<string, unknown>;
    origin_server_ts: number;
}
export interface IThread {
    thread_id: string;
    room_id: string;
    root_event_id: string;
    reply_count: number;
    latest_reply_ts?: number;
    participants: string[];
    unread: boolean;
    subscribed?: boolean;
    frozen?: boolean;
    muted?: boolean;
}
export interface IThreadStats {
    thread_id: string;
    reply_count: number;
    participant_count: number;
}
export interface IThreadListResponse {
    threads: IThread[];
    next_batch?: string;
}
export interface IThreadRepliesResponse {
    replies: IThreadReply[];
    next_batch?: string;
}
export interface IThreadResponse {
    thread: IThread;
}
interface ThreadManagerEventMap {
    [ThreadEvent.ThreadCreated]: (thread: IThread) => void;
    [ThreadEvent.ThreadDeleted]: (threadId: string) => void;
    [ThreadEvent.ThreadUpdated]: (thread: IThread) => void;
    [ThreadEvent.ThreadError]: (error: Error) => void;
}
export declare class ThreadManager extends BaseManager<ThreadEvent, ThreadManagerEventMap> {
    constructor(client: MatrixClient, opts?: ManagerOpts);
    /**
     * 获取房间内的所有话题列表
     * GET /_matrix/client/v1/rooms/{room_id}/threads
     */
    getRoomThreads(roomId: string, params?: {
        from?: string;
        limit?: number;
        include?: string;
    }): Promise<IThreadListResponse>;
    /**
     * 在房间中创建新话题
     * POST /_matrix/client/v1/rooms/{room_id}/threads
     */
    createThread(roomId: string, body: {
        event_id: string;
        name?: string;
    }): Promise<IThreadResponse>;
    /**
     * 搜索房间内的话题
     * GET /_matrix/client/v1/rooms/{room_id}/threads/search
     */
    searchThreads(roomId: string, params: {
        term: string;
        limit?: number;
        from?: string;
    }): Promise<IThreadListResponse>;
    /**
     * 获取房间内未读话题列表
     * GET /_matrix/client/v1/rooms/{room_id}/threads/unread
     */
    getUnreadRoomThreads(roomId: string): Promise<IThreadListResponse>;
    /**
     * 获取话题详情
     * GET /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}
     */
    getThread(roomId: string, threadId: string): Promise<IThreadResponse>;
    /**
     * 删除话题
     * DELETE /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}
     */
    deleteThread(roomId: string, threadId: string): Promise<void>;
    /**
     * 冻结话题（禁止新回复）
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/freeze
     */
    freezeThread(roomId: string, threadId: string): Promise<IThreadResponse>;
    /**
     * 取消冻结话题
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/unfreeze
     */
    unfreezeThread(roomId: string, threadId: string): Promise<IThreadResponse>;
    /**
     * 静音话题
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/mute
     */
    muteThread(roomId: string, threadId: string): Promise<IThreadResponse>;
    /**
     * 标记话题为已读
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/read
     */
    markThreadRead(roomId: string, threadId: string, readUpTo?: string): Promise<void>;
    /**
     * 订阅话题
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/subscribe
     */
    subscribeThread(roomId: string, threadId: string): Promise<IThreadResponse>;
    /**
     * 取消订阅话题
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/unsubscribe
     */
    unsubscribeThread(roomId: string, threadId: string): Promise<IThreadResponse>;
    /**
     * 获取话题回复列表
     * GET /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/replies
     */
    getThreadReplies(roomId: string, threadId: string, params?: {
        from?: string;
        limit?: number;
        dir?: string;
    }): Promise<IThreadRepliesResponse>;
    /**
     * 创建话题回复
     * POST /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/replies
     */
    createThreadReply(roomId: string, threadId: string, body: {
        content: Record<string, unknown>;
    }): Promise<IThreadReply>;
    /**
     * 删除（红线）话题回复
     * POST /_matrix/client/v1/rooms/{room_id}/replies/{event_id}/redact
     */
    redactReply(roomId: string, eventId: string, reason?: string): Promise<void>;
    /**
     * 获取话题统计信息
     * GET /_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/stats
     */
    getThreadStats(roomId: string, threadId: string): Promise<IThreadStats>;
    /**
     * 获取全局所有话题
     * GET /_matrix/client/v1/threads
     */
    getAllThreads(params?: {
        from?: string;
        limit?: number;
    }): Promise<IThreadListResponse>;
    /**
     * 创建话题（无需指定房间上下文）
     * POST /_matrix/client/v1/threads
     */
    createGlobalThread(body: {
        room_id: string;
        event_id: string;
        name?: string;
    }): Promise<IThreadResponse>;
    /**
     * 获取已订阅的话题列表
     * GET /_matrix/client/v1/threads/subscribed
     */
    getSubscribedThreads(params?: {
        from?: string;
        limit?: number;
    }): Promise<IThreadListResponse>;
    /**
     * 获取全局未读话题列表
     * GET /_matrix/client/v1/threads/unread
     */
    getAllUnreadThreads(): Promise<IThreadListResponse>;
    /**
     * 获取用户在某房间内的话题列表
     * GET /_matrix/client/v3/user/{user_id}/rooms/{room_id}/threads
     */
    getUserThreads(userId: string, roomId: string, params?: {
        from?: string;
        limit?: number;
    }): Promise<IThreadListResponse>;
    start(): void;
    stop(): void;
}
export declare function extendMatrixClient(): void;
export {};
//# sourceMappingURL=index.d.ts.map