export declare const THREAD_ROUTES_ENTRY_COUNT: 21;
export declare const THREAD_ROUTES_STATUS_SCENARIOS: readonly [{
    readonly status: 200;
    readonly note: "请求成功";
}, {
    readonly status: 204;
    readonly note: "删除线程成功且无响应体";
}, {
    readonly status: 400;
    readonly note: "room_id 缺失、查询参数错误或请求体字段不完整";
}, {
    readonly status: 401;
    readonly note: "需认证接口缺少或使用无效令牌";
}, {
    readonly status: 404;
    readonly note: "线程不存在";
}, {
    readonly status: 500;
    readonly note: "存储层或 service 层内部错误";
}];
export type ThreadStatusScenario = (typeof THREAD_ROUTES_STATUS_SCENARIOS)[number];
export declare const THREAD_ROUTES_ERROR_SCENARIOS: readonly [];
export type ThreadErrorScenario = (typeof THREAD_ROUTES_ERROR_SCENARIOS)[number];
export declare const THREAD_ROUTES_ERRCODES: readonly [];
export type ThreadErrcode = (typeof THREAD_ROUTES_ERRCODES)[number];
//# sourceMappingURL=contract-assertions.d.ts.map