/** Routes served by the synapse-rust `thread` module (mirrored from the backend contract). */
export declare const THREAD_ROUTES: readonly [{
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/replies/{event_id}/redact";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/search";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/unread";
}, {
    readonly method: "DELETE";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/freeze";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/mute";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/read";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/replies";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/replies";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/stats";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/subscribe";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/unfreeze";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/rooms/{room_id}/threads/{thread_id}/unsubscribe";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/threads";
}, {
    readonly method: "POST";
    readonly path: "/_matrix/client/v1/threads";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/threads/subscribed";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v1/threads/unread";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/v3/user/{user_id}/rooms/{room_id}/threads";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/org.matrix.msc4155/rooms/{room_id}/threads";
}, {
    readonly method: "GET";
    readonly path: "/_matrix/client/unstable/org.matrix.msc4156/threads/subscribed";
}];
/** Union of every (method, path) tuple in `THREAD_ROUTES`. */
export type ThreadRoute = (typeof THREAD_ROUTES)[number];
/** HTTP methods referenced by this module. */
export type ThreadMethod = ThreadRoute["method"];
/** Path templates referenced by this module. */
export type ThreadPath = ThreadRoute["path"];
/**
 * Recursively replace `{name}` placeholders with `${string}` so that
 * runtime template literals like ` `/friends/${userId}` ` satisfy this
 * type. Used by manager code that binds call sites to the ledger while
 * still interpolating path parameters.
 */
export type ThreadReplaceBraces<P extends string> = P extends `${infer A}{${infer ParamSegment}}${infer B}` ? ParamSegment extends string ? `${A}${string}${ThreadReplaceBraces<B>}` : never : P;
/** Broader path type that also accepts parametrised template literals. */
export type ThreadPathPattern = ThreadReplaceBraces<ThreadPath>;
//# sourceMappingURL=route-table.d.ts.map