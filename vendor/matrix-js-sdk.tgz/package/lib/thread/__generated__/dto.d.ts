/**
 * DTO snippets extracted from the contract doc for `thread`.
 * These declarations make prompt-reviewed request/response shapes importable from a stable path.
 */
export type ThreadContractDtoPlaceholder = never;
//# sourceMappingURL=dto.d.ts.map