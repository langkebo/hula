import { Method } from "./http-api/index.ts";
import type { Body, IRequestOpts } from "./http-api/index.ts";
import type { QueryDict } from "./utils.ts";
interface PreviewCache<T> {
    has(key: string): boolean;
    get(key: string): Promise<T> | undefined;
    set(key: string, value: Promise<T>): void;
}
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function getUrlPreviewRequest<T>(url: string, ts: number, cache: PreviewCache<T>, authedRequest: AuthedRequestFn): Promise<T>;
export {};
//# sourceMappingURL=client-url-preview.d.ts.map