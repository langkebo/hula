import { Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import { InflightRequestCache } from "./utils/inflight-request-cache";
import type { QueryDict } from "./utils";
type AuthedRequestFn = <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, requestOpts?: IRequestOpts) => Promise<T>;
export declare function getUrlPreviewRequest<T>(url: string, ts: number, cache: InflightRequestCache<T>, authedRequest: AuthedRequestFn): Promise<T>;
export {};
//# sourceMappingURL=client-url-preview.d.ts.map