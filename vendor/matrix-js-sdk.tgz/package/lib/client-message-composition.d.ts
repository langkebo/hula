import type { IContent } from "./models/event.ts";
import type { MatrixEvent } from "./models/event.ts";
import type { RoomMessageEventContent } from "./@types/events.ts";
export interface ThreadBodyArgs {
    threadId: string | null;
    body: string;
    txnId: string | undefined;
}
/**
 * 归一化 `sendTextMessage` / `sendNotice` / `sendEmoteMessage` 的两种调用形式。
 *
 * 这两组公开方法历史上支持两种签名：
 *   - `(roomId, body, txnId?)`
 *   - `(roomId, threadId, body, txnId?)`
 * 判别依据是第一个参数是否为线程 ID（Matrix 的房间/事件 ID 都以 `$` 开头；`null` 显式表示
 * 「非线程」）。原实现把这段判断在三个方法里各抄了一份，这里收敛成一处。
 */
export declare function normalizeThreadBodyArgs(threadIdOrBody: string | null, bodyOrTxnId?: string, txnId?: string): ThreadBodyArgs;
/**
 * 构建回复内容：在 `m.relates_to.m.in_reply_to` 里指向目标事件，保留调用方已有的
 * `m.relates_to` 字段（例如同时是线程回复时的 `rel_type`/`event_id`）。
 *
 * 房间不匹配时抛错 —— 这个检查必须在**发出去之前**做，否则会把回复发到别的房间。
 */
export declare function buildReplyContent(roomId: string, event: MatrixEvent, content: RoomMessageEventContent): RoomMessageEventContent;
/**
 * 构建编辑内容：新内容放在 `m.new_content`，`m.relates_to` 标记为 `m.replace` 并指向被编辑事件。
 *
 * 注意 `m.new_content` 存的是**原始 content**（不含 `m.relates_to`），与 Matrix 的
 * `m.replace` 约定一致；顶层同样携带新正文，便于旧客户端降级展示。
 */
export declare function buildEditContent(roomId: string, event: MatrixEvent, content: RoomMessageEventContent): RoomMessageEventContent;
/** 便捷断言：把内容当作 `IContent` 使用时不会丢字段（类型层面的回归防线）。 */
export declare function asContent(content: RoomMessageEventContent): IContent;
//# sourceMappingURL=client-message-composition.d.ts.map