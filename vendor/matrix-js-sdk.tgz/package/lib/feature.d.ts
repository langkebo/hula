import { type IServerVersions } from "./client";
export declare enum ServerSupport {
    Stable = 0,
    Unstable = 1,
    Unsupported = 2
}
export declare enum Feature {
    Thread = "Thread",
    ThreadUnreadNotifications = "ThreadUnreadNotifications",
    RelationBasedRedactions = "RelationBasedRedactions",
    AccountDataDeletion = "AccountDataDeletion",
    RelationsRecursion = "RelationsRecursion",
    IntentionalMentions = "IntentionalMentions",
    Location = "Location"
}
export declare function buildFeatureSupportMap(versions: IServerVersions): Promise<Map<Feature, ServerSupport>>;
//# sourceMappingURL=feature.d.ts.map