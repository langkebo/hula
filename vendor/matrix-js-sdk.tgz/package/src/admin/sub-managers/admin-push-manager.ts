/*
Copyright 2024 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * Admin Push Manager - 推送服务运维面
 *
 * 对应后端 `push_notification` 模块的 admin 端点（`synapse-web/src/routes/push_notification.rs`）：
 * - `GET  /_synapse/admin/v1/push/config`  - 读取 provider 配置（密钥已打码）
 * - `PUT  /_synapse/admin/v1/push/config`  - 增量修改配置（`null` = 删除该键）
 * - `POST /_synapse/admin/v1/push/process` - 手动推进发送队列（`batch_size` 1..500）
 * - `POST /_synapse/admin/v1/push/cleanup` - 清理历史发送日志（`days` 1..200）
 *
 * 为什么单独成管理器：这 4 条在 2026-10-18 的封装盘点里**一条都没有调用点**
 * （`push_notification` 模块 8 条里，客户端面的 4 条在 `NotificationsManager`，admin 面的 4 条缺封装）。
 * 它们语义上属"推送服务运维"，与 `AdminNotificationManager`（服务器公告）和
 * `AdminCleanupManager`（数据库清理）都不是一回事，故不硬塞进已有子管理器。
 *
 * 端点形态要点（照后端源码，不是照 Synapse Python 文档）：
 * - `process` / `cleanup` 的参数在 **query string**（`batch_size` / `days`），不是 body；
 * - `process` 的 `batch_size` 后端会 clamp 到 1..500，`cleanup` 的 `days` clamp 到 1..200；
 * - `PUT config` 的 body 是 `{ config: { <key>: <value> | null } }`，未知顶层键会被拒（`deny_unknown_fields`）；
 * - `GET config` 会掩码密钥（只留末 4 位），因此**不能用 GET 的返回值回写 PUT**。
 */

import { Method } from "../../http-api/method";
import { AdminBaseManager, apu, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { MatrixClient } from "../../client";

/** `GET /push/config` 的响应；`config` 里的密钥值已打码（形如 `****abcd`）。 */
export interface PushConfigResponse {
    /** `config_key` → `config_value`（密钥类只保留末 4 位）。 */
    config: Record<string, string>;
    /** 当前已完成初始化的 provider 名称。 */
    initialized_providers: string[];
    /** 后端支持的配置键（仅 `GET` 返回；`PUT` 不返回）。 */
    supported_keys?: string[];
}

/** `PUT /push/config` 的响应（与 GET 同形，但没有 `supported_keys`）。 */
export interface PushConfigUpdateResponse {
    config: Record<string, string>;
    initialized_providers: string[];
}

/**
 * `PUT /push/config` 的请求体。
 *
 * 值为 `string` 表示写入，`null` 表示删除该键（后端语义：空字符串会被当成"未配置"，
 * 想彻底删掉一行只能传 `null`）。
 */
export interface PushConfigPatchRequest {
    config: Record<string, string | null>;
}

/** `POST /push/process` 的响应。 */
export interface PushProcessQueueResponse {
    /** 本次处理的推送条数。 */
    processed: number;
    /** 后端生成的说明文案（可直接展示给运维）。 */
    message: string;
}

/** `POST /push/cleanup` 的响应。 */
export interface PushCleanupLogsResponse {
    /** 本次清理的日志条数。 */
    cleaned: number;
    /** 后端生成的说明文案。 */
    message: string;
}

/**
 * 推送服务运维管理
 *
 * @example
 * ```typescript
 * const push = client.getAdminManager().push;
 * const { config, initialized_providers } = await push.getConfig();
 * await push.setConfig({ apns_topic: "im.example.app", apns_key: null });
 * await push.processQueue(200);
 * await push.cleanupLogs(7);
 * ```
 */
export class AdminPushManager extends AdminBaseManager {
    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts) {
        super(client, onError, opts);
    }

    /**
     * 读取推送 provider 配置
     *
     * 注意：密钥类配置会被后端掩码（只留末 4 位），因此**不要**把这里的返回值原样回写给
     * {@link setConfig} —— 那会把掩码值当成真实密钥写库。
     *
     * 对应 `GET /_synapse/admin/v1/push/config`。
     *
     * @example
     * ```typescript
     * const cfg = await client.getAdminManager().push.getConfig();
     * console.log(cfg.initialized_providers);
     * ```
     */
    async getConfig(): Promise<PushConfigResponse> {
        return await this.adminRequest<PushConfigResponse>(
            Method.Get,
            apu("/push/config"),
            undefined,
            undefined,
            "push.getConfig",
        );
    }

    /**
     * 增量修改推送 provider 配置
     *
     * 后端会**立即重建 provider**，不需要重启 homeserver。只传要改的键；传 `null` 删除。
     *
     * @param patch - `{ config: { <key>: <value> | null } }`；未知键由后端拒绝（400）
     *
     * 对应 `PUT /_synapse/admin/v1/push/config`。
     *
     * @example
     * ```typescript
     * // 设置一个键、删除另一个键
     * await push.setConfig({ config: { apns_topic: "im.example.app", apns_key: null } });
     * ```
     */
    async setConfig(patch: PushConfigPatchRequest): Promise<PushConfigUpdateResponse> {
        return await this.adminRequest<PushConfigUpdateResponse>(
            Method.Put,
            apu("/push/config"),
            undefined,
            patch,
            "push.setConfig",
        );
    }

    /**
     * 手动推进一次推送发送队列
     *
     * @param batchSize - 本次最多处理多少条；后端 clamp 到 `1..500`，缺省 100
     *
     * 对应 `POST /_synapse/admin/v1/push/process?batch_size=N`。
     *
     * 注意：`batch_size` 在 **query string**，不是 body。
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().push.processQueue(200);
     * console.log(result.processed);
     * ```
     */
    async processQueue(batchSize?: number): Promise<PushProcessQueueResponse> {
        return await this.adminRequest<PushProcessQueueResponse>(
            Method.Post,
            apu("/push/process"),
            // adminRequest 的 queryParams 只接受 string/string[]；后端正按字符串解析为 i32。
            batchSize === undefined ? undefined : { batch_size: String(batchSize) },
            undefined,
            "push.processQueue",
        );
    }

    /**
     * 清理历史推送发送日志
     *
     * @param days - 保留最近多少天的日志；后端 clamp 到 `1..200`，缺省 30
     *
     * 对应 `POST /_synapse/admin/v1/push/cleanup?days=N`。
     *
     * 注意：`days` 在 **query string**，不是 body。
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().push.cleanupLogs(7);
     * console.log(result.deleted);
     * ```
     */
    async cleanupLogs(days?: number): Promise<PushCleanupLogsResponse> {
        return await this.adminRequest<PushCleanupLogsResponse>(
            Method.Post,
            apu("/push/cleanup"),
            days === undefined ? undefined : { days: String(days) },
            undefined,
            "push.cleanupLogs",
        );
    }
}
