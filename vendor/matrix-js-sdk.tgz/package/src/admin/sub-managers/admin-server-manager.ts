/*
Copyright 2024 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

import { Method } from "../../http-api/method";
import { MatrixError } from "../../http-api/errors";
import { NotFoundError, ValidationError } from "../../errors";
import { AdminBaseManager, apu, type AdminErrorCallback, type ManagerOpts } from "../admin-base-manager";
import { AdminValidators } from "../validators";
import { buildPaginationParams } from "../utils";
import type {
    CleanupAllRequest,
    CleanupAllResponse,
    CleanupRoomsResponse,
    CleanupTokensResponse,
} from "./admin-cleanup-manager";
// 通知端点的真实响应类型（与 `AdminNotificationManager` 用的是同一个）
import type { ServerNotification } from "./admin-notification-manager";
import type {
    ServerStats,
    ServerStatus,
    ServerHealth,
    ServerInfo,
    ServerNotice,
    ServerNoticePage,
    SendServerNoticeResult,
    SystemNotificationPage,
    AdminPurgeHistoryResult,
    AdminShutdownRoomResult,
    AdminExperimentalFeatures,
    AdminRegisterResult,
    AdminServerConfig,
    AdminInfoResponse,
    AdminRegisterRequest,
    PurgeHistoryRequest,
    ShutdownRoomRequest,
    CleanupRoomsRequest,
    RestartServerPayload,
    RestartServerResponse,
    PurgeRoomResponse,
    WhoamiResponse,
    RateLimitStatusResponse,
} from "../types";
import type { CreateNotificationRequest, UpdateNotificationRequest } from "./admin-notification-manager";
import { MatrixClient } from "../../client";

export enum AdminServerEvent {
    ServerStatsUpdated = "ServerStatsUpdated",
}

export interface AdminServerEventMap {
    [AdminServerEvent.ServerStatsUpdated]: (stats: ServerStats) => void;
}

export class AdminServerManager extends AdminBaseManager<AdminServerEvent, AdminServerEventMap> {
    private serverStats: ServerStats | null = null;

    constructor(client: MatrixClient, onError?: AdminErrorCallback, opts?: ManagerOpts) {
        super(client, onError, opts);
    }

    /**
     * 获取当前管理员身份
     * GET /_synapse/admin/v1/whoami
     *
     * @returns 当前管理员身份信息
     *
     * @example
     * ```typescript
     * const who = await client.getAdminManager().server.whoami();
     * console.log(who.user_id, who.is_admin);
     * ```
     */
    async whoami(): Promise<WhoamiResponse> {
        return await this.adminRequest<WhoamiResponse>(Method.Get, apu("/whoami"), undefined, undefined, "whoami");
    }

    /**
     * 获取服务器统计信息
     *
     * @returns 服务器统计信息
     *
     * @example
     * ```typescript
     * const stats = await client.getAdminManager().server.getServerStats();
     * console.log(stats.total_users, stats.total_rooms);
     * ```
     */
    async getServerStats(): Promise<ServerStats> {
        // 后端只注册 `GET /_synapse/admin/v1/statistics`。
        // 早期版本在 404 时会回退到 `/server_stats`，而后端从未注册该路径 —— 那是条死分支
        // （由 `quality:path-contract` 门禁发现），已移除。
        const stats = await this.adminRequest<ServerStats>(Method.Get, apu("/statistics"));
        this.serverStats = stats;
        this.emit(AdminServerEvent.ServerStatsUpdated, stats);
        return stats;
    }

    /**
     * 获取缓存的服务器统计信息
     *
     * @returns 缓存的服务器统计信息，如果不存在则为 null
     *
     * @example
     * ```typescript
     * const cached = client.getAdminManager().server.getServerStatsCached();
     * console.log(cached?.total_users);
     * ```
     */
    getServerStatsCached(): ServerStats | null {
        return this.serverStats;
    }

    /**
     * 获取服务器状态
     *
     * @returns 服务器状态
     *
     * @example
     * ```typescript
     * const status = await client.getAdminManager().server.getServerStatus();
     * console.log(status.up, status.db_ok);
     * ```
     */
    async getServerStatus(): Promise<ServerStatus> {
        return await this.adminRequest<ServerStatus>(Method.Get, apu("/status"));
    }

    /**
     * 获取服务器健康检查
     *
     * @returns 服务器健康检查结果
     *
     * @example
     * ```typescript
     * const health = await client.getAdminManager().server.getServerHealth();
     * console.log(health.status, health.database);
     * ```
     */
    async getServerHealth(): Promise<ServerHealth> {
        // `/server_health` 回退分支已删除：后端从未注册该路径（只注册 `/health`）。
        return await this.adminRequest<ServerHealth>(Method.Get, apu("/health"));
    }

    /**
     * 获取服务器信息
     *
     * @returns 服务器信息
     *
     * @example
     * ```typescript
     * const info = await client.getAdminManager().server.getServerInfo();
     * console.log(info.server_name, info.server_version);
     * ```
     */
    async getServerInfo(): Promise<ServerInfo> {
        // 后端注册的是**无 `/v1` 段**的 `GET /_synapse/admin/info`
        // （synapse-web/src/routes/admin/mod.rs）。adminRequest 的前缀固定为
        // `/_synapse/admin/v1`，打出去会变成 `/_synapse/admin/v1/info` → 必 404。
        // 故此处必须走 v2Request（前缀 `/_synapse/admin`）。
        // 旧实现在 404 时回退到 `/server_info`，该路径后端同样从未注册 —— 一并移除。
        return await this.v2Request<ServerInfo>(Method.Get, "/info");
    }

    /**
     * 清理数据库（`POST /_synapse/admin/v1/cleanup/all`）。
     *
     * ⚠️ 2026-10-08 把一个**11 个字段的虚构载荷**收成真实键集：后端
     * `cleanup.rs::cleanup_all` 是 `Json<Value>` + `body.get("min_age_ms")`，
     * **只读这一个键**。原先声明的 `room_id` / `min_depth` / `max_depth` / `min_ts` /
     * `max_ts` / `limit` / `delete_local_media` / `delete_remote_media` /
     * `delete_old_events` / `delete_old_rooms` / `delete_old_users` 全部被静默忽略
     * （调用方以为按房间或时间窗清理，实际是全量）。
     *
     * 与 {@link cleanupAll} 是同一个端点，参数类型统一为 `CleanupAllRequest`。
     *
     * @param options - 清理选项（仅 `min_age_ms` 生效）
     * @returns 清理结果
     *
     * @example
     * ```typescript
     * const result = await client.getAdminManager().server.cleanupDatabase({ min_age_ms: 86_400_000 });
     * console.log(result.rooms.deleted_empty_rooms);
     * ```
     */
    async cleanupDatabase(options?: CleanupAllRequest): Promise<CleanupAllResponse> {
        // 后端注册的是 `/cleanup/all`、`/cleanup/rooms`、`/cleanup/tokens`
        // （synapse-web/src/routes/admin/cleanup.rs），**没有**裸 `/cleanup`。
        // 本方法语义上做全量清理，故走 `/cleanup/all`。
        return await this.adminRequest<CleanupAllResponse>(Method.Post, apu("/cleanup/all"), undefined, options || {});
    }

    /**
     * 获取服务器通知列表
     *
     * 后端返回 `{notices, total, next_batch}`。
     *
     * @param fromOrLimit - 分页起点或数量限制
     * @param limit - 数量限制
     * @returns 服务器通知页（含游标）
     *
     * @example
     * ```typescript
     * const page = await client.getAdminManager().server.getServerNotices(50);
     * console.log(page.notices.length, page.next_batch);
     * ```
     */
    async getServerNotices(fromOrLimit?: string | number, limit?: number): Promise<ServerNoticePage> {
        let from: string | undefined;
        let localLimit: number | undefined = limit;
        if (typeof fromOrLimit === "number") {
            localLimit = fromOrLimit;
        } else {
            from = fromOrLimit;
        }
        const queryParams = buildPaginationParams(localLimit, from);
        const response = await this.adminRequest<{
            notices?: ServerNotice[];
            total?: number;
            next_batch?: string | null;
        }>(Method.Get, apu("/server_notices"), queryParams);
        const notices = response.notices ?? [];
        return { notices, total: response.total ?? notices.length, next_batch: response.next_batch ?? null };
    }

    /**
     * 发送服务器通知
     *
     * 对应 `POST /_synapse/admin/v1/send_server_notice`。后端 `ServerNoticeRequest`
     * 带 `#[serde(deny_unknown_fields)]`，形状是 **`{user_id, content: {msgtype, body}}`**。
     *
     * ⚠️ 本方法**只支持对象形态**（`arg1` = 用户 id，`arg2` = `{msgtype, body, …}`）。
     * 字符形态（`sendServerNotice("text", "m.text")`）无论怎么拼都凑不出 `user_id`
     * —— 旧实现在那个分支发的是 `{content: "<字符串>", type, target_users}`，
     * 三个键全是未知字段，**必然 400**。现在该分支直接抛出 `ValidationError` 并指路。
     *
     * @param arg1 - 用户 id（对象形态）
     * @param arg2 - 通知内容对象 `{msgtype, body}`
     * @returns 投递结果（`{event_id, room_id, notice_id}`）
     *
     * @throws {ValidationError} 如果未传内容对象（字符串形态已不再支持）
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.sendServerNotice("@alice:example.org", {
     *     msgtype: "m.text",
     *     body: "维护通知",
     * });
     * ```
     */
    async sendServerNotice(
        arg1: string,
        arg2?: string | { msgtype: string; body: string; [k: string]: unknown },
    ): Promise<SendServerNoticeResult> {
        if (typeof arg2 !== "object" || arg2 === null) {
            throw new ValidationError(
                "sendServerNotice requires a content object: sendServerNotice(userId, { msgtype, body }). " +
                    "The backend rejects any other shape with 400 (deny_unknown_fields).",
            );
        }
        const body = { user_id: arg1, content: arg2 };
        return await this.adminRequest<SendServerNoticeResult>(Method.Post, apu("/send_server_notice"), {}, body);
    }

    /**
     * 删除服务器通知
     *
     * @param notificationId - 通知 ID
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.deleteServerNotice("notice-123");
     * ```
     */
    async deleteServerNotice(notificationId: string): Promise<void> {
        if (!notificationId) {
            throw new ValidationError("Notification ID is required");
        }
        await this.adminRequest(Method.Delete, apu(`/server_notices/${encodeURIComponent(notificationId)}`));
    }

    /**
     * 获取服务器通知详情
     *
     * @param noticeId - 通知 ID
     * @returns 服务器通知详情
     *
     * @throws {ValidationError} 如果 noticeId 为空
     *
     * @example
     * ```typescript
     * const notice = await client.getAdminManager().server.getServerNotice("notice-123");
     * console.log(notice.id, notice.user_id);
     * ```
     */
    async getServerNotice(noticeId: string): Promise<ServerNotice> {
        if (!noticeId) throw new ValidationError("Notice ID is required");
        return await this.adminRequest(Method.Get, apu(`/server_notices/${encodeURIComponent(noticeId)}`));
    }

    /**
     * 获取系统通知列表
     *
     * @param from - 分页起点
     * @param limit - 数量限制
     * @returns 系统通知分页结果
     *
     * @example
     * ```typescript
     * const page = await client.getAdminManager().server.listNotifications(undefined, 20);
     * console.log(page.notifications.length);
     * ```
     */
    async listNotifications(from?: string, limit?: number): Promise<SystemNotificationPage> {
        const queryParams = buildPaginationParams(limit, from);
        const response = await this.adminRequest<SystemNotificationPage>(
            Method.Get,
            apu("/notifications"),
            queryParams,
        );
        return {
            notifications: response.notifications || [],
            next_batch: response.next_batch ?? null,
        };
    }

    /**
     * 创建系统通知（`POST /_synapse/admin/v1/notifications`）。
     *
     * ⚠️ 2026-10-08：签名原来写成 `DynamicConfig`（= `Record<string, unknown>`），
     * 于是"`title` / `content` 必填"这条后端事实在类型上完全消失。改用
     * {@link CreateNotificationRequest}；更完整的通知面请用
     * `adminManager.notifications`（`AdminNotificationManager`）。
     *
     * @param payload - 通知内容（`title` / `content` 必填）
     * @returns 创建的通知信息
     *
     * @example
     * ```typescript
     * const created = await client.getAdminManager().server.createNotification({ title: "维护", content: "今晚 23:00 维护" });
     * console.log(created.id);
     * ```
     */
    async createNotification(payload: CreateNotificationRequest): Promise<ServerNotification> {
        return await this.adminRequest<ServerNotification>(Method.Post, apu("/notifications"), {}, payload);
    }

    /**
     * 获取活跃的系统通知列表
     *
     * ⚠️ 后端 `notification.rs::list_active_notifications` 是 `Ok(Json(json!(notifications)))`
     * —— 顶层就是**数组**。旧实现按 `{notifications: [...]}` 解包，于是 `response.notifications`
     * 恒为 `undefined`，**永远返回空数组**（且因为是"合法地返回空"，调用方看不出异常）。
     *
     * @returns 活跃的系统通知列表
     *
     * @example
     * ```typescript
     * const active = await adminManager.listActiveNotifications();
     * console.log(active.length);
     * ```
     */
    async listActiveNotifications(): Promise<ServerNotification[]> {
        return await this.adminRequest<ServerNotification[]>(Method.Get, apu("/notifications/active"));
    }

    /**
     * 获取系统通知详情
     *
     * @param notificationId - 通知 ID
     * @returns 通知详情
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * const notification = await client.getAdminManager().server.getNotification("notice-123");
     * console.log(notification.id, notification.title);
     * ```
     */
    async getNotification(notificationId: string): Promise<ServerNotification> {
        if (!notificationId) throw new ValidationError("Notification ID is required");
        return await this.adminRequest<ServerNotification>(
            Method.Get,
            apu(`/notifications/${encodeURIComponent(notificationId)}`),
        );
    }

    /**
     * 更新系统通知
     *
     * @param notificationId - 通知 ID
     * @param payload - 更新内容
     * @returns 更新后的通知信息
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * const updated = await client.getAdminManager().server.updateNotification("notice-123", { title: "已更新" });
     * console.log(updated.id);
     * ```
     */
    async updateNotification(notificationId: string, payload: UpdateNotificationRequest): Promise<ServerNotification> {
        if (!notificationId) throw new ValidationError("Notification ID is required");
        return await this.adminRequest<ServerNotification>(
            Method.Put,
            apu(`/notifications/${encodeURIComponent(notificationId)}`),
            {},
            payload,
        );
    }

    /**
     * 停用系统通知
     *
     * @param notificationId - 通知 ID
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.deactivateNotification("notice-123");
     * ```
     */
    async deactivateNotification(notificationId: string): Promise<void> {
        if (!notificationId) throw new ValidationError("Notification ID is required");
        await this.adminRequest(
            Method.Put,
            apu(`/notifications/${encodeURIComponent(notificationId)}/deactivate`),
            {},
            undefined,
        );
    }

    /**
     * 删除系统通知
     *
     * @param notificationId - 通知 ID
     *
     * @throws {ValidationError} 如果 notificationId 为空
     *
     * @example
     * ```typescript
     * await client.getAdminManager().server.deleteNotification("notice-123");
     * ```
     */
    async deleteNotification(notificationId: string): Promise<void> {
        if (!notificationId) throw new ValidationError("Notification ID is required");
        await this.adminRequest(
            Method.Delete,
            apu(`/notifications/${encodeURIComponent(notificationId)}`),
            {},
            undefined,
        );
    }

    /**
     * 获取服务器配置
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器配置
     *
     * @throws {Error} 当 throwOnError 为 true 且请求失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const config = await client.getAdminManager().server.getServerConfig();
     * console.log(config.server_name);
     * ```
     */
    async getServerConfig(throwOnError = true): Promise<AdminServerConfig> {
        // `/server_config` 回退分支已删除：后端只注册 `GET /_synapse/admin/v1/config`，
        // 从未注册 `/server_config`（死分支，由 quality:path-contract 门禁发现）。
        try {
            return await this.adminRequest(Method.Get, apu("/config"));
        } catch (e) {
            if (!throwOnError) return {} as AdminServerConfig;
            throw e;
        }
    }

    /**
     * 获取管理员信息
     *
     * @returns 管理员信息
     *
     * @example
     * ```typescript
     * const info = await client.getAdminManager().server.getAdminInfo();
     * console.log(info.server_name, info.server_version);
     * ```
     */
    async getAdminInfo(): Promise<AdminInfoResponse> {
        // 与 getServerInfo 同理：后端是**无 `/v1` 段**的 `GET /_synapse/admin/info`，
        // 必须走 v2Request（前缀 `/_synapse/admin`）。
        return await this.v2Request(Method.Get, "/info");
    }

    /**
     * 获取服务器版本
     *
     * @param throwOnError - 是否抛出错误（默认 true）
     * @returns 服务器版本信息
     *
     * @throws {Error} 当 throwOnError 为 true 且请求失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const version = await client.getAdminManager().server.getServerVersion();
     * console.log(version.server_version);
     * ```
     */
    async getServerVersion(throwOnError = true): Promise<{ server_version: string; python_version: string }> {
        try {
            return await this.adminRequest(Method.Get, apu("/server_version"));
        } catch (e) {
            if (!throwOnError) return { server_version: "unknown", python_version: "unknown" };
            throw e;
        }
    }

    /**
     * 获取注册 nonce
     *
     * @returns nonce 字符串
     *
     * @example
     * ```typescript
     * const { nonce } = await client.getAdminManager().server.getRegisterNonce();
     * console.log(nonce);
     * ```
     */
    async getRegisterNonce(): Promise<{ nonce: string }> {
        return await this.adminRequest(Method.Get, apu("/register/nonce"));
    }

    /**
     * 注册管理员
     *
     * @param payload - 注册信息
     * @returns 注册结果
     *
     * @example
     * ```typescript
     * const { nonce } = await client.getAdminManager().server.getRegisterNonce();
     * const res = await client.getAdminManager().server.registerAdmin({ nonce, username: "alice", password: "s3cret", admin: true, mac: "ABCDEF..." });
     * console.log(res.user_id);
     * ```
     */
    async registerAdmin(payload: AdminRegisterRequest): Promise<AdminRegisterResult> {
        return await this.adminRequest(Method.Post, apu("/register"), {}, payload);
    }

    /**
     * 重启服务器
     *
     * @param payload - 重启选项
     * @returns 重启结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.restartServer({ timeout_ms: 5000 });
     * console.log(res.restarted);
     * ```
     */
    async restartServer(payload?: RestartServerPayload): Promise<RestartServerResponse> {
        return await this.adminRequest(Method.Post, apu("/restart"), {}, payload ?? {});
    }

    /**
     * 获取实验性功能列表
     *
     * @returns 实验性功能信息
     *
     * @example
     * ```typescript
     * const features = await client.getAdminManager().server.getExperimentalFeatures();
     * console.log(features.total);
     * ```
     */
    async getExperimentalFeatures(): Promise<AdminExperimentalFeatures> {
        return await this.adminRequest(Method.Get, apu("/experimental_features"));
    }

    /**
     * 清除房间
     *
     * @param payload - 清除选项
     * @returns 清除结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.purgeRoom({ room_id: "!room:example.org" });
     * console.log(res);
     * ```
     */
    async purgeRoom(payload: { room_id: string }): Promise<PurgeRoomResponse> {
        return await this.adminRequest(Method.Post, apu("/purge_room"), {}, payload);
    }

    /**
     * 清除历史消息
     *
     * @param payload - 清除选项
     * @returns 清除结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.purgeHistory({ room_id: "!room:example.org", purge_up_to_ts: 1_600_000_000_000 });
     * console.log(res.deleted_events);
     * ```
     */
    async purgeHistory(payload: PurgeHistoryRequest): Promise<AdminPurgeHistoryResult> {
        AdminValidators.validatePurgeTruncation(payload);
        return await this.adminRequest(Method.Post, apu("/purge_history"), {}, payload);
    }

    /**
     * 关闭房间
     *
     * @param payload - 关闭选项
     * @returns 关闭结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.shutdownRoom({ room_id: "!room:example.org" });
     * console.log(res.closed_room);
     * ```
     */
    async shutdownRoom(payload: ShutdownRoomRequest): Promise<AdminShutdownRoomResult> {
        return await this.adminRequest(Method.Post, apu("/shutdown_room"), {}, payload);
    }

    /**
     * 清理所有数据
     *
     * @returns 清理结果
     */
    /**
     * 清理所有数据。
     *
     * ⚠️ 后端 `cleanup.rs::cleanup_all` 用 `Json(body): Json<Value>` 读 `min_age_ms`；
     * **不带请求体会被 axum 以 415 拒绝**（SDK 只在 body 是对象时才设
     * `Content-Type: application/json`）。旧实现打的是无 body 的 POST。
     *
     * @param payload - 可选 `{ min_age_ms }`，省略表示不设最小年龄
     *
     * @example
     * ```typescript
     * await adminManager.cleanupAll({ min_age_ms: 86_400_000 });
     * ```
     */
    async cleanupAll(payload?: { min_age_ms?: number }): Promise<CleanupAllResponse> {
        return await this.adminRequest(Method.Post, apu("/cleanup/all"), {}, payload ?? {});
    }

    /**
     * 清理令牌
     *
     * @returns 清理结果
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.cleanupTokens();
     * console.log(res.access_tokens_deleted);
     * ```
     */
    async cleanupTokens(): Promise<CleanupTokensResponse> {
        return await this.adminRequest(Method.Post, apu("/cleanup/tokens"), {}, undefined);
    }

    /**
     * 清理房间
     *
     * @param payload - 清理选项
     * @returns 清理结果
     *
     * @throws {Error} 当主端点非 404 失败时，原样抛出底层错误
     *
     * @example
     * ```typescript
     * const res = await client.getAdminManager().server.cleanupRooms({ min_age_ms: 604800000 });
     * console.log(res.deleted_empty_rooms);
     * ```
     */
    async cleanupRooms(payload?: CleanupRoomsRequest): Promise<CleanupRoomsResponse> {
        try {
            return await this.adminRequest(Method.Post, apu("/rooms/cleanup"), {}, payload ?? {});
        } catch (e) {
            const err = e as MatrixError;
            if (e instanceof NotFoundError || (err instanceof MatrixError && err.httpStatus === 404)) {
                return await this.adminRequest(Method.Post, apu("/cleanup/rooms"), {}, payload ?? {});
            }
            throw e;
        }
    }

    /**
     * 读取限流运行状态
     *
     * 对应 `GET /_synapse/admin/v1/rate-limit-status`（`admin/server.rs::get_rate_limit_status`）。
     * 返回当前生效的限流配置与**运行时计数**：配置来自文件管理器（缺失则回落 env 配置），
     * `metrics` 是进程内累计值（`rejected_ratio_percent` 由后端算好后 round）。
     *
     * 运维用途：确认限流是否真的启用、后端选到哪一档（`backend`）、Redis 是否可用，
     * 以及拒绝率是否异常 —— 这些都是"配置文件里写了但运行时没生效"类问题的第一诊断点。
     *
     * @example
     * ```typescript
     * const st = await client.getAdminManager().server.getRateLimitStatus();
     * console.log(st.enabled, st.backend, st.metrics.rejected_ratio_percent + "%");
     * ```
     */
    async getRateLimitStatus(): Promise<RateLimitStatusResponse> {
        return await this.adminRequest<RateLimitStatusResponse>(Method.Get, apu("/rate-limit-status"));
    }
}
