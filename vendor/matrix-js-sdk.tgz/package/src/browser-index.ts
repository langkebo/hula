/*
Copyright 2019 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

import { setCryptoStoreFactory } from "./matrix.ts";
import { IndexedDBCryptoStore } from "./crypto/store/indexeddb-crypto-store.ts";
import * as matrixcs from "./matrix.ts";

export * from "./matrix.ts";

type BrowserMatrix = typeof import("./matrix.ts");
declare global {
    /* eslint-disable no-var, camelcase */
    var __js_sdk_entrypoint: boolean;
    var matrixcs: BrowserMatrix;
    /* eslint-enable no-var */
}

if (globalThis.__js_sdk_entrypoint) {
    throw new Error("Multiple matrix-js-sdk entrypoints detected!");
}
globalThis.__js_sdk_entrypoint = true;

let indexedDB: IDBFactory | undefined;
try {
    indexedDB = globalThis.indexedDB;
} catch (error) {
    // IndexedDB may not be available in some environments (e.g., private browsing)
    // eslint-disable-next-line no-console
    console.warn("IndexedDB not available, crypto store will not be initialized", error);
}

if (indexedDB) {
    setCryptoStoreFactory(() => new IndexedDBCryptoStore(indexedDB!, "matrix-js-sdk:crypto"));
}

globalThis.matrixcs = matrixcs;
