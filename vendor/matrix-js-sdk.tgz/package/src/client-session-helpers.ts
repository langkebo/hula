/*
Copyright 2026 The TJG Project.

SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
Please see LICENSE files in the repository root for full details.
*/

/**
 * `MatrixClient` 的「会话级」帮助函数。
 *
 * 覆盖登录身份、初次同步、well-known、client options 持久化、房间密钥导入导出
 * 与 profile 兜底。这些函数只依赖入参（窄接口 / 单个依赖对象），不读 client 的其他
 * 状态，故从 `src/client.ts` 抽出为自由函数：实现可单测，`MatrixClient` 上保留同签名的
 * 一行委托。
 */

import { ClientPrefix, Method, type IHttpOpts, type MatrixHttpApi } from "./http-api/index";
import { SyncState } from "./sync";
import type { IMegolmSessionData } from "./@types/crypto";
import type { CryptoApi, ImportRoomKeysOpts } from "./crypto-api/index";
import type { IClientWellKnown } from "./client-api-types";
import type { IStoredClientOpts } from "./client-config-types";
import type { UserDeviceMap } from "./matrix-client-extensions";

/**
 * 取当前登录用户的 MXID，未登录时显式抛错。
 *
 * @param userId - `credentials.userId`；未登录时为 `null`。
 * @returns 当前登录用户的 MXID。
 * @throws 未登录时抛 `Error`（而不是返回空串，避免把"没登录"写进后续请求路径）。
 * @example
 * ```typescript
 * const userId = requireUserId(client.credentials?.userId);
 * ```
 */
export function requireUserId(userId: string | null | undefined): string {
    if (!userId) {
        throw new Error("Expected logged in user but found none.");
    }
    return userId;
}

/**
 * 同步状态是否已达到「初次同步完成」。
 *
 * @param state - 当前 {@link SyncState}；未知时为 `null`。
 * @returns `Prepared` / `Syncing` 时为 `true`。
 * @example
 * ```typescript
 * const ready = isReadySyncState(client.getSyncState());
 * ```
 */
export function isReadySyncState(state: SyncState | null): boolean {
    return state === SyncState.Prepared || state === SyncState.Syncing;
}

/**
 * 查询某用户的设备密钥（`POST /keys/query`，空设备列表 = 该用户全部设备）。
 *
 * @param http - 已带鉴权的 HTTP 客户端。
 * @param userId - 目标用户 ID。
 * @returns `deviceId → device content` 映射；服务端没有该用户的密钥时返回空对象。
 * @throws `userId` 为空时抛 `Error`。
 * @example
 * ```typescript
 * const devices = await fetchUserDevices(http, "@alice:example.org");
 * ```
 */
export async function fetchUserDevices(
    http: MatrixHttpApi<IHttpOpts & { onlyData: true }>,
    userId: string,
): Promise<UserDeviceMap> {
    if (!userId) {
        throw new Error("getUserDevices requires a userId");
    }
    const response = await http.authedRequest<{ device_keys?: Record<string, UserDeviceMap> }>(
        Method.Post,
        "/keys/query",
        undefined,
        // Empty device list means "all devices of this user".
        { device_keys: { [userId]: [] } },
        // 5th parameter is IRequestOpts, not a bare prefix.
        { prefix: ClientPrefix.V3 },
    );
    return response?.device_keys?.[userId] ?? {};
}

/**
 * 取 well-known 的 promise，客户端未启动时显式抛错。
 *
 * @param clientRunning - 客户端是否已 `startClient()`。
 * @param wellKnownPromise - `startClient()` 期间创建的 well-known promise。
 * @returns well-known 配置。
 * @throws 客户端未启动时抛 `Error`。
 * @example
 * ```typescript
 * const wellKnown = requireClientWellKnown(client.clientRunning, client.clientWellKnownPromise);
 * ```
 */
export function requireClientWellKnown(
    clientRunning: boolean,
    wellKnownPromise: Promise<IClientWellKnown> | undefined,
): Promise<IClientWellKnown> {
    if (!clientRunning) {
        throw new Error("Client is not running");
    }
    return wellKnownPromise!;
}

/**
 * 从 client options 里挑出可持久化的原始值（boolean / string / number）。
 *
 * 非原始值（对象、函数、`undefined`）会被丢掉：`storeClientOptions()` 只用于记录
 * "上次的 sync 是用什么参数建的"，复杂对象无法跨会话比对。
 *
 * @param opts - `MatrixClient` 的 `clientOpts`。
 * @returns 只含原始值的普通对象。
 * @example
 * ```typescript
 * const stored = pickPrimitiveOptions(client.getClientOpts()!);
 * ```
 */
export function pickPrimitiveOptions(opts: IStoredClientOpts): Record<string, unknown> {
    const primTypes = ["boolean", "string", "number"];
    const serializableOpts: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(opts)) {
        if (primTypes.includes(typeof value)) {
            serializableOpts[key] = value;
        }
    }
    return serializableOpts;
}

/**
 * 导出房间密钥，未启用 E2EE 时显式 reject。
 *
 * ⚠️ 2026-10-18 修正：此前是 `Promise.resolve(undefined)` 的空实现 —— 调用方会把
 * `undefined` 读成"没有可导出的密钥"，而不是"没启用加密"，于是**备份功能静默失效**。
 *
 * @param crypto - `client.getCrypto()` 的结果。
 * @returns 可直接落盘备份的 Megolm 会话数据。
 * @example
 * ```typescript
 * const exported = await exportRoomKeysVia(client.getCrypto());
 * ```
 */
export function exportRoomKeysVia(crypto: CryptoApi | undefined): Promise<IMegolmSessionData[]> {
    if (!crypto) {
        return Promise.reject(new Error("End-to-end encryption is not enabled: cannot export room keys"));
    }
    return crypto.exportRoomKeys();
}

/**
 * 导入房间密钥，未启用 E2EE 时显式 reject。
 *
 * ⚠️ 2026-10-18 修正：此前是空实现 —— **密钥恢复静默失败**，调用方以为恢复成功，
 * 实际历史消息永久解不开（不可逆）。
 *
 * @param crypto - `client.getCrypto()` 的结果。
 * @param keys - 由 {@link exportRoomKeysVia} 导出的会话数据。
 * @param options - 可选，支持 `progressCallback` 汇报进度。
 * @example
 * ```typescript
 * await importRoomKeysVia(client.getCrypto(), keys);
 * ```
 */
export function importRoomKeysVia(
    crypto: CryptoApi | undefined,
    keys: IMegolmSessionData[],
    options?: ImportRoomKeysOpts,
): Promise<void> {
    if (!crypto) {
        return Promise.reject(new Error("End-to-end encryption is not enabled: cannot import room keys"));
    }
    return crypto.importRoomKeys(keys, options);
}

/** 等待初次同步所需的最小视图（`MatrixClient` 在调用点构造）。 */
export interface InitialSyncWaiter {
    /** 初次同步是否已完成。 */
    isComplete(): boolean;
    /** 订阅 `ClientEvent.Sync`。 */
    onSync(listener: (state: SyncState) => void): void;
    /** 取消订阅 `ClientEvent.Sync`。 */
    offSync(listener: (state: SyncState) => void): void;
}

/**
 * 等待初次同步完成（状态进入 `Prepared` 或 `Syncing`），超时则 reject。
 *
 * ⚠️ 2026-10-18 修正：此前是空方法（`async waitForSync() {}`）—— **调用方以为等到了**，
 * 实际什么都没发生，是最隐蔽的一类假成功（典型竞态源）。
 *
 * 订阅后会**再检查一次**状态，避免"检查与订阅之间刚好完成"的竞态。
 *
 * @param waiter - 同步状态与事件订阅的最小视图。
 * @param timeoutMs - 超时毫秒。超时后 reject（不静默返回）。
 * @returns 初次同步完成后 resolve。
 * @example
 * ```typescript
 * await waitForInitialSync(waiter, 30_000);
 * ```
 */
export async function waitForInitialSync(waiter: InitialSyncWaiter, timeoutMs: number): Promise<void> {
    if (waiter.isComplete()) return;

    await new Promise<void>((resolve, reject) => {
        const finish = (error?: Error): void => {
            clearTimeout(timer);
            waiter.offSync(onSync);
            if (error) reject(error);
            else resolve();
        };

        const onSync = (state: SyncState): void => {
            if (state === SyncState.Prepared || state === SyncState.Syncing) finish();
        };

        const timer = setTimeout(
            () => finish(new Error(`waitForSync timed out after ${timeoutMs}ms: initial sync never completed`)),
            timeoutMs,
        );

        waiter.onSync(onSync);

        // 竞态：检查与订阅之间可能刚好完成 —— 再查一次，否则会一直等到超时。
        if (waiter.isComplete()) finish();
    });
}

/**
 * `getProfileManager()` 的兜底：未启用 profile 扩展时显式失败。
 *
 * 正常路径由 profile 模块的 `extendMatrixClient()` 覆盖该方法并返回真实 manager；
 * 这里的实现只在 `includeProfile: false` 时被执行。**绝不能返回 `null`**：
 * 返回类型非空，`null!` 只是把崩溃推给调用方更远的一行。
 *
 * @throws 恒抛 `Error`。
 * @example
 * ```typescript
 * throwProfileManagerDisabled();
 * ```
 */
export function throwProfileManagerDisabled(): never {
    throw new Error("ProfileManager is not enabled: pass `includeProfile: true` to createClient() (default).");
}
