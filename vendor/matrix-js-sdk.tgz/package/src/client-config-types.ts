import { Filter } from "./filter";
import type { IIdentityServerProvider } from "./@types/IIdentityServerProvider";
import type { MatrixScheduler } from "./scheduler";
import type { QueryDict } from "./utils";
import type { TokenRefreshFunction } from "./http-api/index";
import type { CryptoStore } from "./crypto/store/base";
import type { CryptoCallbacks } from "./crypto-api/index";
import type { RoomNameState } from "./models/room";
import type { Logger } from "./logger";
import type { SlidingSync } from "./sliding-sync";
import type { IStore } from "./store/index";

export interface IKeysUploadResponse {
    one_time_key_counts: {
        [algorithm: string]: number;
    };
}

export interface ICreateClientOpts {
    baseUrl: string;
    idBaseUrl?: string;
    allowInsecureHttp?: boolean;
    store?: IStore;
    cryptoStore?: CryptoStore;
    scheduler?: MatrixScheduler;
    fetchFn?: typeof globalThis.fetch;
    userId?: string;
    deviceId?: string;
    accessToken?: string;
    refreshToken?: string;
    tokenRefreshFunction?: TokenRefreshFunction;
    identityServer?: IIdentityServerProvider;
    localTimeoutMs?: number;
    useAuthorizationHeader?: boolean;
    timelineSupport?: boolean;
    queryParams?: QueryDict;
    pickleKey?: string;
    verificationMethods?: Array<string>;
    forceTURN?: boolean;
    iceCandidatePoolSize?: number;
    supportsCallTransfer?: boolean;
    fallbackICEServerAllowed?: boolean;
    useE2eForGroupCall?: boolean;
    livekitServiceURL?: string;
    cryptoCallbacks?: CryptoCallbacks;
    enableEncryptedStateEvents?: boolean;
    roomNameGenerator?: (roomId: string, state: RoomNameState) => string | null;
    isVoipWithNoMediaAllowed?: boolean;
    disableVoip?: boolean;
    disableDynamicExtensions?: boolean;
    useLivekitForGroupCalls?: boolean;
    logger?: Logger;
}

export interface IMatrixClientCreateOpts extends ICreateClientOpts {
    usingExternalCrypto?: boolean;
}

export enum PendingEventOrdering {
    Chronological = "chronological",
    Detached = "detached",
}

export interface IStartClientOpts {
    initialSyncLimit?: number;
    includeArchivedRooms?: boolean;
    resolveInvitesToProfiles?: boolean;
    pendingEventOrdering?: PendingEventOrdering;
    pollTimeout?: number;
    filter?: Filter;
    disablePresence?: boolean;
    lazyLoadMembers?: boolean;
    clientWellKnownPollPeriod?: number;
    threadSupport?: boolean;
    slidingSync?: SlidingSync;
}

export interface IStoredClientOpts extends IStartClientOpts {}
