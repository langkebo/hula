import { Method, type Body, type IRequestOpts } from "./http-api/index";
import type { IThirdPartyLocation, IThirdPartyUser } from "./client-internal-types";
import type { IProtocol } from "./client-api-types";
import type { QueryDict } from "./utils";
import type { ThirdPartyLocationSearchParams, ThirdPartyUserSearchParams } from "./third-party";
import * as utils from "./utils";

export interface AuthedRequestFn {
    <T>(method: Method, path: string, queryParams?: QueryDict, body?: Body, paramOpts?: IRequestOpts): Promise<T>;
}

/**
 * 构造并按协议查询第三方**位置**（内部请求件，`client.getThirdpartyLocation()` 走这里）。
 *
 * ⚠️ **本后端不实现这条端点**：`GET /thirdparty/location/{protocol}` 恒返 `404 M_NOT_FOUND`。
 * 这是纯 URL 构造 + 一次请求，没有降级路径 —— 调用方拿到的一定是错误。
 *
 * @backendUnsupported 404 M_NOT_FOUND
 */
export function getThirdpartyLocationRequest(
    protocol: string,
    params: ThirdPartyLocationSearchParams | undefined,
    authedRequest: AuthedRequestFn,
): Promise<IThirdPartyLocation[]> {
    const path = utils.encodeUri("/thirdparty/location/$protocol", { $protocol: protocol });
    return authedRequest<IThirdPartyLocation[]>(Method.Get, path, params as QueryDict);
}

/**
 * 构造并按协议查询第三方**用户**（内部请求件，`client.getThirdpartyUser()` 走这里）。
 *
 * ⚠️ **本后端不实现这条端点**：`GET /thirdparty/user/{protocol}` 恒返 `404 M_NOT_FOUND`。
 *
 * @backendUnsupported 404 M_NOT_FOUND
 */
export function getThirdpartyUserRequest(
    protocol: string,
    params: ThirdPartyUserSearchParams | undefined,
    authedRequest: AuthedRequestFn,
): Promise<IThirdPartyUser[]> {
    const path = utils.encodeUri("/thirdparty/user/$protocol", { $protocol: protocol });
    return authedRequest<IThirdPartyUser[]>(Method.Get, path, params as QueryDict);
}

export async function getThirdpartyProtocolsRequest(
    authedRequest: AuthedRequestFn,
): Promise<{ [protocol: string]: IProtocol }> {
    const response = await authedRequest<Record<string, IProtocol>>(Method.Get, "/thirdparty/protocols", undefined);
    if (!response || typeof response !== "object") {
        throw new Error(`/thirdparty/protocols did not return an object: ${response}`);
    }
    return response;
}
