import * as utils from "./utils";
import { ClientPrefix, Method } from "./http-api/index";
import type { Body, IRequestOpts } from "./http-api/index";
import type { QueryDict } from "./utils";
import type { EmptyObject } from "./@types/common";
import type { IThreepid } from "./@types/three-pids";
import type { IAddThreePidOnlyBody, IBindThreePidBody } from "./@types/requests";
import type { IdServerUnbindResult } from "./@types/partials";
import type { IContent } from "./models/event";
import type { IExtendedProfile } from "./profile/index";
import { ValidationError } from "./errors";

export type ProfileField = "displayname" | "avatar_url";

export function selectExtendedProfileRequestPrefix(
    isVersionSupportedV116: boolean,
    hasStableMsc4133Feature: boolean,
): string {
    if (isVersionSupportedV116 || hasStableMsc4133Feature) {
        return ClientPrefix.V3;
    }
    return "/_matrix/client/unstable/uk.tcpip.msc4133";
}

export function buildProfilePath(userId: string | null): string {
    return utils.encodeUri("/profile/$userId", { $userId: userId });
}

export function buildProfileFieldPath(userId: string | null, field: ProfileField): string {
    return utils.encodeUri("/profile/$userId/$field", { $userId: userId, $field: field });
}

export function buildExtendedProfilePropertyPath(userId: string | null, key: string): string {
    return utils.encodeUri("/profile/$userId/$key", { $userId: userId, $key: key });
}

export function buildDisplayNameBody(displayname: string): { displayname: string } {
    return { displayname };
}

export function buildAvatarUrlBody(avatarUrl: string): { avatar_url: string } {
    return { avatar_url: avatarUrl };
}

/**
 * 构造扩展 profile 的写入体。
 *
 * ⚠️ **顶层 `null` 一律拒绝**（后端 `reject_null_profile_value`，对比文档 P2-7）：服务端把
 * `null` 当非法值回 400 `M_BAD_JSON`，因为"值是 null"与"这个键没设置"无法区分。
 * 清空字段必须走 `DELETE /profile/{userId}/{key}`（SDK 的 `deleteExtendedProfileProperty`）。
 *
 * 只拦**顶层**：嵌套对象里的 `null` 是合法 JSON 值，后端用例 `null_value_is_bad_json`
 * 的边界正是"嵌套 null 仍允许"。写成递归校验会把合法的结构化数据拒掉。
 *
 * @param key - 扩展 profile 的键（如 `com.example.foo`）
 * @param value - 要写入的值；顶层 `null` 会抛 {@link ValidationError}
 * @throws {ValidationError} 当 `value` 为 `null` 时
 */
export function buildExtendedProfilePropertyBody(key: string, value: unknown): IContent {
    if (value === null) {
        throw new ValidationError(
            `Profile property "${key}" cannot be set to null (the server answers 400 M_BAD_JSON): ` +
                "use deleteExtendedProfileProperty() to clear it",
        );
    }
    return { [key]: value };
}

type AuthedRequestFn = <T>(
    method: Method,
    path: string,
    queryParams?: QueryDict,
    body?: Body,
    requestOpts?: IRequestOpts,
) => Promise<T>;

export function getExtendedProfileRequest(
    userId: string,
    requestPrefix: string,
    authedRequest: AuthedRequestFn,
): Promise<IExtendedProfile> {
    return authedRequest<IExtendedProfile>(Method.Get, buildProfilePath(userId), undefined, undefined, {
        prefix: requestPrefix,
    });
}

export async function getExtendedProfilePropertyRequest(
    userId: string,
    key: string,
    requestPrefix: string,
    authedRequest: AuthedRequestFn,
): Promise<unknown> {
    const profile = await authedRequest<IExtendedProfile>(
        Method.Get,
        buildExtendedProfilePropertyPath(userId, key),
        undefined,
        undefined,
        {
            prefix: requestPrefix,
        },
    );
    return profile[key];
}

export function setExtendedProfilePropertyRequest(
    userId: string | null,
    key: string,
    value: unknown,
    requestPrefix: string,
    authedRequest: AuthedRequestFn,
): Promise<void> {
    return authedRequest<void>(
        Method.Put,
        buildExtendedProfilePropertyPath(userId, key),
        undefined,
        buildExtendedProfilePropertyBody(key, value),
        {
            prefix: requestPrefix,
        },
    );
}

export function deleteExtendedProfilePropertyRequest(
    userId: string | null,
    key: string,
    requestPrefix: string,
    authedRequest: AuthedRequestFn,
): Promise<void> {
    return authedRequest<void>(Method.Delete, buildExtendedProfilePropertyPath(userId, key), undefined, undefined, {
        prefix: requestPrefix,
    });
}

export function patchExtendedProfileRequest(
    userId: string | null,
    profile: IExtendedProfile,
    requestPrefix: string,
    authedRequest: AuthedRequestFn,
): Promise<IExtendedProfile> {
    return authedRequest<IExtendedProfile>(Method.Patch, buildProfilePath(userId), {}, profile, {
        prefix: requestPrefix,
    });
}

export function setExtendedProfileRequest(
    userId: string | null,
    profile: IExtendedProfile,
    requestPrefix: string,
    authedRequest: AuthedRequestFn,
): Promise<void> {
    return authedRequest<void>(Method.Put, buildProfilePath(userId), {}, profile, {
        prefix: requestPrefix,
    });
}

export function getThreePidsRequest(authedRequest: AuthedRequestFn): Promise<{ threepids: IThreepid[] }> {
    return authedRequest<{ threepids: IThreepid[] }>(Method.Get, "/account/3pid");
}

export function addThreePidOnlyRequest(
    data: IAddThreePidOnlyBody,
    authedRequest: AuthedRequestFn,
): Promise<EmptyObject> {
    return authedRequest<EmptyObject>(Method.Post, "/account/3pid/add", undefined, data);
}

export function bindThreePidRequest(data: IBindThreePidBody, authedRequest: AuthedRequestFn): Promise<EmptyObject> {
    return authedRequest<EmptyObject>(Method.Post, "/account/3pid/bind", undefined, data);
}

export function unbindThreePidRequest(
    medium: string,
    address: string,
    idServer: string | undefined,
    authedRequest: AuthedRequestFn,
): Promise<{ id_server_unbind_result: IdServerUnbindResult }> {
    return authedRequest<{ id_server_unbind_result: IdServerUnbindResult }>(
        Method.Post,
        "/account/3pid/unbind",
        undefined,
        {
            medium,
            address,
            id_server: idServer,
        },
    );
}

export function deleteThreePidRequest(
    medium: string,
    address: string,
    authedRequest: AuthedRequestFn,
): Promise<{ id_server_unbind_result: IdServerUnbindResult }> {
    return authedRequest<{ id_server_unbind_result: IdServerUnbindResult }>(
        Method.Post,
        "/account/3pid/delete",
        undefined,
        { medium, address },
    );
}
