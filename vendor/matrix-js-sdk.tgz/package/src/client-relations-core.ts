import { EventType, RelationType } from "./@types/event";
import { type MatrixEvent, isSuspectRelationEventType } from "./models/event";

export interface ProcessRelationEventsParams {
    events: MatrixEvent[];
    originalEvent?: MatrixEvent;
    fetchedEventType: EventType | string | null | undefined;
    requestedEventType?: EventType | string | null;
    relationType: RelationType | string | null;
    decryptEventIfNeeded: (event: MatrixEvent) => Promise<void>;
}

export async function processRelationEvents({
    events,
    originalEvent,
    fetchedEventType,
    requestedEventType,
    relationType,
    decryptEventIfNeeded,
}: ProcessRelationEventsParams): Promise<MatrixEvent[]> {
    let processedEvents = events;
    if (fetchedEventType === EventType.RoomMessageEncrypted) {
        const allEvents = originalEvent ? processedEvents.concat(originalEvent) : processedEvents;
        await Promise.all(allEvents.map((event) => decryptEventIfNeeded(event)));
        if (requestedEventType !== null && requestedEventType !== undefined) {
            // type 是哨兵值（后端 `/relations` 把 chunk[].type 写成 `m.relates_to`）时判不出来，
            // 这时**保留**而不是丢掉：按类型过滤的本意是"筛出要的"，不是"把不知道的删掉"。
            processedEvents = processedEvents.filter(
                (event) => event.getType() === requestedEventType || isSuspectRelationEventType(event.getType()),
            );
        }
    }
    if (originalEvent && relationType === RelationType.Replace) {
        processedEvents = processedEvents.filter((event) => event.getSender() === originalEvent.getSender());
    }
    return processedEvents;
}
