/*
Copyright 2026 Element Creations Ltd.

SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
Please see LICENSE files in the repository root for full details.
*/

import {
    type ISendEventResponse,
    type SendDelayedEventRequestOpts,
    type SendDelayedEventResponse,
} from "./@types/requests";
import { Method } from "./http-api/method";
import { buildUnstableDelayQueryOpts } from "./client-internals";
import { buildSendEventPath } from "./client-send-paths";
import { resolveSendEventRequestArgs } from "./client-send-request";
import type { MatrixEvent } from "./models/event";
import type { QueryDict } from "./utils";

interface LoggerLike {
    debug(message: string): void;
}

interface HttpLike {
    authedRequest<T>(method: Method, path: string, queryParams?: QueryDict, body?: unknown): Promise<T>;
}

export interface DispatchSendEventHttpRequestArgs {
    event: MatrixEvent;
    queryOrDelayOpts?: SendDelayedEventRequestOpts | QueryDict;
    queryDict?: QueryDict;
    makeTxnId: () => string;
    http: HttpLike;
    logger: LoggerLike;
    unstableDelayFeatureName: string;
}

export function dispatchSendEventHttpRequest({
    event,
    queryOrDelayOpts,
    queryDict,
    makeTxnId,
    http,
    logger,
    unstableDelayFeatureName,
}: DispatchSendEventHttpRequestArgs): Promise<ISendEventResponse | SendDelayedEventResponse> {
    let txnId = event.getTxnId();
    if (!txnId) {
        txnId = makeTxnId();
        event.setTxnId(txnId);
    }

    // 先算一次 `isRedaction`：只有 redaction 事件才需要问"目标是谁"。
    // 对普通消息短路成 `undefined` 有两个好处 —— ① 语义上"普通消息没有撤回目标"是显式的；
    // ② `buildSendEventPath` 本来就只在 isRedaction 时用这个值，没必要为每条消息多走一次取值。
    const isRedaction = event.isRedaction();

    const path = buildSendEventPath({
        roomId: event.getRoomId()!,
        eventType: event.getWireType(),
        stateKey: event.getStateKey(),
        txnId,
        isState: event.isState(),
        isRedaction,
        redactsEventId: isRedaction ? event.getRedactionTargetId() : undefined,
    });

    const { delayOpts, queryOpts } = resolveSendEventRequestArgs(queryOrDelayOpts, queryDict);
    const content = event.getWireContent();

    if (delayOpts) {
        return http.authedRequest<SendDelayedEventResponse>(
            Method.Put,
            path,
            { ...buildUnstableDelayQueryOpts(delayOpts, unstableDelayFeatureName), ...queryOpts },
            content,
        );
    }

    return http.authedRequest<ISendEventResponse>(Method.Put, path, queryOpts, content).then((res) => {
        logger.debug(`Event sent to ${event.getRoomId()} with event id ${res.event_id}`);
        return res;
    });
}
