/*
Copyright 2024 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * 「选项放错层级」的守卫。
 *
 * ## 为什么需要
 *
 * `startClient()` 的选项（`pollTimeout` / `initialSyncLimit` / `filter` …）**不在** `createClient()`
 * 的选项类型里，但两边的对象都允许额外键（JS 调用方、`...options` 展开、`as any` 都很常见）。
 * 放错层级时 **TS 不报错、运行时静默忽略** —— 2026-10-18 联调为此白跑了一轮：
 * 把 `pollTimeout: 3000` 传给 `createClient` 后，同步仍在用默认 30s 长轮询，
 * 表现为"SDK 同步不推进"（根因极难看出，因为它完全不报错）。
 *
 * 这里只做**提示**，不改行为：调用方可能有意把同一份 options 复用于两处，
 * 硬报错会破坏这种用法。
 */

import type { IStartClientOpts } from "./client-config-types";

/**
 * 只在 `startClient()` 生效的选项键。
 *
 * 依据 `IStartClientOpts`（`client-config-types.ts`）；新增 startClient 选项时**必须**同步这里，
 * 否则守卫会漏报。`spec/unit/client-option-guards.spec.ts` 会做键集对比，漏了会红。
 */
export const START_CLIENT_ONLY_KEYS = [
    "initialSyncLimit",
    "includeArchivedRooms",
    "resolveInvitesToProfiles",
    "pendingEventOrdering",
    "pollTimeout",
    "filter",
    "disablePresence",
    "lazyLoadMembers",
    "clientWellKnownPollPeriod",
    "threadSupport",
    "slidingSync",
    "pendingEventNotSentTimeoutMs",
] as const satisfies readonly (keyof IStartClientOpts)[];

/**
 * 找出被误传给 `createClient()` 的 startClient 选项。
 *
 * 只报告**值不是 `undefined`** 的键：`{ pollTimeout: undefined }` 这种"占位"不该吵人。
 *
 * @param opts - 传给 `createClient()` 的选项对象（任意形状，函数内部按需收窄）
 * @returns 误传的键名（保持 `START_CLIENT_ONLY_KEYS` 的顺序）；没有则返回空数组
 *
 * @example
 * ```typescript
 * findMisplacedSyncOptions({ baseUrl: "https://x", pollTimeout: 3000 });
 * // => ["pollTimeout"]
 * ```
 */
export function findMisplacedSyncOptions(opts: unknown): string[] {
    if (opts === null || typeof opts !== "object") return [];
    const record = opts as Record<string, unknown>;
    return START_CLIENT_ONLY_KEYS.filter((key) => record[key] !== undefined);
}

/**
 * 生成给调用方看的提示文案（纯函数，便于单测断言，不用抓日志）。
 *
 * @param keys - `findMisplacedSyncOptions()` 的结果
 * @returns 一行提示；`keys` 为空时返回 `null`（调用方据此跳过日志）
 */
export function buildMisplacedSyncOptionsWarning(keys: readonly string[]): string | null {
    if (keys.length === 0) return null;
    return (
        `These options only take effect on startClient(), not createClient(): ${keys.join(", ")}. ` +
        `They are being ignored — move them into client.startClient({ ... }). ` +
        `(Silently ignoring them is how a 30s pollTimeout looks like "sync never advances".)`
    );
}
