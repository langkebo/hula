/*
Copyright 2015, 2016 OpenMarket Ltd
Copyright 2017 New Vector Ltd
Copyright 2019, 2020 The Matrix.org Foundation C.I.C.
Copyright 2021 - 2022 Šimon Brandner <simon.bra.ag@gmail.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * Invite/answer signalling state machine of a {@link MatrixCall}.
 *
 * Extracted verbatim from `call.ts` (C-8 split, fourth batch): this module owns
 * the "how a call is set up and torn down" logic — `initWithInvite`, `answer`,
 * `hangup`, `reject`, the answer/offer feed plumbing and the remote answer
 * handlers. Everything it touches on the call (state, peer connection, feeds,
 * VoIP event sending, termination) is injected through
 * {@link CallSignallingOptions}, so the class holds no call state of its own.
 */

import { type MatrixEvent } from "../models/event";
import { EventType, type TimelineEvents } from "../@types/event";
import { logger } from "../logger";
import { isNullOrUndefined } from "../common/safety";
import { type MatrixClient } from "../client";
import { MatrixError } from "../http-api/index";
import {
    type MCallAnswer,
    type MCallHangupReject,
    type MCallInviteNegotiate,
    type MCallSelectAnswer,
    SDPStreamMetadataKey,
    SDPStreamMetadataPurpose,
    type SDPStreamMetadata,
} from "./callEventTypes";
import { CallFeed } from "./callFeed";
import { CallDirection, CallError, CallErrorCode, CallParty, CallState, type CallEventType } from "./call";

export interface CallSignallingOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    client: MatrixClient;
    roomId: string;
    ourPartyId: string;

    getDirection: () => CallDirection | undefined;
    setDirection: (direction: CallDirection) => void;
    getPeerConnection: () => RTCPeerConnection | undefined;
    setPeerConnection: (peerConn: RTCPeerConnection) => void;
    setHangupParty: (party: CallParty) => void;
    getState: () => CallState;
    setState: (state: CallState) => void;
    getInviteOrAnswerSent: () => boolean;
    setInviteOrAnswerSent: (sent: boolean) => void;
    getWaitForLocalAVStream: () => boolean;
    setWaitForLocalAVStream: (wait: boolean) => void;
    getOpponentVersion: () => number | string | undefined;
    getOpponentPartyId: () => string | null | undefined;
    isOnlyDataChannelAllowed: () => boolean;
    /** Shared with `queueGotLocalOffer` in `call.ts`: one negotiate/answer at a time. */
    getResponsePromiseChain: () => Promise<void> | undefined;
    setResponsePromiseChain: (chain: Promise<void> | undefined) => void;
    /** `onNegotiateReceived` in `call.ts` reads this flag, so it stays on the call. */
    setIsSettingRemoteAnswerPending: (pending: boolean) => void;

    // Media feeds owned by `CallFeedSet`.
    getRemoteStream: () => MediaStream | undefined;
    getLocalFeeds: () => CallFeed[];
    getLocalUsermediaStream: () => MediaStream | undefined;
    getLocalScreensharingFeed: () => CallFeed | undefined;
    hasLocalUserMediaAudioTrack: () => boolean;
    hasLocalUserMediaVideoTrack: () => boolean;
    hasRemoteUserMediaAudioTrack: () => boolean;
    hasRemoteUserMediaVideoTrack: () => boolean;
    pushLocalFeed: (feed: CallFeed) => void;
    updateLocalUsermediaStream: (stream: MediaStream, forceAudio?: boolean, forceVideo?: boolean) => Promise<void>;
    opponentSupportsSDPStreamMetadata: () => boolean;
    updateRemoteSDPStreamMetadata: (metadata: SDPStreamMetadata) => void;
    getLocalSDPStreamMetadata: (updateStreamIds?: boolean) => SDPStreamMetadata;
    /** Hand local feeds to a replacement call; returns false when there is none. */
    forwardFeedsToSuccessor: (feeds: CallFeed[]) => boolean;

    // Call lifecycle.
    callHasEnded: () => boolean;
    createPeerConnection: () => RTCPeerConnection;
    chooseOpponent: (event: MatrixEvent) => void;
    initOpponentCrypto: () => Promise<void>;
    addBufferedRemoteCandidates: (partyId: string) => Promise<void>;
    terminate: (hangupParty: CallParty, hangupReason: CallErrorCode, shouldEmit: boolean) => Promise<void>;
    stopAllMedia: () => void;
    removeStatsReportGatherer: () => void;
    sendVoipEvent: <K extends CallEventType>(
        eventType: K,
        content: Omit<TimelineEvents[K], "version" | "call_id" | "party_id" | "conf_id">,
    ) => Promise<void>;
    sendCandidateQueue: () => void;
    discardDuplicateCandidates: () => number;
    getRidOfRTXCodecs: () => void;
    createAnswer: () => Promise<RTCSessionDescriptionInit>;
    /**
     * Resolved through the owning call so that instance-level overrides (tests,
     * consumers) still take effect.
     */
    shouldAnswerWithMediaType: (
        wantedValue: boolean | undefined,
        valueOfTheOtherSide: boolean,
        type: "audio" | "video",
    ) => boolean;
    getUserMediaFailed: (error: Error) => void;

    // Events.
    emitPeerConnectionCreated: (peerConn: RTCPeerConnection) => void;
    emitHangup: () => void;
    emitError: (error: CallError) => void;
    /** Subscribe to `CallEvent.State`; returns the unsubscribe function. */
    subscribeToState: (onState: (state: CallState) => void) => () => void;
}

export class CallSignalling {
    public constructor(private readonly opts: CallSignallingOptions) {}

    /**
     * Configure this call from an invite event. Used by MatrixClient.
     * @param event - The m.call.invite event
     * @param throwOnError - Whether to throw on error (default true)
     */
    public async initWithInvite(event: MatrixEvent, throwOnError = true): Promise<void> {
        const invite = event.getContent<MCallInviteNegotiate>();
        this.opts.setDirection(CallDirection.Inbound);

        // make sure we have valid turn creds. Unless something's gone wrong, it should
        // poll and keep the credentials valid so this should be instant.
        const haveTurnCreds = await this.opts.client.checkTurnServers();
        if (!haveTurnCreds) {
            logger.warn(
                `Call ${this.opts.callId} initWithInvite() failed to get TURN credentials! Proceeding with call anyway...`,
            );
        }

        const sdpStreamMetadata = SDPStreamMetadataKey.findIn(invite);
        if (sdpStreamMetadata) {
            this.opts.updateRemoteSDPStreamMetadata(sdpStreamMetadata);
        } else {
            logger.debug(
                `Call ${this.opts.callId} initWithInvite() did not get any SDPStreamMetadata! Can not send/receive multiple streams`,
            );
        }

        const peerConn = this.opts.createPeerConnection();
        this.opts.setPeerConnection(peerConn);
        this.opts.emitPeerConnectionCreated(peerConn);
        // we must set the party ID before await-ing on anything: the call event
        // handler will start giving us more call events (eg. candidates) so if
        // we haven't set the party ID, we'll ignore them.
        this.opts.chooseOpponent(event);
        await this.opts.initOpponentCrypto();
        try {
            await peerConn.setRemoteDescription(invite.offer);
            logger.debug(`Call ${this.opts.callId} initWithInvite() set remote description: ${invite.offer.type}`);
            await this.opts.addBufferedRemoteCandidates(this.opts.getOpponentPartyId()!);
        } catch (e) {
            logger.debug(`Call ${this.opts.callId} initWithInvite() failed to set remote description`, e);
            this.opts.terminate(CallParty.Local, CallErrorCode.SetRemoteDescription, false);
            if (throwOnError) {
                throw e;
            }
            return;
        }

        const remoteStream = this.opts.getRemoteStream();

        // According to previous comments in this file, firefox at some point did not
        // add streams until media started arriving on them. Testing latest firefox
        // (81 at time of writing), this is no longer a problem, so let's do it the correct way.
        //
        // For example in case of no media webrtc connections like screen share only call we have to allow webrtc
        // connections without remote media. In this case we always use a data channel. At the moment we allow as well
        // only data channel as media in the WebRTC connection with this setup here.
        if (!this.opts.isOnlyDataChannelAllowed() && (!remoteStream || remoteStream.getTracks().length === 0)) {
            logger.error(
                `Call ${this.opts.callId} initWithInvite() no remote stream or no tracks after setting remote description!`,
            );
            this.opts.terminate(CallParty.Local, CallErrorCode.SetRemoteDescription, false);
            if (throwOnError) {
                throw new Error("No remote stream or no tracks after setting remote description");
            }
            return;
        }

        this.opts.setState(CallState.Ringing);

        if (event.getLocalAge()) {
            // Time out the call if it's ringing for too long
            const ringingTimer = setTimeout(() => {
                if (this.opts.getState() == CallState.Ringing) {
                    logger.debug(`Call ${this.opts.callId} initWithInvite() invite has expired. Hanging up.`);
                    this.opts.setHangupParty(CallParty.Remote); // effectively
                    this.opts.setState(CallState.Ended);
                    this.opts.stopAllMedia();
                    const peerConn = this.opts.getPeerConnection()!;
                    if (peerConn.signalingState != "closed") {
                        peerConn.close();
                    }
                    this.opts.removeStatsReportGatherer();
                    this.opts.emitHangup();
                }
            }, invite.lifetime - event.getLocalAge());

            let unsubscribe: () => void = () => {};
            const onState = (state: CallState): void => {
                if (state !== CallState.Ringing) {
                    clearTimeout(ringingTimer);
                    unsubscribe();
                }
            };
            unsubscribe = this.opts.subscribeToState(onState);
        }
    }

    /**
     * Configure this call from a hangup or reject event. Used by MatrixClient.
     * @param _event - The m.call.hangup event
     */
    public initWithHangup(_event: MatrixEvent): void {
        // perverse as it may seem, sometimes we want to instantiate a call with a
        // hangup message (because when getting the state of the room on load, events
        // come in reverse order and we want to remember that a call has been hung up)
        this.opts.setState(CallState.Ended);
    }

    public shouldAnswerWithMediaType(
        wantedValue: boolean | undefined,
        valueOfTheOtherSide: boolean,
        type: "audio" | "video",
    ): boolean {
        if (wantedValue && !valueOfTheOtherSide) {
            // Known limitation: no supported path to satisfy this media combination yet
            logger.warn(
                `Call ${this.opts.callId} shouldAnswerWithMediaType() unable to answer with ${type} because the other side isn't sending it either.`,
            );
            return false;
        } else if (
            !isNullOrUndefined(wantedValue) &&
            wantedValue !== valueOfTheOtherSide &&
            !this.opts.opponentSupportsSDPStreamMetadata()
        ) {
            logger.warn(
                `Call ${this.opts.callId} shouldAnswerWithMediaType() unable to answer with ${type}=${wantedValue} because the other side doesn't support it. Answering with ${type}=${valueOfTheOtherSide}.`,
            );
            return valueOfTheOtherSide!;
        }
        return wantedValue ?? valueOfTheOtherSide!;
    }

    /**
     * Answer a call.
     */
    public async answer(audio?: boolean, video?: boolean): Promise<void> {
        if (this.opts.getInviteOrAnswerSent()) return;
        // Known limitation: answering without any media is not supported
        if (audio === false && video === false) throw new Error("You CANNOT answer a call without media");

        if (!this.opts.getLocalUsermediaStream() && !this.opts.getWaitForLocalAVStream()) {
            const prevState = this.opts.getState();
            const answerWithAudio = this.opts.shouldAnswerWithMediaType(
                audio,
                this.opts.hasRemoteUserMediaAudioTrack(),
                "audio",
            );
            const answerWithVideo = this.opts.shouldAnswerWithMediaType(
                video,
                this.opts.hasRemoteUserMediaVideoTrack(),
                "video",
            );

            this.opts.setState(CallState.WaitLocalMedia);
            this.opts.setWaitForLocalAVStream(true);

            try {
                const stream = await this.opts.client
                    .getMediaHandler()
                    .getUserMediaStream(answerWithAudio, answerWithVideo);
                this.opts.setWaitForLocalAVStream(false);
                const usermediaFeed = new CallFeed({
                    client: this.opts.client,
                    roomId: this.opts.roomId,
                    userId: this.opts.client.getUserId()!,
                    deviceId: this.opts.client.getDeviceId() ?? undefined,
                    stream,
                    purpose: SDPStreamMetadataPurpose.Usermedia,
                    audioMuted: false,
                    videoMuted: false,
                });

                const feeds = [usermediaFeed];

                const screensharingFeed = this.opts.getLocalScreensharingFeed();
                if (screensharingFeed) {
                    feeds.push(screensharingFeed);
                }

                this.answerWithCallFeeds(feeds);
            } catch (e) {
                if (answerWithVideo) {
                    // Try to answer without video
                    logger.warn(
                        `Call ${this.opts.callId} answer() failed to getUserMedia(), trying to getUserMedia() without video`,
                    );
                    this.opts.setState(prevState);
                    this.opts.setWaitForLocalAVStream(false);
                    await this.answer(answerWithAudio, false);
                } else {
                    this.opts.getUserMediaFailed(<Error>e);
                    return;
                }
            }
        } else if (this.opts.getWaitForLocalAVStream()) {
            this.opts.setState(CallState.WaitLocalMedia);
        }
    }

    public answerWithCallFeeds(callFeeds: CallFeed[]): void {
        if (this.opts.getInviteOrAnswerSent()) return;

        this.queueGotCallFeedsForAnswer(callFeeds);
    }

    /**
     * Hangup a call.
     * @param reason - The reason why the call is being hung up.
     * @param suppressEvent - True to suppress emitting an event.
     */
    public hangup(reason: CallErrorCode, suppressEvent: boolean): void {
        if (this.opts.callHasEnded()) return;

        logger.debug(`Call ${this.opts.callId} hangup() ending call (reason=${reason})`);
        this.opts.terminate(CallParty.Local, reason, !suppressEvent);
        // We don't want to send hangup here if we didn't even get to sending an invite
        if ([CallState.Fledgling, CallState.WaitLocalMedia].includes(this.opts.getState())) return;
        const content: Omit<MCallHangupReject, "version" | "call_id" | "party_id" | "conf_id"> = {};
        // Don't send UserHangup reason to older clients
        const opponentVersion = this.opts.getOpponentVersion();
        if ((opponentVersion && opponentVersion !== 0) || reason !== CallErrorCode.UserHangup) {
            content["reason"] = reason;
        }
        this.opts.sendVoipEvent(EventType.CallHangup, content);
    }

    /**
     * Reject a call
     * This used to be done by calling hangup, but is a separate method and protocol
     * event as of MSC2746.
     */
    public reject(): void {
        if (this.opts.getState() !== CallState.Ringing) {
            throw Error("Call must be in 'ringing' state to reject!");
        }

        if (this.opts.getOpponentVersion() === 0) {
            logger.info(
                `Call ${this.opts.callId} reject() opponent version is less than 1: sending hangup instead of reject (opponentVersion=${this.opts.getOpponentVersion()})`,
            );
            this.hangup(CallErrorCode.UserHangup, true);
            return;
        }

        logger.debug("Rejecting call: " + this.opts.callId);
        this.opts.terminate(CallParty.Local, CallErrorCode.UserHangup, true);
        this.opts.sendVoipEvent(EventType.CallReject, {});
    }

    /**
     * Adds an audio and/or video track - upgrades the call
     * @param audio - should add an audio track
     * @param video - should add an video track
     */
    public async upgradeCall(audio: boolean, video: boolean): Promise<void> {
        // We don't do call downgrades
        if (!audio && !video) return;
        if (!this.opts.opponentSupportsSDPStreamMetadata()) return;

        try {
            logger.debug(`Call ${this.opts.callId} upgradeCall() upgrading call (audio=${audio}, video=${video})`);
            const getAudio = audio || this.opts.hasLocalUserMediaAudioTrack();
            const getVideo = video || this.opts.hasLocalUserMediaVideoTrack();

            // updateLocalUsermediaStream() will take the tracks, use them as
            // replacement and throw the stream away, so it isn't reusable
            const stream = await this.opts.client.getMediaHandler().getUserMediaStream(getAudio, getVideo, false);
            await this.opts.updateLocalUsermediaStream(stream, audio, video);
        } catch (error) {
            logger.error(`Call ${this.opts.callId} upgradeCall() failed to upgrade the call`, error);
            this.opts.emitError(
                new CallError(CallErrorCode.NoUserMedia, "Failed to get camera access: ", <Error>error),
            );
        }
    }

    public gotCallFeedsForInvite(callFeeds: CallFeed[], requestScreenshareFeed = false): void {
        if (this.opts.forwardFeedsToSuccessor(callFeeds)) {
            return;
        }
        if (this.opts.callHasEnded()) {
            this.opts.stopAllMedia();
            return;
        }

        for (const feed of callFeeds) {
            this.opts.pushLocalFeed(feed);
        }

        if (requestScreenshareFeed) {
            this.opts.getPeerConnection()!.addTransceiver("video", {
                direction: "recvonly",
            });
        }

        this.opts.setState(CallState.CreateOffer);

        logger.debug(`Call ${this.opts.callId} gotUserMediaForInvite() run`);
        // Now we wait for the negotiationneeded event
    }

    public async sendAnswer(): Promise<void> {
        const peerConn = this.opts.getPeerConnection()!;
        const answerContent: Omit<MCallAnswer, "version" | "call_id" | "party_id" | "conf_id"> = {
            answer: {
                sdp: peerConn.localDescription!.sdp,
                // type is now deprecated as of Matrix VoIP v1, but
                // required to still be sent for backwards compat
                type: peerConn.localDescription!.type,
            },
            [SDPStreamMetadataKey.name]: this.opts.getLocalSDPStreamMetadata(true),
        };

        answerContent.capabilities = {
            "m.call.transferee": this.opts.client.supportsCallTransfer,
            "m.call.dtmf": false,
        };

        // We have just taken the local description from the peerConn which will
        // contain all the local candidates added so far, so we can discard any candidates
        // we had queued up because they'll be in the answer.
        const discardCount = this.opts.discardDuplicateCandidates();
        logger.info(
            `Call ${this.opts.callId} sendAnswer() discarding ${discardCount} candidates that will be sent in answer`,
        );

        try {
            await this.opts.sendVoipEvent(EventType.CallAnswer, answerContent);
            // If this isn't the first time we've tried to send the answer,
            // we may have candidates queued up, so send them now.
            this.opts.setInviteOrAnswerSent(true);
        } catch (error) {
            // We've failed to answer: back to the ringing state
            this.opts.setState(CallState.Ringing);
            if (error instanceof MatrixError && error.event) this.opts.client.cancelPendingEvent(error.event);

            let code = CallErrorCode.SendAnswer;
            let message = "Failed to send answer";
            if ((<Error>error).name == "UnknownDeviceError") {
                code = CallErrorCode.UnknownDevices;
                message = "Unknown devices present in the room";
            }
            this.opts.emitError(new CallError(code, message, <Error>error));
            throw error;
        }

        // error handler re-throws so this won't happen on error, but
        // we don't want the same error handling on the candidate queue
        this.opts.sendCandidateQueue();
    }

    public queueGotCallFeedsForAnswer(callFeeds: CallFeed[]): void {
        // Ensure only one negotiate/answer event is being processed at a time.
        const chain = this.opts.getResponsePromiseChain();
        if (chain) {
            this.opts.setResponsePromiseChain(chain.then(() => this.gotCallFeedsForAnswer(callFeeds)));
        } else {
            this.opts.setResponsePromiseChain(this.gotCallFeedsForAnswer(callFeeds));
        }
    }

    public async gotCallFeedsForAnswer(callFeeds: CallFeed[]): Promise<void> {
        if (this.opts.callHasEnded()) return;

        this.opts.setWaitForLocalAVStream(false);

        for (const feed of callFeeds) {
            this.opts.pushLocalFeed(feed);
        }

        this.opts.setState(CallState.CreateAnswer);

        let answer: RTCSessionDescriptionInit;
        try {
            this.opts.getRidOfRTXCodecs();
            answer = await this.opts.createAnswer();
        } catch (err) {
            logger.debug(`Call ${this.opts.callId} gotCallFeedsForAnswer() failed to create answer: `, err);
            this.opts.terminate(CallParty.Local, CallErrorCode.CreateAnswer, true);
            return;
        }

        try {
            await this.opts.getPeerConnection()!.setLocalDescription(answer);

            // make sure we're still going
            if (this.opts.callHasEnded()) return;

            this.opts.setState(CallState.Connecting);

            // Allow a short time for initial candidates to be gathered
            await new Promise((resolve) => {
                setTimeout(resolve, 200);
            });

            // make sure the call hasn't ended before we continue
            if (this.opts.callHasEnded()) return;

            this.sendAnswer();
        } catch (err) {
            logger.debug(`Call ${this.opts.callId} gotCallFeedsForAnswer() error setting local description!`, err);
            this.opts.terminate(CallParty.Local, CallErrorCode.SetLocalDescription, true);
            return;
        }
    }

    /**
     * Used by MatrixClient.
     */
    public async onAnswerReceived(event: MatrixEvent): Promise<void> {
        const content = event.getContent<MCallAnswer>();
        logger.debug(`Call ${this.opts.callId} onAnswerReceived() running (hangupParty=${content.party_id})`);

        if (this.opts.callHasEnded()) {
            logger.debug(`Call ${this.opts.callId} onAnswerReceived() ignoring answer because call has ended`);
            return;
        }

        if (this.opts.getOpponentPartyId() !== undefined) {
            logger.info(
                `Call ${this.opts.callId} onAnswerReceived() ignoring answer from party ID ${content.party_id}: we already have an answer/reject from ${this.opts.getOpponentPartyId()}`,
            );
            return;
        }

        this.opts.chooseOpponent(event);
        await this.opts.addBufferedRemoteCandidates(this.opts.getOpponentPartyId()!);

        this.opts.setState(CallState.Connecting);

        const sdpStreamMetadata = SDPStreamMetadataKey.findIn(content);
        if (sdpStreamMetadata) {
            this.opts.updateRemoteSDPStreamMetadata(sdpStreamMetadata);
        } else {
            logger.warn(
                `Call ${this.opts.callId} onAnswerReceived() did not get any SDPStreamMetadata! Can not send/receive multiple streams`,
            );
        }

        try {
            this.opts.setIsSettingRemoteAnswerPending(true);
            await this.opts.getPeerConnection()!.setRemoteDescription(content.answer);
            this.opts.setIsSettingRemoteAnswerPending(false);
            logger.debug(`Call ${this.opts.callId} onAnswerReceived() set remote description: ${content.answer.type}`);
        } catch (e) {
            this.opts.setIsSettingRemoteAnswerPending(false);
            logger.debug(`Call ${this.opts.callId} onAnswerReceived() failed to set remote description`, e);
            this.opts.terminate(CallParty.Local, CallErrorCode.SetRemoteDescription, false);
            return;
        }

        // If the answer we selected has a party_id, send a select_answer event
        // We do this after setting the remote description since otherwise we'd block
        // call setup on it
        const opponentPartyId = this.opts.getOpponentPartyId();
        if (opponentPartyId !== null) {
            try {
                await this.opts.sendVoipEvent(EventType.CallSelectAnswer, {
                    selected_party_id: opponentPartyId!,
                });
            } catch (err) {
                // This isn't fatal, and will just mean that if another party has raced to answer
                // the call, they won't know they got rejected, so we carry on & don't retry.
                logger.warn(`Call ${this.opts.callId} onAnswerReceived() failed to send select_answer event`, err);
            }
        }
    }

    public async onSelectAnswerReceived(event: MatrixEvent): Promise<void> {
        if (this.opts.getDirection() !== CallDirection.Inbound) {
            logger.warn(
                `Call ${this.opts.callId} onSelectAnswerReceived() got select_answer for an outbound call: ignoring`,
            );
            return;
        }

        const selectedPartyId = event.getContent<MCallSelectAnswer>().selected_party_id;

        if (selectedPartyId === undefined || selectedPartyId === null) {
            logger.warn(
                `Call ${this.opts.callId} onSelectAnswerReceived() got nonsensical select_answer with null/undefined selected_party_id: ignoring`,
            );
            return;
        }

        if (selectedPartyId !== this.opts.ourPartyId) {
            logger.info(
                `Call ${this.opts.callId} onSelectAnswerReceived() got select_answer for party ID ${selectedPartyId}: we are party ID ${this.opts.ourPartyId}.`,
            );
            // The other party has picked somebody else's answer
            await this.opts.terminate(CallParty.Remote, CallErrorCode.AnsweredElsewhere, true);
        }
    }
}
