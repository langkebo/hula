/*
Copyright 2015, 2016 OpenMarket Ltd
Copyright 2017 New Vector Ltd
Copyright 2019, 2020 The Matrix.org Foundation C.I.C.
Copyright 2021 - 2022 Šimon Brandner <simon.bra.ag@gmail.com>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * SDP munging and codec helpers for {@link MatrixCall}.
 *
 * Extracted verbatim from `call.ts` (C-8 split): these helpers depend only on
 * the SDP payload, the call id (for logging) and the transceiver map, never on
 * mutable call state.
 */

import { parse as parseSdp, write as writeSdp } from "sdp-transform";

import { logger } from "../logger";
import { SDPStreamMetadataPurpose } from "./callEventTypes";

export enum MediaType {
    AUDIO = "audio",
    VIDEO = "video",
}

export enum CodecName {
    OPUS = "opus",
    // add more as needed
}

// Used internally to specify modifications to codec parameters in SDP
export interface CodecParamsMod {
    mediaType: MediaType;
    codec: CodecName;
    enableDtx?: boolean; // true to enable discontinuous transmission, false to disable, undefined to leave as-is
    maxAverageBitrate?: number; // sets the max average bitrate, or undefined to leave as-is
}

export function getCodecParamMods(isPtt: boolean): CodecParamsMod[] {
    const mods = [
        {
            mediaType: "audio",
            codec: "opus",
            enableDtx: true,
            maxAverageBitrate: isPtt ? 12000 : undefined,
        },
    ] as CodecParamsMod[];

    return mods;
}

// The key of the transceiver map (purpose + media type, separated by ':')
export type TransceiverKey = string;

// generates keys for the map of transceivers
// kind is unfortunately a string rather than MediaType as this is the type of
// track.kind
export function getTransceiverKey(purpose: SDPStreamMetadataPurpose, kind: TransceiverKey): string {
    return purpose + ":" + kind;
}

// Enables DTX (discontinuous transmission) on the given session to reduce
// bandwidth when transmitting silence
export function mungeSdp(description: RTCSessionDescriptionInit, mods: CodecParamsMod[], callId: string): void {
    // The only way to enable DTX at this time is through SDP munging
    const sdp = parseSdp(description.sdp!);

    sdp.media.forEach((media) => {
        const payloadTypeToCodecMap = new Map<number, string>();
        const codecToPayloadTypeMap = new Map<string, number>();
        for (const rtp of media.rtp) {
            payloadTypeToCodecMap.set(rtp.payload, rtp.codec);
            codecToPayloadTypeMap.set(rtp.codec, rtp.payload);
        }

        for (const mod of mods) {
            if (mod.mediaType !== media.type) continue;

            if (!codecToPayloadTypeMap.has(mod.codec)) {
                logger.info(
                    `Call ${callId} mungeSdp() ignoring SDP modifications for ${mod.codec} as it's not present.`,
                );
                continue;
            }

            const extraConfig: string[] = [];
            if (mod.enableDtx !== undefined) {
                extraConfig.push(`usedtx=${mod.enableDtx ? "1" : "0"}`);
            }
            if (mod.maxAverageBitrate !== undefined) {
                extraConfig.push(`maxaveragebitrate=${mod.maxAverageBitrate}`);
            }

            let found = false;
            for (const fmtp of media.fmtp) {
                if (payloadTypeToCodecMap.get(fmtp.payload) === mod.codec) {
                    found = true;
                    fmtp.config += ";" + extraConfig.join(";");
                }
            }
            if (!found) {
                media.fmtp.push({
                    payload: codecToPayloadTypeMap.get(mod.codec)!,
                    config: extraConfig.join(";"),
                });
            }
        }
    });
    description.sdp = writeSdp(sdp);
}

/**
 * This removes all video/rtx codecs from screensharing video
 * transceivers. This is necessary since they can cause problems. Without
 * this the following steps should produce an error:
 *   Chromium calls Firefox
 *   Firefox answers
 *   Firefox starts screen-sharing
 *   Chromium starts screen-sharing
 *   Call crashes for Chromium with:
 *       [96685:23:0518/162603.933321:ERROR:webrtc_video_engine.cc(3296)] RTX codec (PT=97) mapped to PT=96 which is not in the codec list.
 *       [96685:23:0518/162603.933377:ERROR:webrtc_video_engine.cc(1171)] GetChangedRecvParameters called without any video codecs.
 *       [96685:23:0518/162603.933430:ERROR:sdp_offer_answer.cc(4302)] Failed to set local video description recv parameters for m-section with mid='2'. (INVALID_PARAMETER)
 */
export function getRidOfRTXCodecs(transceivers: Map<TransceiverKey, RTCRtpTransceiver>): void {
    // RTCRtpReceiver.getCapabilities and RTCRtpSender.getCapabilities don't seem to be supported on FF before v113
    if (!RTCRtpReceiver.getCapabilities || !RTCRtpSender.getCapabilities) return;

    const screenshareVideoTransceiver = transceivers.get(
        getTransceiverKey(SDPStreamMetadataPurpose.Screenshare, "video"),
    );

    // setCodecPreferences isn't supported on FF (as of v113)
    if (!screenshareVideoTransceiver || !screenshareVideoTransceiver.setCodecPreferences) return;

    const recvCodecs = RTCRtpReceiver.getCapabilities("video")!.codecs;
    const sendCodecs = RTCRtpSender.getCapabilities("video")!.codecs;
    const codecs = [];

    for (const codec of [...recvCodecs, ...sendCodecs]) {
        if (codec.mimeType !== "video/rtx") {
            codecs.push(codec);
            try {
                screenshareVideoTransceiver.setCodecPreferences(codecs);
            } catch (e) {
                // Specifically, Chrome around version 125 and Electron 30 (which is Chromium 124) return an H.264 codec in
                // the sender's capabilities but throw when you try to set it. Hence... this mess.
                // Specifically, that codec is:
                // {
                //   clockRate: 90000,
                //   mimeType: "video/H264",
                //   sdpFmtpLine: "level-asymmetry-allowed=1;packetization-mode=1;profile-level-id=640034",
                // }
                logger.info(
                    "Working around buggy WebRTC impl: claimed to support codec but threw when setting codec preferences",
                    codec,
                    e,
                );
                codecs.pop();
            }
        }
    }
}
