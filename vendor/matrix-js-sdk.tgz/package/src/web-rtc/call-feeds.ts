/*
Copyright 2015, 2016 OpenMarket Ltd
Copyright 2017 New Vector Ltd
Copyright 2019, 2020 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * The set of media feeds belonging to a {@link MatrixCall}.
 *
 * Extracted verbatim from `call.ts` (C-8 split, third batch): the feed set owns
 * the `CallFeed` array and every mutation of it, but knows nothing about the call
 * state machine. Everything it needs from the call (client, room, peer
 * connection, transceiver map, opponent info, `feeds_changed` event) is injected
 * through {@link CallFeedSetOptions}.
 */

import { logger } from "../logger";
import { type MatrixClient } from "../client";
import { type RoomMember } from "../models/room-member";
import { CallFeed } from "./callFeed";
import { getTransceiverKey, type TransceiverKey } from "./call-sdp";
import { type SDPStreamMetadata, SDPStreamMetadataPurpose } from "./callEventTypes";
import { setTracksEnabled, type MatrixCall } from "./call";

export interface CallFeedSetOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    client: MatrixClient;
    roomId: string;
    /** The owning call, passed to `CallFeed` so feeds can find their way back. */
    getCall: () => MatrixCall;
    /** Group calls keep local feeds alive when the underlying call goes away. */
    getGroupCallId: () => string | undefined;
    getPeerConnection: () => RTCPeerConnection | undefined;
    getTransceivers: () => Map<TransceiverKey, RTCRtpTransceiver>;
    getOpponentMember: () => RoomMember | undefined;
    getOpponentDeviceId: () => string | undefined;
    opponentSupportsSDPStreamMetadata: () => boolean;
    getRemoteSDPStreamMetadata: () => SDPStreamMetadata | undefined;
    /** Notify the call that the feed list changed (`CallEvent.FeedsChanged`). */
    onFeedsChanged: (feeds: CallFeed[]) => void;
}

export class CallFeedSet {
    private feeds: CallFeed[] = [];

    public constructor(private readonly opts: CallFeedSetOptions) {}

    public get allFeeds(): Array<CallFeed> {
        return this.feeds;
    }

    public get localFeeds(): Array<CallFeed> {
        return this.feeds.filter((feed) => feed.isLocal());
    }

    public get remoteFeeds(): Array<CallFeed> {
        return this.feeds.filter((feed) => !feed.isLocal());
    }

    public get localUsermediaFeed(): CallFeed | undefined {
        return this.localFeeds.find((feed) => feed.purpose === SDPStreamMetadataPurpose.Usermedia);
    }

    public get localScreensharingFeed(): CallFeed | undefined {
        return this.localFeeds.find((feed) => feed.purpose === SDPStreamMetadataPurpose.Screenshare);
    }

    public get remoteUsermediaFeed(): CallFeed | undefined {
        return this.remoteFeeds.find((feed) => feed.purpose === SDPStreamMetadataPurpose.Usermedia);
    }

    public get remoteScreensharingFeed(): CallFeed | undefined {
        return this.remoteFeeds.find((feed) => feed.purpose === SDPStreamMetadataPurpose.Screenshare);
    }

    public getFeedByStreamId(streamId: string): CallFeed | undefined {
        return this.feeds.find((feed) => feed.stream.id === streamId);
    }

    /** Whether there are no incoming feeds at all. */
    public hasIncomingFeeds(): boolean {
        return this.feeds.some((feed) => !feed.isLocal());
    }

    public pushRemoteFeed(stream: MediaStream): void {
        // Fallback to old behavior if the other side doesn't support SDPStreamMetadata
        if (!this.opts.opponentSupportsSDPStreamMetadata()) {
            this.pushRemoteFeedWithoutMetadata(stream);
            return;
        }

        const userId = this.opts.getOpponentMember()!.userId;
        const metadata = this.opts.getRemoteSDPStreamMetadata()!;
        const purpose = metadata[stream.id].purpose;
        const audioMuted = metadata[stream.id].audio_muted;
        const videoMuted = metadata[stream.id].video_muted;

        if (!purpose) {
            logger.warn(
                `Call ${this.opts.callId} pushRemoteFeed() ignoring stream because we didn't get any metadata about it (streamId=${stream.id})`,
            );
            return;
        }

        if (this.getFeedByStreamId(stream.id)) {
            logger.warn(
                `Call ${this.opts.callId} pushRemoteFeed() ignoring stream because we already have a feed for it (streamId=${stream.id})`,
            );
            return;
        }

        this.feeds.push(
            new CallFeed({
                client: this.opts.client,
                call: this.opts.getCall(),
                roomId: this.opts.roomId,
                userId,
                deviceId: this.opts.getOpponentDeviceId(),
                stream,
                purpose,
                audioMuted,
                videoMuted,
            }),
        );

        this.emitFeedsChanged();

        logger.info(
            `Call ${this.opts.callId} pushRemoteFeed() pushed stream (streamId=${stream.id}, active=${stream.active}, purpose=${purpose})`,
        );
    }

    /**
     * This method is used ONLY if the other client doesn't support sending SDPStreamMetadata
     */
    public pushRemoteFeedWithoutMetadata(stream: MediaStream): void {
        const userId = this.opts.getOpponentMember()!.userId;
        // We can guess the purpose here since the other client can only send one stream
        const purpose = SDPStreamMetadataPurpose.Usermedia;
        const oldRemoteStream = this.feeds.find((feed) => !feed.isLocal())?.stream;

        // Note that we check by ID and always set the remote stream: Chrome appears
        // to make new stream objects when transceiver directionality is changed and the 'active'
        // status of streams change - Dave
        // If we already have a stream, check this stream has the same id
        if (oldRemoteStream && stream.id !== oldRemoteStream.id) {
            logger.warn(
                `Call ${this.opts.callId} pushRemoteFeedWithoutMetadata() ignoring new stream because we already have stream (streamId=${stream.id})`,
            );
            return;
        }

        if (this.getFeedByStreamId(stream.id)) {
            logger.warn(
                `Call ${this.opts.callId} pushRemoteFeedWithoutMetadata() ignoring stream because we already have a feed for it (streamId=${stream.id})`,
            );
            return;
        }

        this.feeds.push(
            new CallFeed({
                client: this.opts.client,
                call: this.opts.getCall(),
                roomId: this.opts.roomId,
                audioMuted: false,
                videoMuted: false,
                userId,
                deviceId: this.opts.getOpponentDeviceId(),
                stream,
                purpose,
            }),
        );

        this.emitFeedsChanged();

        logger.info(
            `Call ${this.opts.callId} pushRemoteFeedWithoutMetadata() pushed stream (streamId=${stream.id}, active=${stream.active})`,
        );
    }

    public pushNewLocalFeed(stream: MediaStream, purpose: SDPStreamMetadataPurpose, addToPeerConnection = true): void {
        const userId = this.opts.client.getUserId()!;

        // Tracks don't always start off enabled, eg. chrome will give a disabled
        // audio track if you ask for user media audio and already had one that
        // you'd set to disabled (presumably because it clones them internally).
        setTracksEnabled(stream.getAudioTracks(), true);
        setTracksEnabled(stream.getVideoTracks(), true);

        if (this.getFeedByStreamId(stream.id)) {
            logger.warn(
                `Call ${this.opts.callId} pushNewLocalFeed() ignoring stream because we already have a feed for it (streamId=${stream.id})`,
            );
            return;
        }

        this.pushLocalFeed(
            new CallFeed({
                client: this.opts.client,
                roomId: this.opts.roomId,
                audioMuted: false,
                videoMuted: false,
                userId,
                deviceId: this.opts.getOpponentDeviceId(),
                stream,
                purpose,
            }),
            addToPeerConnection,
        );
    }

    /**
     * Pushes supplied feed to the call
     * @param callFeed - to push
     * @param addToPeerConnection - whether to add the tracks to the peer connection
     */
    public pushLocalFeed(callFeed: CallFeed, addToPeerConnection = true): void {
        if (this.feeds.some((feed) => callFeed.stream.id === feed.stream.id)) {
            logger.info(
                `Call ${this.opts.callId} pushLocalFeed() ignoring duplicate local stream (streamId=${callFeed.stream.id})`,
            );
            return;
        }

        this.feeds.push(callFeed);

        if (addToPeerConnection) {
            const transceivers = this.opts.getTransceivers();
            for (const track of callFeed.stream.getTracks()) {
                logger.info(
                    `Call ${this.opts.callId} pushLocalFeed() adding track to peer connection (id=${track.id}, kind=${track.kind}, streamId=${callFeed.stream.id}, streamPurpose=${callFeed.purpose}, enabled=${track.enabled})`,
                );

                const tKey = getTransceiverKey(callFeed.purpose, track.kind);
                if (transceivers.has(tKey)) {
                    // we already have a sender, so we re-use it. We try to re-use transceivers as much
                    // as possible because they can't be removed once added, so otherwise they just
                    // accumulate which makes the SDP very large very quickly: in fact it only takes
                    // about 6 video tracks to exceed the maximum size of an Olm-encrypted
                    // Matrix event.
                    const transceiver = transceivers.get(tKey)!;

                    transceiver.sender.replaceTrack(track);
                    // set the direction to indicate we're going to start sending again
                    // (this will trigger the re-negotiation)
                    transceiver.direction = transceiver.direction === "inactive" ? "sendonly" : "sendrecv";
                } else {
                    // create a new one. We need to use addTrack rather addTransceiver for this because firefox
                    // doesn't yet implement RTCRTPSender.setStreams()
                    // (https://bugzilla.mozilla.org/show_bug.cgi?id=1510802) so we'd have no way to group the
                    // two tracks together into a stream.
                    const newSender = this.opts.getPeerConnection()!.addTrack(track, callFeed.stream);

                    // now go & fish for the new transceiver
                    const newTransceiver = this.opts
                        .getPeerConnection()!
                        .getTransceivers()
                        .find((t) => t.sender === newSender);
                    if (newTransceiver) {
                        transceivers.set(tKey, newTransceiver);
                    } else {
                        logger.warn(
                            `Call ${this.opts.callId} pushLocalFeed() didn't find a matching transceiver after adding track!`,
                        );
                    }
                }
            }
        }

        logger.info(
            `Call ${this.opts.callId} pushLocalFeed() pushed stream (id=${callFeed.stream.id}, active=${callFeed.stream.active}, purpose=${callFeed.purpose})`,
        );

        this.emitFeedsChanged();
    }

    /**
     * Removes local call feed from the call and its tracks from the peer
     * connection
     * @param callFeed - to remove
     */
    public removeLocalFeed(callFeed: CallFeed): void {
        const audioTransceiverKey = getTransceiverKey(callFeed.purpose, "audio");
        const videoTransceiverKey = getTransceiverKey(callFeed.purpose, "video");
        const transceivers = this.opts.getTransceivers();

        for (const transceiverKey of [audioTransceiverKey, videoTransceiverKey]) {
            // this is slightly mixing the track and transceiver API but is basically just shorthand.
            // There is no way to actually remove a transceiver, so this just sets it to inactive
            // (or recvonly) and replaces the source with nothing.
            if (transceivers.has(transceiverKey)) {
                const transceiver = transceivers.get(transceiverKey)!;
                if (transceiver.sender) this.opts.getPeerConnection()!.removeTrack(transceiver.sender);
            }
        }

        if (callFeed.purpose === SDPStreamMetadataPurpose.Screenshare) {
            this.opts.client.getMediaHandler().stopScreensharingStream(callFeed.stream);
        }

        this.deleteFeed(callFeed);
    }

    public deleteAllFeeds(): void {
        for (const feed of this.feeds) {
            if (!feed.isLocal() || !this.opts.getGroupCallId()) {
                feed.dispose();
            }
        }

        this.feeds = [];
        this.emitFeedsChanged();
    }

    public deleteFeedByStream(stream: MediaStream): void {
        const feed = this.getFeedByStreamId(stream.id);
        if (!feed) {
            logger.warn(
                `Call ${this.opts.callId} deleteFeedByStream() didn't find the feed to delete (streamId=${stream.id})`,
            );
            return;
        }
        this.deleteFeed(feed);
    }

    private deleteFeed(feed: CallFeed): void {
        feed.dispose();
        this.feeds.splice(this.feeds.indexOf(feed), 1);
        this.emitFeedsChanged();
    }

    private emitFeedsChanged(): void {
        this.opts.onFeedsChanged(this.feeds);
    }
}
