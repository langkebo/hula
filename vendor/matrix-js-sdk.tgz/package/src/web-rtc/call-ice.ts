/*
Copyright 2015, 2016 OpenMarket Ltd
Copyright 2017 New Vector Ltd
Copyright 2019, 2020 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/**
 * Outbound and inbound ICE candidate handling for {@link MatrixCall}.
 *
 * Extracted verbatim from `call.ts` (C-8 split, second batch). The behaviour is
 * intentionally unchanged: outbound candidates are amalgamated into as few
 * `m.call.candidates` events as possible (MSC2746 delay), retried with
 * exponential backoff, and re-queued on failure; inbound candidates that arrive
 * before an opponent has been chosen are buffered per party ID and added once the
 * opponent is picked. All call-specific knowledge (state machine, signalling,
 * hangup, peer connection) is injected through the options objects so this module
 * never touches `MatrixCall`'s internals.
 */

import { logger } from "../logger";
import { type MCallCandidates } from "./callEventTypes";

export interface CallIceCandidateSenderOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    /** Whether the call has already ended: a dead call has nothing left to signal. */
    isCallEnded: () => boolean;
    /**
     * Don't send the candidates yet: either the call is in the ringing state
     * (a failed answer went back to ringing) or the invite/answer has not been
     * sent, in which case the first batch rides along with it.
     */
    isHeldBack: () => boolean;
    /** MSC2746 delay before the first flush: longer for outbound calls. */
    getSendDelayMs: () => number;
    /** Actually send the amalgamated candidates. */
    sendCandidates: (content: Pick<MCallCandidates, "candidates">) => Promise<void>;
    /** A send failed; lets the owner cancel the pending event. */
    onSendError: (error: unknown) => void;
    /** Too many consecutive failed sends ⇒ signalling is broken, give up on the call. */
    onSignallingFailed: (error: Error) => void;
}

/**
 * De-trickles outbound ICE candidates.
 *
 * Candidates trickle in continuously during gathering; we wait `getSendDelayMs()`
 * and send them as one message, because `m.call.candidates` is rate limited in
 * Matrix (in practice it would be better to remove rate limits for `m.call.*`).
 */
export class CallIceCandidateSender {
    private queue: Array<RTCIceCandidate> = [];
    private sendTries = 0;
    private ended = false;
    private timer?: ReturnType<typeof setTimeout>;

    public constructor(private readonly opts: CallIceCandidateSenderOptions) {}

    /** Whether end-of-candidates has been signalled for this generation. */
    public get hasCandidatesEnded(): boolean {
        return this.ended;
    }

    /** ICE restart: a new generation of candidates is about to be gathered. */
    public resetCandidatesEnded(): void {
        this.ended = false;
    }

    /**
     * Queue a candidate to be sent.
     *
     * @param content - The candidate to queue up, or null if candidates have finished
     *                being generated and end-of-candidates should be signalled.
     */
    public queueCandidate(content: RTCIceCandidate | null): void {
        // N.B. this deliberately lets you queue and send blank candidates, which MSC2746
        // currently proposes as the way to indicate that candidate gathering is complete.
        // This will hopefully be changed to an explicit rather than implicit notification
        // shortly.
        if (content) {
            this.queue.push(content);
        } else {
            this.ended = true;
        }

        if (this.opts.isHeldBack()) return;

        if (this.sendTries === 0) {
            this.schedule(this.opts.getSendDelayMs());
        }
    }

    /**
     * Schedule a deferred flush of the queue.
     *
     * The handle is retained so that a pending flush can be cancelled when the
     * call ends (see {@link clearTimer}); otherwise the timer - and the closure
     * it captures - would survive the call and keep it alive until it fired.
     *
     * If a flush is already pending we keep the earliest scheduled one rather
     * than pushing it back: candidates trickle in continuously during gathering,
     * and resetting the delay on each arrival could postpone the flush
     * indefinitely.
     */
    private schedule(delayMs: number): void {
        if (this.timer !== undefined) return;

        this.timer = setTimeout(() => {
            this.timer = undefined;
            void this.send();
        }, delayMs);
    }

    /** Cancel any pending deferred flush. */
    public clearTimer(): void {
        if (this.timer === undefined) return;

        clearTimeout(this.timer);
        this.timer = undefined;
    }

    /**
     * Discard all non-end-of-candidates messages.
     *
     * Call this before sending an invite or answer: the local description being
     * sent already contains every candidate gathered so far.
     *
     * @returns the number of candidate messages that were discarded.
     */
    public discardDuplicateCandidates(): number {
        let discardCount = 0;
        const newQueue: RTCIceCandidate[] = [];

        for (let i = 0; i < this.queue.length; i++) {
            const candidate = this.queue[i];
            if (candidate.candidate === "") {
                newQueue.push(candidate);
            } else {
                discardCount++;
            }
        }

        this.queue = newQueue;

        return discardCount;
    }

    /** Flush the queue, retrying with exponential backoff on failure. */
    public async send(): Promise<void> {
        if (this.queue.length === 0 || this.opts.isCallEnded()) {
            return;
        }

        const candidates = this.queue;
        this.queue = [];
        ++this.sendTries;
        const content: Pick<MCallCandidates, "candidates"> = {
            candidates: candidates.map((candidate) => candidate.toJSON()),
        };
        if (this.ended) {
            // If there are no more candidates, signal this by adding an empty string candidate
            content.candidates.push({
                candidate: "",
            });
        }
        logger.debug(
            `Call ${this.opts.callId} sendCandidateQueue() attempting to send ${candidates.length} candidates`,
        );
        try {
            await this.opts.sendCandidates(content);
            // reset our retry count if we have successfully sent our candidates
            // otherwise queueCandidate() will refuse to try to flush the queue
            this.sendTries = 0;

            // Try to send candidates again just in case we received more candidates while sending.
            void this.send();
        } catch (error) {
            // don't retry this event: we'll send another one later as we might
            // have more candidates by then.
            this.opts.onSendError(error);

            // put all the candidates we failed to send back in the queue
            this.queue.push(...candidates);

            if (this.sendTries > 5) {
                logger.debug(
                    `Call ${this.opts.callId} sendCandidateQueue() failed to send candidates on attempt ${this.sendTries}. Giving up on this call.`,
                    error,
                );

                this.opts.onSignallingFailed(<Error>error);

                return;
            }

            const delayMs = 500 * Math.pow(2, this.sendTries);
            ++this.sendTries;
            logger.debug(
                `Call ${this.opts.callId} sendCandidateQueue() failed to send candidates. Retrying in ${delayMs}ms`,
                error,
            );
            this.schedule(delayMs);
        }
    }
}

export interface CallIceCandidateReceiverOptions {
    /** Call id, used only to prefix log lines. */
    callId: string;
    /** Add candidates to the peer connection (owned by `MatrixCall`). */
    addRemoteCandidates: (candidates: RTCIceCandidate[] | MCallCandidates["candidates"]) => Promise<void>;
}

/**
 * Buffers inbound ICE candidates until an opponent has been chosen.
 *
 * Candidates can arrive eagerly, before the user answers, so we hold them per
 * party ID and then add the ones from the party we picked (see
 * {@link addBuffered}).
 */
export class CallIceCandidateReceiver {
    private buffer = new Map<string, MCallCandidates["candidates"]>();

    public constructor(private readonly opts: CallIceCandidateReceiverOptions) {}

    /** Buffer candidates from `partyId` until {@link addBuffered} picks the opponent. */
    public bufferCandidates(partyId: string, candidates: MCallCandidates["candidates"]): void {
        logger.info(
            `Call ${this.opts.callId} onRemoteIceCandidatesReceived() buffering ${candidates.length} candidates until we pick an opponent`,
        );
        const bufferedCandidates = this.buffer.get(partyId) || [];
        bufferedCandidates.push(...candidates);
        this.buffer.set(partyId, bufferedCandidates);
    }

    /**
     * Add the buffered candidates belonging to `partyId` and drop the rest.
     *
     * Called right after an opponent is chosen via an invite or answer.
     */
    public async addBuffered(partyId: string): Promise<void> {
        const bufferedCandidates = this.buffer.get(partyId);
        if (bufferedCandidates) {
            logger.info(
                `Call ${this.opts.callId} addBufferedIceCandidates() adding ${bufferedCandidates.length} buffered candidates for opponent ${partyId}`,
            );
            await this.opts.addRemoteCandidates(bufferedCandidates);
        }
        this.buffer.clear();
    }
}
