/*
Copyright 2026 The TJG Project.

SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-Element-Commercial
*/

/**
 * 本构建**不提供**的公开入口（"死入口"）清单。
 *
 * 这些方法在 `MatrixClient` 上仍然存在（类型签名是真的，调用方不会编译失败），但一调就抛错 ——
 * 以前每个方法体都内联一段 6~9 行的 `new Error("client.xxx() is not supported: ...")`，
 * 14 个方法合计占掉上百行。真正有价值的是**文案本身**（它告诉调用方替代入口），
 * 而不是那段重复的拼接代码，于是把文案收进这张表，方法体只剩一行委托。
 *
 * 为什么集中在一处而不是散落在各方法里：
 * - 文案是"这一版为什么不提供"的唯一出处，集中后可以一眼审阅全部死入口；
 * - 拼接格式（`client.<name>() <detail>`）只有一处实现，不会出现某个方法漏写前缀；
 * - `MatrixClient` 的体积压力直接来自这些重复代码块，移走即净减。
 *
 * ⚠️ 新增一条前先确认：**真的没有可用的替代入口**时才登记。若只是"暂时没接"，
 * 应该补实现而不是加到这里 —— `quality:fake-implementations` 守的是"假成功"，
 * 这张表守的是"明确失败"，两者都不能用来掩盖欠账。
 */

/** 每个键 = `MatrixClient` 上的方法名；值 = 拼在 `client.<name>() ` 之后的说明。 */
const UNSUPPORTED_ENTRY_DETAILS = {
    setCryptoAlgorithm:
        "is not supported: the room encryption algorithm is fixed to m.megolm.v1.aes-sha2 by the Rust crypto " +
        "backend and cannot be configured.",
    initCrypto:
        "is not supported: encryption is initialised by initRustCrypto() during startClient(). Pass " +
        "cryptoCallbacks/store to createClient() instead.",
    stopCrypto:
        "is not supported: the crypto backend's lifecycle is tied to the client. Call client.stopClient() instead.",
    deleteCryptoStore:
        "is not implemented: no backend method deletes the persisted Rust crypto store. Clear the rust-crypto " +
        "IndexedDB database directly if you really need this.",
    isRotationNeeded:
        "is not implemented: rotation state is only available asynchronously. Use " +
        "`await client.getKeyRotationManager().getStatus()` and inspect `status.next_rotation_at`.",
    getRotationPeriod:
        "is not implemented: the rotation period is only available asynchronously. Use " +
        "`await client.getKeyRotationManager().getStatus()`.",
    setRotationPeriod:
        "is not implemented: use the asynchronous " +
        "`client.getKeyRotationManager().updateConfig({ rotation_period_ms })` instead.",
    getLastRotationTime:
        "is not implemented: the last rotation timestamp is only available asynchronously. Use " +
        "`await client.getKeyRotationManager().getStatus()`.",
    claimKeys:
        "is not implemented in this build: one-time keys are claimed internally by the Rust crypto backend. Use " +
        "client.claimOneTimeKeys(devices) or client.getCryptoKeysManager().claimKeys(devices, algorithm) instead.",
    getUserStorageUsage: "is not implemented: the homeserver exposes no per-user storage-usage endpoint in this build.",
    shareRoomKey:
        "is not implemented in this build: room-key sharing is driven by the Rust crypto backend. To share room " +
        "*history* with a user, use client.getCrypto()?.shareRoomHistoryWithUser(roomId, userId).",
    getSharedWithUsers:
        "is not implemented: the Rust crypto backend does not expose per-room key-sharing recipients. Room key " +
        "sharing is decided internally by the sharing strategy.",
    hasSharedKeyWithUser:
        "is not implemented: the Rust crypto backend does not expose per-room key-sharing recipients.",
    waitForPendingRequests:
        "is not implemented: this SDK does not track in-flight requests globally. Await the specific request " +
        "promises (or client.waitForSync()) instead.",
} as const;

/** 可登记的入口名（= `UNSUPPORTED_ENTRY_DETAILS` 的键），写错方法名是编译错误。 */
type UnsupportedEntryName = keyof typeof UNSUPPORTED_ENTRY_DETAILS;

/** 拼出统一格式的错误文案。 */
function unsupportedEntryMessage(name: UnsupportedEntryName): string {
    return `client.${name}() ${UNSUPPORTED_ENTRY_DETAILS[name]}`;
}

/** 同步入口的显式失败：直接抛出，调用方拿不到任何"看起来成功"的返回值。 */
export function throwUnsupportedEntry(name: UnsupportedEntryName): never {
    throw new Error(unsupportedEntryMessage(name));
}

/** 异步入口的显式失败：reject，而不是 `resolve(undefined)`。 */
export function rejectUnsupportedEntry(name: UnsupportedEntryName): Promise<never> {
    return Promise.reject(new Error(unsupportedEntryMessage(name)));
}
