/*
Copyright 2023 The Matrix.org Foundation C.I.C.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

import { MXID_PATTERN } from "../models/room-member";
import { deepCompare } from "../common/collections";
import { type LivekitFocusSelection } from "./LivekitTransport";
import { slotDescriptionToId, slotIdToDescription, type SlotDescription } from "./MatrixRTCSession";
import type { RTCCallIntent, Transport } from "./types";
import { type MatrixEvent, type IContent } from "../models/event";
import { type RelationType } from "../@types/event";
import { sha256 } from "../digest";
import { encodeUnpaddedBase64 } from "../base64";
import { type Logger } from "../logger";

/**
 * The default duration in milliseconds that a membership is considered valid for.
 * Ordinarily the client responsible for the session will update the membership before it expires.
 * We use this duration as the fallback case where stale sessions are present for some reason.
 */
export const DEFAULT_EXPIRE_DURATION = 1000 * 60 * 60 * 4;

type CallScope = "m.room" | "m.user";
type Member = {
    user_id: string;
    device_id: string;
    /**
     * The id used on the media backend.
     * (With livekit this is the participant identity on the LK SFU)
     * This can be a UUID but right now it is `${this.matrixEventData.sender}:${data.device_id}`.
     */
    id: string;
};

export interface RtcMembershipData extends IContent {
    slot_id: string;
    member: Member;
    "m.relates_to"?: {
        event_id: string;
        rel_type: RelationType.Reference;
    };
    application: {
        type: string;
        // other application specific keys
        [key: string]: unknown;
    };
    rtc_transports: Transport[];
    versions: string[];
    msc4354_sticky_key?: string;
    sticky_key?: string;
}

type MembershipApplication = {
    type?: string;
    [key: string]: unknown;
};

const checkRtcMembershipData = (
    data: IContent,
    errors: string[],
    referenceUserId: string,
): data is RtcMembershipData => {
    const prefix = " - ";

    // required fields
    if (typeof data.slot_id !== "string") {
        errors.push(prefix + "slot_id must be string");
    } else {
        if (data.slot_id.split("#").length !== 2) errors.push(prefix + 'slot_id must include exactly one "#"');
    }
    if (typeof data.member !== "object" || data.member === null) {
        errors.push(prefix + "member must be an object");
    } else {
        const member = data.member as Partial<Member>;
        if (typeof member.user_id !== "string") errors.push(prefix + "member.user_id must be string");
        else if (!MXID_PATTERN.test(member.user_id)) errors.push(prefix + "member.user_id must be a valid mxid");
        // This is not what the spec enforces but there currently are no rules what power levels are required to
        // send a m.rtc.member event for a other user. So we add this check for simplicity and to avoid possible attacks until there
        // is a proper definition when this is allowed.
        else if (member.user_id !== referenceUserId) errors.push(prefix + "member.user_id must match the sender");
        if (typeof member.device_id !== "string") errors.push(prefix + "member.device_id must be string");
        if (typeof member.id !== "string") errors.push(prefix + "member.id must be string");
    }
    if (typeof data.application !== "object" || data.application === null) {
        errors.push(prefix + "application must be an object");
    } else {
        const application = data.application as MembershipApplication;
        if (typeof application.type !== "string") {
            errors.push(prefix + "application.type must be a string");
        } else {
            if (application.type.includes("#")) errors.push(prefix + 'application.type must not include "#"');
        }
    }
    if (data.rtc_transports === undefined || !Array.isArray(data.rtc_transports)) {
        errors.push(prefix + "rtc_transports must be an array");
    } else {
        // validate that each transport has at least a string 'type'
        for (const t of data.rtc_transports) {
            if (
                typeof t !== "object" ||
                t === null ||
                typeof (t as Record<string, unknown>) /* Dynamic: validating untyped transport object */.type !==
                    "string"
            ) {
                errors.push(prefix + "rtc_transports entries must be objects with a string type");
                break;
            }
        }
    }
    if (data.versions === undefined || !Array.isArray(data.versions)) {
        errors.push(prefix + "versions must be an array");
    } else if (!data.versions.every((v) => typeof v === "string")) {
        errors.push(prefix + "versions must be an array of strings");
    }

    // optional fields
    if ((data.sticky_key ?? data.msc4354_sticky_key) === undefined) {
        errors.push(prefix + "sticky_key or msc4354_sticky_key must be a defined");
    }
    if (data.sticky_key !== undefined && typeof data.sticky_key !== "string") {
        errors.push(prefix + "sticky_key must be a string");
    }
    if (data.msc4354_sticky_key !== undefined && typeof data.msc4354_sticky_key !== "string") {
        errors.push(prefix + "msc4354_sticky_key must be a string");
    }
    if (
        data.sticky_key !== undefined &&
        data.msc4354_sticky_key !== undefined &&
        data.sticky_key !== data.msc4354_sticky_key
    ) {
        errors.push(prefix + "sticky_key and msc4354_sticky_key must be equal if both are defined");
    }
    if (data["m.relates_to"] !== undefined) {
        const rel = data["m.relates_to"] as RtcMembershipData["m.relates_to"];
        if (typeof rel !== "object" || rel === null) {
            errors.push(prefix + "m.relates_to must be an object if provided");
        } else {
            if (typeof rel.event_id !== "string") errors.push(prefix + "m.relates_to.event_id must be a string");
            if (rel.rel_type !== "m.reference") errors.push(prefix + "m.relates_to.rel_type must be m.reference");
        }
    }

    return errors.length === 0;
};

/**
 * MSC4143 (MatrixRTC) session membership data.
 * Represents the `session` in the memberships section of an m.call.member event as it is on the wire.
 **/
export type SessionMembershipData = IContent & {
    /**
     * The RTC application defines the type of the RTC session.
     */
    application: string;

    /**
     * The id of this session.
     * A session can never span over multiple rooms so this id is to distinguish between
     * multiple session in one room. A room wide session that is not associated with a user,
     * and therefore immune to creation race conflicts, uses the `call_id: ""`.
     */
    call_id: string;

    /**
     * The Matrix device ID of this session. A single user can have multiple sessions on different devices.
     */
    device_id: string;

    /**
     * The focus selection system this user/membership is using.
     */
    focus_active: LivekitFocusSelection;

    /**
     * A list of possible foci this user knows about. One of them might be used based on the focus_active
     * selection system.
     */
    foci_preferred: Transport[];

    /**
     * Optional field that contains the creation of the session. If it is undefined the creation
     * is the `origin_server_ts` of the event itself. For updates to the event this property tracks
     * the `origin_server_ts` of the initial join event.
     *  - If it is undefined it can be interpreted as a "Join".
     *  - If it is defined it can be interpreted as an "Update"
     */
    created_ts?: number;

    // Application specific data

    /**
     * If the `application` = `"m.call"` this defines if it is a room or user owned call.
     * There can always be one room scoped call but multiple user owned calls (breakout sessions)
     */
    scope?: CallScope;

    /**
     * Optionally we allow to define a delta to the `created_ts` that defines when the event is expired/invalid.
     * This should be set to multiple hours. The only reason it exist is to deal with failed delayed events.
     * (for example caused by a homeserver crashes)
     **/
    expires?: number;

    /**
     * The intent of the call from the perspective of this user. This may be an audio call, video call or
     * something else.
     */
    "m.call.intent"?: RTCCallIntent;
    /**
     * The sticky key in case of a sticky event. This string encodes the application + device_id indicating the used slot + device.
     */
    msc4354_sticky_key?: string;

    /**
     * The id used on the media backend.
     * (With livekit this is the participant identity on the LK SFU)
     * This can be a UUID but right now it is `${this.matrixEventData.sender}:${data.device_id}`.
     *
     * It is compleatly valid to not set this field. Other clients will treat `undefined` as `${this.matrixEventData.sender}:${data.device_id}`
     */
    membershipID?: string;
};

const checkSessionsMembershipData = (data: IContent, errors: string[]): data is SessionMembershipData => {
    const prefix = " - ";
    if (typeof data.device_id !== "string") errors.push(prefix + "device_id must be string");
    if (typeof data.call_id !== "string") errors.push(prefix + "call_id must be string");
    if (typeof data.application !== "string") errors.push(prefix + "application must be a string");
    const focusActive = data.focus_active as { type?: string } | undefined;
    if (typeof focusActive?.type !== "string") errors.push(prefix + "focus_active.type must be a string");
    if (data.focus_active === undefined) {
        errors.push(prefix + "focus_active has an invalid type");
    }
    if (
        data.foci_preferred !== undefined &&
        !(
            Array.isArray(data.foci_preferred) &&
            data.foci_preferred.every(
                (f: Transport) => typeof f === "object" && f !== null && typeof f.type === "string",
            )
        )
    ) {
        errors.push(prefix + "foci_preferred must be an array of transport objects");
    }
    // optional parameters
    if (data.created_ts !== undefined && typeof data.created_ts !== "number") {
        errors.push(prefix + "created_ts must be number");
    }

    // application specific data (we first need to check if they exist)
    if (data.scope !== undefined && typeof data.scope !== "string") errors.push(prefix + "scope must be string");

    if (data["m.call.intent"] !== undefined && typeof data["m.call.intent"] !== "string") {
        errors.push(prefix + "m.call.intent must be a string");
    }

    return errors.length === 0;
};

type MembershipData = { kind: "rtc"; data: RtcMembershipData } | { kind: "session"; data: SessionMembershipData };
// Known limitation: rename to RtcMembership after legacy SessionMembership support is removed from this file.
export class CallMembership {
    public static equal(a?: CallMembership, b?: CallMembership): boolean {
        return deepCompare(a?.membershipData, b?.membershipData);
    }

    private logger?: Logger;
    /** The parsed data from the Matrix event.
     * To access checked eventId and sender from the matrixEvent.
     * Class construction will fail if these values cannot get obtained. */
    private readonly matrixEventData: { eventId: string; sender: string; ts: number };

    public constructor(
        /** The required parts of the Matrix event that this membership is based on */
        matrixEvent: Pick<MatrixEvent, "getId" | "getSender" | "getTs">,

        /**
         * The type checked membership data {data: (content of the matrix event), kind: (type hint)}
         *
         */
        private readonly membershipData: MembershipData,

        /**
         *
         * Anonymized identity to use with the RTC backend.
         *
         * The rtcBackendIdentity is a hashed version of all the identity parts:
         * `sha256(${this.userId}|${this.deviceId}|${this.memberId})`
         *
         * It is used to anonymize the identity of the user in the RTC backend.
         */
        public readonly rtcBackendIdentity: string,
        /**
         * The constructor will automatically create a properly tagged child logger instance.
         */
        logger?: Logger,
    ) {
        const [eventId, sender, ts] = [matrixEvent.getId(), matrixEvent.getSender(), matrixEvent.getTs()];
        if (eventId === undefined) throw new Error("parentEvent is missing eventId field");
        if (sender === undefined) throw new Error("parentEvent is missing sender field");

        this.matrixEventData = { eventId, sender, ts };

        this.logger = logger?.getChild(`[CallMembership ${sender}:${this.deviceId}]`);
    }

    /**
     * sha256(`${this.userId}|${this.deviceId}|${this.memberId}`) for sticky events (kind = rtc)
     * `${this.userId}:${this.deviceId}` for state events (kind = session)
     */
    public static async computeRtcBackendIdentity(
        matrixEvent: Pick<MatrixEvent, "getSender">,
        membershipData: MembershipData,
    ): Promise<string> {
        const { kind, data } = membershipData;
        switch (kind) {
            case "rtc": {
                return CallMembership.computeRtcIdentityRaw(data.member.user_id, data.member.device_id, data.member.id);
            }
            case "session":
                return `${matrixEvent.getSender()}:${data.device_id}`;
        }
    }

    public static async computeRtcIdentityRaw(userId: string, deviceId: string, memberId: string): Promise<string> {
        return encodeUnpaddedBase64(await sha256(`${userId}|${deviceId}|${memberId}`));
    }

    public static membershipDataFromMatrixEvent(matrixEvent: MatrixEvent): MembershipData {
        const [eventId, sender, content] = [matrixEvent.getId(), matrixEvent.getSender(), matrixEvent.getContent()];

        if (eventId === undefined) throw new Error("parentEvent is missing eventId field");
        if (sender === undefined) throw new Error("parentEvent is missing sender field");

        const sessionErrors: string[] = [];
        const rtcErrors: string[] = [];
        if (checkSessionsMembershipData(content, sessionErrors)) {
            return { kind: "session", data: content };
        } else if (checkRtcMembershipData(content, rtcErrors, sender)) {
            return { kind: "rtc", data: content };
        } else {
            const details =
                sessionErrors.length < rtcErrors.length
                    ? `Does not match MSC4143 m.call.member:\n${sessionErrors.join("\n")}\n\n`
                    : `Does not match MSC4143 m.rtc.member:\n${rtcErrors.join("\n")}\n\n`;
            const json = "\nevent:\n" + JSON.stringify(content).replaceAll('"', "'");
            throw Error(`unknown CallMembership data.\n` + details + json);
        }
    }

    public get userId(): string {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.member.user_id;
            case "session":
            default:
                return this.matrixEventData.sender;
        }
    }

    public get eventId(): string {
        return this.matrixEventData.eventId;
    }

    /**
     * The ID of the MatrixRTC slot that this membership belongs to (format `{application}#{id}`).
     * This is computed in case SessionMembershipData is used.
     */
    public get slotId(): string {
        const { kind, data } = this.membershipData;
        if (data.application === "m.call") {
            switch (kind) {
                case "rtc":
                    return data.slot_id;
                case "session":
                default: {
                    const [application, id] = [this.application, data.call_id];

                    // INFO_SLOT_ID_LEGACY_CASE  (search for all occurances of this INFO to get the full picture)
                    // The spec got changed to use `"ROOM"` instead of `""` empyt string for the implicit default call.
                    // State events still are sent with `""` however. To find other events that should end up in the same call,
                    // we use the slotId.
                    // Since the CallMembership is the public representation of a rtc.member event, we just pretend it is a
                    // "ROOM" slotId/call_id.
                    // This makes all the remote members work with just this simple trick.
                    //
                    // We of course now need to be careful when sending legacy events (state events)
                    // They get a slotDescription containing "ROOM" since this is what we use starting at the time this comment
                    // is commited.
                    //
                    // See the Other INFO_SLOT_ID_LEGACY_CASE comments to see where we revert back to "" just before sending the event.
                    let compatibilityAdaptedId: string;
                    if (id === "") {
                        compatibilityAdaptedId = "ROOM";
                        this.logger?.info("use slotId compat hack emptyString -> ROOM");
                    } else {
                        compatibilityAdaptedId = id;
                    }
                    return slotDescriptionToId({
                        application,
                        id: compatibilityAdaptedId,
                    });
                }
            }
        }

        this.logger?.info("NOT using slotId compat hack emptyString -> ROOM");
        // This is what the function should look like for any other application that did not
        // go through a `""`=> `"ROOM"` rename
        switch (kind) {
            case "rtc":
                return data.slot_id;
            case "session":
            default: {
                const [application, id] = [this.application, data.call_id];
                return slotDescriptionToId({ application, id });
            }
        }
    }

    public get deviceId(): string {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.member.device_id;
            case "session":
            default:
                return data.device_id;
        }
    }

    public get callIntent(): RTCCallIntent | undefined {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc": {
                const intent = data.application["m.call.intent"];
                if (typeof intent === "string") {
                    return intent;
                }
                this.logger?.warn("RTC membership has invalid m.call.intent");
                return undefined;
            }
            case "session":
            default:
                return data["m.call.intent"];
        }
    }

    /**
     * Parsed `slot_id` (format `{application}#{id}`) into its components (application and id).
     */
    public get slotDescription(): SlotDescription {
        return slotIdToDescription(this.slotId);
    }

    public get application(): string {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.application.type;
            case "session":
            default:
                return data.application;
        }
    }
    public get applicationData(): { type: string; [key: string]: unknown } {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.application;
            case "session":
            default:
                return { type: data.application, "m.call.intent": data["m.call.intent"] };
        }
    }
    /**
     * This computes the membership ID for the membership.
     * For the sticky event based rtcSessionData this is trivial it is `member.id`.
     * This is not supposed to be used to identity on an rtc backend. This is just a nouance for
     * a generated (sha256) anonymised identity. Only send `rtcBackendIdentity` to any rtc backend service.
     *
     * For the legacy sessionMemberEvents it is a bit more complex. Here we sometimes do not have this data
     * in the event content and we expected the SFU and the client to use `${this.matrixEventData.sender}:${data.device_id}`.
     *
     * So if there is no membershipID we use the hard coded jwt id default (`${this.matrixEventData.sender}:${data.device_id}`)
     * value (used until version 0.16.0)
     *
     * It is also possible for a session event to set a custom membershipID. in that case this will be used.
     */
    public get memberId(): string {
        // the createdTs behaves equivalent to the membershipID.
        // we only need the field for the legacy member events where we needed to update them
        // synapse ignores sending state events if they have the same content.
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.member.id;
            case "session":
            default:
                return (
                    // best case we have a client already publishing the right custom membershipId
                    data.membershipID ??
                    // alternativly we use the hard coded jwt id defuatl value (used until version 0.16.0)
                    `${this.matrixEventData.sender}:${data.device_id}`
                );
        }
    }

    public createdTs(): number {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                // Known limitation: should read the referenced relation event to obtain the canonical created_ts.
                return this.matrixEventData.ts;
            case "session":
            default:
                return data.created_ts ?? this.matrixEventData.ts;
        }
    }

    /**
     * Gets the absolute expiry timestamp of the membership.
     * @returns The absolute expiry time of the membership as a unix timestamp in milliseconds or undefined if not applicable
     */
    public getAbsoluteExpiry(): number | undefined {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return undefined;
            case "session":
            default:
                // Known limitation: this should be calculated directly from MatrixRTCSession join configuration.
                return this.createdTs() + (data.expires ?? DEFAULT_EXPIRE_DURATION);
        }
    }

    /**
     * @returns The number of milliseconds until the membership expires or undefined if applicable
     */
    public getMsUntilExpiry(): number | undefined {
        const { kind } = this.membershipData;
        switch (kind) {
            case "rtc":
                return undefined;
            case "session":
            default:
                // Assume that local clock is sufficiently in sync with other clocks in the distributed system.
                // We used to try and adjust for the local clock being skewed, but there are cases where this is not accurate.
                // The current implementation allows for the local clock to be -infinity to +MatrixRTCSession.MEMBERSHIP_EXPIRY_TIME/2
                return this.getAbsoluteExpiry()! - Date.now();
        }
    }

    /**
     * @returns true if the membership has expired, otherwise false
     */
    public isExpired(): boolean {
        const { kind } = this.membershipData;
        switch (kind) {
            case "rtc":
                return false;
            case "session":
            default:
                return this.getMsUntilExpiry()! <= 0;
        }
    }

    /**
     * ## RTC Membership
     * Gets the primary transport to use for this RTC membership (m.rtc.member).
     * This will return the primary transport that is used by this call membership to publish their media.
     * Directly relates to the `rtc_transports` field.
     *
     * ## Legacy session membership
     * In case of a legacy session membership (m.call.member) this will return the selected transport where
     * media is published. How this selection happens depends on the `focus_active` field of the session membership.
     * If the `focus_selection` is `oldest_membership` this will return the transport of the oldest membership
     * in the room (based on the `created_ts` field of the session membership).
     * If the `focus_selection` is `multi_sfu` it will return the first transport of the `foci_preferred` list.
     * (`multi_sfu` is equivalent to how `m.rtc.member` `rtc_transports` work).
     * @param oldestMembership For backwards compatibility with session membership (legacy). Unused in case of RTC membership.
     * Always required to make the consumer not care if it deals with RTC or session memberships.
     * @returns The transport this membership uses to publish media or undefined if no transport is available.
     */
    public getTransport(oldestMembership: CallMembership): Transport | undefined {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.rtc_transports[0];
            case "session":
                switch (data.focus_active.focus_selection) {
                    case "multi_sfu":
                        return data.foci_preferred[0];
                    case "oldest_membership":
                        if (CallMembership.equal(this, oldestMembership)) return data.foci_preferred[0];
                        if (oldestMembership !== undefined) return oldestMembership.getTransport(oldestMembership);
                        break;
                }
        }
        return undefined;
    }
    /**
     * The value of the `rtc_transports` field for RTC memberships (m.rtc.member).
     * Or the value of the `foci_preferred` field for legacy session memberships (m.call.member).
     */
    public get transports(): Transport[] {
        const { kind, data } = this.membershipData;
        switch (kind) {
            case "rtc":
                return data.rtc_transports;
            case "session":
            default:
                return data.foci_preferred;
        }
    }
    public get kind(): MembershipData["kind"] {
        return this.membershipData.kind;
    }
}
