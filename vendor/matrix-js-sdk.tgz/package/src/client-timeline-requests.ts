import { Filter } from "./filter";
import type { IRoomEventFilter } from "./filter";
import { Direction } from "./models/event-timeline";
import * as utils from "./utils";

export function buildMessagesRequestPath(roomId: string): string {
    return utils.encodeUri("/rooms/$roomId/messages", { $roomId: roomId });
}

export function buildThreadListRequestPath(roomId: string): string {
    return utils.encodeUri("/rooms/$roomId/threads", { $roomId: roomId });
}

export function buildEventContextPath(roomId: string, eventId: string): string {
    return utils.encodeUri("/rooms/$roomId/context/$eventId", {
        $roomId: roomId,
        $eventId: eventId,
    });
}

export function buildEventContextParams(lazyLoadMembers: boolean): Record<string, string | string[]> {
    const params: Record<string, string | string[]> = {
        limit: "0",
    };
    if (lazyLoadMembers) {
        params.filter = JSON.stringify(Filter.LAZY_LOADING_MESSAGES_FILTER);
    }
    return params;
}

/**
 * Default number of events requested for `/messages` pagination when the caller
 * does not specify a limit.
 *
 * Note this applies to the `/messages` endpoint only - the `/notifications`
 * pagination path keeps its own default (see `paginateEventTimelineRequest`), as
 * the two endpoints are independent and should be free to diverge.
 */
export const DEFAULT_MESSAGES_LIMIT = 30;

export function buildMessagesRequestParams({
    fromToken,
    limit,
    dir,
    lazyLoadMembers,
    timelineFilter,
}: {
    fromToken: string | null;
    limit?: number | undefined;
    dir: Direction;
    lazyLoadMembers: boolean;
    timelineFilter?: IRoomEventFilter;
}): Record<string, string> {
    const params: Record<string, string> = { dir };

    // `limit` is optional on purpose: omitting it lets the homeserver apply its own
    // default. Callers with no limit preference must not be forced to send one.
    if (limit !== undefined) {
        params.limit = limit.toString();
    }

    if (fromToken) {
        params.from = fromToken;
    }

    let filter: IRoomEventFilter | null = null;
    if (lazyLoadMembers) {
        // create a shallow copy of LAZY_LOADING_MESSAGES_FILTER
        filter = Object.assign({}, Filter.LAZY_LOADING_MESSAGES_FILTER);
    }

    if (timelineFilter) {
        filter = filter || {};
        Object.assign(filter, timelineFilter);
    }

    if (filter) {
        params.filter = JSON.stringify(filter);
    }

    return params;
}

export function buildThreadListRequestParams({
    fromToken,
    limit,
    dir,
    include,
}: {
    fromToken: string | null;
    limit: number;
    dir: Direction;
    include: string;
}): Record<string, string> {
    /**
     * ⚠️ 2026-10-21：**不再发送 `filter`**。
     *
     * 线程列表端点（`GET /_matrix/client/v1/rooms/{room_id}/threads`）的服务端契约只有
     * `from` / `limit` / `include` / `dir`（后端 `handlers/thread.rs:95-101` 的 `ListQuery`
     * 与 SDK 自己的 `docs/api-contract/thread.md:71` 一致，都没有 `filter`）。
     * 以前这里会把 `lazyLoadMembers` 与 `timelineFilter` 合成一个 `filter` 查询串发出去 ——
     * 服务端 serde 直接忽略，**惰性加载成员与时间线过滤在线程列表上从来没有生效过**。
     *
     * 保留 `lazyLoadMembers` / `timelineFilter` 两个**入参**（`EventManager` 的公开签名依赖它们，
     * 且调用方 `models/room.ts` / `timeline/index.ts` 仍在传），但不再让它们伪装成"已下发的过滤条件"。
     * 真正的线程过滤需要服务端支持（见 backend-issues §R 的 B-33）。
     */
    const params: Record<string, string> = {
        limit: limit.toString(),
        dir,
        include,
    };

    if (fromToken) {
        params.from = fromToken;
    }

    return params;
}
